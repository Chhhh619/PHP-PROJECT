<?php
/**
author : Cheng Jun Yang
 */

class Database {
    private static $instance = null;
    private $connection;
    
    
    private $host = 'localhost';
    private $database = 'zuspresso_db';
    private $username = 'root';
    private $password = '';  
    private $charset = 'utf8mb4';
    
    private function __construct() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->database};charset={$this->charset}";
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ];
            
            $this->connection = new PDO($dsn, $this->username, $this->password, $options);
            
            echo "<!-- Database connected successfully -->\n";
            
        } catch (PDOException $e) {
           
            error_log("Database connection failed: " . $e->getMessage());
            die("Database connection failed. Please check your configuration.");
        }
    }
    
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    
    public function testConnection() {
        try {
            $stmt = $this->connection->query("SELECT 'Database connected!' as message");
            return $stmt->fetch()['message'];
        } catch (Exception $e) {
            return "Connection test failed: " . $e->getMessage();
        }
    }
}

?>