<?php
/**
author : Cheng Jun Yang
 */

session_start();
require_once '../database.php';
require_once '../model/UserFactory.php';

class UserAPI {
    private $db;
    private $userFactory;
    private $method;
    private $endpoint;
    
    public function __construct() {
        header('Content-Type: application/json');
        $this->setSecurityHeaders();
        
        try {
            $this->db = Database::getInstance()->getConnection();
            $this->userFactory = new UserFactory($this->db);
            $this->method = $_SERVER['REQUEST_METHOD'];
            $this->endpoint = $this->parseEndpoint();
        } catch (Exception $e) {
            $this->sendResponse(['error' => 'Service unavailable'], 503);
        }
    }
    
    public function processRequest() {
        try {
           
            if ($this->method === 'OPTIONS') {
                $this->sendResponse(['status' => 'OK'], 200);
            }
            
         
            if (!in_array($this->endpoint, ['login', 'register'])) {
                if (!$this->isAuthenticated()) {
                    $this->sendResponse(['error' => 'Authentication required'], 401);
                }
            }
            
           
            switch ($this->endpoint) {
                case 'users':
                    $this->handleUsersEndpoint();
                    break;
                case 'profile':
                    $this->handleProfileEndpoint();
                    break;
                case 'login':
                    $this->handleLoginEndpoint();
                    break;
                case 'register':
                    $this->handleRegisterEndpoint();
                    break;
                case 'session':
                    $this->handleSessionEndpoint();
                    break;
                default:
                    $this->sendResponse(['error' => 'Endpoint not found'], 404);
            }
            
        } catch (Exception $e) {
            error_log("API Error: " . $e->getMessage());
            $this->sendResponse(['error' => 'Internal server error'], 500);
        }
    }
    
   
    private function handleUsersEndpoint() {
        // Require admin role
        if ($_SESSION['user_role'] !== 'admin') {
            $this->sendResponse(['error' => 'Admin access required'], 403);
        }
        
        switch ($this->method) {
            case 'GET':
                $this->getUsersList();
                break;
            case 'POST':
                $this->createUser();
                break;
            case 'PUT':
                $this->updateUser();
                break;
            case 'DELETE':
                $this->deleteUser();
                break;
            default:
                $this->sendResponse(['error' => 'Method not allowed'], 405);
        }
    }
    
   
    private function handleProfileEndpoint() {
        switch ($this->method) {
            case 'GET':
                $this->getCurrentUserProfile();
                break;
            case 'PUT':
                $this->updateCurrentUserProfile();
                break;
            default:
                $this->sendResponse(['error' => 'Method not allowed'], 405);
        }
    }
    

private function handleLoginEndpoint() {
    switch ($this->method) {
        case 'GET':
            // Return login endpoint information
            $this->sendResponse([
                'endpoint' => 'login',
                'methods' => ['POST'],
                'description' => 'User authentication endpoint',
                'required_fields' => ['email', 'password'],
                'example' => [
                    'email' => 'user@example.com',
                    'password' => 'your_password'
                ]
            ]);
            break;
            
        case 'POST':
            $this->processLogin();
            break;
            
        default:
            $this->sendResponse(['error' => 'Method not allowed'], 405);
    }
}

private function processLogin() {
    $input = $this->getJsonInput();
    
    if (!isset($input['email']) || !isset($input['password'])) {
        $this->sendResponse(['error' => 'Email and password required'], 400);
    }
    
    try {
        $user = $this->userFactory->createUserByEmail($input['email']);
        
        if ($user && $user->verifyPassword($input['password'])) {
            // Start session for API user
            $_SESSION['user_id'] = $user->getUserId();
            $_SESSION['user_role'] = $user->getRole();
            $_SESSION['user_email'] = $user->getEmail();
            
            $this->sendResponse([
                'success' => true,
                'message' => 'Login successful',
                'user' => [
                    'id' => $user->getUserId(),
                    'email' => $user->getEmail(),
                    'role' => $user->getRole(),
                    'display_name' => $user->getDisplayName()
                ]
            ]);
        } else {
            $this->sendResponse(['error' => 'Invalid credentials'], 401);
        }
    } catch (Exception $e) {
        $this->sendResponse(['error' => 'Authentication failed'], 500);
    }
}
    
  
    private function handleRegisterEndpoint() {
        if ($this->method !== 'POST') {
            $this->sendResponse(['error' => 'Method not allowed'], 405);
        }
        
        $input = $this->getJsonInput();
        
        $required_fields = ['email', 'password', 'first_name', 'last_name'];
        foreach ($required_fields as $field) {
            if (!isset($input[$field]) || empty($input[$field])) {
                $this->sendResponse(['error' => "Field '$field' is required"], 400);
            }
        }
        
        try {
            $customer = $this->userFactory->registerCustomer($input);
            
            if ($customer) {
                $this->sendResponse([
                    'success' => true,
                    'message' => 'Registration successful',
                    'user' => [
                        'id' => $customer->getUserId(),
                        'email' => $customer->getEmail(),
                        'display_name' => $customer->getDisplayName()
                    ]
                ], 201);
            } else {
                $this->sendResponse(['error' => 'Registration failed'], 500);
            }
        } catch (InvalidArgumentException $e) {
            $this->sendResponse(['error' => $e->getMessage()], 400);
        } catch (Exception $e) {
            $this->sendResponse(['error' => 'Registration failed'], 500);
        }
    }
    
  
    private function handleSessionEndpoint() {
        if ($this->method === 'GET') {
            if ($this->isAuthenticated()) {
                $user = $this->userFactory->createUserById($_SESSION['user_id']);
                $this->sendResponse([
                    'authenticated' => true,
                    'user' => $user->getProfileData()
                ]);
            } else {
                $this->sendResponse(['authenticated' => false]);
            }
        } elseif ($this->method === 'DELETE') {
            // Logout
            session_destroy();
            $this->sendResponse(['message' => 'Logged out successfully']);
        } else {
            $this->sendResponse(['error' => 'Method not allowed'], 405);
        }
    }
    
  
    private function getCurrentUserProfile() {
        $user = $this->userFactory->createUserById($_SESSION['user_id']);
        
        if ($user) {
            $this->sendResponse($user->getProfileData());
        } else {
            $this->sendResponse(['error' => 'User not found'], 404);
        }
    }
    
  
    private function updateCurrentUserProfile() {
        $input = $this->getJsonInput();
        $user = $this->userFactory->createUserById($_SESSION['user_id']);
        
        if (!$user) {
            $this->sendResponse(['error' => 'User not found'], 404);
        }
        
        try {
            if ($user->getRole() === 'customer') {
                $result = $user->updateProfile(
                    $input['first_name'] ?? '',
                    $input['last_name'] ?? '',
                    $input['phone'] ?? null,
                    $input['date_of_birth'] ?? null
                );
            } else {
                $result = $user->updateProfile(
                    $input['admin_name'] ?? '',
                    $input['permissions'] ?? null
                );
            }
            
            if ($result) {
                $this->sendResponse(['success' => true, 'message' => 'Profile updated']);
            } else {
                $this->sendResponse(['error' => 'Update failed'], 500);
            }
        } catch (InvalidArgumentException $e) {
            $this->sendResponse(['error' => $e->getMessage()], 400);
        }
    }
  
    private function getUsersList() {
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
        
        $result = $this->userFactory->getAllUsers($page, $per_page);
        
       
        $users_data = [];
        foreach ($result['users'] as $user) {
            $users_data[] = $user->getProfileData();
        }
        
        $this->sendResponse([
            'users' => $users_data,
            'pagination' => $result['pagination']
        ]);
    }
    
    
    private function createUser() {
        $input = $this->getJsonInput();
        
        if (!isset($input['role']) || !in_array($input['role'], ['customer', 'admin'])) {
            $this->sendResponse(['error' => 'Valid role required'], 400);
        }
        
        try {
            if ($input['role'] === 'customer') {
                $user = $this->userFactory->registerCustomer($input);
            } else {
                $user = $this->userFactory->createAdmin($input);
            }
            
            if ($user) {
                $this->sendResponse([
                    'success' => true,
                    'message' => 'User created successfully',
                    'user' => $user->getProfileData()
                ], 201);
            } else {
                $this->sendResponse(['error' => 'User creation failed'], 500);
            }
        } catch (InvalidArgumentException $e) {
            $this->sendResponse(['error' => $e->getMessage()], 400);
        }
    }
    
    
    
private function parseEndpoint() {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $segments = explode('/', trim($path, '/'));
    
  
    $api_index = array_search('api', $segments);
    
    if ($api_index !== false && isset($segments[$api_index + 1])) {
        $endpoint = $segments[$api_index + 1];
        
     
        if ($endpoint === 'UserAPI.php' || strpos($endpoint, '.php') !== false) {
            return $this->determineEndpointFromRequest();
        }
        
        return $endpoint;
    }
    
    return $this->determineEndpointFromRequest();
}

private function determineEndpointFromRequest() {
   
    if (isset($_GET['endpoint'])) {
        return $_GET['endpoint'];
    }
    
  
    if ($this->method === 'POST') {
        $input = $this->getJsonInput();
        
       
        if (isset($input['email']) && isset($input['password']) && !isset($input['first_name'])) {
            return 'login';
        }
        
    
        if (isset($input['first_name']) && isset($input['last_name'])) {
            return 'register';
        }
    }
    
    
    return 'login';
}
    
    private function getJsonInput() {
        $input = json_decode(file_get_contents('php://input'), true);
        return $input ?: [];
    }
    
    private function isAuthenticated() {
        return isset($_SESSION['user_id']);
    }
    
    private function setSecurityHeaders() {
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        header("X-XSS-Protection: 1; mode=block");
    }
    
    private function sendResponse($data, $status_code = 200) {
        http_response_code($status_code);
        echo json_encode($data);
        exit;
    }
}


$api = new UserAPI();
$api->processRequest();
?>