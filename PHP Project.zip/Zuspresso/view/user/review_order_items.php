<?php
/**
author : Cheng Jun Yang
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Your Order Items - Zuspresso</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/Zuspresso/assets/css/rate-order.css">
    <style>
        .warning-message {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
            border-radius: 5px;
            padding: 15px;
            margin: 20px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            padding: 15px;
            margin: 20px 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    
    <div class="main-content">
        <div class="container">
            <div class="header">
                <h1><i class="fas fa-star"></i> Rate Your Order</h1>
                <p>Share your experience with the items you purchased</p>
            </div>
            
            <div class="content">
                <div class="back-link">
                    <a href="../view/user/orders.php">
                        <i class="fas fa-arrow-left"></i>
                        Back to Order History
                    </a>
                </div>
                
                <?php if (isset($_GET['success'])): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['success_message'])): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success_message']); ?>
                    </div>
                    <?php unset($_SESSION['success_message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['warning_message'])): ?>
                    <div class="warning-message">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_SESSION['warning_message']); ?>
                    </div>
                    <?php unset($_SESSION['warning_message']); ?>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error_message']); ?>
                    </div>
                    <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>
                
                <div class="order-info">
                    <h3>
                        <i class="fas fa-receipt"></i> Order #<?php echo htmlspecialchars($orderId); ?>
                    </h3>
                    <p>Click on "Add Review" or "Edit Review" to share your thoughts about each item.</p>
                </div>
                
                <?php if (!empty($items)): ?>
                    <?php foreach ($items as $item): ?>
                        <div class="item-card">
                            <div class="item-header">
                                <div class="item-info">
                                    <div class="item-name">
                                        <?php echo htmlspecialchars($item['item_name']); ?>
                                    </div>
                                    <div class="item-details">
                                        Quantity: <?php echo htmlspecialchars($item['quantity']); ?> | 
                                        Price: RM <?php echo number_format($item['item_price'], 2); ?>
                                        <?php if (isset($item['subtotal'])): ?>
                                            | Subtotal: RM <?php echo number_format($item['subtotal'], 2); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="review-status">
                                    <?php if ($item['review_id']): ?>
                                        <!-- Existing Review -->
                                        <div class="current-rating">
                                            <div class="stars">
                                                <?php 
                                                $rating = $item['rating'];
                                                for ($i = 1; $i <= 5; $i++) {
                                                    echo $i <= $rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                                                }
                                                ?>
                                            </div>
                                            <div class="rating-text">Your Rating: <?php echo $rating; ?>/5</div>
                                            
                                            <?php if ($item['review_text']): ?>
                                                <div class="review-text">"<?php echo htmlspecialchars(substr($item['review_text'], 0, 100)); ?><?php echo strlen($item['review_text']) > 100 ? '...' : ''; ?>"</div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <?php 
                                        $action = (isset($item['data_source']) && $item['data_source'] === 'OrderService API') ? 'show_form_api' : 'show_form';
                                        ?>
                                        <a href="../controller/ReviewController.php?action=<?php echo $action; ?>&order_id=<?php echo $orderId; ?>&item_id=<?php echo $item['item_id']; ?>" 
                                           class="btn btn-secondary">
                                            <i class="fas fa-edit"></i> Edit Review
                                        </a>
                                    <?php else: ?>
                                        <!-- No Review Yet -->
                                        <div class="rating-text" style="margin-bottom: 1rem;">
                                            <i class="fas fa-star-half-alt" style="color: #D2691E;"></i> Not reviewed yet
                                        </div>
                                        
                                        <?php 
                                        $action = (isset($item['data_source']) && $item['data_source'] === 'OrderService API') ? 'show_form_api' : 'show_form';
                                        ?>
                                        <a href="../controller/ReviewController.php?action=<?php echo $action; ?>&order_id=<?php echo $orderId; ?>&item_id=<?php echo $item['item_id']; ?>" 
                                           class="btn btn-primary">
                                            <i class="fas fa-plus"></i> Add Review
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-reviews">
                        <i class="fas fa-shopping-bag"></i>
                        <h3>No items found for this order</h3>
                        <p>This order may not exist or you may not have permission to view it.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        setTimeout(function() {
            const successMsg = document.querySelector('.success-message');
            if (successMsg) {
                successMsg.style.transition = 'opacity 0.5s';
                successMsg.style.opacity = '0';
                setTimeout(() => successMsg.remove(), 500);
            }
            
            const warningMsg = document.querySelector('.warning-message');
            if (warningMsg) {
                warningMsg.style.transition = 'opacity 0.5s';
                warningMsg.style.opacity = '0';
                setTimeout(() => warningMsg.remove(), 500);
            }
        }, 8000);
        
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.item-card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 * index);
            });
        });
    </script>
</body>
</html>