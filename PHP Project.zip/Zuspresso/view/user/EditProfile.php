<?php

/**
author : Cheng Jun Yang
 */

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../../database.php';
require_once '../../model/BaseModel.php';


class UserModel extends BaseModel {
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['email', 'password_hash', 'role', 'is_active'];
}


$userModel = new UserModel();


$user = $userModel
    ->select([
        'u.*', 
        'c.first_name', 
        'c.last_name', 
        'c.loyalty_points', 
        'c.phone', 
        'c.date_of_birth', 
        'c.customer_id'
    ])
    ->from('users u')
    ->join('customers c', 'u.user_id', '=', 'c.user_id')
    ->where('u.user_id', '=', $_SESSION['user_id'])
    ->first();

if (!$user) {
    header('Location: dashboard.php?error=profile_load_failed');
    exit;
}

$success_message = $_GET['success'] ?? '';
$error_message = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Zuspresso</title>
    <link rel="stylesheet" href="../../assets/css/navbar.css">
    <link rel="stylesheet" href="../../assets/css/edit-profile.css">
</head>
<body>

  
    
    <div class="profile-container">
        <div class="profile-card">
            <div class="profile-header">
                <h1>Edit Profile</h1>
                <p>Update your personal information and preferences</p>
            </div>

            <?php if ($success_message): ?>
                <div class="alert alert-success">
                    <?php 
                    switch($success_message) {
                        case 'profile_updated':
                            echo '✅ Profile updated successfully!';
                            break;
                        case 'password_updated':
                            echo '✅ Password updated successfully!';
                            break;
                        default:
                            echo '✅ Changes saved successfully!';
                    }
                    ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <?php 
                    switch($error_message) {
                        case 'invalid_name':
                            echo '❌ Please enter valid names (2-50 characters, letters only).';
                            break;
                        case 'invalid_phone':
                            echo '❌ Please enter a valid phone number.';
                            break;
                        case 'password_mismatch':
                            echo '❌ New passwords do not match.';
                            break;
                        case 'current_password_incorrect':
                            echo '❌ Current password is incorrect.';
                            break;
                        case 'password_insecure':
                            echo '❌ Password must be at least 8 characters with uppercase, lowercase, number, and special character.';
                            break;
                        case 'update_failed':
                            echo '❌ Failed to update profile. Please try again.';
                            break;
                        default:
                            echo '❌ An error occurred. Please try again.';
                    }
                    ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="../../controller/ProfileController.php" id="profileForm">
                <input type="hidden" name="action" value="update_profile">
                
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" id="first_name" name="first_name" 
                               value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" 
                               required maxlength="50">
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" id="last_name" name="last_name" 
                               value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" 
                               required maxlength="50">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" 
                               value="<?= htmlspecialchars($user['phone'] ?? '') ?>" 
                               placeholder="+60123456789" maxlength="15">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" 
                               value="<?= htmlspecialchars($user['email'] ?? '') ?>" 
                               readonly style="background-color: #f8f9fa; color: #666;">
                        <small style="color: #666; font-size: 0.8rem;">Opps! Email cannot be changed.</small>
                    </div>
                </div>

               
                <div class="password-section">
                    <div class="password-header">
                        <h3>Change Password</h3>
                        <button type="button" class="toggle-password" onclick="togglePasswordSection()">
                            Change Password
                        </button>
                    </div>
                    
                    <div class="password-fields" id="passwordFields">
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" 
                                   placeholder="Enter current password">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" 
                                   placeholder="Enter new password">
                            <div class="password-requirements">
                                Password must contain at least 8 characters with uppercase, lowercase, number, and special character.
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" 
                                   placeholder="Confirm new password">
                        </div>
                    </div>
                </div>

                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Profile</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        function togglePasswordSection() {
            const passwordFields = document.getElementById('passwordFields');
            const toggleBtn = document.querySelector('.toggle-password');
            
            if (passwordFields.classList.contains('active')) {
                passwordFields.classList.remove('active');
                toggleBtn.textContent = 'Change Password';
                
                
                document.getElementById('current_password').value = '';
                document.getElementById('new_password').value = '';
                document.getElementById('confirm_password').value = '';
            } else {
                passwordFields.classList.add('active');
                toggleBtn.textContent = 'Cancel Password Change';
            }
        }

     
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            const firstName = document.getElementById('first_name').value.trim();
            const lastName = document.getElementById('last_name').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const passwordFields = document.getElementById('passwordFields');
            
         
            if (!firstName || !lastName) {
                alert('Please enter both first name and last name.');
                e.preventDefault();
                return;
            }
            
            if (!/^[a-zA-Z\s\'-]{2,50}$/.test(firstName) || !/^[a-zA-Z\s\'-]{2,50}$/.test(lastName)) {
                alert('Names should contain only letters, spaces, hyphens, and apostrophes (2-50 characters).');
                e.preventDefault();
                return;
            }
            
          
            if (phone && !/^[\d\+\-\s\(\)]{10,15}$/.test(phone.replace(/\s/g, ''))) {
                alert('Please enter a valid phone number.');
                e.preventDefault();
                return;
            }
            
           
            if (passwordFields.classList.contains('active')) {
                const currentPassword = document.getElementById('current_password').value;
                const newPassword = document.getElementById('new_password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                
                if (!currentPassword) {
                    alert('Please enter your current password.');
                    e.preventDefault();
                    return;
                }
                
                if (newPassword && newPassword !== confirmPassword) {
                    alert('New passwords do not match.');
                    e.preventDefault();
                    return;
                }
                
                if (newPassword && !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(newPassword)) {
                    alert('Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
                    e.preventDefault();
                    return;
                }
            }
        });

   
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            const requirements = document.querySelector('.password-requirements');
            
            if (password) {
                const isValid = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);
                requirements.style.color = isValid ? '#28a745' : '#dc3545';
                requirements.innerHTML = isValid ? 
                    '✅ Password meets requirements' : 
                    'Password must contain at least 8 characters with uppercase, lowercase, number, and special character.';
            } else {
                requirements.style.color = '#666';
                requirements.innerHTML = 'Password must contain at least 8 characters with uppercase, lowercase, number, and special character.';
            }
        });
    </script>
</body>
</html>