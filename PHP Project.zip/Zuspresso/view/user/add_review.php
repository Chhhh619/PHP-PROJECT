<?php
/**
author : Cheng Jun Yang
 */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($existingReview['review_id']) ? 'Edit' : 'Add'; ?> Review - Zuspresso</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/Zuspresso/assets/css/add-review.css">
</head>
<body>
    
    
    <div class="main-content">
        <div class="container">
            <div class="header">
                <h1>
                    <i class="fas fa-star"></i>
                    <?php echo isset($existingReview['review_id']) ? 'Edit Your Review' : 'Write a Review'; ?>
                </h1>
                <p>Share your experience with this item</p>
            </div>
            
            <div class="content">
                <div class="back-link">
                    <a href="../controller/ReviewController.php?action=show_order_items_api&order_id=<?php echo htmlspecialchars($orderId); ?>">
                        <i class="fas fa-arrow-left"></i>
                        Back to Order Items
                    </a>
                </div>
                
                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error_message']); ?>
                    </div>
                    <?php unset($_SESSION['error_message']); ?>
                <?php endif; ?>
                
                <div class="item-info">
                    <h3><i class="fas fa-coffee"></i> <?php echo htmlspecialchars($itemDetails['item_name']); ?></h3>
                    <p>
                        Quantity: <?php echo htmlspecialchars($itemDetails['quantity']); ?> | 
                        Price: RM <?php echo number_format($itemDetails['item_price'], 2); ?>
                    </p>
                </div>
                
                <form method="POST" action="../controller/ReviewController.php?action=submit_api" id="reviewForm">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($orderId); ?>">
                    <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($itemId); ?>">
                    <input type="hidden" name="rating" id="ratingInput" value="<?php echo htmlspecialchars($existingReview['rating'] ?? ''); ?>">
                    
                    <div class="rating-container">
                        <label class="form-label">
                            Rating <span class="required">*</span>
                        </label>
                        <div class="star-rating" id="starRating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star star" data-rating="<?php echo $i; ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <div class="rating-text" id="ratingText">
                            <?php if (isset($existingReview['rating'])): ?>
                                <?php echo $existingReview['rating']; ?> out of 5 stars
                            <?php else: ?>
                                Click to rate this item
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="reviewText" class="form-label">Your Review</label>
                        <textarea 
                            id="reviewText" 
                            name="review_text" 
                            class="form-control"
                            rows="6"
                            placeholder="Tell others about your experience with this item..."
                            maxlength="1000"
                        ><?php echo htmlspecialchars($existingReview['review_text'] ?? ''); ?></textarea>
                        <div class="rating-text">
                            <span id="charCount">0</span>/1000 characters
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <a href="../controller/ReviewController.php?action=show_order_items&order_id=<?php echo htmlspecialchars($orderId); ?>" 
                           class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fas fa-save"></i>
                            <?php echo isset($existingReview['review_id']) ? 'Update Review' : 'Submit Review'; ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const stars = document.querySelectorAll('.star');
            const ratingInput = document.getElementById('ratingInput');
            const ratingText = document.getElementById('ratingText');
            const reviewText = document.getElementById('reviewText');
            const charCount = document.getElementById('charCount');
            const submitBtn = document.getElementById('submitBtn');
            
            const ratingTexts = {
                1: '1 out of 5 stars - Poor',
                2: '2 out of 5 stars - Fair',
                3: '3 out of 5 stars - Good',
                4: '4 out of 5 stars - Very Good',
                5: '5 out of 5 stars - Excellent'
            };
            
          
            let currentRating = parseInt(ratingInput.value) || 0;
            updateStarDisplay(currentRating);
            
        
            stars.forEach(star => {
                star.addEventListener('click', function() {
                    const rating = parseInt(this.dataset.rating);
                    currentRating = rating;
                    ratingInput.value = rating;
                    updateStarDisplay(rating);
                    ratingText.textContent = ratingTexts[rating];
                });
                
                star.addEventListener('mouseover', function() {
                    const rating = parseInt(this.dataset.rating);
                    updateStarDisplay(rating);
                });
            });
            
           
            document.getElementById('starRating').addEventListener('mouseleave', function() {
                updateStarDisplay(currentRating);
                if (currentRating > 0) {
                    ratingText.textContent = ratingTexts[currentRating];
                } else {
                    ratingText.textContent = 'Click to rate this item';
                }
            });
            
            function updateStarDisplay(rating) {
                stars.forEach((star, index) => {
                    if (index < rating) {
                        star.classList.add('active');
                    } else {
                        star.classList.remove('active');
                    }
                });
            }
            
     
            function updateCharCount() {
                const count = reviewText.value.length;
                charCount.textContent = count;
                charCount.style.color = count > 900 ? '#dc3545' : '#6c757d';
            }
            
            reviewText.addEventListener('input', updateCharCount);
            updateCharCount(); 
            
         
            document.getElementById('reviewForm').addEventListener('submit', function(e) {
                if (currentRating === 0) {
                    e.preventDefault();
                    alert('Please select a rating before submitting your review.');
                    return false;
                }
                
               
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            });
            
       
            const formGroups = document.querySelectorAll('.form-group');
            formGroups.forEach((group, index) => {
                group.style.opacity = '0';
                group.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    group.style.transition = 'all 0.5s ease';
                    group.style.opacity = '1';
                    group.style.transform = 'translateY(0)';
                }, 100 * index);
            });
        });
    </script>
</body>
</html>