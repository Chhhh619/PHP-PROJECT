<?php

/**
author : Cheng Jun Yang
 */

require_once '../../model/BaseModel.php';
require_once '../../model/ProductReview.php';

class ReviewDisplay {
    private $reviewModel;
    
    public function __construct() {
        $this->reviewModel = new ProductReview();
    }
    
    public function getItemReviews($itemId, $page = 1, $limit = 5) {
        try {
            $itemId = (int)$itemId;
            
            if ($itemId <= 0) {
                throw new Exception("Invalid item ID");
            }
            
            $reviews = $this->reviewModel->select([
                    'pr.*', 
                    'CONCAT(c.first_name, " ", c.last_name) as customer_name',
                    'DATE_FORMAT(pr.created_at, "%M %d, %Y") as review_date'
                ])
                ->from('product_reviews pr')
                ->leftJoin('customers c', 'pr.customer_id', '=', 'c.customer_id')
                ->where('pr.item_id', $itemId)
                ->orderBy('pr.created_at', 'DESC')
                ->limit($limit)
                ->offset(($page - 1) * $limit)
                ->get();
            
            $totalReviews = $this->reviewModel->where('item_id', $itemId)->count();
            $stats = $this->getReviewStats($itemId);
            
            return [
                'success' => true,
                'reviews' => $reviews,
                'stats' => $stats,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $limit,
                    'total' => $totalReviews,
                    'total_pages' => ceil($totalReviews / $limit),
                    'has_more' => ($page * $limit) < $totalReviews
                ]
            ];
            
        } catch (Exception $e) {
            error_log("ReviewDisplay error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    public function getReviewStats($itemId) {
        try {
            $itemId = (int)$itemId;
            
            $totalReviews = $this->reviewModel->where('item_id', $itemId)->count();
            
            if ($totalReviews == 0) {
                return [
                    'total_reviews' => 0,
                    'average_rating' => 0,
                    'rating_distribution' => [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0],
                    'star_display' => $this->generateStarDisplay(0)
                ];
            }
            
            $avgResult = $this->reviewModel->select(['AVG(rating) as avg_rating'])
                ->where('item_id', $itemId)
                ->first();
            
            $averageRating = $avgResult ? round($avgResult['avg_rating'], 1) : 0;
            
            $distribution = $this->reviewModel->select([
                    'rating',
                    'COUNT(*) as count'
                ])
                ->where('item_id', $itemId)
                ->groupBy('rating')
                ->orderBy('rating', 'DESC')
                ->get();
            
            $ratingCounts = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
            foreach ($distribution as $row) {
                $ratingCounts[$row['rating']] = (int)$row['count'];
            }
            
            return [
                'total_reviews' => $totalReviews,
                'average_rating' => $averageRating,
                'rating_distribution' => $ratingCounts,
                'star_display' => $this->generateStarDisplay($averageRating)
            ];
            
        } catch (Exception $e) {
            return [
                'total_reviews' => 0,
                'average_rating' => 0,
                'rating_distribution' => [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0],
                'star_display' => $this->generateStarDisplay(0)
            ];
        }
    }
    
    public function generateStarDisplay($rating, $showRating = true) {
        $fullStars = floor($rating);
        $hasHalfStar = ($rating - $fullStars) >= 0.5;
        $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
        
        $html = str_repeat('★', $fullStars);
        
        if ($hasHalfStar) {
            $html .= '☆'; // Half star representation
        }
        
        $html .= str_repeat('☆', $emptyStars);
        
        return $html;
    }
    
    public function formatReviewText($text, $maxLength = 150) {
        if (empty($text)) {
            return '';
        }
        
        $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        
        if (strlen($text) <= $maxLength) {
            return $text;
        }
        
        return substr($text, 0, $maxLength) . '...';
    }
    
    public function getReviewSummary($itemId) {
        $stats = $this->getReviewStats($itemId);
        
        if ($stats['total_reviews'] == 0) {
            return [
                'has_reviews' => false,
                'summary_text' => 'No reviews yet',
                'star_display' => 'No reviews'
            ];
        }
        
        $summaryText = $stats['total_reviews'] . ' review' . ($stats['total_reviews'] > 1 ? 's' : '');
        
        return [
            'has_reviews' => true,
            'average_rating' => $stats['average_rating'],
            'total_reviews' => $stats['total_reviews'],
            'summary_text' => $summaryText,
            'star_display' => $this->generateStarDisplay($stats['average_rating'])
        ];
    }
}


if (isset($_GET['action'])) {
    $reviewDisplay = new ReviewDisplay();
    
    header('Content-Type: application/json');
    
    switch ($_GET['action']) {
        case 'get_reviews':
            $itemId = $_GET['item_id'] ?? 0;
            $page = $_GET['page'] ?? 1;
            $limit = $_GET['limit'] ?? 5;
            
            $result = $reviewDisplay->getItemReviews($itemId, $page, $limit);
            echo json_encode($result);
            break;
            
        case 'get_stats':
            $itemId = $_GET['item_id'] ?? 0;
            $result = $reviewDisplay->getReviewStats($itemId);
            echo json_encode(['success' => true, 'stats' => $result]);
            break;
            
        case 'get_summary':
            $itemId = $_GET['item_id'] ?? 0;
            $result = $reviewDisplay->getReviewSummary($itemId);
            echo json_encode(['success' => true, 'summary' => $result]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit;
}
?>