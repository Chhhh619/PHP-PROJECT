<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tan Cheng Hong
 * @module  Rewards Module - Navigation Component
 * @version 1.0
 */

$current_page = basename($_SERVER['PHP_SELF']);
?>

<link rel="stylesheet" href="../../assets/css/navbar.css">

<nav class="navbar">
    <div class="nav-container">
        <a href="dashboard.php" class="logo">
            <span class="logo-icon">☕</span>
            Zuspresso
        </a>

        <div class="nav-links">
            <a href="dashboard.php" class="nav-link <?= $current_page === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
            <a href="menu.php" class="nav-link <?= $current_page === 'menu.php' ? 'active' : '' ?>">Menu</a>
            <a href="orders.php" class="nav-link <?= $current_page === 'orders.php' ? 'active' : '' ?>">Orders</a>
            <a href="rewards.php" class="nav-link <?= $current_page === 'rewards.php' ? 'active' : '' ?>">Rewards</a>
            <a href="cart.php" class="nav-link <?= $current_page === 'cart.php' ? 'active' : '' ?>">
                Cart
                <span class="cart-badge" id="cartBadge">0</span>
            </a>
        </div>

        <div class="user-menu">
            <a href="EditProfile.php" class="user-profile">
                <div class="user-avatar">
                    <?= isset($user['first_name']) ? strtoupper(substr($user['first_name'], 0, 1)) : strtoupper(substr($display_name, 0, 1)) ?>
                </div>
                <span class="user-name"><?= isset($display_name) ? htmlspecialchars($display_name) : 'User' ?></span>
            </a>
            <a href="#" onclick="logout()" class="logout-btn">Logout</a>
        </div>
    </div>
</nav>

<div class="cart-notification" id="cartNotification"></div>

<script>
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/Zuspresso/controller/AuthController.php';

        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'logout';
        form.appendChild(actionInput);

        document.body.appendChild(form);
        form.submit();
    }
}

function updateCartBadge(itemCount) {
    const badge = document.getElementById('cartBadge');
    if (badge) {
        badge.textContent = itemCount || 0;
        if (itemCount > 0) {
            badge.classList.add('show');
            badge.style.animation = 'none';
            badge.offsetHeight; // Force reflow
            badge.style.animation = 'pulse 0.5s ease';
        } else {
            badge.classList.remove('show');
        }
    }
    
    const cartCounts = document.querySelectorAll('.cart-count');
    cartCounts.forEach(element => {
        element.textContent = itemCount || 0;
    });
}

function showCartNotification(message, type = 'success') {
    const notification = document.getElementById('cartNotification');
    if (notification) {
        notification.textContent = message;
        notification.style.background = type === 'success' ? '#28a745' : '#dc3545';
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 2000);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (typeof loadCartBadge === 'function') {
        loadCartBadge();
    } else {
        fetch('/Zuspresso/controller/OrderController.php?action=get_cart')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.cart_totals) {
                    updateCartBadge(data.cart_totals.item_count || 0);
                }
            })
            .catch(error => console.log('Could not load cart badge:', error));
    }
});
</script>