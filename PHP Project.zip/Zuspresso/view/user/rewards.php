<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

require_once '../../model/BaseModel.php';
require_once '../../model/Customer.php';
require_once '../../model/LoyaltyService.php';
require_once '../../model/Reward.php';
require_once '../../model/RewardRedemption.php';
require_once '../../model/LoyaltyTransaction.php';
require_once '../../model/JWTHelper.php';
require_once '../../model/SecurityValidator.php';

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'redeem') {
    header('Content-Type: application/json');

    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Invalid security token");
        }

        if (!SecurityValidator::checkRateLimit($_SESSION['user_id'], 'redemption', 8, 300)) {
            throw new Exception("Too many redemption attempts. Please try again later.");
        }

        $rewardId = filter_var($_POST['reward_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$rewardId) {
            throw new Exception("Invalid reward ID");
        }

        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $token = str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']);
            if (!JWTHelper::validateToken($token)) {
                throw new Exception("Invalid or expired authentication token");
            }
        }

        $customer = Customer::getByUserId($_SESSION['user_id']);
        if (!$customer) {
            throw new Exception("Customer not found");
        }

        $loyaltyService = new LoyaltyService();

        $idempotencyKey = 'redemption_' . $_SESSION['user_id'] . '_' . $rewardId . '_' . date('Y-m-d');

        $result = $loyaltyService->redeemRewardWithSecurity(
                $_SESSION['user_id'],
                $rewardId,
                $idempotencyKey
        );

        SecurityValidator::logAction($_SESSION['user_id'], 'reward_redemption', [
            'reward_id' => $rewardId,
            'points_used' => $result['points_used'],
            'redemption_code' => $result['redemption_code']
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Reward redeemed successfully! Check "My Rewards" to view your voucher.',
            'redemption_code' => $result['redemption_code'],
            'reward_name' => $result['reward_name'] ?? 'Reward',
            'remaining_points' => $result['remaining_points']
        ]);
    } catch (Exception $e) {
        SecurityValidator::logAction($_SESSION['user_id'] ?? 'unknown', 'failed_redemption', [
            'error' => $e->getMessage(),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);

        error_log("Reward redemption error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'activate_voucher') {
    header('Content-Type: application/json');

    try {
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Invalid security token");
        }

        $redemptionId = filter_var($_POST['redemption_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$redemptionId) {
            throw new Exception("Invalid redemption ID");
        }

        $redemption = RewardRedemption::getById($redemptionId);
        if (!$redemption || $redemption['customer_id'] != $_SESSION['user_id']) {
            throw new Exception("Unauthorized access to redemption");
        }

        SecurityValidator::logAction($_SESSION['user_id'], 'voucher_activation', [
            'redemption_id' => $redemptionId
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Voucher activated successfully! You can now use it for your next order.'
        ]);
    } catch (Exception $e) {
        error_log("Voucher activation error: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

$loyaltyPoints = 0;
$loyaltyTier = 'Bronze';
$display_name = 'Guest';
$rewards = [];
$redemptions = [];
$transactions = [];
$error_message = null;
$promotionStatus = null;

try {
    $customer = Customer::getByUserId($_SESSION['user_id']);

    if (!$customer) {
        throw new Exception("Customer record not found. Please contact support.");
    }

    $loyaltyService = new LoyaltyService();
    $loyaltyPoints = $loyaltyService->getCustomerPoints($customer->customer_id);
    $loyaltyTier = $loyaltyService->getLoyaltyTier($customer->customer_id);
    $promotionStatus = $loyaltyService->getTuesdayPromotionStatus();
    $rewards = Reward::getActive();
    $redemptions = RewardRedemption::getCustomerRedemptions($_SESSION['user_id']);

    if (!empty($redemptions)) {
        usort($redemptions, function ($a, $b) {
            $statusPriority = [
                'active' => 1,
                'pending' => 2,
                'used' => 3,
                'expired' => 4,
                'cancelled' => 5
            ];

            $priorityA = $statusPriority[$a['status']] ?? 99;
            $priorityB = $statusPriority[$b['status']] ?? 99;

            if ($priorityA !== $priorityB) {
                return $priorityA - $priorityB;
            }

            return strcasecmp($a['reward_name'], $b['reward_name']);
        });
    }

    $transactions = LoyaltyTransaction::getCustomerTransactions($_SESSION['user_id'], 10);

    $display_name = $customer->getDisplayName();
} catch (Exception $e) {
    $error_message = $e->getMessage();
    error_log("Rewards page error: " . $error_message);
}

$user = ['first_name' => $customer ? $customer->first_name : 'Guest'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Rewards - Zuspresso</title>
        <link rel="stylesheet" href="../../assets/css/navbar.css"> 
        <link rel="stylesheet" href="../../assets/css/rewards.css">
        <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';">
    </head> 
    <body>
        <?php include 'navbar.php'; ?>

        <div class="container">
            <div class="page-header">
                <div class="header-container">
                    <div class="header-content">
                        <div>
                            <h1 class="page-title">Rewards & Loyalty</h1>
                            <p style="color: #6c757d; margin-top: 0.5rem;">Redeem your points for exclusive rewards and offers</p>
                        </div>
                        <div class="points-card">
                            <div class="points-label">ZUS Points</div>
                            <div class="points-value"><?= number_format($loyaltyPoints) ?></div>
                            <div class="tier-badge"><?= $loyaltyTier ?> Member</div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($promotionStatus): ?>
                <div class="promotion-banner <?= $promotionStatus['is_tuesday'] ? 'active-promotion' : 'upcoming-promotion' ?>">
                    <div class="promotion-content">
                        <div class="promotion-icon">🎉</div>
                        <div class="promotion-text">
                            <h3><?= $promotionStatus['promotion_message'] ?></h3>
                            <p>
                                <?php if ($promotionStatus['is_tuesday']): ?>
                                    Today only! Earn 2.5x points on all orders. Don't miss out!
                                <?php else: ?>
                                    Every Tuesday you earn 2.5x loyalty points on all orders.
                                <?php endif; ?>
                            </p>
                        </div>
                        <?php if ($promotionStatus['is_tuesday']): ?>
                            <div class="promotion-multiplier">2.5x</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <div class="tabs-container">
                <div class="tabs">
                    <button class="tab active" onclick="showTab('rewards')">Redeem Rewards</button>
                    <button class="tab" onclick="showTab('my-rewards')">My Rewards</button>
                    <button class="tab" onclick="showTab('history')">Points History</button>
                </div>
            </div>

            <div class="content-area">
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-error">
                        Error: <?= htmlspecialchars($error_message) ?>
                    </div>
                <?php endif; ?>

                <div id="rewards-tab" class="tab-content active">
                    <div class="rewards-section">
                        <h2 class="section-title">ZUS Rewards</h2>
                        <div class="rewards-grid">
                            <?php if (!empty($rewards)): ?>
                                <?php foreach ($rewards as $reward): ?>
                                    <div class="reward-card">
                                        <div class="reward-image <?= ($reward['points_required'] >= 500) ? 'premium' : (($reward['reward_type'] === 'free_item') ? 'special' : '') ?>">
                                            <?php if (!empty($reward['image_url']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $reward['image_url'])): ?>
                                                <img src="<?= htmlspecialchars($reward['image_url']) ?>" alt="<?= htmlspecialchars($reward['name']) ?>" class="reward-image-photo">
                                            <?php else: ?>
                                                <div class="reward-icon">
                                                    <?php
                                                    $icons = [
                                                        'discount' => '🎫',
                                                        'free_item' => '🎁',
                                                        'merchandise' => '👕',
                                                        'voucher' => '🎟️'
                                                    ];
                                                    echo $icons[$reward['reward_type']] ?? '🎁';
                                                    ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (isset($reward['stock_quantity']) && $reward['stock_quantity'] <= 0): ?>
                                                <div class="out-of-stock-overlay">
                                                    <div class="out-of-stock-text">Fully Redeemed</div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="reward-content">
                                            <h3 class="reward-title"><?= htmlspecialchars($reward['name']) ?></h3>
                                            <p class="reward-description"><?= htmlspecialchars($reward['description']) ?></p>
                                            <div class="reward-footer">
                                                <div class="points-required">
                                                    <div class="points-icon">Z</div>
                                                    <span><?= number_format($reward['points_required']) ?> pts</span>
                                                </div>
                                                <button class="redeem-btn" 
                                                        onclick="redeemReward(<?= $reward['reward_id'] ?>)"
                                                        <?php
                                                        $isOutOfStock = isset($reward['stock_quantity']) && $reward['stock_quantity'] <= 0;
                                                        $hasInsufficientPoints = $loyaltyPoints < $reward['points_required'];
                                                        echo ($isOutOfStock || $hasInsufficientPoints) ? 'disabled' : '';
                                                        ?>>
                                                            <?php if ($isOutOfStock): ?>
                                                        Fully Redeemed
                                                    <?php elseif ($hasInsufficientPoints): ?>
                                                        Insufficient Points
                                                    <?php else: ?>
                                                        Redeem
                                                    <?php endif; ?>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-state-icon">🎁</div>
                                    <h3>No Rewards Available</h3>
                                    <p>Check back later for exciting rewards!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div id="my-rewards-tab" class="tab-content">
                    <div class="rewards-section">
                        <h2 class="section-title">My Vouchers</h2>
                        <?php if (!empty($redemptions)): ?>
                            <?php foreach ($redemptions as $redemption): ?>
                                <div class="voucher-card">
                                    <div class="voucher-status <?= strtolower($redemption['status']) ?>">
                                        <?= ucfirst($redemption['status']) ?>
                                    </div>

                                    <div class="voucher-header">
                                        <div class="voucher-title"><?= htmlspecialchars($redemption['reward_name']) ?></div>
                                        <div class="voucher-subtitle">
                                            <span>Code: <?= htmlspecialchars($redemption['redemption_code']) ?></span>
                                            <button class="copy-code-btn" onclick="copyToClipboard('<?= htmlspecialchars($redemption['redemption_code']) ?>')">
                                                Copy Code
                                            </button>
                                        </div>
                                    </div>

                                    <div class="voucher-details">
                                        <div class="detail-item">
                                            <div class="detail-icon">⏰</div>
                                            <div class="detail-content">
                                                <h4>Validity</h4>
                                                <p><?= $redemption['expires_at'] ? date('j M Y', strtotime($redemption['expires_at'])) : 'No Expiry' ?></p>
                                            </div>
                                        </div>
                                        <div class="detail-item">
                                            <div class="detail-icon">💰</div>
                                            <div class="detail-content">
                                                <h4>Points Used</h4>
                                                <p><?= number_format($redemption['points_used']) ?> pts</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="voucher-actions">
                                        <div>
                                            <?php if ($redemption['status'] === 'active'): ?>
                                                <small style="color: #28a745; font-weight: 600;">✓ Ready to use</small>
                                            <?php elseif ($redemption['status'] === 'used'): ?>
                                                <small style="color: #6c757d;">Used on <?= date('j M Y', strtotime($redemption['used_at'])) ?></small>
                                            <?php endif; ?>
                                        </div>

                                        <div>
                                            <?php if ($redemption['status'] === 'active'): ?>
                                                <button class="use-btn" onclick="useVoucher('<?= htmlspecialchars($redemption['redemption_code']) ?>')">
                                                    Use Now
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <div class="empty-state-icon">🎫</div>
                                <h3>No Vouchers Yet</h3>
                                <p>Redeem rewards to see your vouchers here!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div id="history-tab" class="tab-content">
                    <div class="history-container">
                        <table class="history-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Points</th>
                                    <th>Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($transactions)): ?>
                                    <?php foreach ($transactions as $transaction): ?>
                                        <tr>
                                            <td><?= date('M j, Y H:i', strtotime($transaction['created_at'])) ?></td>
                                            <td><?= htmlspecialchars($transaction['description']) ?></td>
                                            <td>
                                                <span class="points-change <?= $transaction['points'] > 0 ? 'points-positive' : 'points-negative' ?>">
                                                    <?= $transaction['points'] > 0 ? '+' : '' ?><?= number_format($transaction['points']) ?> pts
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?= $transaction['transaction_type'] ?>">
                                                    <?= ucfirst($transaction['transaction_type']) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4">
                                            <div class="empty-state">
                                                <div class="empty-state-icon">📊</div>
                                                <h3>No Transaction History</h3>
                                                <p>Make your first order to start earning points!</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="redemption-success" id="successNotification"></div>

        <script>
            const csrfToken = '<?= $_SESSION['csrf_token'] ?>';

            function showTab(tabName) {
                const tabContents = document.querySelectorAll('.tab-content');
                tabContents.forEach(content => content.classList.remove('active'));

                const tabs = document.querySelectorAll('.tab');
                tabs.forEach(tab => tab.classList.remove('active'));

                document.getElementById(tabName + '-tab').classList.add('active');
                event.target.classList.add('active');
            }

            function redeemReward(rewardId) {
                if (event.target.disabled) {
                    if (event.target.textContent === 'Fully Redeemed') {
                        showErrorNotification('This reward has been fully redeemed and is no longer available.');
                    }
                    return;
                }

                if (!confirm('Are you sure you want to redeem this reward?')) {
                    return;
                }

                const redeemButton = event.target;
                const originalText = redeemButton.textContent;
                redeemButton.disabled = true;
                redeemButton.textContent = 'Redeeming...';

                const formData = new FormData();
                formData.append('action', 'redeem');
                formData.append('reward_id', rewardId);
                formData.append('csrf_token', csrfToken);

                fetch('rewards.php', {
                    method: 'POST',
                    body: formData
                })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP error! status: ${response.status}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                            console.log('Response data:', data);

                            if (data.success === false || data.error || data.status === 'error') {
                                let errorMessage = data.message || 'An error occurred while redeeming the reward.';
                                console.log('Error message:', errorMessage);

                                if (errorMessage.includes('already redeemed this reward recently') ||
                                        errorMessage.includes('wait 24 hours') ||
                                        errorMessage.includes('wait') && errorMessage.includes('hours') ||
                                        (errorMessage.includes('redeemed this reward') && errorMessage.includes('recently'))) {

                                    let timeMessage = '24 hours';
                                    const hoursMatch = errorMessage.match(/(\d+)\s*hours?/i);
                                    if (hoursMatch) {
                                        timeMessage = hoursMatch[1] + ' hour' + (hoursMatch[1] > 1 ? 's' : '');
                                    }

                                    showErrorNotification(`You've already redeemed this reward recently. Please wait ${timeMessage} before redeeming the same reward again.`);
                                } else if (errorMessage.includes('rate limit') || errorMessage.includes('too many attempts')) {
                                    showErrorNotification('Too many attempts. Please wait a few minutes before trying again.');
                                } else if (errorMessage.includes('insufficient') || errorMessage.includes('points')) {
                                    showErrorNotification('You don\'t have enough points for this reward.');
                                } else if (errorMessage.includes('out of stock')) {
                                    showErrorNotification('This reward is currently out of stock.');
                                } else if (errorMessage.includes('security token') || errorMessage.includes('unauthorized')) {
                                    showErrorNotification('Security error. Please refresh the page and try again.');
                                } else if (errorMessage.includes('wait a moment')) {
                                    showErrorNotification('Please wait a moment before redeeming this reward again.');
                                } else {
                                    showErrorNotification(errorMessage);
                                }

                                redeemButton.disabled = false;
                                redeemButton.textContent = originalText;
                                return;
                            }

                            if (data.success === true) {
                                showSuccessNotification(data.message || 'Reward redeemed successfully! Check "My Rewards" to view your voucher.');

                                if (data.remaining_points !== undefined) {
                                    const pointsValue = document.querySelector('.points-value');
                                    if (pointsValue) {
                                        pointsValue.textContent = data.remaining_points.toLocaleString();
                                    }
                                }

                                setTimeout(() => {
                                    location.reload();
                                }, 2000);
                            } else {
                                showErrorNotification('Unable to redeem reward. Please try again.');
                                redeemButton.disabled = false;
                                redeemButton.textContent = originalText;
                            }
                        })
                        .catch(error => {
                            console.error('Redemption Error:', error);

                            let errorMessage = 'Unable to redeem reward. Please try again.';
                            if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
                                errorMessage = 'Connection error. Please check your internet connection and try again.';
                            } else if (error.message.includes('timeout')) {
                                errorMessage = 'Request timed out. Please try again.';
                            } else if (error.message.includes('HTTP error')) {
                                errorMessage = 'Server error. Please try again or contact support.';
                            }

                            showErrorNotification(errorMessage);

                            redeemButton.disabled = false;
                            redeemButton.textContent = originalText;
                        });
            }

            function showSuccessNotification(message) {
                const notification = document.getElementById('successNotification');
                notification.textContent = message;
                notification.className = 'redemption-success success show';

                setTimeout(() => {
                    notification.classList.remove('show');
                }, 4000);
            }

            function showErrorNotification(message) {
                let errorNotification = document.getElementById('errorNotification');
                if (!errorNotification) {
                    errorNotification = document.createElement('div');
                    errorNotification.id = 'errorNotification';
                    errorNotification.className = 'redemption-success error';
                    document.body.appendChild(errorNotification);
                }

                errorNotification.textContent = message;
                errorNotification.className = 'redemption-success error show';

                setTimeout(() => {
                    errorNotification.classList.remove('show');
                }, 6000);
            }

            function copyToClipboard(text) {
                const sanitizedText = text.replace(/[<>]/g, '');

                navigator.clipboard.writeText(sanitizedText).then(() => {
                    showSuccessNotification('Code copied to clipboard!');
                }).catch(() => {
                    const textArea = document.createElement('textarea');
                    textArea.value = sanitizedText;
                    textArea.style.position = 'fixed';
                    textArea.style.opacity = '0';
                    document.body.appendChild(textArea);
                    textArea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textArea);
                    showSuccessNotification('Code copied to clipboard!');
                });
            }

            function useVoucher(redemptionCode) {
                alert(`Voucher ${redemptionCode} is ready to use! Present this code during checkout or show it to staff when ordering.`);
            }
        </script>

        <style>
            .promotion-banner {
                background: linear-gradient(135deg, #ff6b6b 0%, #ffa500 100%);
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 20px;
                box-shadow: 0 4px 15px rgba(255, 107, 107, 0.2);
                border: 2px solid transparent;
                animation: promotionPulse 3s ease-in-out infinite;
            }

            .promotion-banner.upcoming-promotion {
                background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
                box-shadow: 0 4px 15px rgba(108, 117, 125, 0.15);
                animation: none;
            }

            .promotion-content {
                display: flex;
                align-items: center;
                gap: 15px;
            }

            .promotion-icon {
                font-size: 2rem;
                animation: bounce 2s ease-in-out infinite;
            }

            .promotion-text h3 {
                margin: 0 0 5px 0;
                color: white;
                font-size: 1.25rem;
                font-weight: 600;
            }

            .promotion-text p {
                margin: 0;
                color: rgba(255, 255, 255, 0.9);
                font-size: 0.95rem;
            }

            .promotion-multiplier {
                margin-left: auto;
                background: rgba(255, 255, 255, 0.2);
                color: white;
                padding: 8px 16px;
                border-radius: 20px;
                font-weight: bold;
                font-size: 1.1rem;
                backdrop-filter: blur(10px);
                border: 1px solid rgba(255, 255, 255, 0.3);
            }

            @keyframes promotionPulse {
                0% {
                    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.2);
                    transform: scale(1);
                }
                50% {
                    box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
                    transform: scale(1.02);
                }
                100% {
                    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.2);
                    transform: scale(1);
                }
            }

            @keyframes bounce {
                0%, 20%, 50%, 80%, 100% {
                    transform: translateY(0);
                }
                40% {
                    transform: translateY(-5px);
                }
                60% {
                    transform: translateY(-3px);
                }
            }

            @media (max-width: 768px) {
                .promotion-content {
                    flex-direction: column;
                    text-align: center;
                    gap: 10px;
                }

                .promotion-multiplier {
                    margin: 0;
                }

                .promotion-text h3 {
                    font-size: 1.1rem;
                }

                .promotion-text p {
                    font-size: 0.9rem;
                }
            }
        </style>
    </body>
</html>