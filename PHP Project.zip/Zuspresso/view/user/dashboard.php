<?php
/**
 * Zuspresso Customer Dashboard - Zus Coffee Inspired Design
 */
session_start();

// Check if user is logged in and is a customer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

// Get user details from database
require_once '../../database.php';
$db = Database::getInstance()->getConnection();

$sql = "SELECT u.*, c.first_name, c.last_name, c.loyalty_points, c.phone 
        FROM users u 
        JOIN customers c ON u.user_id = c.user_id 
        WHERE u.user_id = ?";
$stmt = $db->prepare($sql);
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$display_name = $user['first_name'] . ' ' . $user['last_name'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard - Zuspresso</title>
        <link rel="stylesheet" href="../../assets/css/navbar.css">
        <style>
            .welcome-section {
                background: white;
                border-radius: 20px;
                padding: 3rem;
                margin-bottom: 2rem;
                box-shadow: 0 4px 30px rgba(0,0,0,0.08);
                position: relative;
                overflow: hidden;
            }

            .welcome-section::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #8B4513, #D2691E, #CD853F);
            }

            .welcome-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 2rem;
            }

            .welcome-text h1 {
                font-size: 2.5rem;
                color: #2c2c2c;
                margin-bottom: 0.5rem;
            }

            .welcome-text p {
                color: #666;
                font-size: 1.1rem;
            }

            .loyalty-badge {
                background: linear-gradient(135deg, #8B4513, #D2691E);
                color: white;
                padding: 1.5rem 2rem;
                border-radius: 15px;
                text-align: center;
                min-width: 200px;
            }

            .loyalty-points {
                font-size: 2.5rem;
                font-weight: 700;
                margin-bottom: 0.5rem;
            }

            .loyalty-label {
                font-size: 0.9rem;
                opacity: 0.9;
            }

            /* Dashboard Grid */
            .dashboard-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 2rem;
                margin-bottom: 2rem;
            }

            .card {
                background: white;
                border-radius: 20px;
                padding: 2rem;
                box-shadow: 0 4px 30px rgba(0,0,0,0.08);
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }

            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 8px 40px rgba(0,0,0,0.12);
            }

            .card-header {
                display: flex;
                align-items: center;
                margin-bottom: 1.5rem;
            }

            .card-icon {
                width: 50px;
                height: 50px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.5rem;
                margin-right: 1rem;
            }

            .card-title {
                font-size: 1.3rem;
                font-weight: 600;
                color: #2c2c2c;
            }

            .card-content {
                color: #666;
                margin-bottom: 1.5rem;
            }

            .btn {
                background: linear-gradient(135deg, #8B4513, #D2691E);
                color: white;
                border: none;
                padding: 0.75rem 1.5rem;
                border-radius: 25px;
                font-weight: 500;
                text-decoration: none;
                display: inline-block;
                transition: all 0.3s ease;
                cursor: pointer;
            }

            .btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 20px rgba(139, 69, 19, 0.3);
            }

            .btn-outline {
                background: transparent;
                border: 2px solid #8B4513;
                color: #8B4513;
            }

            .btn-outline:hover {
                background: #8B4513;
                color: white;
            }

            /* Feature Cards */
            .order-card .card-icon {
                background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
                color: white;
            }

            .rewards-card .card-icon {
                background: linear-gradient(135deg, #4ECDC4, #44A08D);
                color: white;
            }

            .profile-card .card-icon {
                background: linear-gradient(135deg, #45B7D1, #96CEB4);
                color: white;
            }

            /* Stats Section */
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1.5rem;
                margin: 2rem 0;
            }

            .stat-card {
                background: white;
                padding: 1.5rem;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            }

            .stat-number {
                font-size: 2rem;
                font-weight: 700;
                color: #8B4513;
                margin-bottom: 0.5rem;
            }

            .stat-label {
                color: #666;
                font-size: 0.9rem;
            }

            /* Responsive Design */
            @media (max-width: 768px) {
                .welcome-section {
                    padding: 2rem;
                }

                .welcome-header {
                    flex-direction: column;
                    text-align: center;
                    gap: 1rem;
                }

                .welcome-text h1 {
                    font-size: 2rem;
                }

                .dashboard-grid {
                    grid-template-columns: 1fr;
                }
            }

            /* Animation */
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .card {
                animation: fadeInUp 0.6s ease forwards;
            }

            .card:nth-child(2) {
                animation-delay: 0.1s;
            }
            .card:nth-child(3) {
                animation-delay: 0.2s;
            }
        </style>
    </head>
    <body>
        <!-- Include Navigation -->
        <?php include 'navbar.php'; ?>
        
        <!-- Main Content -->
        <div class="container">
            <!-- Welcome Section -->
            <section class="welcome-section">
                <div class="welcome-header">
                    <div class="welcome-text">
                        <h1>Welcome back, <?= htmlspecialchars($user['first_name']) ?>!</h1>
                        <p>Ready to discover your perfect cup of coffee?</p>
                    </div>
                    <div class="loyalty-badge">
                        <div class="loyalty-points"><?= number_format($user['loyalty_points']) ?></div>
                        <div class="loyalty-label">Loyalty Points</div>
                    </div>
                </div>
            </section>

            <!-- Quick Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number">0</div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">RM 0</div>
                    <div class="stat-label">Amount Spent</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">Silver</div>
                    <div class="stat-label">Member Status</div>
                </div>
            </div>

            <!-- Feature Cards -->
            <div class="dashboard-grid">
                <div class="card order-card">
                    <div class="card-header">
                        <div class="card-icon">🛒</div>
                        <h3 class="card-title">Order Now</h3>
                    </div>
                    <div class="card-content">
                        <p>Browse our full menu and place your order for pickup or delivery. Fresh coffee, made just for you.</p>
                    </div>
                    <a href="menu.php" class="btn">Browse Menu</a>
                </div>

                <div class="card rewards-card">
                    <div class="card-header">
                        <div class="card-icon">🎁</div>
                        <h3 class="card-title">Rewards & Offers</h3>
                    </div>
                    <div class="card-content">
                        <p>You have <?= number_format($user['loyalty_points']) ?> points! Redeem them for free drinks, food, and exclusive merchandise.</p>
                    </div>
                    <a href="rewards.php" class="btn btn-outline">View Rewards</a>
                </div>

                <div class="card profile-card">
                    <div class="card-header">
                        <div class="card-icon">👤</div>
                        <h3 class="card-title">My Profile</h3>
                    </div>
                    <div class="card-content">
                        <p>Manage your account details, payment methods, and preferences to enhance your Zuspresso experience.</p>
                    </div>
                    <a href="EditProfile.php" class="btn btn-outline">Edit Profile</a>
                </div>
            </div>

      
        </div>

        <script>
            function logout() {
                if (confirm('Are you sure you want to logout?')) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '/Zuspresso/controller/AuthController.php';

                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'logout';
                    form.appendChild(actionInput);

                    document.body.appendChild(form);
                    form.submit();
                }
            }
            
            // Add smooth scrolling and interactive elements
            document.addEventListener('DOMContentLoaded', function () {
                // Add hover effects to cards
                const cards = document.querySelectorAll('.card');
                cards.forEach(card => {
                    card.addEventListener('mouseenter', function () {
                        this.style.transform = 'translateY(-8px)';
                    });

                    card.addEventListener('mouseleave', function () {
                        this.style.transform = 'translateY(-5px)';
                    });
                });
            });
        </script>
    </body>
</html>