<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun & Tan Cheng Hong (Rewards Integration)
 * @module Cart(order management) & Checkout with Complete Rewards Integration
 * @version 1.0
 */
session_start();

// Check if user is logged in and is a customer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

// Include required models
require_once '../../model/BaseModel.php';
require_once '../../model/Customer.php';
require_once '../../model/Cart.php';
require_once '../../model/MenuItem.php';
require_once '../../model/LoyaltyService.php';
require_once '../../model/RewardRedemption.php';
require_once '../../model/OutputSecurity.php';

// Initialize variables
$display_name = 'Guest';
$user_phone = '';
$user_email = '';
$cart_items = [];
$cart_totals = ['subtotal' => 0, 'tax' => 0, 'total' => 0, 'item_count' => 0];
$error_message = null;
$customer_points = 0;
$available_vouchers = [];
$applied_voucher = null;

try {
    // Get customer details using ORM
    $customer = Customer::getByUserId($_SESSION['user_id']);

    if (!$customer) {
        throw new Exception("Customer record not found. Please contact support.");
    }

    $display_name = $customer->getDisplayName();
    $user_phone = $customer->phone ?? '';
    $user_email = $customer->email ?? '';

    // Get loyalty service and customer points
    $loyaltyService = new LoyaltyService();
    $customer_points = $loyaltyService->getCustomerPoints($customer->customer_id);

    // Get cart data from SESSION instead of database
    $cart_items = $_SESSION['cart'] ?? [];

    // Calculate cart totals from session data
    $cart_totals = [
        'subtotal' => 0,
        'tax' => 0,
        'total' => 0,
        'item_count' => 0,
        'original_subtotal' => 0  // Add this to store the original amount
    ];

    foreach ($cart_items as $item) {
        $itemSubtotal = $item['price'] * $item['quantity'];
        $cart_totals['subtotal'] += $itemSubtotal;
        $cart_totals['item_count'] += $item['quantity'];
    }

// Store the original subtotal BEFORE any discounts
    $cart_totals['original_subtotal'] = $cart_totals['subtotal'];
    $cart_totals['tax'] = $cart_totals['subtotal'] * 0.06; // 6% SST
    $cart_totals['total'] = $cart_totals['subtotal'] + $cart_totals['tax'];

// Get available vouchers
    $redemptions = RewardRedemption::getCustomerRedemptions($_SESSION['user_id']);
    foreach ($redemptions as $redemption) {
        if ($redemption['status'] === 'active' &&
                (!$redemption['expires_at'] || strtotime($redemption['expires_at']) > time())) {
            $available_vouchers[] = $redemption;
        }
    }

    if (isset($_SESSION['applied_voucher'])) {
        $applied_voucher = $_SESSION['applied_voucher'];

        // If reward_value is missing but we have the voucher data, get it from there
        if (!isset($applied_voucher['reward_value']) && isset($applied_voucher['voucher_data']['reward_value'])) {
            $applied_voucher['reward_value'] = $applied_voucher['voucher_data']['reward_value'];
        }

        // Recalculate totals with discount - USE ORIGINAL SUBTOTAL for discount calculation
        if ($applied_voucher['reward_type'] === 'discount') {
            $reward_value = $applied_voucher['reward_value'] ?? ($applied_voucher['voucher_data']['reward_value'] ?? 0);
            $discount = $cart_totals['original_subtotal'] * $reward_value / 100;
            $cart_totals['discount'] = $discount;
            $cart_totals['subtotal'] = $cart_totals['original_subtotal'] - $discount; // Calculate from original
            $cart_totals['tax'] = $cart_totals['subtotal'] * 0.06;
            $cart_totals['total'] = $cart_totals['subtotal'] + $cart_totals['tax'];

            // Ensure the reward_value is available for display
            $applied_voucher['reward_value'] = $reward_value;
        } elseif ($applied_voucher['reward_type'] === 'voucher') {
            $reward_value = $applied_voucher['voucher_data']['reward_value'] ?? ($applied_voucher['reward_value'] ?? 0);
            $discount = min($reward_value, $cart_totals['original_subtotal']);
            $cart_totals['discount'] = $discount;
            $cart_totals['subtotal'] = $cart_totals['original_subtotal'] - $discount; // Calculate from original
            $cart_totals['tax'] = $cart_totals['subtotal'] * 0.06;
            $cart_totals['total'] = $cart_totals['subtotal'] + $cart_totals['tax'];

            // Ensure the reward_value is available for display
            $applied_voucher['reward_value'] = $reward_value;
        }
    }

    // Validate cart items availability
    $menuItemModel = new MenuItem();
    foreach ($cart_items as $key => $item) {
        if (!isset($item['is_free_item']) || !$item['is_free_item']) {
            $menuItem = $menuItemModel->find($item['item_id']);
            if (!$menuItem || !$menuItem->is_available) {
                unset($cart_items[$key]);
                unset($_SESSION['cart'][$key]); // Remove from session too
            }
        }
    }
} catch (Exception $e) {
    $error_message = $e->getMessage();
    error_log("Cart page error: " . $error_message);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cart & Checkout - Zuspresso</title>
        <link rel="stylesheet" href="../../assets/css/navbar.css">
        <link rel="stylesheet" href="../../assets/css/orderModule.css">
        <style>
            .applied-voucher {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                border: 2px solid #28a745;
                border-radius: 8px;
                padding: 1.5rem; /* Increased padding */
                margin-top: 1rem;
                position: relative;
            }

            .voucher-details {
                display: flex;
                justify-content: space-between;
                align-items: flex-start; /* Changed to flex-start for better alignment */
                gap: 1rem; /* Add gap between content and button */
            }

            .voucher-info {
                flex: 1; /* Allow it to take available space */
                min-width: 0; /* Allow text to wrap properly */
            }

            .voucher-info h4 {
                margin: 0 0 0.5rem 0;
                color: #155724;
                font-size: 1.1rem;
                word-wrap: break-word; /* Handle long names */
                line-height: 1.3;
            }

            .voucher-info p {
                margin: 0 0 0.25rem 0;
                color: #6c757d;
                font-size: 0.875rem;
                word-wrap: break-word;
            }

            .remove-voucher-btn {
                background: #dc3545;
                color: white;
                border: none;
                padding: 0.6rem 1.2rem; /* Slightly larger for better touch targets */
                border-radius: 20px;
                font-size: 0.875rem;
                cursor: pointer;
                transition: all 0.3s ease;
                white-space: nowrap; /* Keep button text on one line */
                flex-shrink: 0; /* Prevent button from shrinking */
            }

            /* Better discount row formatting */
            .discount-row {
                color: #28a745;
                font-weight: 600;
                padding: 0.75rem; /* More padding */
                border-radius: 6px;
                margin: 0.5rem 0;
            }

            .discount-row span:first-child {
                word-wrap: break-word;
                flex: 1;
            }

            .discount-row span:last-child {
                white-space: nowrap;
                margin-left: 1rem;
            }
            /* Rewards Integration Styles */
            .rewards-section {
                background: linear-gradient(135deg, #fff8e1 0%, #ffe082 100%);
                border-radius: 12px;
                padding: 1.5rem;
                margin: 1.5rem 0;
                border: 2px solid #ffb300;
            }

            .rewards-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1rem;
            }

            .points-display {
                background: linear-gradient(135deg, #8B4513, #A0522D);
                color: white;
                padding: 0.75rem 1.5rem;
                border-radius: 25px;
                font-weight: 600;
                font-size: 0.9rem;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .voucher-selector {
                margin-top: 1rem;
            }

            .voucher-dropdown {
                width: 100%;
                padding: 0.75rem;
                border: 2px solid #ddd;
                border-radius: 8px;
                font-size: 1rem;
                background: white;
            }

            .applied-voucher {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                border: 2px solid #28a745;
                border-radius: 8px;
                padding: 1rem;
                margin-top: 1rem;
                position: relative;
            }

            .voucher-details {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .voucher-info h4 {
                margin: 0 0 0.25rem 0;
                color: #155724;
                font-size: 1rem;
            }

            .voucher-info p {
                margin: 0;
                color: #6c757d;
                font-size: 0.875rem;
            }

            .remove-voucher-btn {
                background: #dc3545;
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                font-size: 0.875rem;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .remove-voucher-btn:hover {
                background: #c82333;
                transform: translateY(-1px);
            }

            .discount-row {
                color: #28a745;
                font-weight: 600;
            }

            .free-item-badge {
                background: linear-gradient(135deg, #28a745, #20c997);
                color: white;
                padding: 0.25rem 0.75rem;
                border-radius: 15px;
                font-size: 0.75rem;
                font-weight: 600;
                margin-left: 0.5rem;
            }

            .free-items-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 1000;
                align-items: center;
                justify-content: center;
            }

            .free-items-modal.show {
                display: flex;
            }

            .free-items-content {
                background: white;
                border-radius: 12px;
                padding: 2rem;
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
            }

            .free-item-option {
                display: flex;
                align-items: center;
                padding: 1rem;
                border: 2px solid #ddd;
                border-radius: 8px;
                margin-bottom: 1rem;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .free-item-option:hover {
                border-color: #8B4513;
                background: #f8f9fa;
            }

            .free-item-option.selected {
                border-color: #8B4513;
                background: linear-gradient(135deg, #fff8e1, #ffe082);
            }

            .btn-rewards {
                background: linear-gradient(135deg, #ffb300, #ff8f00);
                color: white;
                border: none;
                padding: 0.75rem 1.5rem;
                border-radius: 25px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .btn-rewards:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(255, 179, 0, 0.3);
            }
        </style>
    </head>
    <body>
        <!-- Include Navigation -->
        <?php include 'navbar.php'; ?>

        <!-- Main Content -->
        <div class="container">
            <div class="page-header">
                <h1>Cart & Checkout</h1>
                <p>Review your order and complete your purchase</p>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <?php if (empty($cart_items)): ?>
                <!-- Empty Cart State -->
                <div id="emptyCart" class="empty-cart">
                    <div class="empty-cart-icon">🛒</div>
                    <h2>Your cart is empty</h2>
                    <p>Looks like you haven't added anything to your cart yet.</p>
                    <a href="menu.php" class="btn btn-primary" style="margin-top: 2rem;">Browse Menu</a>
                </div>
            <?php else: ?>
                <!-- Checkout Layout -->
                <div id="checkoutLayout" class="checkout-layout">
                    <!-- Cart Items -->
                    <div class="checkout-section">
                        <h2 class="section-title">Order Items</h2>
                        <div id="cartItems">
                            <?php foreach ($cart_items as $cartKey => $item): ?>
                                <div class="cart-item">
                                    <div class="item-image"><?= OutputSecurity::html(getItemEmoji($item['category'] ?? 'coffee')) ?></div>
                                    <div class="item-details">
                                        <div class="item-name">
                                            <?= OutputSecurity::html($item['name']) ?>
                                            <?php if (isset($item['is_free_item']) && $item['is_free_item']): ?>
                                                <span class="free-item-badge">FREE</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="item-price">
                                            <?php if (isset($item['is_free_item']) && $item['is_free_item']): ?>
                                                <span style="text-decoration: line-through; color: #999;">
                                                    RM <?= number_format(OutputSecurity::float($item['original_price']), 2) ?>
                                                </span>
                                                <span style="color: #28a745; font-weight: 600;">FREE</span>
                                            <?php else: ?>
                                                RM <?= number_format(OutputSecurity::float($item['price']), 2) ?> each
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="item-controls">
                                        <?php if (!isset($item['is_free_item']) || !$item['is_free_item']): ?>
                                            <div class="quantity-controls">
                                                <button class="quantity-btn" 
                                                        onclick="updateQuantity('<?= OutputSecurity::attr($cartKey) ?>', <?= OutputSecurity::int($item['quantity'] - 1) ?>)">
                                                    -
                                                </button>
                                                <span style="margin: 0 1rem; font-weight: 600;">
                                                    <?= OutputSecurity::int($item['quantity']) ?>
                                                </span>
                                                <button class="quantity-btn" 
                                                        onclick="updateQuantity('<?= OutputSecurity::attr($cartKey) ?>', <?= OutputSecurity::int($item['quantity'] + 1) ?>)">
                                                    +
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <div style="margin: 0 1rem; font-weight: 600; color: #28a745;">
                                                Qty: 1 (FREE)
                                            </div>
                                        <?php endif; ?>
                                        <div style="font-weight: 600; color: #8B4513;">
                                            RM <?= number_format(OutputSecurity::float($item['price']) * OutputSecurity::int($item['quantity']), 2) ?>
                                        </div>
                                        <button class="remove-btn" onclick="removeItem('<?= OutputSecurity::attr($cartKey) ?>')">
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Rewards Section -->
                        <div class="rewards-section">
                            <div class="rewards-header">
                                <h3 style="margin: 0; color: #8B4513;">💎 Rewards & Vouchers</h3>
                                <div class="points-display">
                                    <span>⭐</span> <?= number_format($customer_points) ?> Points
                                </div>
                            </div>

                            <?php if ($applied_voucher): ?>
                                <!-- Applied Voucher Display -->
                                <div class="applied-voucher">
                                    <div class="voucher-details">
                                        <div class="voucher-info">
                                            <h4><?= htmlspecialchars($applied_voucher['reward_name'] ?? 'Voucher Applied') ?></h4>
                                            <p>Code: <?= htmlspecialchars($applied_voucher['redemption_code']) ?></p>
                                            <?php if ($applied_voucher['reward_type'] === 'free_item'): ?>
                                                <p style="color: #28a745; font-weight: 600;">Free item added to cart!</p>
                                            <?php endif; ?>
                                        </div>
                                        <button class="remove-voucher-btn" onclick="removeVoucher()">Remove</button>
                                    </div>
                                </div>
                            <?php elseif (!empty($available_vouchers)): ?>
                                <!-- Voucher Selection -->
                                <div class="voucher-selector">
                                    <label for="voucherSelect" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Select a voucher to apply:</label>
                                    <select id="voucherSelect" class="voucher-dropdown" onchange="handleVoucherSelection()">
                                        <option value="">Choose a voucher...</option>
                                        <?php foreach ($available_vouchers as $voucher): ?>
                                            <option value="<?= htmlspecialchars($voucher['redemption_code']) ?>" 
                                                    data-type="<?= $voucher['reward_type'] ?>"
                                                    data-value="<?= $voucher['reward_value'] ?? 0 ?>">
                                                        <?= htmlspecialchars($voucher['reward_name']) ?>
                                                        <?php if ($voucher['reward_type'] === 'discount'): ?>
                                                    (<?= $voucher['reward_value'] ?>% off)
                                                <?php elseif ($voucher['reward_type'] === 'voucher'): ?>
                                                    (RM <?= number_format($voucher['reward_value'], 2) ?> off)
                                                <?php elseif ($voucher['reward_type'] === 'free_item'): ?>
                                                    (Free Item)
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php else: ?>
                                <p style="text-align: center; color: #6c757d; margin: 1rem 0;">
                                    No vouchers available. <a href="rewards.php" style="color: #8B4513;">Redeem rewards</a> to get vouchers!
                                </p>
                            <?php endif; ?>
                        </div>

                        <div style="margin-top: 2rem;">
                            <a href="menu.php" class="btn btn-secondary">Continue Shopping</a>
                        </div>
                    </div>

                    <!-- Order Summary & Checkout -->
                    <div class="checkout-section">
                        <h2 class="section-title">Order Summary</h2>

                        <div id="orderSummary">
                            <div class="summary-row">
                                <span>Original Subtotal (<?= $cart_totals['item_count'] ?> items):</span>
                                <span>RM <?= number_format($cart_totals['original_subtotal'], 2) ?></span>
                            </div>

                            <?php if (isset($cart_totals['discount']) && $cart_totals['discount'] > 0): ?>
                                <div class="summary-row discount-row" style="background: #f0f8f0; padding: 0.5rem; border-radius: 4px; margin: 0.5rem 0;">
                                    <span>Voucher: "<?= htmlspecialchars($applied_voucher['reward_name'] ?? 'Discount') ?>"</span>
                                    <span>-RM <?= number_format($cart_totals['discount'], 2) ?></span>
                                </div>

                                <?php if ($applied_voucher && $applied_voucher['reward_type'] === 'discount'): ?>
                                    <div style="font-size: 0.875rem; color: #28a745; text-align: center; margin: 0.25rem 0;">
                                        (<?= $applied_voucher['reward_value'] ?? ($applied_voucher['voucher_data']['reward_value'] ?? 0) ?>% discount applied)
                                    </div>
                                <?php endif; ?>

                                <hr style="margin: 0.75rem 0; border: none; border-top: 1px dashed #ddd;">

                                <div class="summary-row" style="font-weight: 600; color: #28a745;">
                                    <span>Discounted Subtotal:</span>
                                    <span>RM <?= number_format($cart_totals['subtotal'], 2) ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="summary-row">
                                <span>Tax (6% SST):</span>
                                <span>RM <?= number_format($cart_totals['tax'], 2) ?></span>
                            </div>
                            <div class="summary-row" id="deliveryFeeRow">
                                <span>Delivery Fee:</span>
                                <span>RM 3.00</span>
                            </div>

                            <hr style="margin: 1rem 0; border: none; border-top: 2px solid #8B4513;">

                            <div class="summary-row total" style="font-size: 1.1rem; font-weight: 700; color: #8B4513;">
                                <span>Total:</span>
                                <span id="orderTotal">RM <?= number_format($cart_totals['total'] + 3, 2) ?></span>
                            </div>

                            <?php if (isset($cart_totals['discount']) && $cart_totals['discount'] > 0): ?>
                                <div style="background: linear-gradient(135deg, #d4edda, #c3e6cb); padding: 0.75rem; border-radius: 8px; margin-top: 1rem; text-align: center; border: 1px solid #28a745;">
                                    <div style="color: #155724; font-weight: 600; font-size: 0.9rem;">
                                        🎉 You saved RM <?= number_format($cart_totals['discount'], 2) ?> with your voucher!
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Rest of the checkout form remains the same as original -->
                        <form id="checkoutForm" style="margin-top: 2rem;">
                            <!-- Order Type Selection -->
                            <div class="form-group">
                                <label>Order Type *</label>
                                <div class="order-type-options">
                                    <div class="order-type-option">
                                        <input type="radio" id="delivery" name="order_type" value="delivery" checked onchange="toggleOrderType('delivery')">
                                        <label for="delivery" class="order-type-card">
                                            <div class="order-type-icon">🚗</div>
                                            <div class="order-type-label">Delivery</div>
                                            <div class="order-type-desc">Get it delivered to your doorstep</div>
                                        </label>
                                    </div>
                                    <div class="order-type-option">
                                        <input type="radio" id="pickup" name="order_type" value="pickup" onchange="toggleOrderType('pickup')">
                                        <label for="pickup" class="order-type-card">
                                            <div class="order-type-icon">🏪</div>
                                            <div class="order-type-label">Pickup</div>
                                            <div class="order-type-desc">Pick it up from our store</div>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Pickup Notice -->
                            <div id="pickupNotice" class="pickup-notice">
                                <strong>Pickup Location:</strong><br>
                                Your order will be ready for pickup at our main branch.<br>
                            </div>

                            <!-- Delivery Address (hidden for pickup) -->
                            <div id="deliveryFields" class="delivery-fields">
                                <div class="form-group">
                                    <label for="delivery_address">Delivery Address *</label>
                                    <textarea id="delivery_address" name="delivery_address" placeholder="Enter your full delivery address" required></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" id="phone" name="phone" 
                                       value="<?= OutputSecurity::attr($user_phone) ?>" 
                                       placeholder="Your contact number" required>
                            </div>

                            <div class="form-group">
                                <label for="notes">Special Instructions</label>
                                <textarea id="notes" name="notes" placeholder="Any special requests or notes for your order"></textarea>
                            </div>

                            <div class="form-group">
                                <label>Payment Method *</label>
                                <div class="payment-methods">
                                    <div class="payment-option">
                                        <input type="radio" id="cash" name="payment_method" value="cash" checked onchange="showPaymentDetails('cash')">
                                        <label for="cash" class="payment-card">
                                            <div class="payment-icon">💵</div>
                                            <div class="payment-label">Cash</div>
                                        </label>
                                    </div>
                                    <div class="payment-option">
                                        <input type="radio" id="card" name="payment_method" value="card" onchange="showPaymentDetails('card')">
                                        <label for="card" class="payment-card">
                                            <div class="payment-icon">💳</div>
                                            <div class="payment-label">Card</div>
                                        </label>
                                    </div>
                                    <div class="payment-option">
                                        <input type="radio" id="ewallet" name="payment_method" value="ewallet" onchange="showPaymentDetails('ewallet')">
                                        <label for="ewallet" class="payment-card">
                                            <div class="payment-icon">📱</div>
                                            <div class="payment-label">E-Wallet</div>
                                        </label>
                                    </div>
                                </div>

                                <!-- Payment Details Sections -->
                                <div id="cashDetails" class="payment-details active">
                                    <h4>💵 Cash Payment</h4>
                                    <p>Pay with cash upon delivery. Please have the exact amount ready.</p>
                                    <div class="security-notice">
                                        <span class="security-icon">ℹ️</span>
                                        Our delivery rider will provide you with a receipt upon payment.
                                    </div>
                                </div>

                                <div id="cardDetails" class="payment-details">
                                    <h4>💳 Card Payment</h4>
                                    <div class="form-group">
                                        <label for="card_number">Card Number *</label>
                                        <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19">
                                        <div class="card-icons">
                                            <span class="card-icon">VISA</span>
                                            <span class="card-icon">MC</span>
                                            <span class="card-icon">AMEX</span>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="expiry_date">Expiry Date *</label>
                                            <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY" maxlength="5">
                                        </div>
                                        <div class="form-group">
                                            <label for="cvv">CVV *</label>
                                            <input type="text" id="cvv" name="cvv" placeholder="123" maxlength="4">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="card_holder_name">Cardholder Name *</label>
                                        <input type="text" id="card_holder_name" name="card_holder_name" placeholder="Name as shown on card">
                                    </div>
                                    <div class="security-notice">
                                        <span class="security-icon">🔒</span>
                                        Your card information is securely encrypted and processed by our payment gateway.
                                    </div>
                                </div>

                                <div id="ewalletDetails" class="payment-details">
                                    <h4>📱 E-Wallet Payment</h4>
                                    <div class="form-group">
                                        <label>Select E-Wallet Provider *</label>
                                        <div class="ewallet-options">
                                            <div class="ewallet-option">
                                                <input type="radio" id="grabpay" name="ewallet_provider" value="grabpay">
                                                <label for="grabpay" style="display: flex; align-items: center; cursor: pointer;">
                                                    <div class="ewallet-logo" style="background: #00b14f; color: white;">G</div>
                                                    GrabPay
                                                </label>
                                            </div>
                                            <div class="ewallet-option">
                                                <input type="radio" id="tng" name="ewallet_provider" value="touchngo">
                                                <label for="tng" style="display: flex; align-items: center; cursor: pointer;">
                                                    <div class="ewallet-logo" style="background: #1e3a8a; color: white;">T</div>
                                                    Touch 'n Go
                                                </label>
                                            </div>
                                            <div class="ewallet-option">
                                                <input type="radio" id="boost" name="ewallet_provider" value="boost">
                                                <label for="boost" style="display: flex; align-items: center; cursor: pointer;">
                                                    <div class="ewallet-logo" style="background: #ff6b35; color: white;">B</div>
                                                    Boost
                                                </label>
                                            </div>
                                            <div class="ewallet-option">
                                                <input type="radio" id="paypal" name="ewallet_provider" value="paypal">
                                                <label for="paypal" style="display: flex; align-items: center; cursor: pointer;">
                                                    <div class="ewallet-logo" style="background: #0070ba; color: white;">P</div>
                                                    PayPal
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="paypalFields" style="display: none;">
                                        <div class="form-group">
                                            <label for="paypal_email">PayPal Email *</label>
                                            <input type="email" id="paypal_email" name="paypal_email" placeholder="your.email@example.com">
                                        </div>
                                    </div>

                                    <div id="tngFields" style="display: none;">
                                        <div class="form-group">
                                            <label for="tng_phone">Touch 'n Go Registered Phone *</label>
                                            <input type="tel" id="tng_phone" name="tng_phone" placeholder="+60123456789">
                                        </div>
                                    </div>

                                    <div class="security-notice">
                                        <span class="security-icon">🔒</span>
                                        You will be redirected to your selected e-wallet provider to complete the payment securely.
                                    </div>
                                </div>
                            </div>

                            <div class="checkout-actions">
                                <button type="button" class="btn btn-secondary btn-full" onclick="clearCart()">
                                    Clear Cart
                                </button>
                                <button type="submit" class="btn btn-primary btn-full">
                                    Place Order
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Free Items Selection Modal -->
        <div class="free-items-modal" id="freeItemsModal">
            <div class="free-items-content">
                <h3 style="margin-bottom: 1.5rem; color: #8B4513;">🎁 Select Your Free Item</h3>
                <div id="freeItemsList">
                    <!-- Free items will be loaded here -->
                </div>
                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button class="btn btn-secondary" onclick="closeFreeItemsModal()">Cancel</button>
                    <button class="btn-rewards" onclick="addSelectedFreeItem()" id="addFreeItemBtn" disabled>Add Free Item</button>
                </div>
            </div>
        </div>

        <!-- Success Modal -->
        <div class="success-modal" id="successModal">
            <div class="success-modal-content">
                <div class="success-modal-icon">✅</div>
                <h2>Order Placed Successfully!</h2>
                <p id="orderSuccessMessage">Your order has been received and is being prepared.</p>
                <div id="pointsEarned" style="margin: 1rem 0; padding: 1rem; background: linear-gradient(135deg, #fff8e1, #ffe082); border-radius: 8px; display: none;">
                    <h4 style="margin: 0 0 0.5rem 0; color: #8B4513;">🎉 Points Earned!</h4>
                    <p style="margin: 0; color: #6c757d;">You've earned <strong id="pointsAmount">0</strong> loyalty points from this order!</p>
                </div>
                <button class="btn btn-primary" onclick="redirectToOrders()">
                    View Orders
                </button>
            </div>
        </div>

        <!-- Notification -->
        <div class="notification" id="notification"></div>

        <script>
            let cartData = {
                cart_items: <?= OutputSecurity::js($cart_items) ?>,
                cart_totals: <?= OutputSecurity::js($cart_totals) ?>
            };

            let selectedFreeItem = null;
            let currentVoucherCode = null;

            document.addEventListener('DOMContentLoaded', function () {
                setupCheckoutForm();
                setupPaymentValidation();
            });

            // Handle voucher selection
            async function handleVoucherSelection() {
                const select = document.getElementById('voucherSelect');
                const selectedCode = select.value;

                if (!selectedCode)
                    return;

                const selectedOption = select.options[select.selectedIndex];
                const rewardType = selectedOption.dataset.type;

                // Add loading state to dropdown
                select.disabled = true;
                const originalText = selectedOption.textContent;
                selectedOption.textContent = '🔄 Applying voucher...';

                try {
                    if (rewardType === 'free_item') {
                        await showFreeItemsModal(selectedCode);
                    } else {
                        await applyVoucher(selectedCode);
                    }
                } catch (error) {
                    console.error('Error handling voucher selection:', error);
                    showNotification('Error applying voucher', 'error');
                } finally {
                    // Reset dropdown state
                    select.disabled = false;
                    selectedOption.textContent = originalText;
                }
            }

            // Show free items selection modal
            async function showFreeItemsModal(voucherCode) {
                currentVoucherCode = voucherCode;

                try {
                    const formData = new FormData();
                    formData.append('action', 'get_free_items');
                    formData.append('voucher_code', voucherCode);

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success && data.free_items) {
                        displayFreeItems(data.free_items);
                        document.getElementById('freeItemsModal').classList.add('show');
                    } else {
                        showNotification('Error loading free items', 'error');
                    }
                } catch (error) {
                    console.error('Error fetching free items:', error);
                    showNotification('Error loading free items', 'error');
                }
            }

            // Display free items in modal
            function displayFreeItems(items) {
                const container = document.getElementById('freeItemsList');
                container.innerHTML = '';

                items.forEach(item => {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'free-item-option';
                    itemDiv.onclick = () => selectFreeItem(item.item_id, itemDiv);

                    itemDiv.innerHTML = `
            <div style="margin-right: 1rem; font-size: 2rem;">
                ${getItemEmoji(item.category)}
            </div>
            <div style="flex: 1;">
                <h4 style="margin: 0 0 0.25rem 0;">${item.name}</h4>
                <p style="margin: 0; color: #6c757d; font-size: 0.875rem;">${item.description || 'Delicious beverage'}</p>
                <p style="margin: 0.25rem 0 0 0; color: #28a745; font-weight: 600;">FREE (Worth RM ${parseFloat(item.price).toFixed(2)})</p>
            </div>
        `;

                    container.appendChild(itemDiv);
                });
            }

            // Select free item
            function selectFreeItem(itemId, element) {
                document.querySelectorAll('.free-item-option').forEach(option => {
                    option.classList.remove('selected');
                });

                element.classList.add('selected');
                selectedFreeItem = itemId;
                document.getElementById('addFreeItemBtn').disabled = false;
            }

            // Add selected free item to cart
            async function addSelectedFreeItem() {
                if (!selectedFreeItem || !currentVoucherCode)
                    return;

                try {
                    const formData = new FormData();
                    formData.append('action', 'add_free_item_to_cart');
                    formData.append('item_id', selectedFreeItem);
                    formData.append('redemption_code', currentVoucherCode);

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification('Free item added to cart!');
                        closeFreeItemsModal();
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error adding free item:', error);
                    showNotification('Error adding free item', 'error');
                }
            }

            // Close free items modal
            function closeFreeItemsModal() {
                document.getElementById('freeItemsModal').classList.remove('show');
                document.getElementById('voucherSelect').value = '';
                selectedFreeItem = null;
                currentVoucherCode = null;
                document.getElementById('addFreeItemBtn').disabled = true;
            }

            async function applyVoucher(redemptionCode) {
                try {
                    const formData = new FormData();
                    formData.append('action', 'apply_voucher');
                    formData.append('redemption_code', redemptionCode);

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        // Get voucher value from dropdown if not provided in response
                        const select = document.getElementById('voucherSelect');
                        const selectedOption = select.options[select.selectedIndex];

                        // Ensure reward_value is available
                        if (!data.reward_value && selectedOption.dataset.value) {
                            data.reward_value = parseFloat(selectedOption.dataset.value);
                        }

                        // Immediately update the UI without reload
                        await updateUIAfterVoucherApplication(data, redemptionCode);

                        // Show success notification
                        showEnhancedNotification('Voucher applied successfully!', 'success');

                        // No reload needed - all updates are done client-side
                    } else {
                        showNotification(data.message, 'error');
                        // Reset the dropdown
                        document.getElementById('voucherSelect').value = '';
                    }
                } catch (error) {
                    console.error('Error applying voucher:', error);
                    showNotification('Error applying voucher', 'error');
                    document.getElementById('voucherSelect').value = '';
                }
            }

            function getSelectedVoucherName() {
                const select = document.getElementById('voucherSelect');
                const selectedOption = select.options[select.selectedIndex];
                return selectedOption.textContent.replace('🎫 ', '').split(' (')[0];
            }

            async function removeVoucher() {
                const removeBtn = document.querySelector('.remove-voucher-btn');
                const originalText = removeBtn.textContent;

                // Show loading state
                removeBtn.disabled = true;
                removeBtn.textContent = '🔄 Removing...';
                removeBtn.style.opacity = '0.7';

                try {
                    const formData = new FormData();
                    formData.append('action', 'remove_voucher');

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        // Smoothly remove the voucher and update UI
                        await updateUIAfterVoucherRemoval();
                        showEnhancedNotification('Voucher removed successfully!', 'success');
                    } else {
                        showNotification(data.message || 'Failed to remove voucher', 'error');
                        // Reset button state on error
                        removeBtn.disabled = false;
                        removeBtn.textContent = originalText;
                        removeBtn.style.opacity = '1';
                    }
                } catch (error) {
                    console.error('Error removing voucher:', error);
                    showNotification('Error removing voucher. Please try again.', 'error');

                    // Reset button state on error
                    removeBtn.disabled = false;
                    removeBtn.textContent = originalText;
                    removeBtn.style.opacity = '1';
                }
            }

            async function updateUIAfterVoucherRemoval() {
                // 1. Animate out the applied voucher section
                const appliedVoucherSection = document.querySelector('.applied-voucher');
                if (appliedVoucherSection) {
                    appliedVoucherSection.style.transition = 'all 0.5s ease-out';
                    appliedVoucherSection.style.opacity = '0';
                    appliedVoucherSection.style.transform = 'translateY(-10px)';

                    setTimeout(() => {
                        appliedVoucherSection.remove();
                    }, 500);
                }

                // 2. Calculate and update totals without discount - use original_subtotal if available
                const currentTotals = cartData.cart_totals;
                const originalSubtotal = currentTotals.original_subtotal || (currentTotals.subtotal + (currentTotals.discount || 0));

                const updatedTotals = {
                    subtotal: originalSubtotal,
                    original_subtotal: originalSubtotal, // Keep track of original
                    tax: originalSubtotal * 0.06,
                    total: 0,
                    item_count: currentTotals.item_count,
                    discount: 0
                };
                updatedTotals.total = updatedTotals.subtotal + updatedTotals.tax;

                // 3. Update order summary with animation
                updateOrderSummaryWithAnimation(updatedTotals);

                // 4. Show voucher selector again
                setTimeout(() => {
                    showVoucherSelector();
                }, 600);
            }

            function showVoucherSelector() {
                const rewardsSection = document.querySelector('.rewards-section');

                // Check if voucher selector already exists
                if (document.querySelector('.voucher-selector')) {
                    const voucherSelector = document.querySelector('.voucher-selector');
                    voucherSelector.style.display = 'block';
                    voucherSelector.style.transition = 'all 0.5s ease-out';
                    voucherSelector.style.transform = 'translateY(0)';
                    voucherSelector.style.opacity = '1';
                    return;
                }

                // Create new voucher selector
                const voucherSelectorHTML = `
        <div class="voucher-selector" style="opacity: 0; transform: translateY(10px); transition: all 0.5s ease-out;">
            <label for="voucherSelect" style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Select a voucher to apply:</label>
            <select id="voucherSelect" class="voucher-dropdown" onchange="handleVoucherSelection()">
                <option value="">Choose a voucher...</option>
            </select>
        </div>
    `;

                rewardsSection.insertAdjacentHTML('beforeend', voucherSelectorHTML);

                // Animate in
                setTimeout(() => {
                    const voucherSelector = document.querySelector('.voucher-selector');
                    if (voucherSelector) {
                        voucherSelector.style.opacity = '1';
                        voucherSelector.style.transform = 'translateY(0)';
                    }
                }, 100);

                // Repopulate the voucher options
                repopulateVoucherOptions();
            }

            function repopulateVoucherOptions() {
                const voucherSelect = document.getElementById('voucherSelect');
                if (voucherSelect) {
                    voucherSelect.value = '';
                }
            }

            function showEnhancedNotification(message, type = 'success') {
                const notification = document.getElementById('notification');
                notification.textContent = message;
                notification.className = `notification ${type}`;
                notification.style.transform = 'translateY(-100%)';
                notification.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
                notification.classList.add('show');

                // Animate in
                setTimeout(() => {
                    notification.style.transform = 'translateY(0)';
                }, 10);

                // Auto hide with animation
                setTimeout(() => {
                    notification.style.transform = 'translateY(-100%)';
                    setTimeout(() => {
                        notification.classList.remove('show');
                    }, 400);
                }, 3000);
            }

            async function updateUIAfterVoucherApplication(data, redemptionCode) {
                // 1. Update order summary with smooth transition
                const orderSummary = document.getElementById('orderSummary');
                orderSummary.style.transition = 'opacity 0.3s ease';
                orderSummary.style.opacity = '0.7';

                // 2. Hide the voucher selector section with animation
                const voucherSelector = document.querySelector('.voucher-selector');
                if (voucherSelector) {
                    voucherSelector.style.transition = 'all 0.5s ease-out';
                    voucherSelector.style.transform = 'translateY(-10px)';
                    voucherSelector.style.opacity = '0';

                    setTimeout(() => {
                        voucherSelector.style.display = 'none';
                    }, 500);
                }

                // 3. Create and show applied voucher section
                setTimeout(() => {
                    createAppliedVoucherSection(data, redemptionCode);
                    updateOrderSummaryContent(data);

                    // Restore order summary opacity
                    orderSummary.style.opacity = '1';

                    // Update cart data
                    updateCartData(data);
                }, 300);
            }

            function updateCartData(data) {
                // Update the global cart data object
                if (data.new_totals) {
                    cartData.cart_totals = data.new_totals;
                }
            }

            function updateOrderSummaryContent(data) {
                // Get the selected voucher info from the dropdown option
                const select = document.getElementById('voucherSelect');
                const selectedOption = select.options[select.selectedIndex];

                const voucherInfo = {
                    reward_name: getSelectedVoucherName(),
                    reward_type: data.reward_type,
                    reward_value: data.reward_value || selectedOption.dataset.value || 0
                };

                const summaryHTML = generateOrderSummaryHTML(data.new_totals, voucherInfo);
                document.getElementById('orderSummary').innerHTML = summaryHTML;

                // Update pickup/delivery totals
                updateOrderTypeDisplay();
            }


            function createAppliedVoucherSection(data, redemptionCode) {
                const rewardsSection = document.querySelector('.rewards-section');
                const voucherSelector = document.querySelector('.voucher-selector');

                // Get the selected voucher info from dropdown for display
                const select = document.getElementById('voucherSelect');
                const selectedOption = select.options[select.selectedIndex];
                const voucherName = getSelectedVoucherName();
                const rewardValue = data.reward_value || selectedOption.dataset.value || 0;

                // Create applied voucher HTML with proper reward value
                const appliedVoucherHTML = `
        <div class="applied-voucher" style="opacity: 0; transform: translateY(10px); transition: all 0.5s ease-out;">
            <div class="voucher-details">
                <div class="voucher-info">
                    <h4>${voucherName}</h4>                  
                    <p>Code: ${redemptionCode}</p>
                    ${data.reward_type === 'free_item' ?
                        '<p style="color: #28a745; font-weight: 600;">Free item added to cart!</p>' :
                        data.reward_type === 'discount' ?
                        `<p style="color: #28a745; font-weight: 600;">${rewardValue}% discount applied</p>` :
                        `<p style="color: #28a745; font-weight: 600;">RM ${parseFloat(rewardValue).toFixed(2)} discount applied</p>`
                        }
                </div>
                <button class="remove-voucher-btn" onclick="removeVoucher()">Remove</button>
            </div>
        </div>
    `;

                // Insert the applied voucher section
                if (voucherSelector) {
                    voucherSelector.insertAdjacentHTML('afterend', appliedVoucherHTML);
                } else {
                    rewardsSection.insertAdjacentHTML('beforeend', appliedVoucherHTML);
                }

                // Animate in the applied voucher
                setTimeout(() => {
                    const appliedVoucher = document.querySelector('.applied-voucher');
                    if (appliedVoucher) {
                        appliedVoucher.style.opacity = '1';
                        appliedVoucher.style.transform = 'translateY(0)';
                    }
                }, 100);
            }


            function updateOrderSummaryWithAnimation(totals) {
                const orderSummary = document.getElementById('orderSummary');

                // Add transition effect
                orderSummary.style.transition = 'opacity 0.3s ease';
                orderSummary.style.opacity = '0.7';

                setTimeout(() => {
                    // Generate new summary HTML without discount
                    const newSummaryHTML = `
            <div class="summary-row">
    <span>Subtotal:</span>
    <span>RM <?= OutputSecurity::float($cart_totals['subtotal']) ?></span>
</div>
<div class="summary-row">
    <span>Tax (6% SST):</span>
    <span>RM <?= OutputSecurity::float($cart_totals['tax']) ?></span>
</div>
<div class="summary-row total">
    <span>Total:</span>
    <span>RM <?= OutputSecurity::float($cart_totals['total'] + 3) ?></span>
</div>
        `;

                    orderSummary.innerHTML = newSummaryHTML;

                    // Restore opacity
                    orderSummary.style.opacity = '1';

                    // Update cart data
                    cartData.cart_totals = totals;
                }, 200);
            }

            // Toggle between pickup and delivery
            function toggleOrderType(type) {
                const deliveryFields = document.getElementById('deliveryFields');
                const pickupNotice = document.getElementById('pickupNotice');
                const deliveryAddress = document.getElementById('delivery_address');
                const deliveryFeeRow = document.getElementById('deliveryFeeRow');
                const orderTotal = document.getElementById('orderTotal');

                if (type === 'pickup') {
                    deliveryFields.classList.add('hidden');
                    pickupNotice.classList.add('show');
                    deliveryAddress.removeAttribute('required');
                    deliveryFeeRow.style.display = 'none';
                    orderTotal.textContent = 'RM ' + cartData.cart_totals.total.toFixed(2);
                } else {
                    deliveryFields.classList.remove('hidden');
                    pickupNotice.classList.remove('show');
                    deliveryAddress.setAttribute('required', 'required');
                    deliveryFeeRow.style.display = 'flex';
                    orderTotal.textContent = 'RM ' + (cartData.cart_totals.total + 3).toFixed(2);
                }
            }

            // Show payment details based on selected method
            function showPaymentDetails(method) {
                document.querySelectorAll('.payment-details').forEach(detail => {
                    detail.classList.remove('active');
                });
                document.getElementById(method + 'Details').classList.add('active');

                if (method === 'ewallet') {
                    setupEwalletProviders();
                }
            }

            // Setup e-wallet provider selection
            function setupEwalletProviders() {
                const providers = document.querySelectorAll('input[name="ewallet_provider"]');
                providers.forEach(provider => {
                    provider.addEventListener('change', function () {
                        document.getElementById('paypalFields').style.display = 'none';
                        document.getElementById('tngFields').style.display = 'none';

                        if (this.value === 'paypal') {
                            document.getElementById('paypalFields').style.display = 'block';
                        } else if (this.value === 'touchngo') {
                            document.getElementById('tngFields').style.display = 'block';
                        }
                    });
                });
            }

            // Setup payment validation
            function setupPaymentValidation() {
                const cardNumberInput = document.getElementById('card_number');
                if (cardNumberInput) {
                    cardNumberInput.addEventListener('input', function (e) {
                        let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                        let matches = value.match(/\d{4,16}/g);
                        let match = matches && matches[0] || '';
                        let parts = [];
                        for (let i = 0; i < match.length; i += 4) {
                            parts.push(match.substring(i, i + 4));
                        }
                        e.target.value = parts.length ? parts.join(' ') : value;
                    });
                }

                const expiryInput = document.getElementById('expiry_date');
                if (expiryInput) {
                    expiryInput.addEventListener('input', function (e) {
                        let value = e.target.value.replace(/\D/g, '');
                        if (value.length >= 2) {
                            value = value.substring(0, 2) + '/' + value.substring(2, 4);
                        }
                        e.target.value = value;
                    });
                }

                const cvvInput = document.getElementById('cvv');
                if (cvvInput) {
                    cvvInput.addEventListener('input', function (e) {
                        e.target.value = e.target.value.replace(/\D/g, '');
                    });
                }

                const tngPhoneInput = document.getElementById('tng_phone');
                if (tngPhoneInput) {
                    tngPhoneInput.addEventListener('input', function (e) {
                        let value = e.target.value.replace(/\D/g, '');
                        if (value.startsWith('60')) {
                            value = '+' + value;
                        } else if (value.startsWith('0')) {
                            value = '+6' + value;
                        } else if (!value.startsWith('+')) {
                            value = '+60' + value;
                        }
                        e.target.value = value;
                    });
                }
            }

            // Update quantity
            async function updateQuantity(cartKey, newQuantity) {
                const formData = new FormData();
                formData.append('action', 'update_cart');
                formData.append('cart_key', cartKey);
                formData.append('quantity', newQuantity);

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification(data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error updating quantity:', error);
                    showNotification('Failed to update quantity', 'error');
                }
            }

            // Remove item
            async function removeItem(cartKey) {
                if (!confirm('Remove this item from your cart?'))
                    return;

                const formData = new FormData();
                formData.append('action', 'remove_from_cart');
                formData.append('cart_key', cartKey);

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification(data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error removing item:', error);
                    showNotification('Failed to remove item', 'error');
                }
            }

            // Clear cart
            async function clearCart() {
                if (!confirm('Are you sure you want to clear your cart?'))
                    return;

                const formData = new FormData();
                formData.append('action', 'clear_cart');

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification(data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error clearing cart:', error);
                    showNotification('Failed to clear cart', 'error');
                }
            }

            // Setup checkout form
            function setupCheckoutForm() {
                const form = document.getElementById('checkoutForm');
                if (form) {
                    form.addEventListener('submit', handleCheckout);
                }
            }

            // Handle checkout
            async function handleCheckout(e) {
                e.preventDefault();

                const orderType = document.querySelector('input[name="order_type"]:checked').value;
                const paymentMethod = document.querySelector('input[name="payment_method"]:checked').value;

                if (!validatePaymentDetails(paymentMethod)) {
                    return;
                }

                if (orderType === 'pickup') {
                    document.getElementById('delivery_address').value = 'Pickup at Store';
                }

                const formData = new FormData(e.target);
                formData.append('action', 'place_order');

                const submitBtn = e.target.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;

                submitBtn.disabled = true;
                submitBtn.textContent = 'Processing...';

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        const orderTypeText = orderType === 'pickup' ?
                                ' for pickup' : ' and will be delivered soon';
                        document.getElementById('orderSuccessMessage').textContent =
                                `Order #${data.order_id} has been placed successfully${orderTypeText}!`;

                        if (data.points_earned) {
                            document.getElementById('pointsAmount').textContent = data.points_earned;
                            document.getElementById('pointsEarned').style.display = 'block';
                        }

                        document.getElementById('successModal').classList.add('show');
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error placing order:', error);
                    showNotification('Failed to place order', 'error');
                } finally {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }
            }

            // Validate payment details
            function validatePaymentDetails(method) {
                switch (method) {
                    case 'cash':
                        return true;
                    case 'card':
                        return validateCardDetails();
                    case 'ewallet':
                        return validateEwalletDetails();
                    default:
                        return false;
                }
            }

            // Validate card payment details
            function validateCardDetails() {
                const cardNumber = document.getElementById('card_number').value.replace(/\s/g, '');
                const expiryDate = document.getElementById('expiry_date').value;
                const cvv = document.getElementById('cvv').value;
                const cardHolderName = document.getElementById('card_holder_name').value.trim();

                if (!cardNumber || cardNumber.length < 13 || cardNumber.length > 19) {
                    showNotification('Please enter a valid card number', 'error');
                    document.getElementById('card_number').focus();
                    return false;
                }

                if (!expiryDate || !/^\d{2}\/\d{2}$/.test(expiryDate)) {
                    showNotification('Please enter a valid expiry date (MM/YY)', 'error');
                    document.getElementById('expiry_date').focus();
                    return false;
                }

                const [month, year] = expiryDate.split('/');
                const currentDate = new Date();
                const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);
                if (expiryDateObj < currentDate) {
                    showNotification('Card has expired', 'error');
                    document.getElementById('expiry_date').focus();
                    return false;
                }

                if (!cvv || cvv.length < 3 || cvv.length > 4) {
                    showNotification('Please enter a valid CVV', 'error');
                    document.getElementById('cvv').focus();
                    return false;
                }

                if (!cardHolderName || cardHolderName.length < 2) {
                    showNotification('Please enter the cardholder name', 'error');
                    document.getElementById('card_holder_name').focus();
                    return false;
                }

                return true;
            }

            // Validate e-wallet payment details
            function validateEwalletDetails() {
                const provider = document.querySelector('input[name="ewallet_provider"]:checked');

                if (!provider) {
                    showNotification('Please select an e-wallet provider', 'error');
                    return false;
                }

                switch (provider.value) {
                    case 'paypal':
                        const paypalEmail = document.getElementById('paypal_email').value.trim();
                        if (!paypalEmail || !isValidEmail(paypalEmail)) {
                            showNotification('Please enter a valid PayPal email', 'error');
                            document.getElementById('paypal_email').focus();
                            return false;
                        }
                        break;

                    case 'touchngo':
                        const tngPhone = document.getElementById('tng_phone').value.trim();
                        if (!tngPhone || !isValidMalaysianPhone(tngPhone)) {
                            showNotification('Please enter a valid Malaysian phone number', 'error');
                            document.getElementById('tng_phone').focus();
                            return false;
                        }
                        break;
                }

                return true;
            }

            // Email validation helper
            function isValidEmail(email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email);
            }

            // Malaysian phone number validation helper
            function isValidMalaysianPhone(phone) {
                const cleaned = phone.replace(/[^\d+]/g, '');
                return /^(\+?6?0?1[0-46-9]\d{7,8}|\+?6?0?[3-9]\d{7})$/.test(cleaned);
            }

            // Redirect to orders page
            function redirectToOrders() {
                window.location.href = 'orders.php';
            }

            // Show notification
            function showNotification(message, type = 'success') {
                const notification = document.getElementById('notification');
                notification.textContent = message;
                notification.className = `notification ${type}`;
                notification.classList.add('show');

                setTimeout(() => {
                    notification.classList.remove('show');
                }, 3000);
            }

            // Helper function for item emoji
            function getItemEmoji(category) {
                const emojis = {
                    'coffee': '☕',
                    'frappe': '🥤',
                    'tea': '🍵',
                    'cham': '☕',
                    'chocolate': '🍫',
                    'specialty': '✨',
                    'refresher': '🧊'
                };
                return emojis[category] || '☕';
            }

            // Order summary functions
            function updateOrderSummaryDisplay(totals, voucherInfo = null) {
                const summaryHtml = generateOrderSummaryHTML(totals, voucherInfo);
                document.getElementById('orderSummary').innerHTML = summaryHtml;

                // Update the pickup/delivery toggle totals as well
                updateOrderTypeDisplay();
            }

            function generateOrderSummaryHTML(totals, voucherInfo) {
                // Always use original_subtotal if available, otherwise calculate it
                const originalSubtotal = totals.original_subtotal || (totals.subtotal + (totals.discount || 0));

                let html = `
        <div class="summary-row">
            <span>Original Subtotal (${totals.item_count} items):</span>
            <span>RM ${originalSubtotal.toFixed(2)}</span>
        </div>
    `;

                // Show discount details if voucher is applied
                if (totals.discount && totals.discount > 0 && voucherInfo) {
                    html += `
            <div class="summary-row discount-row" style="background: #f0f8f0; padding: 0.5rem; border-radius: 4px; margin: 0.5rem 0;">
                <span style="word-wrap: break-word;">Voucher: "${voucherInfo.reward_name}"</span>
                <span style="color: #dc3545; font-weight: bold;">-RM ${totals.discount.toFixed(2)}</span>
            </div>
        `;

                    // Show percentage info for discount type
                    if (voucherInfo.reward_type === 'discount') {
                        html += `
                <div style="font-size: 0.875rem; color: #28a745; text-align: center; margin: 0.25rem 0; font-style: italic;">
                    (${voucherInfo.reward_value}% discount applied)
                </div>
            `;
                    }

                    html += `<hr style="margin: 0.75rem 0; border: none; border-top: 1px dashed #ddd;">`;

                    html += `
            <div class="summary-row" style="font-weight: 600; color: #28a745;">
                <span>Discounted Subtotal:</span>
                <span>RM ${totals.subtotal.toFixed(2)}</span>
            </div>
        `;
                }

                html += `
        <div class="summary-row">
            <span>Tax (6% SST):</span>
            <span>RM ${totals.tax.toFixed(2)}</span>
        </div>
        <div class="summary-row" id="deliveryFeeRow">
            <span>Delivery Fee:</span>
            <span>RM 3.00</span>
        </div>
        <hr style="margin: 1rem 0; border: none; border-top: 2px solid #8B4513;">
        <div class="summary-row total" style="font-size: 1.1rem; font-weight: 700; color: #8B4513;">
            <span>Total:</span>
            <span id="orderTotal">RM ${(totals.total + 3).toFixed(2)}</span>
        </div>
    `;

                // Show savings highlight
                if (totals.discount && totals.discount > 0) {
                    html += `
            <div style="background: linear-gradient(135deg, #d4edda, #c3e6cb); padding: 0.75rem; border-radius: 8px; margin-top: 1rem; text-align: center; border: 1px solid #28a745;">
                <div style="color: #155724; font-weight: 600; font-size: 0.9rem;">
                    🎉 You saved RM ${totals.discount.toFixed(2)} with your voucher!
                </div>
            </div>
        `;
                }

                return html;
            }

// Also update the updateOrderSummaryWithAnimation function to use original_subtotal properly
            function updateOrderSummaryWithAnimation(totals) {
                const orderSummary = document.getElementById('orderSummary');

                // Add transition effect
                orderSummary.style.transition = 'opacity 0.3s ease';
                orderSummary.style.opacity = '0.7';

                setTimeout(() => {
                    // Generate new summary HTML without discount - use original_subtotal consistently
                    const originalSubtotal = totals.original_subtotal || totals.subtotal;

                    const newSummaryHTML = `
            <div class="summary-row">
                <span>Original Subtotal (${totals.item_count} items):</span>
                <span>RM ${originalSubtotal.toFixed(2)}</span>
            </div>
            <div class="summary-row">
                <span>Tax (6% SST):</span>
                <span>RM ${totals.tax.toFixed(2)}</span>
            </div>
            <div class="summary-row" id="deliveryFeeRow">
                <span>Delivery Fee:</span>
                <span>RM 3.00</span>
            </div>
            <hr style="margin: 1rem 0; border: none; border-top: 2px solid #8B4513;">
            <div class="summary-row total" style="font-size: 1.1rem; font-weight: 700; color: #8B4513;">
                <span>Total:</span>
                <span id="orderTotal">RM ${(totals.total + 3).toFixed(2)}</span>
            </div>
        `;

                    orderSummary.innerHTML = newSummaryHTML;

                    // Restore opacity
                    orderSummary.style.opacity = '1';

                    // Update cart data
                    cartData.cart_totals = totals;
                }, 200);
            }

            function updateOrderTypeDisplay() {
                const deliveryFeeRow = document.getElementById('deliveryFeeRow');
                const orderTotal = document.getElementById('orderTotal');
                const isPickup = document.querySelector('input[name="order_type"]:checked')?.value === 'pickup';

                if (deliveryFeeRow && orderTotal) {
                    if (isPickup) {
                        deliveryFeeRow.style.display = 'none';
                        const currentTotal = parseFloat(orderTotal.textContent.replace('RM ', ''));
                        orderTotal.textContent = `RM ${(currentTotal - 3).toFixed(2)}`;
                    } else {
                        deliveryFeeRow.style.display = 'flex';
                    }
                }
            }
        </script>
    </body>
</html>

<?php

// Helper function for item emoji
function getItemEmoji($category) {
    $emojis = [
        'coffee' => '☕',
        'frappe' => '🥤',
        'tea' => '🍵',
        'cham' => '☕',
        'chocolate' => '🍫',
        'specialty' => '✨',
        'refresher' => '🧊'
    ];
    return $emojis[$category] ?? '☕';
}
?>