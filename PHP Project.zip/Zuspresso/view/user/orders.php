<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Order Management 
 * @version 2.0 - Integrated State Pattern for Order Status Management
 */
session_start();

// Check if user is logged in and is a customer
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

// Include required models
require_once '../../model/BaseModel.php';
require_once '../../model/Customer.php';
require_once '../../model/Order.php';
require_once '../../model/OrderItem.php';
require_once '../../model/ProductReview.php';
require_once '../../model/OrderFeedback.php';
require_once '../../model/OutputSecurity.php';
require_once '../../model/OrderState.php'; 

// Initialize variables
$display_name = 'Guest';
$orders = [];
$stats = [
    'total_orders' => 0,
    'total_spent' => 0,
    'avg_order_value' => 0,
    'last_order_date' => 'Never'
];
$error_message = null;

try {
    // Get customer details using ORM
    $customer = Customer::getByUserId($_SESSION['user_id']);

    if (!$customer) {
        throw new Exception("Customer record not found. Please contact support.");
    }

    $display_name = $customer->getDisplayName();

    // Get orders using ORM
    $orderModel = new Order();
    $orders_data = $orderModel->findAll(
            ['customer_id' => $_SESSION['user_id']],
            'created_at DESC'
    );

    // Format orders with additional data and state information
    $orderItemModel = new OrderItem();
    foreach ($orders_data as $order) {
        $items = $orderItemModel->findAll(['order_id' => $order['order_id']]);
        $itemCount = array_sum(array_column($items, 'quantity'));
        
        // Get state information for this order
        $stateInfo = OrderStateManager::getOrderStateInfo($order['order_id']);

        $orders[] = [
            'order_id' => $order['order_id'],
            'customer_id' => $order['customer_id'],
            'total_amount' => $order['total_amount'],
            'subtotal' => $order['subtotal'],
            'tax_amount' => $order['tax_amount'],
            'delivery_fee' => $order['delivery_fee'] ?? 0,
            'discount_amount' => $order['discount_amount'] ?? 0,
            'voucher_code' => $order['voucher_code'] ?? null,
            'delivery_address' => $order['delivery_address'],
            'phone' => $order['phone'],
            'notes' => $order['notes'],
            'payment_method' => $order['payment_method'],
            'order_type' => $order['order_type'],
            'order_status' => $order['order_status'],
            'is_received' => $order['is_received'],
            'received_at' => $order['received_at'],
            'created_at' => date('M j, Y g:i A', strtotime($order['created_at'])),
            'status_label' => getStatusLabel($order['order_status']),
            'formatted_total' => 'RM ' . number_format($order['total_amount'], 2),
            'item_count' => $itemCount,
            'items' => $items,
            // State Pattern data
            'state_info' => $stateInfo,
            'can_cancel' => $stateInfo ? $stateInfo['can_cancel'] : false,
            'can_modify' => $stateInfo ? $stateInfo['can_modify'] : false,
            'next_states' => $stateInfo ? $stateInfo['next_possible_states'] : []
        ];
    }

    // Calculate statistics
    if (!empty($orders)) {
        $stats['total_orders'] = count($orders);
        $stats['total_spent'] = array_sum(array_column($orders, 'total_amount'));
        $stats['avg_order_value'] = $stats['total_spent'] / $stats['total_orders'];
        $stats['last_order_date'] = formatDateShort($orders[0]['created_at']);
    }
} catch (Exception $e) {
    $error_message = $e->getMessage();
    error_log("Orders page error: " . $error_message);
}

// Helper functions
function getStatusLabel($status) {
    $labels = [
        'pending' => 'Pending',
        'preparing' => 'Preparing',
        'canceled' => 'Canceled',
        'out for delivery' => 'Out for Delivery',
        'ready to pickup' => 'Ready to Pickup',
        'delivered' => 'Delivered'
    ];
    return $labels[$status] ?? ucfirst($status);
}

function formatDateShort($dateString) {
    return date('M j', strtotime($dateString));
}

function getItemEmoji($itemName) {
    $name = strtolower($itemName);
    if (strpos($name, 'latte') !== false || strpos($name, 'coffee') !== false)
        return '☕';
    if (strpos($name, 'frappe') !== false)
        return '🥤';
    if (strpos($name, 'tea') !== false)
        return '🍵';
    if (strpos($name, 'chocolate') !== false)
        return '🍫';
    if (strpos($name, 'matcha') !== false)
        return '🍵';
    return '☕';
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order History - Zuspresso</title>
        <link rel="stylesheet" href="../../assets/css/navbar.css">
        <link rel="stylesheet" href="../../assets/css/orderModule.css">
        <style>
            /* Additional status styles for new statuses */
            .status-pending {
                background: linear-gradient(135deg, #fff3cd, #ffeaa7);
                color: #856404;
                border: 1px solid #ffc107;
            }

            .status-preparing {
                background: linear-gradient(135deg, #cce5ff, #b8daff);
                color: #004085;
                border: 1px solid #0984e3;
            }

            .status-canceled {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                color: #721c24;
                border: 1px solid #d63384;
            }

            .status-out-for-delivery {
                background: linear-gradient(135deg, #e2e3ff, #d1d2ff);
                color: #383874;
                border: 1px solid #6c5ce7;
            }

            .status-ready-to-pickup {
                background: linear-gradient(135deg, #d1f2eb, #a6f0e4);
                color: #0c5460;
                border: 1px solid #00b894;
            }

            .status-delivered {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                color: #155724;
                border: 1px solid #28a745;
            }

            .confirm-received-btn {
                background: linear-gradient(135deg, #28a745, #20c997);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .confirm-received-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
            }

            /* Cancel button styles */
            .cancel-order-btn {
                background: linear-gradient(135deg, #dc3545, #c82333);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: 20px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .cancel-order-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
            }

            .cancel-order-btn:disabled {
                background: #6c757d;
                cursor: not-allowed;
                opacity: 0.5;
            }

            /* State info section */
            .state-info-section {
                background: #f8f9fa;
                border-radius: 8px;
                padding: 1rem;
                margin: 1rem 0;
                border: 1px solid #e9ecef;
            }

            .state-info-title {
                font-weight: 600;
                color: #495057;
                margin-bottom: 0.5rem;
                font-size: 0.9rem;
            }

            .next-states {
                display: flex;
                gap: 0.5rem;
                flex-wrap: wrap;
                margin-top: 0.5rem;
            }

            .next-state-badge {
                background: #e9ecef;
                color: #495057;
                padding: 0.25rem 0.75rem;
                border-radius: 15px;
                font-size: 0.85rem;
            }
        </style>
    </head>
    <body>
        <!-- Include Navigation -->
        <?php include 'navbar.php'; ?>

        <!-- Main Content -->
        <div class="container">
            <div class="page-header">
                <h1>Order History</h1>
                <p>Track your orders and view past purchases</p>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <!-- Stats Section -->
            <div class="stats-grid" id="statsGrid">
                <div class="stat-card">
                    <div class="stat-number"><?= OutputSecurity::int($stats['total_orders']) ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">RM <?= OutputSecurity::float($stats['total_spent']) ?></div>
                    <div class="stat-label">Total Spent</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">RM <?= number_format($stats['avg_order_value'], 2) ?></div>
                    <div class="stat-label">Average Order</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $stats['last_order_date'] ?></div>
                    <div class="stat-label">Last Order</div>
                </div>
            </div>

            <!-- Orders Section -->
            <div class="orders-section">
                <h2 class="section-title">Your Orders</h2>

                <!-- Filter Tabs - Updated with all statuses -->
                <div class="filter-tabs">
                    <button class="filter-tab active" data-status="" onclick="filterOrders('')">All Orders</button>
                    <button class="filter-tab" data-status="pending" onclick="filterOrders('pending')">Pending</button>
                    <button class="filter-tab" data-status="preparing" onclick="filterOrders('preparing')">Preparing</button>
                    <button class="filter-tab" data-status="canceled" onclick="filterOrders('canceled')">Canceled</button>
                    <button class="filter-tab" data-status="out for delivery" onclick="filterOrders('out for delivery')">Out for Delivery</button>
                    <button class="filter-tab" data-status="ready to pickup" onclick="filterOrders('ready to pickup')">Ready to Pickup</button>
                    <button class="filter-tab" data-status="delivered" onclick="filterOrders('delivered')">Delivered</button>
                </div>

                <!-- Orders List -->
                <div id="ordersList">
                    <?php if (empty($orders)): ?>
                        <div class="empty-orders">
                            <div class="empty-icon">📋</div>
                            <h2>No orders found</h2>
                            <p>You haven't placed any orders yet. Start exploring our delicious menu!</p>
                            <a href="menu.php" class="view-details-btn" style="margin-top: 2rem; text-decoration: none; display: inline-block;">Browse Menu</a>
                        </div>
                    <?php else: ?>
                        <!-- Orders will be rendered by JavaScript using PHP data -->
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Order Details Modal -->
        <div class="order-modal" id="orderModal">
            <div class="order-modal-content">
                <div class="order-modal-header">
                    <h3 class="order-modal-title" id="modalTitle">Order Details</h3>
                    <button class="order-modal-close" onclick="closeModal()">&times;</button>
                </div>
                <div class="order-modal-body" id="modalBody">
                    <!-- Order details will be loaded here -->
                </div>
            </div>
        </div>

        <!-- Feedback Modal -->
        <div class="feedback-modal" id="feedbackModal">
            <div class="feedback-content">
                <div class="feedback-header">
                    <h3 class="feedback-title">Share Your Experience</h3>
                    <p class="feedback-subtitle">How was your Zuspresso order experience?</p>
                </div>
                <div class="feedback-body">
                    <textarea 
                        class="feedback-textarea" 
                        id="feedbackText" 
                        placeholder="Tell us about your experience (optional)..."></textarea>
                    <div class="feedback-actions">
                        <button class="feedback-btn dismiss" onclick="dismissFeedback()">Dismiss</button>
                        <button class="feedback-btn submit" onclick="submitFeedback()">Submit Feedback</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notification -->
        <div class="notification" id="notification"></div>

        <script>
            // Initialize with PHP data
            let allOrders = <?= OutputSecurity::js($orders) ?>;
            let currentFilter = '';

            // Initialize page
            document.addEventListener('DOMContentLoaded', function () {
                renderOrders();
            });

            // Render orders list
            function renderOrders() {
                const ordersList = document.getElementById('ordersList');

                let filteredOrders = allOrders;
                if (currentFilter) {
                    filteredOrders = allOrders.filter(order => order.order_status === currentFilter);
                }

                if (filteredOrders.length === 0) {
                    ordersList.innerHTML = `
                        <div class="empty-orders">
                            <div class="empty-icon">📋</div>
                            <h2>No orders found</h2>
                            <p>${currentFilter ? 'No ' + getStatusLabel(currentFilter) + ' orders' : 'You haven\'t placed any orders yet. Start exploring our delicious menu!'}</p>
                            <a href="menu.php" class="view-details-btn" style="margin-top: 2rem; text-decoration: none; display: inline-block;">Browse Menu</a>
                        </div>
                    `;
                    return;
                }

                let html = '';
                filteredOrders.forEach(order => {
                    const statusClass = `status-${order.order_status.replace(/\s+/g, '-')}`;
                    const canReview = order.order_status === 'delivered';
                    const needsConfirmation = (order.order_status === 'out for delivery' || order.order_status === 'ready to pickup') && !order.is_received;
                    const canCancel = order.can_cancel;

                    html += `
                        <div class="order-card" onclick="viewOrderDetails(${order.order_id})">
                            <div class="order-header" style="display: flex; justify-content: space-between; align-items: center;">
                                <div class="order-info">
                                    <div class="order-id">Order #${order.order_id}</div>
                                    <div class="order-date">${order.created_at}</div>
                                </div>
                                <div class="order-status ${statusClass}">${order.status_label}</div>
                            </div>
                            <div class="order-summary">
                                <div>
                                    <div class="order-amount">${order.formatted_total}</div>
                                    <div class="order-items-count">${order.item_count} item${order.item_count > 1 ? 's' : ''}</div>
                                </div>
                                <div style="display: flex; gap: 0.5rem; align-items: center;">
                                    ${needsConfirmation ? `
                                        <button class="confirm-received-btn" onclick="event.stopPropagation(); confirmOrderReceived(${order.order_id})" 
                                            title="Mark this order as received">
                                            ✔ Order Received
                                        </button>
                                    ` : ''}
                                    ${canCancel ? `
                                        <button class="cancel-order-btn" onclick="event.stopPropagation(); cancelOrder(${order.order_id})" 
                                            title="Cancel this order">
                                            Cancel Order
                                        </button>
                                    ` : ''}
                                    ${canReview ? `
                                        <a href="../../controller/ReviewController.php?action=show_order_items_api&order_id=${order.order_id}" 
                                           class="rate-btn" onclick="event.stopPropagation()" 
                                           style="text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem;">
                                            <span>⭐</span> Rate
                                        </a>
                                    ` : ''}
                                    <button class="view-details-btn" onclick="event.stopPropagation(); viewOrderDetails(${order.order_id})">
                                        View Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                });

                ordersList.innerHTML = html;
            }

            function getStatusLabel(status) {
                const labels = {
                    'pending': 'Pending',
                    'preparing': 'Preparing',
                    'canceled': 'Canceled',
                    'out for delivery': 'Out for Delivery',
                    'ready to pickup': 'Ready to Pickup',
                    'delivered': 'Delivered'
                };
                return labels[status] || status.charAt(0).toUpperCase() + status.slice(1);
            }

            // Filter orders by status
            function filterOrders(status) {
                currentFilter = status;

                document.querySelectorAll('.filter-tab').forEach(tab => {
                    tab.classList.remove('active');
                });
                document.querySelector(`[data-status="${status}"]`).classList.add('active');

                renderOrders();
            }

            // View order details
            async function viewOrderDetails(orderId) {
                const order = allOrders.find(o => o.order_id == orderId);
                if (!order) return;

                renderOrderModal(order);
                document.getElementById('orderModal').classList.add('show');
            }

            // Render order details modal with State Pattern info
            function renderOrderModal(order) {
                document.getElementById('modalTitle').textContent = `Order #${order.order_id}`;

                const statusClass = `status-${order.order_status.replace(/\s+/g, '-')}`;
                let html = `
                    <div class="order-detail-section">
                        <div class="order-detail-title">Order Information</div>
                        <div class="detail-item">
                            <span>Order ID:</span>
                            <span>#${order.order_id}</span>
                        </div>
                        <div class="detail-item">
                            <span>Date:</span>
                            <span>${order.created_at}</span>
                        </div>
                        <div class="detail-item">
                            <span>Status:</span>
                            <span class="order-status ${statusClass}">${order.status_label}</span>
                        </div>
                        <div class="detail-item">
                            <span>Order Type:</span>
                            <span>${order.order_type ? order.order_type.toUpperCase() : 'DELIVERY'}</span>
                        </div>
                        <div class="detail-item">
                            <span>Payment Method:</span>
                            <span>${order.payment_method.toUpperCase()}</span>
                        </div>
                    </div>
                `;

                // Add State Information Section
                if (order.state_info) {
                    html += `
                        <div class="state-info-section">
                            <div class="state-info-title">Order Status Information</div>
                            <div class="detail-item">
                                <span>Current State Message:</span>
                                <span>${order.state_info.state_message}</span>
                            </div>
                            ${order.next_states && order.next_states.length > 0 ? `
                                <div class="detail-item">
                                    <span>Next Possible States:</span>
                                    <div class="next-states">
                                        ${order.next_states.map(state => `
                                            <span class="next-state-badge">${getStatusLabel(state)}</span>
                                        `).join('')}
                                    </div>
                                </div>
                            ` : ''}
                            <div class="detail-item">
                                <span>Can Cancel:</span>
                                <span>${order.can_cancel ? 'Yes' : 'No'}</span>
                            </div>
                            <div class="detail-item">
                                <span>Can Modify:</span>
                                <span>${order.can_modify ? 'Yes' : 'No'}</span>
                            </div>
                        </div>
                    `;
                }

                html += `
                    <div class="order-detail-section">
                        <div class="order-detail-title">Delivery Information</div>
                        <div class="detail-item">
                            <span>Address:</span>
                            <span>${order.delivery_address}</span>
                        </div>
                        <div class="detail-item">
                            <span>Phone:</span>
                            <span>${order.phone}</span>
                        </div>
                        ${order.notes ? `
                        <div class="detail-item">
                            <span>Notes:</span>
                            <span>${order.notes}</span>
                        </div>
                        ` : ''}
                    </div>

                    <div class="order-detail-section">
                        <div class="order-detail-title">Order Items</div>
                `;

                order.items.forEach(item => {
                    const emoji = getItemEmoji(item.item_name);
                    const subtotal = parseFloat(item.item_price) * parseInt(item.quantity);
                    html += `
                        <div class="order-item">
                            <div class="item-emoji">${emoji}</div>
                            <div class="item-info">
                                <div class="item-name">${item.item_name}</div>
                                <div class="item-details">RM ${parseFloat(item.item_price).toFixed(2)} × ${item.quantity}</div>
                            </div>
                            <div class="item-total">RM ${subtotal.toFixed(2)}</div>
                        </div>
                    `;
                });

                html += `
                    </div>

                    <div class="order-detail-section">
                        <div class="order-detail-title">Order Summary</div>
                        <div class="detail-item">
                            <span>Original Subtotal:</span>
                            <span>RM ${(parseFloat(order.subtotal) + parseFloat(order.discount_amount || 0)).toFixed(2)}</span>
                        </div>
                `;

                // Show discount if there was one
                if (order.discount_amount && parseFloat(order.discount_amount) > 0) {
                    html += `
                        <div class="detail-item" style="color: #28a745; background: #f0f8f0; padding: 0.5rem; border-radius: 4px; margin: 0.25rem 0;">
                            <span>Voucher Discount${order.voucher_code ? ` (${order.voucher_code})` : ''}:</span>
                            <span>-RM ${parseFloat(order.discount_amount).toFixed(2)}</span>
                        </div>
                        <div class="detail-item" style="font-weight: 600;">
                            <span>Discounted Subtotal:</span>
                            <span>RM ${parseFloat(order.subtotal).toFixed(2)}</span>
                        </div>
                    `;
                } else {
                    html += `
                        <div class="detail-item">
                            <span>Subtotal:</span>
                            <span>RM ${parseFloat(order.subtotal).toFixed(2)}</span>
                        </div>
                    `;
                }

                html += `
                        <div class="detail-item">
                            <span>Tax (6% SST):</span>
                            <span>RM ${parseFloat(order.tax_amount).toFixed(2)}</span>
                        </div>
                `;

                // Show delivery fee if it exists
                if (order.delivery_fee && parseFloat(order.delivery_fee) > 0) {
                    html += `
                        <div class="detail-item">
                            <span>Delivery Fee:</span>
                            <span>RM ${parseFloat(order.delivery_fee).toFixed(2)}</span>
                        </div>
                    `;
                }

                html += `
                        <div class="detail-item" style="font-weight: 700; font-size: 1.1rem; color: #8B4513; border-top: 2px solid #f0f0f0; padding-top: 1rem; margin-top: 1rem;">
                            <span>Total:</span>
                            <span>RM ${parseFloat(order.total_amount).toFixed(2)}</span>
                        </div>
                    </div>
                `;

                // Add action buttons based on state
                if (order.can_cancel || order.next_states.includes('delivered')) {
                    html += `
                        <div class="order-detail-section" style="display: flex; gap: 1rem;">
                    `;
                    
                    if (order.can_cancel) {
                        html += `
                            <button class="cancel-order-btn" onclick="cancelOrder(${order.order_id})" style="flex: 1; padding: 1rem;">
                                Cancel Order
                            </button>
                        `;
                    }
                    
                    if (order.order_status === 'out for delivery' || order.order_status === 'ready to pickup') {
                        if (!order.is_received) {
                            html += `
                                <button class="confirm-received-btn" onclick="confirmOrderReceived(${order.order_id})" style="flex: 1; padding: 1rem;">
                                    ✔ Mark as Received
                                </button>
                            `;
                        }
                    }
                    
                    html += `</div>`;
                }

                document.getElementById('modalBody').innerHTML = html;
            }

            // Cancel order function using State Pattern
            async function cancelOrder(orderId) {
                const order = allOrders.find(o => o.order_id == orderId);
                
                if (!order) {
                    showNotification('Order not found', 'error');
                    return;
                }
                
                if (!order.can_cancel) {
                    showNotification('This order cannot be canceled in its current state', 'error');
                    return;
                }
                
                if (!confirm('Are you sure you want to cancel this order? This action cannot be undone.')) {
                    return;
                }
                
                try {
                    const formData = new FormData();
                    formData.append('action', 'update_order_status');
                    formData.append('order_id', orderId);
                    formData.append('new_status', 'canceled');
                    
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Update local data
                        const orderIndex = allOrders.findIndex(o => o.order_id == orderId);
                        if (orderIndex !== -1) {
                            allOrders[orderIndex].order_status = 'canceled';
                            allOrders[orderIndex].status_label = 'Canceled';
                            allOrders[orderIndex].can_cancel = false;
                            allOrders[orderIndex].can_modify = false;
                            allOrders[orderIndex].next_states = [];
                        }
                        
                        showNotification('Order has been canceled successfully', 'success');
                        
                        // Re-render orders
                        renderOrders();
                        
                        // Close modal if open
                        if (document.getElementById('orderModal').classList.contains('show')) {
                            closeModal();
                        }
                    } else {
                        showNotification(data.message || 'Failed to cancel order', 'error');
                    }
                } catch (error) {
                    console.error('Error canceling order:', error);
                    showNotification('Failed to cancel order', 'error');
                }
            }

            // Updated confirm order received function to use State Pattern
            async function confirmOrderReceived(orderId) {
                const order = allOrders.find(o => o.order_id == orderId);

                if (!order) {
                    showNotification('Order not found', 'error');
                    return;
                }

                if (order.order_status !== 'out for delivery' && order.order_status !== 'ready to pickup') {
                    showNotification('Order cannot be marked as received in current status', 'error');
                    return;
                }

                const orderType = order.order_type || 'delivery';
                const confirmMessage = orderType === 'pickup'
                        ? 'Please confirm that you have picked up this order from our store.'
                        : 'Please confirm that you have received this delivery order.';

                if (!confirm(confirmMessage + ' This action cannot be undone.')) {
                    return;
                }

                try {
                    const formData = new FormData();
                    formData.append('action', 'update_order_status');
                    formData.append('order_id', orderId);
                    formData.append('new_status', 'delivered');

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        // Update local data
                        const orderIndex = allOrders.findIndex(o => o.order_id == orderId);
                        if (orderIndex !== -1) {
                            allOrders[orderIndex].order_status = 'delivered';
                            allOrders[orderIndex].status_label = 'Delivered';
                            allOrders[orderIndex].is_received = 1;
                            allOrders[orderIndex].received_at = new Date().toISOString();
                            allOrders[orderIndex].can_cancel = false;
                            allOrders[orderIndex].next_states = [];
                        }

                        showNotification('Order confirmed as received. You can now rate your items!', 'success');

                        // Show feedback modal
                        showFeedbackModal(orderId);

                        // Re-render orders
                        renderOrders();

                        // Close modal if open
                        if (document.getElementById('orderModal').classList.contains('show')) {
                            closeModal();
                        }
                    } else {
                        showNotification(data.message || 'Failed to confirm order receipt', 'error');
                    }
                } catch (error) {
                    console.error('Error confirming order:', error);
                    showNotification('Failed to confirm order receipt', 'error');
                }
            }

            // Show feedback modal
            function showFeedbackModal(orderId) {
                document.getElementById('feedbackModal').classList.add('show');
                document.getElementById('feedbackText').value = '';
                document.getElementById('feedbackModal').dataset.orderId = orderId;

                setTimeout(() => {
                    document.getElementById('feedbackText').focus();
                }, 300);
            }

            // Dismiss feedback
            function dismissFeedback() {
                document.getElementById('feedbackModal').classList.remove('show');
            }

            // Submit feedback
            async function submitFeedback() {
                const orderId = document.getElementById('feedbackModal').dataset.orderId;
                const feedbackText = document.getElementById('feedbackText').value.trim();

                if (!feedbackText || feedbackText.length === 0) {
                    showNotification('Please provide feedback before submitting', 'error');
                    document.getElementById('feedbackText').focus();
                    return;
                }

                if (feedbackText.length < 10) {
                    showNotification('Please provide more detailed feedback (at least 10 characters)', 'error');
                    document.getElementById('feedbackText').focus();
                    return;
                }

                try {
                    const formData = new FormData();
                    formData.append('action', 'submit_feedback');
                    formData.append('order_id', orderId);
                    formData.append('feedback_text', feedbackText);

                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification('Thank you for your feedback!');
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error submitting feedback:', error);
                    showNotification('Failed to submit feedback', 'error');
                } finally {
                    document.getElementById('feedbackModal').classList.remove('show');
                }
            }

            // Get emoji helper
            function getItemEmoji(itemName) {
                const name = itemName.toLowerCase();
                if (name.includes('latte') || name.includes('coffee'))
                    return '☕';
                if (name.includes('frappe'))
                    return '🥤';
                if (name.includes('tea'))
                    return '🍵';
                if (name.includes('chocolate'))
                    return '🍫';
                if (name.includes('matcha'))
                    return '🍵';
                return '☕';
            }

            // Close modal
            function closeModal() {
                document.getElementById('orderModal').classList.remove('show');
            }

            // Show notification
            function showNotification(message, type = 'success') {
                const notification = document.getElementById('notification');
                notification.textContent = message;
                notification.className = `notification ${type}`;
                notification.classList.add('show');

                setTimeout(() => {
                    notification.classList.remove('show');
                }, 3000);
            }

            // Close modal when clicking outside
            document.getElementById('orderModal').addEventListener('click', function (e) {
                if (e.target === this) {
                    closeModal();
                }
            });

            // Close feedback modal when clicking outside
            document.getElementById('feedbackModal').addEventListener('click', function (e) {
                if (e.target === this) {
                    dismissFeedback();
                }
            });

            // Close feedback modal with Escape key
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && document.getElementById('feedbackModal').classList.contains('show')) {
                    dismissFeedback();
                }
            });
        </script>
    </body>
</html>