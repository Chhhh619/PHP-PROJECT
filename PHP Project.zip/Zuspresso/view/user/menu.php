<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Order Management 
 * @version 1.3 
 */
session_start();

// Check if user is logged in 
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

// Include required models
require_once '../../model/BaseModel.php';
require_once '../../model/Customer.php';
require_once '../../model/MenuItem.php';
require_once '../../model/OutputSecurity.php';
require_once 'ReviewDisplay.php';

// Initialize variables
$display_name = 'Guest';
$menu_items = [];
$categories = [];
$cart_items = [];
$cart_totals = ['subtotal' => 0, 'tax' => 0, 'total' => 0, 'item_count' => 0];
$error_message = null;

try {
    // Get customer details
    $customer = Customer::getByUserId($_SESSION['user_id']);
    if (!$customer) {
        throw new Exception("Customer record not found.");
    }
    $display_name = $customer->getDisplayName();

    // Get menu items
    $menuItemModel = new MenuItem();
    $menu_items = $menuItemModel->findAll(['is_available' => 1], 'category, name');

    // Get unique categories
    $categories_result = $menuItemModel->query(
            "SELECT DISTINCT category FROM menu_items WHERE is_available = 1 ORDER BY category"
    );
    $categories = array_column($categories_result, 'category');

    // Get cart data from session
    $cart_items = $_SESSION['cart'] ?? [];

    // Calculate cart totals
    foreach ($cart_items as $item) {
        $itemSubtotal = $item['price'] * $item['quantity'];
        $cart_totals['subtotal'] += $itemSubtotal;
        $cart_totals['item_count'] += $item['quantity'];
    }
    $cart_totals['tax'] = $cart_totals['subtotal'] * 0.06;
    $cart_totals['total'] = $cart_totals['subtotal'] + $cart_totals['tax'];
} catch (Exception $e) {
    $error_message = $e->getMessage();
    error_log("Menu page error: " . $error_message);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Menu - Zuspresso</title>
        <link rel="stylesheet" href="../../assets/css/navbar.css">
        <link rel="stylesheet" href="../../assets/css/orderModule.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            /* Reviews CSS */
            .modal-tabs {
                display: flex;
                border-bottom: 1px solid #e9ecef;
                margin-bottom: 1.5rem;
            }

            .modal-tab {
                flex: 1;
                padding: 1rem;
                text-align: center;
                background: none;
                border: none;
                cursor: pointer;
                color: #6c757d;
                border-bottom: 2px solid transparent;
                transition: all 0.3s ease;
            }

            .modal-tab.active {
                color: #D2691E;
                border-bottom-color: #D2691E;
            }

            .tab-content {
                display: none;
            }

            .tab-content.active {
                display: block;
            }

            .reviews-section {
                margin-top: 2rem;
                padding-top: 2rem;
                border-top: 1px solid #e9ecef;
            }

            .review-stats {
                display: flex;
                align-items: center;
                gap: 1rem;
                margin-bottom: 1.5rem;
                padding: 1rem;
                background: #f8f9fa;
                border-radius: 8px;
            }

            .overall-rating {
                text-align: center;
            }

            .rating-number {
                font-size: 2rem;
                font-weight: bold;
                color: #D2691E;
                display: block;
            }

            .star-display {
                color: #D2691E;
                font-size: 1.1rem;
                margin: 0.5rem 0;
            }

            .rating-count {
                color: #6c757d;
                font-size: 0.9rem;
            }

            .rating-bars {
                flex: 1;
                margin-left: 1rem;
            }

            .rating-bar-item {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                margin-bottom: 0.3rem;
                font-size: 0.9rem;
            }

            .rating-bar {
                flex: 1;
                height: 8px;
                background: #e9ecef;
                border-radius: 4px;
                overflow: hidden;
            }

            .rating-bar-fill {
                height: 100%;
                background: #D2691E;
                transition: width 0.3s ease;
            }

            .reviews-list {
                max-height: 400px;
                overflow-y: auto;
            }

            .review-item {
                padding: 1rem;
                border: 1px solid #e9ecef;
                border-radius: 8px;
                margin-bottom: 1rem;
                background: white;
            }

            .review-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 0.5rem;
            }

            .reviewer-name {
                font-weight: 600;
                color: #2c2c2c;
            }

            .review-date {
                color: #6c757d;
                font-size: 0.85rem;
            }

            .review-rating {
                color: #D2691E;
                margin-bottom: 0.5rem;
            }

            .review-text {
                color: #495057;
                line-height: 1.4;
                margin: 0;
            }

            .no-reviews {
                text-align: center;
                padding: 2rem;
                color: #6c757d;
            }

            .reviews-loading {
                text-align: center;
                padding: 2rem;
                color: #6c757d;
            }

            .load-more-reviews {
                width: 100%;
                padding: 0.75rem;
                background: #f8f9fa;
                border: 1px solid #e9ecef;
                border-radius: 6px;
                color: #6c757d;
                cursor: pointer;
                transition: all 0.3s ease;
                margin-top: 1rem;
            }

            .load-more-reviews:hover {
                background: #e9ecef;
                color: #495057;
            }
        </style>
    </head>
    <body>
        <!-- Include Navigation -->
        <?php include 'navbar.php'; ?>

        <!-- Main Content -->
        <div class="container">
            <div class="page-header">
                <h1>Our Menu</h1>
                <p>Discover your perfect cup of coffee</p>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <?= OutputSecurity::html($error_message) ?>
                </div>
            <?php endif; ?>

            <!-- Category Filter -->
            <div class="category-filter" id="categoryFilter">
                <button class="category-btn active" data-category="">All Items</button>
                <?php foreach ($categories as $category): ?>
                    <button class="category-btn" data-category="<?= OutputSecurity::attr($category) ?>">
                        <?= OutputSecurity::html(ucfirst($category)) ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <!-- Menu Grid -->
            <div class="menu-grid" id="menuGrid">
                <!-- Items rendered by JavaScript -->
            </div>
        </div>

        <!-- Enhanced Item Details Modal with Reviews -->
        <div class="item-modal" id="itemModal">
            <div class="item-modal-content">
                <div class="item-modal-header">
                    <span id="modalItemEmoji">☕</span>
                    <button class="item-modal-close" onclick="closeItemModal()">×</button>
                </div>
                <div class="item-modal-body">
                    <h2 class="item-detail-title" id="modalItemName">Item Name</h2>
                    <div class="item-detail-price" id="modalItemPrice">RM 0.00</div>
                    <p class="item-detail-description" id="modalItemDescription">Description</p>

                    <div class="item-detail-info">
                        <div class="info-row">
                            <span class="info-label">Category:</span>
                            <span class="info-value" id="modalItemCategory">Category</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Availability:</span>
                            <span class="info-value" id="modalItemAvailability">Available</span>
                        </div>
                    </div>

                    <!-- Modal Tabs -->
                    <div class="modal-tabs">
                        <button class="modal-tab active" data-tab="order">Order</button>
                        <button class="modal-tab" data-tab="reviews">Reviews</button>
                    </div>

                    <!-- Order Tab Content -->
                    <div class="tab-content active" id="orderTab">
                        <div class="modal-actions">
                            <div class="modal-quantity-selector">
                                <button class="quantity-btn" onclick="changeModalQuantity(-1)">-</button>
                                <input type="number" class="quantity-input" id="modalQuantity" value="1" min="1" max="10">
                                <button class="quantity-btn" onclick="changeModalQuantity(1)">+</button>
                            </div>
                            <button class="modal-add-btn" id="modalAddBtn" onclick="addToCartFromModal()">
                                Add to Cart - RM <span id="modalTotalPrice">0.00</span>
                            </button>
                        </div>
                    </div>

                    <!-- Reviews Tab Content -->
                    <div class="tab-content" id="reviewsTab">
                        <div class="reviews-section">
                            <div class="reviews-loading" id="reviewsLoading">
                                <i class="fas fa-spinner fa-spin"></i>
                                <p>Loading reviews...</p>
                            </div>

                            <div id="reviewsContent" style="display: none;">
                                <div class="review-stats" id="reviewStats"></div>
                                <div class="reviews-list" id="reviewsList"></div>
                                <button class="load-more-reviews" id="loadMoreReviews" style="display: none;">
                                    <i class="fas fa-plus"></i> Load More Reviews
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cart Sidebar -->
        <div class="cart-sidebar" id="cartSidebar">
            <div class="cart-header">
                <h3 class="cart-title">Your Cart</h3>
                <button class="cart-close" onclick="toggleCart()">×</button>
            </div>

            <div class="cart-content" id="cartContent">
                <!-- Cart content rendered by JavaScript -->
            </div>

            <div class="cart-summary" id="cartSummary" style="<?= empty($cart_items) ? 'display: none;' : '' ?>">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span id="cartSubtotal">RM <?= number_format($cart_totals['subtotal'], 2) ?></span>
                </div>
                <div class="summary-row">
                    <span>Tax (6%):</span>
                    <span id="cartTax">RM <?= number_format($cart_totals['tax'], 2) ?></span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="cartTotal">RM <?= number_format($cart_totals['total'], 2) ?></span>
                </div>
                <button class="checkout-btn" onclick="proceedToCheckout()">
                    Proceed to Checkout
                </button>
            </div>
        </div>

        <!-- Notification -->
        <div class="notification" id="notification"></div>

        <script>
            // Initialize with PHP data using OutputSecurity
            let menuItems = <?= OutputSecurity::js($menu_items) ?>;
            let categories = <?= OutputSecurity::js($categories) ?>;
            let cart = <?= OutputSecurity::js($cart_items) ?>;
            let currentItem = null;
            let currentReviewPage = 1;
            let reviewsData = null;

            // Initialize page
            document.addEventListener('DOMContentLoaded', function () {
                initializeCategoryFilter();
                initializeModalTabs();
                renderMenu();
                renderCart(cart, <?= OutputSecurity::js($cart_totals) ?>);
                updateCartBadge(<?= OutputSecurity::int($cart_totals['item_count'] ?? 0) ?>);
            });

            // Initialize category filter with event delegation
            function initializeCategoryFilter() {
                const categoryFilter = document.getElementById('categoryFilter');

                categoryFilter.addEventListener('click', function (e) {
                    const button = e.target.closest('.category-btn');
                    if (!button)
                        return;

                    const category = button.getAttribute('data-category') || '';

                    // Update active state
                    document.querySelectorAll('.category-btn').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    button.classList.add('active');

                    renderMenu(category);
                });
            }

            // Initialize modal tabs
            function initializeModalTabs() {
                document.querySelectorAll('.modal-tab').forEach(tab => {
                    tab.addEventListener('click', function (e) {
                        const tabName = this.getAttribute('data-tab');
                        showTab(tabName);
                    });
                });
            }

            // Show tab
            function showTab(tabName) {
                // Update tab buttons
                document.querySelectorAll('.modal-tab').forEach(tab => {
                    tab.classList.remove('active');
                });
                document.querySelector(`.modal-tab[data-tab="${tabName}"]`).classList.add('active');

                // Update tab content
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                document.getElementById(tabName + 'Tab').classList.add('active');

                // Load reviews when reviews tab is selected
                if (tabName === 'reviews' && currentItem) {
                    loadItemReviews(currentItem.item_id);
                }
            }

            // Render menu items
            function renderMenu(filterCategory = '') {
                const menuGrid = document.getElementById('menuGrid');
                let filteredItems = menuItems;

                if (filterCategory !== '') {
                    filteredItems = menuItems.filter(item => item.category === filterCategory);
                }

                if (filteredItems.length === 0) {
                    menuGrid.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">☕</div>
                        <p>No items found</p>
                    </div>
                `;
                    return;
                }

                let html = '';
                filteredItems.forEach(item => {
                    const emoji = getItemEmoji(item.category);
                    html += `
                    <div class="menu-item" data-item-id="${item.item_id}">
                        <div class="menu-item-image">${emoji}</div>
                        <div class="menu-item-content">
                            <div class="menu-item-header">
                                <div>
                                    <h3 class="menu-item-title">${escapeHtml(item.name)}</h3>
                                    <p class="menu-item-price">RM ${parseFloat(item.price).toFixed(2)}</p>
                                </div>
                            </div>
                            <p class="menu-item-description">${escapeHtml(item.description)}</p>
                            <div class="menu-item-actions">
                                <div class="quantity-selector">
                                    <button class="quantity-btn qty-minus" data-item-id="${item.item_id}">-</button>
                                    <input type="number" class="quantity-input" id="qty_${item.item_id}" value="1" min="1" max="10">
                                    <button class="quantity-btn qty-plus" data-item-id="${item.item_id}">+</button>
                                </div>
                                <button class="add-to-cart-btn" data-item-id="${item.item_id}">
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                });

                menuGrid.innerHTML = html;
                attachMenuEventListeners();
            }

            // Attach event listeners to menu items
            function attachMenuEventListeners() {
                // Item click for details
                document.querySelectorAll('.menu-item').forEach(item => {
                    item.addEventListener('click', function (e) {
                        if (!e.target.closest('.menu-item-actions')) {
                            const itemId = this.getAttribute('data-item-id');
                            showItemDetails(parseInt(itemId));
                        }
                    });
                });

                // Quantity buttons
                document.querySelectorAll('.qty-minus').forEach(btn => {
                    btn.addEventListener('click', function (e) {
                        e.stopPropagation();
                        const itemId = this.getAttribute('data-item-id');
                        changeQuantity(parseInt(itemId), -1);
                    });
                });

                document.querySelectorAll('.qty-plus').forEach(btn => {
                    btn.addEventListener('click', function (e) {
                        e.stopPropagation();
                        const itemId = this.getAttribute('data-item-id');
                        changeQuantity(parseInt(itemId), 1);
                    });
                });

                // Add to cart buttons
                document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
                    btn.addEventListener('click', function (e) {
                        e.stopPropagation();
                        const itemId = this.getAttribute('data-item-id');
                        addToCart(parseInt(itemId));
                    });
                });
            }

            // Load item reviews
            async function loadItemReviews(itemId, page = 1) {
                const reviewsLoading = document.getElementById('reviewsLoading');
                const reviewsContent = document.getElementById('reviewsContent');

                if (page === 1) {
                    reviewsLoading.style.display = 'block';
                    reviewsContent.style.display = 'none';
                }

                try {
                    const response = await fetch(`ReviewDisplay.php?action=get_reviews&item_id=${encodeURIComponent(itemId)}&page=${encodeURIComponent(page)}&limit=5`);
                    const data = await response.json();

                    if (data.success) {
                        reviewsData = data;
                        currentReviewPage = page;

                        if (page === 1) {
                            renderReviewStats(data.stats);
                            renderReviews(data.reviews, true);
                        } else {
                            renderReviews(data.reviews, false);
                        }

                        updateLoadMoreButton(data.pagination);

                        reviewsLoading.style.display = 'none';
                        reviewsContent.style.display = 'block';
                    } else {
                        throw new Error(data.error || 'Failed to load reviews');
                    }
                } catch (error) {
                    console.error('Error loading reviews:', error);
                    reviewsLoading.innerHTML = `
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error loading reviews</p>
                `;
            }
            }

            // Render review stats
            function renderReviewStats(stats) {
                const reviewStats = document.getElementById('reviewStats');

                if (stats.total_reviews === 0) {
                    reviewStats.innerHTML = '';
                    return;
                }

                const ratingBars = Object.entries(stats.rating_distribution)
                        .sort(([a], [b]) => b - a)
                        .map(([rating, count]) => {
                            const percentage = stats.total_reviews > 0 ? (count / stats.total_reviews) * 100 : 0;
                            return `
                        <div class="rating-bar-item">
                            <span>${escapeHtml(rating)}★</span>
                            <div class="rating-bar">
                                <div class="rating-bar-fill" style="width: ${percentage}%"></div>
                            </div>
                            <span>${escapeHtml(count)}</span>
                        </div>
                    `;
                        }).join('');

                reviewStats.innerHTML = `
                <div class="overall-rating">
                    <span class="rating-number">${escapeHtml(stats.average_rating)}</span>
                    <div class="star-display">${escapeHtml(stats.star_display)}</div>
                    <div class="rating-count">${escapeHtml(stats.total_reviews)} reviews</div>
                </div>
                <div class="rating-bars">
                    ${ratingBars}
                </div>
            `;
            }

            // Render reviews
            function renderReviews(reviews, replace = true) {
                const reviewsList = document.getElementById('reviewsList');

                if (reviews.length === 0 && replace) {
                    reviewsList.innerHTML = `
                    <div class="no-reviews">
                        <i class="fas fa-comment"></i>
                        <p>No written reviews yet</p>
                    </div>
                `;
                    return;
                }

                const reviewsHtml = reviews.map(review => {
                    const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
                    const customerName = review.customer_name || 'Anonymous';

                    return `
                    <div class="review-item">
                        <div class="review-header">
                            <span class="reviewer-name">${escapeHtml(customerName)}</span>
                            <span class="review-date">${escapeHtml(review.review_date)}</span>
                        </div>
                        <div class="review-rating">${stars}</div>
                        ${review.review_text ? `<p class="review-text">${escapeHtml(review.review_text)}</p>` : ''}
                    </div>
                `;
                }).join('');

                if (replace) {
                    reviewsList.innerHTML = reviewsHtml;
                } else {
                    reviewsList.insertAdjacentHTML('beforeend', reviewsHtml);
            }
            }

            // Update load more button
            function updateLoadMoreButton(pagination) {
                const loadMoreBtn = document.getElementById('loadMoreReviews');

                if (pagination.has_more) {
                    loadMoreBtn.style.display = 'block';
                    loadMoreBtn.onclick = () => loadItemReviews(currentItem.item_id, currentReviewPage + 1);
                } else {
                    loadMoreBtn.style.display = 'none';
                }
            }

            // Show item details modal
            function showItemDetails(itemId) {
                const item = menuItems.find(i => parseInt(i.item_id) === itemId);
                if (!item)
                    return;

                currentItem = item;
                currentReviewPage = 1;

                document.getElementById('modalItemEmoji').textContent = getItemEmoji(item.category);
                document.getElementById('modalItemName').textContent = item.name;
                document.getElementById('modalItemPrice').textContent = `RM ${parseFloat(item.price).toFixed(2)}`;
                document.getElementById('modalItemDescription').textContent = item.description;
                document.getElementById('modalItemCategory').textContent = item.category.charAt(0).toUpperCase() + item.category.slice(1);
                document.getElementById('modalItemAvailability').textContent = item.is_available == 1 ? 'Available' : 'Not Available';
                document.getElementById('modalQuantity').value = 1;
                updateModalTotal();

                // Reset to order tab
                showTab('order');

                // Reset reviews content
                document.getElementById('reviewsContent').style.display = 'none';
                document.getElementById('reviewsLoading').style.display = 'none';

                document.getElementById('itemModal').classList.add('show');
            }

            // Close item modal
            function closeItemModal() {
                document.getElementById('itemModal').classList.remove('show');
                currentItem = null;
                currentReviewPage = 1;
            }

            // Change quantity
            function changeQuantity(itemId, change) {
                const input = document.getElementById(`qty_${itemId}`);
                let newValue = parseInt(input.value) + change;
                if (newValue < 1)
                    newValue = 1;
                if (newValue > 10)
                    newValue = 10;
                input.value = newValue;
            }

            // Change modal quantity
            function changeModalQuantity(change) {
                const input = document.getElementById('modalQuantity');
                let newValue = parseInt(input.value) + change;
                if (newValue < 1)
                    newValue = 1;
                if (newValue > 10)
                    newValue = 10;
                input.value = newValue;
                updateModalTotal();
            }

            // Update modal total
            function updateModalTotal() {
                if (!currentItem)
                    return;
                const quantity = parseInt(document.getElementById('modalQuantity').value);
                const total = parseFloat(currentItem.price) * quantity;
                document.getElementById('modalTotalPrice').textContent = total.toFixed(2);
            }

            // Add to cart
            async function addToCart(itemId) {
                const quantityInput = document.getElementById(`qty_${itemId}`);
                const quantity = parseInt(quantityInput.value);

                const formData = new FormData();
                formData.append('action', 'add_to_cart');
                formData.append('item_id', itemId);
                formData.append('quantity', quantity);
                formData.append('customizations', JSON.stringify([]));

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification('Item added to cart!');
                        quantityInput.value = 1;
                        if (data.cart_totals) {
                            updateCartBadge(data.cart_totals.item_count);
                        }
                        loadCart();
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showNotification('Failed to add item', 'error');
                }
            }

            // Add to cart from modal
            async function addToCartFromModal() {
                if (!currentItem)
                    return;
                const quantity = parseInt(document.getElementById('modalQuantity').value);

                const formData = new FormData();
                formData.append('action', 'add_to_cart');
                formData.append('item_id', currentItem.item_id);
                formData.append('quantity', quantity);
                formData.append('customizations', JSON.stringify([]));

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();

                    if (data.success) {
                        showNotification('Item added to cart!');
                        if (data.cart_totals) {
                            updateCartBadge(data.cart_totals.item_count);
                        }
                        loadCart();
                        closeItemModal();
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showNotification('Failed to add item', 'error');
                }
            }

            // Load cart
            async function loadCart() {
                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php?action=get_cart');
                    const data = await response.json();

                    if (data.success) {
                        renderCart(data.cart_items, data.cart_totals);
                    }
                } catch (error) {
                    console.error('Error loading cart:', error);
                }
            }

            // Render cart
            function renderCart(cartItems, totals) {
                const cartContent = document.getElementById('cartContent');
                const cartSummary = document.getElementById('cartSummary');

                updateCartBadge(totals.item_count);

                if (Object.keys(cartItems).length === 0) {
                    cartContent.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">🛒</div>
                        <p>Your cart is empty</p>
                    </div>
                `;
                    cartSummary.style.display = 'none';
                    return;
                }

                let html = '';
                Object.entries(cartItems).forEach(([cartKey, item]) => {
                    html += `
                    <div class="cart-item">
                        <div class="cart-item-info">
                            <div class="cart-item-name">${escapeHtml(item.name)}</div>
                            <div class="cart-item-price">RM ${parseFloat(item.price).toFixed(2)} x ${item.quantity}</div>
                            <div class="cart-item-controls">
                                <button class="quantity-btn" onclick="updateCartQuantity('${cartKey}', ${item.quantity - 1})">-</button>
                                <span>${item.quantity}</span>
                                <button class="quantity-btn" onclick="updateCartQuantity('${cartKey}', ${item.quantity + 1})">+</button>
                                <button class="remove-btn" onclick="removeFromCart('${cartKey}')">×</button>
                            </div>
                        </div>
                    </div>
                `;
                });

                cartContent.innerHTML = html;

                document.getElementById('cartSubtotal').textContent = `RM ${totals.subtotal.toFixed(2)}`;
                document.getElementById('cartTax').textContent = `RM ${totals.tax.toFixed(2)}`;
                document.getElementById('cartTotal').textContent = `RM ${totals.total.toFixed(2)}`;
                cartSummary.style.display = 'block';
            }

            // Update cart quantity
            async function updateCartQuantity(cartKey, newQuantity) {
                const formData = new FormData();
                formData.append('action', 'update_cart');
                formData.append('cart_key', cartKey);
                formData.append('quantity', newQuantity);

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();
                    if (data.success) {
                        loadCart();
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            }

            // Remove from cart
            async function removeFromCart(cartKey) {
                const formData = new FormData();
                formData.append('action', 'remove_from_cart');
                formData.append('cart_key', cartKey);

                try {
                    const response = await fetch('/Zuspresso/controller/OrderController.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await response.json();
                    if (data.success) {
                        showNotification('Item removed');
                        loadCart();
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            }

            // Toggle cart sidebar
            function toggleCart() {
                const cartSidebar = document.getElementById('cartSidebar');
                cartSidebar.classList.toggle('open');
            }

            // Proceed to checkout
            function proceedToCheckout() {
                window.location.href = 'cart.php';
            }

            // Show notification
            function showNotification(message, type = 'success') {
                const notification = document.getElementById('notification');
                notification.textContent = message;
                notification.className = `notification ${type}`;
                notification.classList.add('show');

                setTimeout(() => {
                    notification.classList.remove('show');
                }, 3000);
            }

            function updateCartBadge(count) {
                const badge = document.querySelector('.cart-badge');
                if (badge) {
                    badge.textContent = count;
                    if (count > 0) {
                        badge.style.display = 'flex';
                        badge.classList.add('show');
                    } else {
                        badge.style.display = 'none';
                        badge.classList.remove('show');
                    }
                }
            }

            // Helper functions
            function escapeHtml(text) {
                const map = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };
                return String(text).replace(/[&<>"']/g, m => map[m]);
            }

            function getItemEmoji(category) {
                const emojis = {
                    coffee: '☕',
                    frappe: '🥤',
                    tea: '🍵',
                    cham: '☕',
                    chocolate: '🍫',
                    specialty: '✨',
                    refresher: '🧊'
                };
                return emojis[category] || '☕';
            }

            // Close modal when clicking outside
            document.getElementById('itemModal').addEventListener('click', function (e) {
                if (e.target === this) {
                    closeItemModal();
                }
            });

            // Modal quantity input listener
            document.getElementById('modalQuantity').addEventListener('input', updateModalTotal);
        </script>
    </body>
</html>