<?php

session_start();

require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

try {

    $db = Database::getInstance()->getConnection();

    
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }

    
    $currentAdmin->updateLastLogin();


    $stats = $currentAdmin->getSystemStats();

    
    $stmt = $db->prepare("
        SELECT u.user_id, u.email, u.role, u.created_at,
               COALESCE(c.first_name, a.admin_name) as display_name,
               CASE 
                   WHEN c.first_name IS NOT NULL THEN CONCAT(c.first_name, ' ', c.last_name)
                   ELSE a.admin_name 
               END as full_name
        FROM users u
        LEFT JOIN customers c ON u.user_id = c.user_id
        LEFT JOIN admins a ON u.user_id = a.user_id
        WHERE u.is_active = 1
        ORDER BY u.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Admin Dashboard Error: " . $e->getMessage());
    $error_message = "Error loading dashboard data.";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Dashboard - Zuspresso</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {
                --zus-brown: #8B4513;
                --zus-cream: #F5F5DC;
                --zus-dark-brown: #654321;
                --zus-gold: #D4AF37;
            }

            body {
                background: linear-gradient(135deg, #f8f9fa, var(--zus-cream));
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .navbar {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .card {
                border: none;
                border-radius: 15px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                overflow: hidden;
            }

            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            }

            .card-header {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                padding: 1rem 1.5rem;
            }

            .btn-zus {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                border-radius: 10px;
                padding: 10px 20px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .btn-zus:hover {
                background: linear-gradient(135deg, var(--zus-dark-brown), var(--zus-brown));
                color: white;
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            }

            .stats-card {
                background: linear-gradient(135deg, #ffffff, var(--zus-cream));
                border-left: 4px solid var(--zus-brown);
            }

            .stats-icon {
                font-size: 2.5rem;
                color: var(--zus-brown);
                opacity: 0.8;
            }

            .stats-number {
                font-size: 2rem;
                font-weight: bold;
                color: var(--zus-dark-brown);
            }

            .sidebar {
                background: linear-gradient(180deg, var(--zus-cream), #ffffff);
                min-height: calc(100vh - 56px);
                border-right: 1px solid rgba(139, 69, 19, 0.1);
            }

            .sidebar .nav-link {
                color: var(--zus-dark-brown);
                border-radius: 10px;
                margin: 5px 10px;
                padding: 10px 15px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .sidebar .nav-link:hover, .sidebar .nav-link.active {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                transform: translateX(5px);
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

            .welcome-card {
                background: linear-gradient(135deg, var(--zus-gold), #f4d03f);
                color: var(--zus-dark-brown);
                border-radius: 15px;
                padding: 2rem;
                margin-bottom: 2rem;
            }

            .table-card .table {
                margin-bottom: 0;
            }

            .table thead th {
                background-color: var(--zus-cream);
                border: none;
                color: var(--zus-dark-brown);
                font-weight: 600;
            }

            .badge-role {
                font-size: 0.8rem;
                padding: 0.4rem 0.8rem;
                border-radius: 20px;
            }

            .badge-admin {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            }

            .badge-customer {
                background: linear-gradient(135deg, #28a745, #20c997);
            }
        </style>
    </head>
    <body>
      
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" href="#">
                    <i class="fas fa-coffee"></i> Zuspresso Admin
                </a>
                <div class="navbar-nav ms-auto">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($currentAdmin->getAdminName()) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                
                <nav class="col-md-3 col-lg-2 sidebar">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>
                            <?php if ($currentAdmin->hasPermission('user_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="user_management.php">
                                        <i class="fas fa-users"></i> User Management
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if ($currentAdmin->hasPermission('menu_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="menu_management.php">
                                        <i class="fas fa-utensils"></i> Menu Management
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if ($currentAdmin->hasPermission('order_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="order_management.php">
                                        <i class="fas fa-shopping-cart"></i> Orders
                                    </a>
                                </li>
                            <?php endif; ?>

                             <li class="nav-item">
                                    <a class="nav-link" href="review_management.php">
                                        <i class="fas fa-star"></i> Reviews
                                    </a>
                                </li>

                            <?php if ($currentAdmin->hasPermission('reports')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="reports.php">
                                        <i class="fas fa-chart-bar"></i> Reports
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link" href="admin_register.php">
                                    <i class="fas fa-user-plus"></i> Add Admin
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>

               
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger mt-3">
                            <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
                        </div>
                    <?php endif; ?>

                    
                    <div class="welcome-card mt-4">
                        <h1 class="h2 mb-0">
                            <i class="fas fa-coffee"></i> Welcome back, <?= htmlspecialchars($currentAdmin->getAdminName()) ?>!
                        </h1>
                        <p class="mb-0 mt-2">Here's what's happening with your Zuspresso system today.</p>
                    </div>

                    
                    <?php if ($stats): ?>
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card stats-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="me-3">
                                            <i class="fas fa-users stats-icon"></i>
                                        </div>
                                        <div>
                                            <div class="stats-number"><?= number_format($stats['total_users']) ?></div>
                                            <div class="text-muted">Total Users</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card stats-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="me-3">
                                            <i class="fas fa-user-friends stats-icon"></i>
                                        </div>
                                        <div>
                                            <div class="stats-number"><?= number_format($stats['total_customers']) ?></div>
                                            <div class="text-muted">Customers</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card stats-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="me-3">
                                            <i class="fas fa-user-shield stats-icon"></i>
                                        </div>
                                        <div>
                                            <div class="stats-number"><?= number_format($stats['total_admins']) ?></div>
                                            <div class="text-muted">Administrators</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card stats-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="me-3">
                                            <i class="fas fa-user-plus stats-icon"></i>
                                        </div>
                                        <div>
                                            <div class="stats-number"><?= number_format($stats['recent_registrations']) ?></div>
                                            <div class="text-muted">New (30 days)</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    
                    <div class="card table-card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-clock"></i> Recent User Registrations
                            </h5>
                        </div>
                        <div class="card-body p-0">
                            <?php if (empty($recent_users)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-users text-muted" style="font-size: 3rem;"></i>
                                    <p class="text-muted mt-3">No recent user registrations found.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Role</th>
                                                <th>Registration Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recent_users as $user): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?= htmlspecialchars($user['full_name'] ?? $user['display_name'] ?? 'N/A') ?></strong>
                                                    </td>
                                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                                    <td>
                                                        <span class="badge <?= $user['role'] === 'admin' ? 'badge-admin' : 'badge-customer' ?> badge-role">
                                                            <i class="fas <?= $user['role'] === 'admin' ? 'fa-user-shield' : 'fa-user' ?>"></i>
                                                            <?= ucfirst(htmlspecialchars($user['role'])) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <small class="text-muted">
                                                            <?= date('M d, Y H:i', strtotime($user['created_at'])) ?>
                                                        </small>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                   
                    <div class="row mt-4 mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">
                                        <i class="fas fa-bolt"></i> Quick Actions
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <a href="admin_register.php" class="btn btn-zus w-100">
                                                <i class="fas fa-user-plus"></i><br>
                                                <small>Add Admin</small>
                                            </a>
                                        </div>
                                        <?php if ($currentAdmin->hasPermission('user_management')): ?>
                                            <div class="col-md-3 mb-3">
                                                <a href="user_management.php" class="btn btn-zus w-100">
                                                    <i class="fas fa-users-cog"></i><br>
                                                    <small>Manage Users</small>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($currentAdmin->hasPermission('order_management')): ?>
                                            <div class="col-md-3 mb-3">
                                                <a href="order_management.php" class="btn btn-zus w-100">
                                                    <i class="fas fa-shopping-cart"></i><br>
                                                    <small>Manage Orders</small>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                        <li class="nav-item">
                                            <a class="nav-link" href="review_management.php">
                                                <i class="fas fa-star"></i> Reviews
                                            </a>
                                        </li>

                                        <?php if ($currentAdmin->hasPermission('reports')): ?>
                                            <div class="col-md-3 mb-3">
                                                <a href="reports.php" class="btn btn-zus w-100">
                                                    <i class="fas fa-chart-line"></i><br>
                                                    <small>View Reports</small>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                        <div class="col-md-3 mb-3">
                                            <a href="profile.php" class="btn btn-zus w-100">
                                                <i class="fas fa-user-edit"></i><br>
                                                <small>Edit Profile</small>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
        <script>
                                
                                setTimeout(function () {
                                    location.reload();
                                }, 300000);

                               
                                document.querySelectorAll('.btn-zus').forEach(btn => {
                                    btn.addEventListener('click', function () {
                                        if (this.getAttribute('href') !== '#') {
                                            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
                                        }
                                    });
                                });


                                function logout() {
                                    if (confirm('Are you sure you want to logout?')) {
                                        
                                        const form = document.createElement('form');
                                        form.method = 'POST';
                                        form.action = '/Zuspresso/controller/AuthController.php';

                                        const actionInput = document.createElement('input');
                                        actionInput.type = 'hidden';
                                        actionInput.name = 'action';
                                        actionInput.value = 'logout';
                                        form.appendChild(actionInput);

                                        document.body.appendChild(form);
                                        form.submit();
                                    }
                                }

        </script>
    </body>
</html>