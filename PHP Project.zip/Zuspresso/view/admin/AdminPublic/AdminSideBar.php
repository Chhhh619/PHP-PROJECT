<?php

$currentPage = $currentPage ?? '';
?>

<!-- Sidebar -->
<nav class="col-md-3 col-lg-2 sidebar">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'dashboard' ? 'active' : '' ?>" href="admin_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            
            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('user_management')): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'user_management' ? 'active' : '' ?>" href="user_management.php">
                    <i class="fas fa-users"></i> User Management
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('menu_management')): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'menu_management' ? 'active' : '' ?>" href="menu_management.php">
                    <i class="fas fa-utensils"></i> Menu Management
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('order_management')): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'order_management' ? 'active' : '' ?>" href="order_management.php">
                    <i class="fas fa-shopping-cart"></i> Orders
                </a>
            </li>
            <?php endif; ?>
            
            
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'review_management' ? 'active' : '' ?>" href="review_management.php">
                    <i class="fas fa-star"></i> Reviews
                </a>
            </li>
            
            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('reports')): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'reports' ? 'active' : '' ?>" href="reports.php">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
            </li>
            <?php endif; ?>
            
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'admin_register' ? 'active' : '' ?>" href="admin_register.php">
                    <i class="fas fa-user-plus"></i> Add Admin
                </a>
            </li>
        </ul>
    </div>
</nav>