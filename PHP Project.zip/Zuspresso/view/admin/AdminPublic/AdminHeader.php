<?php

?>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="admin_dashboard.php">
            <i class="fas fa-coffee"></i> Zuspresso Admin
        </a>
        <div class="navbar-nav ms-auto">
            <div class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle"></i> 
                    <?= isset($currentAdmin) ? htmlspecialchars($currentAdmin->getAdminName()) : 'Admin' ?>
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="admin_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a></li>

                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="#" onclick="logout()">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<script>

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '../../controller/AuthController.php';

        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'logout';
        form.appendChild(actionInput);

        document.body.appendChild(form);
        form.submit();
    }
}
</script>