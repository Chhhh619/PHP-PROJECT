<?php

session_start();


require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}


try {
    $database = Database::getInstance()->getConnection();
    $userFactory = new UserFactory($database);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

   
    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }

    
    if (!$currentAdmin->hasPermission('menu_management')) {
        $permissionError = "Looks like you need menu management permissions to access this page. " .
                "Ask your friendly system administrator to grant you access!";
    }
} catch (Exception $e) {
    error_log("Menu Management Page Error: " . $e->getMessage());
    $systemError = "Something went wrong loading the page. Please try refreshing or contact support.";
}


$currentPage = 'menu_management';
$adminDisplayName = isset($currentAdmin) ? $currentAdmin->getAdminName() : 'Coffee Admin';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Menu Management - Zuspresso Coffee</title>

        
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <link href="AdminCss/Admincss.css" rel="stylesheet">

        <style>

            .availability-available {
                background: linear-gradient(135deg, #28a745, #20c997);
                color: white;
                font-weight: 600;
            }

            .availability-unavailable {
                background: linear-gradient(135deg, #dc3545, #fd7e14);
                color: white;
                font-weight: 600;
            }


            .loading-spinner {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #8B4513;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                animation: coffeeSpin 1s linear infinite;
                margin: 30px auto;
            }

            @keyframes coffeeSpin {
                0% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(360deg);
                }
            }


            .form-label {
                font-weight: 600;
                color: #495057;
                margin-bottom: 8px;
            }

            .form-control:focus, .form-select:focus {
                border-color: #8B4513;
                box-shadow: 0 0 0 0.25rem rgba(139, 69, 19, 0.25);
            }


            .btn-zus {
                background: linear-gradient(135deg, #8B4513, #654321);
                border: none;
                color: white;
                font-weight: 600;
                border-radius: 10px;
                padding: 10px 20px;
                transition: all 0.3s ease;
            }

            .btn-zus:hover {
                background: linear-gradient(135deg, #654321, #8B4513);
                color: white;
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            }


            .alert {
                border-radius: 15px;
                border: none;
                font-weight: 500;
            }

            .alert-success {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                color: #155724;
            }

            .alert-danger {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                color: #721c24;
            }


            .table th {
                background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                color: #495057;
                font-weight: 600;
                border-bottom: 2px solid #8B4513;
            }

            .table tbody tr:hover {
                background-color: rgba(139, 69, 19, 0.05);
            }


            .category-badge {
                padding: 5px 12px;
                border-radius: 20px;
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            .category-coffee {
                background: linear-gradient(135deg, #8B4513, #654321);
                color: white;
            }
            .category-tea {
                background: linear-gradient(135deg, #28a745, #20c997);
                color: white;
            }
            .category-frappe {
                background: linear-gradient(135deg, #17a2b8, #138496);
                color: white;
            }
            .category-cham {
                background: linear-gradient(135deg, #ffc107, #fd7e14);
                color: black;
            }
            .category-chocolate {
                background: linear-gradient(135deg, #6f42c1, #563d7c);
                color: white;
            }
            .category-refresher {
                background: linear-gradient(135deg, #20c997, #17a2b8);
                color: white;
            }
            .category-specialty {
                background: linear-gradient(135deg, #e83e8c, #dc3545);
                color: white;
            }


            .item-description {
                max-width: 300px;
                word-wrap: break-word;
            }
        </style>
    </head>
    <body>

        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" href="admin_dashboard.php">
                    <i class="fas fa-coffee"></i> Zuspresso Coffee Admin
                </a>
                <div class="navbar-nav ms-auto">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> 
                            <?= htmlspecialchars($adminDisplayName) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" onclick="logout()">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">

                <nav class="col-md-3 col-lg-2 sidebar">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>

                            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('user_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="user_management.php">
                                        <i class="fas fa-users"></i> User Management
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('menu_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link active" href="menu_management.php">
                                        <i class="fas fa-utensils"></i> Menu Management
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('order_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="order_management.php">
                                        <i class="fas fa-shopping-cart"></i> Orders
                                    </a>
                                </li>
                               
                            <?php endif; ?>
                                 <li class="nav-item">
                                    <a class="nav-link" href="review_management.php">
                                        <i class="fas fa-star"></i> Reviews
                                    </a>
                                </li>

                            <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('reports')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="reports.php">
                                        <i class="fas fa-chart-bar"></i> Reports
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link" href="admin_register.php">
                                    <i class="fas fa-user-plus"></i> Add Admin
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>


                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">
                            <i class="fas fa-utensils text-primary"></i> Menu Management
                            <small class="text-muted fs-6">Manage your coffee shop's delicious offerings</small>
                        </h1>
                        <div class="btn-toolbar mb-2 mb-md-0">
                            <?php if (!isset($permissionError) && !isset($systemError)): ?>
                                <button type="button" class="btn btn-zus" data-bs-toggle="modal" data-bs-target="#addItemModal">
                                    <i class="fas fa-plus"></i> Add New Menu Item
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <?php if (isset($permissionError)): ?>
                        <div class="alert alert-warning">
                            <h4 class="alert-heading">
                                <i class="fas fa-exclamation-triangle"></i> Access Restricted
                            </h4>
                            <p class="mb-0"><?= htmlspecialchars($permissionError) ?></p>
                            <hr>
                            <small>Once you have the right permissions, you'll be able to add new drinks, update prices, and manage all our menu items!</small>
                        </div>
                    <?php elseif (isset($systemError)): ?>
                        <div class="alert alert-danger">
                            <h4 class="alert-heading">
                                <i class="fas fa-exclamation-circle"></i> System Error
                            </h4>
                            <p class="mb-0"><?= htmlspecialchars($systemError) ?></p>
                        </div>
                    <?php else: ?>


                        <div id="notificationArea"></div>


                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="fas fa-filter"></i> Find & Filter Menu Items
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="categoryFilter" class="form-label">
                                            <i class="fas fa-tags"></i> Category
                                        </label>
                                        <select class="form-select" id="categoryFilter">
                                            <option value="">All Categories</option>
                                            <option value="coffee">Coffee</option>
                                            <option value="tea">Tea</option>
                                            <option value="frappe">Frappe</option>
                                            <option value="cham">Cham</option>
                                            <option value="chocolate">Chocolate</option>
                                            <option value="refresher">Refresher</option>
                                            <option value="specialty">Specialty</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="availabilityFilter" class="form-label">
                                            <i class="fas fa-eye"></i> Availability
                                        </label>
                                        <select class="form-select" id="availabilityFilter">
                                            <option value="">All Items</option>
                                            <option value="1">Available</option>
                                            <option value="0">Unavailable</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="searchInput" class="form-label">
                                            <i class="fas fa-search"></i> Search Items
                                        </label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" id="searchInput" 
                                                   placeholder="Search by name or description...">
                                            <button type="button" class="btn btn-outline-secondary" onclick="clearAllFilters()">
                                                <i class="fas fa-eraser"></i> Clear
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">
                                    <i class="fas fa-coffee"></i> Your Menu Items
                                    <span class="badge bg-primary ms-2" id="itemCount">Loading...</span>
                                </h5>
                            </div>
                            <div class="card-body">

                                <div id="loadingIndicator" class="text-center py-5">
                                    <div class="loading-spinner"></div>
                                    <p class="text-muted mt-3">Brewing up your menu items...</p>
                                    <small class="text-muted">This might take a moment</small>
                                </div>

                            
                                <div class="table-responsive" id="menuTableContainer" style="display: none;">
                                    <table class="table table-hover" id="menuItemsTable">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <i class="fas fa-coffee"></i> Item Details
                                                </th>
                                                <th>
                                                    <i class="fas fa-tag"></i> Category
                                                </th>
                                                <th>
                                                    <i class="fas fa-dollar-sign"></i> Price
                                                </th>
                                                <th>
                                                    <i class="fas fa-toggle-on"></i> Status
                                                </th>
                                                <th width="200">
                                                    <i class="fas fa-cogs"></i> Actions
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody id="menuItemsTableBody">

                                        </tbody>
                                    </table>
                                </div>


                                <div id="noResultsIndicator" class="text-center py-5" style="display: none;">
                                    <i class="fas fa-search text-muted" style="font-size: 4rem;"></i>
                                    <h4 class="text-muted mt-3">No Menu Items Found</h4>
                                    <p class="text-muted">
                                        Try adjusting your search criteria or add some delicious new items to your menu!
                                    </p>
                                    <button class="btn btn-zus" onclick="clearAllFilters()">
                                        <i class="fas fa-refresh"></i> Show All Items
                                    </button>
                                </div>
                            </div>


                            <div class="card-footer" id="paginationSection">
                                <nav aria-label="Menu items pagination">
                                    <ul class="pagination justify-content-center mb-0" id="paginationControls">

                                    </ul>
                                </nav>
                            </div>
                        </div>

                    <?php endif; ?>
                </main>
            </div>
        </div>


        <div class="modal fade" id="addItemModal" tabindex="-1" aria-labelledby="addItemModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addItemModalLabel">
                            <i class="fas fa-plus"></i> Add New Menu Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="addItemForm">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="addItemName" class="form-label">
                                        <i class="fas fa-coffee"></i> Item Name *
                                    </label>
                                    <input type="text" class="form-control" id="addItemName" name="name" required
                                           placeholder="e.g., Spanish Latte">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="addItemCategory" class="form-label">
                                        <i class="fas fa-tags"></i> Category *
                                    </label>
                                    <select class="form-select" id="addItemCategory" name="category" required>
                                        <option value="">Choose a category</option>
                                        <option value="coffee">Coffee</option>
                                        <option value="tea">Tea</option>
                                        <option value="frappe">Frappe</option>
                                        <option value="cham">Cham</option>
                                        <option value="chocolate">Chocolate</option>
                                        <option value="refresher">Refresher</option>
                                        <option value="specialty">Specialty</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="addItemDescription" class="form-label">
                                    <i class="fas fa-align-left"></i> Description *
                                </label>
                                <textarea class="form-control" id="addItemDescription" name="description" rows="3" required
                                          placeholder="Describe what makes this item special..."></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="addItemPrice" class="form-label">
                                        <i class="fas fa-dollar-sign"></i> Price (RM) *
                                    </label>
                                    <input type="number" class="form-control" id="addItemPrice" name="price" 
                                           step="0.01" min="0" required placeholder="13.90">
                                </div>
                                <div class="col-md-6 mb-3 d-flex align-items-end">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="addItemAvailable" name="is_available" checked>
                                        <label class="form-check-label" for="addItemAvailable">
                                            <i class="fas fa-toggle-on"></i> <strong>Available for customers to order</strong>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-zus">
                                <i class="fas fa-plus"></i> Add to Menu
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <div class="modal fade" id="editItemModal" tabindex="-1" aria-labelledby="editItemModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editItemModalLabel">
                            <i class="fas fa-edit"></i> Edit Menu Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="editItemForm">
                        <input type="hidden" id="editItemId" name="item_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="editItemName" class="form-label">
                                        <i class="fas fa-coffee"></i> Item Name *
                                    </label>
                                    <input type="text" class="form-control" id="editItemName" name="name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="editItemCategory" class="form-label">
                                        <i class="fas fa-tags"></i> Category *
                                    </label>
                                    <select class="form-select" id="editItemCategory" name="category" required>
                                        <option value="">Choose a category</option>
                                        <option value="coffee">Coffee</option>
                                        <option value="tea">Tea</option>
                                        <option value="frappe">Frappe</option>
                                        <option value="cham">Cham</option>
                                        <option value="chocolate">Chocolate</option>
                                        <option value="refresher">Refresher</option>
                                        <option value="specialty">Specialty</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="editItemDescription" class="form-label">
                                    <i class="fas fa-align-left"></i> Description *
                                </label>
                                <textarea class="form-control" id="editItemDescription" name="description" rows="3" required></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="editItemPrice" class="form-label">
                                        <i class="fas fa-dollar-sign"></i> Price (RM) *
                                    </label>
                                    <input type="number" class="form-control" id="editItemPrice" name="price" 
                                           step="0.01" min="0" required>
                                </div>
                                <div class="col-md-6 mb-3 d-flex align-items-end">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="editItemAvailable" name="is_available">
                                        <label class="form-check-label" for="editItemAvailable">
                                            <i class="fas fa-toggle-on"></i> <strong>Available for customers to order</strong>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-zus">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <div class="modal fade" id="deleteItemModal" tabindex="-1" aria-labelledby="deleteItemModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteItemModalLabel">
                            <i class="fas fa-trash"></i> Confirm Deletion
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to remove "<span id="deleteItemName" class="fw-bold"></span>" from your menu?</p>
                        <div class="alert alert-warning">
                            <i class="fas fa-info-circle"></i>
                            <strong>Note:</strong> If this item has been ordered before, it will be marked as unavailable 
                            instead of being completely deleted (to preserve order history).
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times"></i> Keep Item
                        </button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteButton">
                            <i class="fas fa-trash"></i> Remove from Menu
                        </button>
                    </div>
                </div>
            </div>
        </div>


        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

        <script>
                                        

                                        class MenuManager {
                                            constructor() {
                                                
                                                this.apiEndpoint = '../../controller/MenuController.php';
                                                this.currentPage = 1;
                                                this.currentFilters = {};
                                                this.itemToDelete = null;

                                                // Initialize when page loads
                                                this.initializeInterface();
                                            }

                                           
                                            initializeInterface() {
                                                
                                                this.loadMenuItems();

                                               
                                                this.setupEventListeners();

                                                
                                                this.setupFormHandlers();

                                                console.log('Simplified menu management interface ready!');
                                            }

                                            
                                            setupEventListeners() {
                                                
                                                document.getElementById('categoryFilter').addEventListener('change', () => this.applyFilters());
                                                document.getElementById('availabilityFilter').addEventListener('change', () => this.applyFilters());

                                               
                                                document.getElementById('searchInput').addEventListener('input', this.debounce(() => this.applyFilters(), 500));

                                                
                                                document.getElementById('confirmDeleteButton').addEventListener('click', () => this.executeDelete());
                                            }

                                            
                                            setupFormHandlers() {
                                                document.getElementById('addItemForm').addEventListener('submit', (e) => this.handleAddItem(e));
                                                document.getElementById('editItemForm').addEventListener('submit', (e) => this.handleEditItem(e));
                                            }

                                            
                                            debounce(func, wait) {
                                                let timeout;
                                                return function executedFunction(...args) {
                                                    const later = () => {
                                                        clearTimeout(timeout);
                                                        func(...args);
                                                    };
                                                    clearTimeout(timeout);
                                                    timeout = setTimeout(later, wait);
                                                };
                                            }

                                            
                                            async loadMenuItems(page = 1) {
                                                this.currentPage = page;

                                                try {
                                                    this.showLoading(true);

                                                   
                                                    const params = new URLSearchParams({
                                                        action: 'list',
                                                        page: page,
                                                        limit: 10,
                                                        ...this.currentFilters
                                                    });

                                                    const response = await fetch(`${this.apiEndpoint}?${params}`);
                                                    const data = await response.json();

                                                    if (data.success) {
                                                        this.displayMenuItems(data.items);
                                                        this.displayPagination(data.pagination);
                                                        this.updateItemCount(data.pagination.total_items);
                                                    } else {
                                                        this.showNotification('Oops! ' + data.message, 'danger');
                                                    }

                                                } catch (error) {
                                                    console.error('Error loading menu items:', error);
                                                    this.showNotification('Had trouble loading menu items. Please try refreshing the page.', 'danger');
                                                } finally {
                                                    this.showLoading(false);
                                            }
                                            }

                                            
                                            displayMenuItems(items) {
                                                const tableBody = document.getElementById('menuItemsTableBody');
                                                const tableContainer = document.getElementById('menuTableContainer');
                                                const noResults = document.getElementById('noResultsIndicator');

                                                if (items.length === 0) {
                                                    tableContainer.style.display = 'none';
                                                    noResults.style.display = 'block';
                                                    return;
                                                }

                                                tableContainer.style.display = 'block';
                                                noResults.style.display = 'none';

                                                
                                                tableBody.innerHTML = items.map(item => {
                                                    const categoryClass = `category-${item.category}`;
                                                    const availabilityClass = item.is_available == 1 ? 'availability-available' : 'availability-unavailable';

                                                    return `
                            <tr>
                                <td class="item-description">
                                    <div class="fw-bold">${this.escapeHtml(item.name)}</div>
                                    <small class="text-muted">${this.escapeHtml(item.description)}</small>
                                </td>
                                <td>
                                    <span class="badge category-badge ${categoryClass}">${this.escapeHtml(item.category)}</span>
                                </td>
                                <td class="fw-bold">RM ${parseFloat(item.price).toFixed(2)}</td>
                                <td>
                                    <span class="badge ${availabilityClass}">
                                        ${item.is_available == 1 ? 'Available' : 'Unavailable'}
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button type="button" class="btn btn-outline-primary" onclick="menuManager.editItem(${item.item_id})" title="Edit this item">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-outline-${item.is_available == 1 ? 'warning' : 'success'}" 
                                                onclick="menuManager.toggleAvailability(${item.item_id})" 
                                                title="${item.is_available == 1 ? 'Mark unavailable' : 'Mark available'}">
                                            <i class="fas fa-${item.is_available == 1 ? 'eye-slash' : 'eye'}"></i>
                                        </button>
                                        <button type="button" class="btn btn-outline-danger" onclick="menuManager.deleteItem(${item.item_id}, '${this.escapeHtml(item.name)}')" title="Remove from menu">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                                                }).join('');
                                            }

                                            
                                            async handleAddItem(e) {
                                                e.preventDefault();

                                                try {
                                                    const formData = new FormData(e.target);
                                                    formData.append('action', 'create');

                                                    const response = await fetch(this.apiEndpoint, {
                                                        method: 'POST',
                                                        body: formData
                                                    });

                                                    const data = await response.json();

                                                    if (data.success) {
                                                        this.showNotification('Menu item added successfully!', 'success');
                                                        bootstrap.Modal.getInstance(document.getElementById('addItemModal')).hide();
                                                        document.getElementById('addItemForm').reset();
                                                        this.loadMenuItems(this.currentPage);
                                                    } else {
                                                        this.showNotification('Error adding menu item: ' + data.message, 'danger');
                                                    }

                                                } catch (error) {
                                                    console.error('Error adding menu item:', error);
                                                    this.showNotification('Failed to add menu item. Please try again.', 'danger');
                                                }
                                            }

                                            
                                            async handleEditItem(e) {
                                                e.preventDefault();

                                                try {
                                                    const formData = new FormData(e.target);
                                                    formData.append('action', 'update');

                                                    const response = await fetch(this.apiEndpoint, {
                                                        method: 'POST',
                                                        body: formData
                                                    });

                                                    const data = await response.json();

                                                    if (data.success) {
                                                        this.showNotification('Menu item updated successfully!', 'success');
                                                        bootstrap.Modal.getInstance(document.getElementById('editItemModal')).hide();
                                                        this.loadMenuItems(this.currentPage);
                                                    } else {
                                                        this.showNotification('Error updating menu item: ' + data.message, 'danger');
                                                    }

                                                } catch (error) {
                                                    console.error('Error updating menu item:', error);
                                                    this.showNotification('Failed to update menu item. Please try again.', 'danger');
                                                }
                                            }

                                            
                                            async editItem(itemId) {
                                                try {
                                                    const response = await fetch(`${this.apiEndpoint}?action=get&item_id=${itemId}`);
                                                    const data = await response.json();

                                                    if (data.success) {
                                                        const item = data.item;
                                                        document.getElementById('editItemId').value = item.item_id;
                                                        document.getElementById('editItemName').value = item.name;
                                                        document.getElementById('editItemCategory').value = item.category;
                                                        document.getElementById('editItemDescription').value = item.description;
                                                        document.getElementById('editItemPrice').value = item.price;
                                                        document.getElementById('editItemAvailable').checked = item.is_available == 1;

                                                        new bootstrap.Modal(document.getElementById('editItemModal')).show();
                                                    } else {
                                                        this.showNotification('Error loading item data: ' + data.message, 'danger');
                                                    }
                                                } catch (error) {
                                                    console.error('Error loading item:', error);
                                                    this.showNotification('Failed to load item data. Please try again.', 'danger');
                                                }
                                            }

                                            
                                            async toggleAvailability(itemId) {
                                                try {
                                                    const formData = new FormData();
                                                    formData.append('action', 'toggle_availability');
                                                    formData.append('item_id', itemId);

                                                    const response = await fetch(this.apiEndpoint, {
                                                        method: 'POST',
                                                        body: formData
                                                    });

                                                    const data = await response.json();

                                                    if (data.success) {
                                                        this.showNotification(data.message, 'success');
                                                        this.loadMenuItems(this.currentPage);
                                                    } else {
                                                        this.showNotification('Error toggling availability: ' + data.message, 'danger');
                                                    }
                                                } catch (error) {
                                                    console.error('Error toggling availability:', error);
                                                    this.showNotification('Failed to toggle availability. Please try again.', 'danger');
                                                }
                                            }

                                            
                                            deleteItem(itemId, itemName) {
                                                this.itemToDelete = itemId;
                                                document.getElementById('deleteItemName').textContent = itemName;
                                                new bootstrap.Modal(document.getElementById('deleteItemModal')).show();
                                            }

                                            
                                            async executeDelete() {
                                                if (!this.itemToDelete)
                                                    return;

                                                try {
                                                    const formData = new FormData();
                                                    formData.append('action', 'delete');
                                                    formData.append('item_id', this.itemToDelete);

                                                    const response = await fetch(this.apiEndpoint, {
                                                        method: 'POST',
                                                        body: formData
                                                    });

                                                    const data = await response.json();

                                                    if (data.success) {
                                                        this.showNotification(data.message, 'success');
                                                        bootstrap.Modal.getInstance(document.getElementById('deleteItemModal')).hide();
                                                        this.loadMenuItems(this.currentPage);
                                                    } else {
                                                        this.showNotification('Error deleting item: ' + data.message, 'danger');
                                                    }
                                                } catch (error) {
                                                    console.error('Error deleting item:', error);
                                                    this.showNotification('Failed to delete item. Please try again.', 'danger');
                                                } finally {
                                                    this.itemToDelete = null;
                                                }
                                            }

                                           
                                            showLoading(show) {
                                                document.getElementById('loadingIndicator').style.display = show ? 'block' : 'none';
                                                document.getElementById('menuTableContainer').style.display = show ? 'none' : 'block';
                                            }

                                            
                                            updateItemCount(count) {
                                                document.getElementById('itemCount').textContent = `${count} item${count !== 1 ? 's' : ''}`;
                                            }

                                           
                                            displayPagination(pagination) {
                                                const paginationContainer = document.getElementById('paginationControls');

                                                if (pagination.total_pages <= 1) {
                                                    document.getElementById('paginationSection').style.display = 'none';
                                                    return;
                                                }

                                                document.getElementById('paginationSection').style.display = 'block';

                                                let html = '';

                                                
                                                html += `
                        <li class="page-item ${!pagination.has_previous ? 'disabled' : ''}">
                            <a class="page-link" href="#" onclick="menuManager.loadMenuItems(${pagination.current_page - 1})">
                                <i class="fas fa-chevron-left"></i> Previous
                            </a>
                        </li>
                    `;

                                               
                                                for (let i = 1; i <= pagination.total_pages; i++) {
                                                    if (i === 1 || i === pagination.total_pages ||
                                                            (i >= pagination.current_page - 2 && i <= pagination.current_page + 2)) {
                                                        html += `
                                <li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                                    <a class="page-link" href="#" onclick="menuManager.loadMenuItems(${i})">${i}</a>
                                </li>
                            `;
                                                    } else if (i === pagination.current_page - 3 || i === pagination.current_page + 3) {
                                                        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                                    }
                                                }

                                                
                                                html += `
                        <li class="page-item ${!pagination.has_next ? 'disabled' : ''}">
                            <a class="page-link" href="#" onclick="menuManager.loadMenuItems(${pagination.current_page + 1})">
                                Next <i class="fas fa-chevron-right"></i>
                            </a>
                        </li>
                    `;

                                                paginationContainer.innerHTML = html;
                                            }


                                            applyFilters() {
                                                this.currentFilters = {
                                                    category: document.getElementById('categoryFilter').value,
                                                    availability: document.getElementById('availabilityFilter').value,
                                                    search: document.getElementById('searchInput').value
                                                };

                                                
                                                Object.keys(this.currentFilters).forEach(key => {
                                                    if (!this.currentFilters[key]) {
                                                        delete this.currentFilters[key];
                                                    }
                                                });

                                                this.loadMenuItems(1);
                                            }


                                            clearAllFilters() {
                                                document.getElementById('categoryFilter').value = '';
                                                document.getElementById('availabilityFilter').value = '';
                                                document.getElementById('searchInput').value = '';
                                                this.currentFilters = {};
                                                this.loadMenuItems(1);
                                            }


                                            showNotification(message, type = 'success') {
                                                const container = document.getElementById('notificationArea');
                                                const alertId = 'alert-' + Date.now();

                                                const alertHtml = `
                        <div class="alert alert-${type} alert-dismissible fade show" role="alert" id="${alertId}">
                            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'exclamation-circle'}"></i>
                            ${message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    `;

                                                container.insertAdjacentHTML('afterbegin', alertHtml);

                                              
                                                if (type === 'success') {
                                                    setTimeout(() => {
                                                        const alert = document.getElementById(alertId);
                                                        if (alert) {
                                                            new bootstrap.Alert(alert).close();
                                                        }
                                                    }, 5000);
                                            }
                                            }

                                            
                                            escapeHtml(text) {
                                                const map = {
                                                    '&': '&amp;',
                                                    '<': '&lt;',
                                                    '>': '&gt;',
                                                    '"': '&quot;',
                                                    "'": '&#039;'
                                                };
                                                return text.replace(/[&<>"']/g, m => map[m]);
                                            }
                                        }

                                      
                                        function clearAllFilters() {
                                            menuManager.clearAllFilters();
                                        }
                                        function logout() {
                                            if (confirm('Are you sure you want to logout?')) {
                                                
                                                const form = document.createElement('form');
                                                form.method = 'POST';
                                                form.action = '../../controller/AuthController.php';

                                                const actionInput = document.createElement('input');
                                                actionInput.type = 'hidden';
                                                actionInput.name = 'action';
                                                actionInput.value = 'logout';
                                                form.appendChild(actionInput);

                                                document.body.appendChild(form);
                                                form.submit();
                                            }
                                        }


                                        let menuManager;
                                        document.addEventListener('DOMContentLoaded', function () {
                                            menuManager = new MenuManager();
                                        });
        </script>
    </body>
</html>