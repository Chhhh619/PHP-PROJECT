<?php

session_start();


require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

try {
    
    $db = Database::getInstance()->getConnection();

    
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }

    

} catch (Exception $e) {
    error_log("Review Management Error: " . $e->getMessage());
    $error_message = "Error loading review management data.";
}


$reviewServiceUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/Zuspresso/service/ReviewService.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Management - Zuspresso Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --zus-brown: #8B4513;
            --zus-cream: #F5F5DC;
            --zus-dark-brown: #654321;
            --zus-gold: #D4AF37;
        }

        body {
            background: linear-gradient(135deg, #f8f9fa, var(--zus-cream));
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar {
            background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .card-header {
            background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            color: white;
            border: none;
            padding: 1rem 1.5rem;
        }

        .btn-zus {
            background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            color: white;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .btn-zus:hover {
            background: linear-gradient(135deg, var(--zus-dark-brown), var(--zus-brown));
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .btn-outline-zus {
            color: var(--zus-brown);
            border: 2px solid var(--zus-brown);
            background: transparent;
            border-radius: 10px;
            padding: 8px 16px;
            transition: all 0.3s ease;
        }

        .btn-outline-zus:hover {
            background: var(--zus-brown);
            color: white;
        }

        .sidebar {
            background: linear-gradient(180deg, var(--zus-cream), #ffffff);
            min-height: calc(100vh - 56px);
            border-right: 1px solid rgba(139, 69, 19, 0.1);
        }

        .sidebar .nav-link {
            color: var(--zus-dark-brown);
            border-radius: 10px;
            margin: 5px 10px;
            padding: 10px 15px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            color: white;
            transform: translateX(5px);
        }

        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .search-form {
            background: linear-gradient(135deg, #ffffff, var(--zus-cream));
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 1px solid rgba(139, 69, 19, 0.1);
        }

        .star-rating {
            color: var(--zus-gold);
            font-size: 1.2rem;
        }

        .review-card {
            background: #ffffff;
            border-left: 4px solid var(--zus-brown);
            margin-bottom: 1rem;
        }

        .loading-spinner {
            display: none;
            text-align: center;
            padding: 2rem;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .pagination .page-link {
            color: var(--zus-brown);
            border-color: var(--zus-brown);
        }

        .pagination .page-item.active .page-link {
            background-color: var(--zus-brown);
            border-color: var(--zus-brown);
        }

        .badge-rating {
            background: linear-gradient(135deg, var(--zus-gold), #f4d03f);
            color: var(--zus-dark-brown);
        }

        .table thead th {
            background-color: var(--zus-cream);
            border: none;
            color: var(--zus-dark-brown);
            font-weight: 600;
        }

        .alert-info {
            background: linear-gradient(135deg, #d1ecf1, #bee5eb);
            border: 1px solid #b6d4da;
            color: #0c5460;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">
                <i class="fas fa-coffee"></i> Zuspresso Admin
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> <?= htmlspecialchars($currentAdmin->getAdminName()) ?>
                    </a>
                    <ul class="dropdown-menu">                                           
                       <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        <?php if ($currentAdmin->hasPermission('user_management')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="user_management.php">
                                    <i class="fas fa-users"></i> User Management
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($currentAdmin->hasPermission('menu_management')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="menu_management.php">
                                    <i class="fas fa-utensils"></i> Menu Management
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if ($currentAdmin->hasPermission('order_management')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="order_management.php">
                                    <i class="fas fa-shopping-cart"></i> Orders
                                </a>
                            </li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link active" href="review_management.php">
                                <i class="fas fa-star"></i> Reviews
                            </a>
                        </li>

                        <?php if ($currentAdmin->hasPermission('reports')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="reports.php">
                                    <i class="fas fa-chart-bar"></i> Reports
                                </a>
                            </li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link" href="admin_register.php">
                                <i class="fas fa-user-plus"></i> Add Admin
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>


            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger mt-3">
                        <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
                    </div>
                <?php endif; ?>

                
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-star text-warning"></i> Review Management
                    </h1>
                </div>

                
                <div class="search-form">
                    <h5 class="mb-3"><i class="fas fa-search"></i> Search Reviews</h5>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-box"></i> Item Reviews</h6>
                                </div>
                                <div class="card-body">
                                    <form id="itemReviewsForm">
                                        <div class="mb-3">
                                            <label for="item_id" class="form-label">Item ID</label>
                                            <input type="number" class="form-control" id="item_id" name="item_id" placeholder="Enter item ID" required>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="page" class="form-label">Page</label>
                                                <input type="number" class="form-control" id="page" name="page" value="1" min="1">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="limit" class="form-label">Per Page</label>
                                                <select class="form-select" id="limit" name="limit">
                                                    <option value="10">10</option>
                                                    <option value="20">20</option>
                                                    <option value="50">50</option>
                                                </select>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-zus mt-3">
                                            <i class="fas fa-search"></i> Get Item Reviews
                                        </button>
                                        <button type="button" class="btn btn-outline-zus mt-3 ms-2" onclick="getReviewSummary()">
                                            <i class="fas fa-chart-pie"></i> Summary Only
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-user"></i> Customer Reviews</h6>
                                </div>
                                <div class="card-body">
                                    <form id="customerReviewsForm">
                                        <div class="mb-3">
                                            <label for="customer_id" class="form-label">Customer ID</label>
                                            <input type="number" class="form-control" id="customer_id" name="customer_id" placeholder="Enter customer ID" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="customer_limit" class="form-label">Limit</label>
                                            <select class="form-select" id="customer_limit" name="limit">
                                                <option value="20">20</option>
                                                <option value="50">50</option>
                                                <option value="100">100</option>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-zus">
                                            <i class="fas fa-search"></i> Get Customer Reviews
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div id="loadingSpinner" class="loading-spinner">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading reviews...</p>
                </div>

                
                <div id="resultsContainer">
                    <div class="empty-state">
                        <i class="fas fa-star"></i>
                        <h4>Welcome to Review Management</h4>
                        <p>Use the search forms above to view and manage product reviews.</p>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        const reviewServiceUrl = '<?= $reviewServiceUrl ?>';

        
        function showLoading() {
            document.getElementById('loadingSpinner').style.display = 'block';
            document.getElementById('resultsContainer').innerHTML = '';
        }


        function hideLoading() {
            document.getElementById('loadingSpinner').style.display = 'none';
        }

        
        document.getElementById('itemReviewsForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const params = new URLSearchParams();
            params.append('action', 'get_item_reviews');
            
            for (let [key, value] of formData.entries()) {
                if (value) params.append(key, value);
            }

            showLoading();
            
            try {
                const response = await fetch(`${reviewServiceUrl}?${params.toString()}`);
                const data = await response.json();
                
                if (data.success) {
                    displayItemReviews(data.data);
                } else {
                    displayError(data.error.message);
                }
            } catch (error) {
                displayError('Failed to fetch item reviews: ' + error.message);
            } finally {
                hideLoading();
            }
        });


        document.getElementById('customerReviewsForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const params = new URLSearchParams();
            params.append('action', 'get_customer_reviews');
            
            for (let [key, value] of formData.entries()) {
                if (value) params.append(key, value);
            }

            showLoading();
            
            try {
                const response = await fetch(`${reviewServiceUrl}?${params.toString()}`);
                const data = await response.json();
                
                if (data.success) {
                    displayCustomerReviews(data.data);
                } else {
                    displayError(data.error.message);
                }
            } catch (error) {
                displayError('Failed to fetch customer reviews: ' + error.message);
            } finally {
                hideLoading();
            }
        });

        
        async function getReviewSummary() {
            const itemId = document.getElementById('item_id').value;
            if (!itemId) {
                alert('Please enter an Item ID first');
                return;
            }

            showLoading();
            
            try {
                const response = await fetch(`${reviewServiceUrl}?action=get_review_summary&item_id=${itemId}`);
                const data = await response.json();
                
                if (data.success) {
                    displayReviewSummary(data.data);
                } else {
                    displayError(data.error.message);
                }
            } catch (error) {
                displayError('Failed to fetch review summary: ' + error.message);
            } finally {
                hideLoading();
            }
        }

       
        function displayItemReviews(data) {
            const { reviews, statistics, pagination } = data;
            
            let html = `
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-box"></i> Item Reviews</h5>
                    </div>
                    <div class="card-body">
                        <!-- Statistics -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="text-center">
                                    <h3 class="text-primary">${statistics.total_reviews}</h3>
                                    <small class="text-muted">Total Reviews</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-center">
                                    <h3 class="text-warning">${statistics.average_rating}</h3>
                                    <small class="text-muted">Average Rating</small>
                                    <div class="star-rating">${statistics.star_display}</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <small class="text-muted">Rating Distribution:</small><br>
                                ${generateRatingDistribution(statistics.rating_distribution)}
                            </div>
                        </div>
                        
                        <!-- Reviews -->
                        <h6>Reviews (Page ${pagination.current_page} of ${pagination.total_pages})</h6>
            `;

            if (reviews.length === 0) {
                html += '<div class="empty-state"><i class="fas fa-comment-slash"></i><p>No reviews found</p></div>';
            } else {
                reviews.forEach(review => {
                    html += `
                        <div class="card review-card mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <div class="star-rating">${'★'.repeat(review.rating)}${'☆'.repeat(5-review.rating)}</div>
                                        <span class="badge badge-rating">${review.rating}/5</span>
                                    </div>
                                    <small class="text-muted">${new Date(review.created_at).toLocaleDateString()}</small>
                                </div>
                                <p class="mt-2 mb-1">${review.review_text || 'No comment provided'}</p>
                                <small class="text-muted">Customer ID: ${review.customer_id} | Order ID: ${review.order_id}</small>
                            </div>
                        </div>
                    `;
                });

                
                if (pagination.total_pages > 1) {
                    html += generatePagination(pagination);
                }
            }

            html += '</div></div>';
            document.getElementById('resultsContainer').innerHTML = html;
        }


        function displayCustomerReviews(data) {
            const { customer_id, reviews, customer_statistics } = data;
            
            let html = `
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-user"></i> Customer Reviews (ID: ${customer_id})</h5>
                    </div>
                    <div class="card-body">
                        <!-- Customer Statistics -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="text-center">
                                    <h3 class="text-primary">${customer_statistics.total_reviews}</h3>
                                    <small class="text-muted">Total Reviews</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-center">
                                    <h3 class="text-warning">${customer_statistics.average_rating}</h3>
                                    <small class="text-muted">Average Rating</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <small class="text-muted">Most Recent: ${customer_statistics.most_recent_review || 'N/A'}</small>
                            </div>
                        </div>
                        
                        <!-- Reviews -->
                        <h6>All Reviews</h6>
            `;

            if (reviews.length === 0) {
                html += '<div class="empty-state"><i class="fas fa-comment-slash"></i><p>No reviews found for this customer</p></div>';
            } else {
                reviews.forEach(review => {
                    html += `
                        <div class="card review-card mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <div class="star-rating">${'★'.repeat(review.rating)}${'☆'.repeat(5-review.rating)}</div>
                                        <span class="badge badge-rating">${review.rating}/5</span>
                                    </div>
                                    <small class="text-muted">${new Date(review.created_at).toLocaleDateString()}</small>
                                </div>
                                <p class="mt-2 mb-1">${review.review_text || 'No comment provided'}</p>
                                <small class="text-muted">Item ID: ${review.item_id} | Order ID: ${review.order_id}</small>
                            </div>
                        </div>
                    `;
                });
            }

            html += '</div></div>';
            document.getElementById('resultsContainer').innerHTML = html;
        }


        function displayReviewSummary(data) {
            let html = `
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-chart-pie"></i> Review Summary (Item ID: ${data.item_id})</h5>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-4">
                                <h2 class="text-primary">${data.total_reviews}</h2>
                                <p class="text-muted">Total Reviews</p>
                            </div>
                            <div class="col-md-4">
                                <h2 class="text-warning">${data.average_rating}</h2>
                                <div class="star-rating">${data.star_display}</div>
                                <p class="text-muted">Average Rating</p>
                            </div>
                            <div class="col-md-4">
                                <h6>Rating Distribution</h6>
                                ${generateRatingDistribution(data.rating_distribution)}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('resultsContainer').innerHTML = html;
        }

        
        function generateRatingDistribution(distribution) {
            let html = '';
            for (let i = 5; i >= 1; i--) {
                const count = distribution[`${i}_star`] || 0;
                html += `
                    <div class="d-flex align-items-center mb-1">
                        <span class="me-2">${i}★</span>
                        <div class="progress flex-grow-1 me-2" style="height: 10px;">
                            <div class="progress-bar bg-warning" style="width: ${count > 0 ? (count / 100) * 100 : 0}%"></div>
                        </div>
                        <small>${count}</small>
                    </div>
                `;
            }
            return html;
        }

        
        function generatePagination(pagination) {
            let html = '<nav class="mt-3"><ul class="pagination justify-content-center">';
            
            if (pagination.has_previous) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="changePage(${pagination.previous_page})">Previous</a></li>`;
            }
            
            for (let i = Math.max(1, pagination.current_page - 2); i <= Math.min(pagination.total_pages, pagination.current_page + 2); i++) {
                html += `<li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
                </li>`;
            }
            
            if (pagination.has_next) {
                html += `<li class="page-item"><a class="page-link" href="#" onclick="changePage(${pagination.next_page})">Next</a></li>`;
            }
            
            html += '</ul></nav>';
            return html;
        }


        function changePage(page) {
            document.getElementById('page').value = page;
            document.getElementById('itemReviewsForm').dispatchEvent(new Event('submit'));
        }

        
        function displayError(message) {
            document.getElementById('resultsContainer').innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> ${message}
                </div>
            `;
        }

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '/Zuspresso/controller/AuthController.php';

                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'logout';
                form.appendChild(actionInput);

                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>