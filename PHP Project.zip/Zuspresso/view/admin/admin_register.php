<?php

/**
author : Cheng Jun Yang
 */

session_start();


require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

try {
    
    $db = Database::getInstance()->getConnection();

  
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }


    if (!$currentAdmin->hasPermission('user_management')) {
        $permission_error = "You don't have permission to create new administrators.";
    }
} catch (Exception $e) {
    error_log("Admin Register Page Error: " . $e->getMessage());
    $error_message = "Error loading page.";
}


$success_message = '';
$error_message = '';
$form_data = [
    'email' => '',
    'admin_name' => '',
    'permissions' => []
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($permission_error)) {
    try {
       
        $form_data['email'] = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $form_data['admin_name'] = trim($_POST['admin_name']);
        $form_data['password'] = $_POST['password'];
        $form_data['confirm_password'] = $_POST['confirm_password'];

        
        $selected_permissions = $_POST['permissions'] ?? [];
        $form_data['permissions'] = $selected_permissions;


        $errors = [];

        if (empty($form_data['email'])) {
            $errors[] = "Email is required";
        } elseif (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Please enter a valid email address";
        }

        if (empty($form_data['admin_name'])) {
            $errors[] = "Admin name is required";
        } elseif (strlen($form_data['admin_name']) < 2) {
            $errors[] = "Admin name must be at least 2 characters long";
        }

        if (empty($form_data['password'])) {
            $errors[] = "Password is required";
        } elseif (strlen($form_data['password']) < 8) {
            $errors[] = "Password must be at least 8 characters long";
        } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $form_data['password'])) {
            $errors[] = "Password must contain at least one uppercase letter, lowercase letter, number, and special character";
        }

        if ($form_data['password'] !== $form_data['confirm_password']) {
            $errors[] = "Passwords do not match";
        }

        if (empty($selected_permissions)) {
            $errors[] = "Please select at least one permission";
        }

        if (!empty($errors)) {
            $error_message = implode('<br>', $errors);
        } else {
            
            $db->beginTransaction();

            try {
                
                $hashedPassword = password_hash($form_data['password'], PASSWORD_DEFAULT);

                $userSql = "INSERT INTO users (email, password_hash, role, is_active) VALUES (:email, :password_hash, 'admin', 1)";
                $userStmt = $db->prepare($userSql);
                $userStmt->bindParam(':email', $form_data['email']);
                $userStmt->bindParam(':password_hash', $hashedPassword);

                if (!$userStmt->execute()) {
                    throw new Exception("Failed to create user account");
                }

                $userId = $db->lastInsertId();

                
                $permissions = [
                    'user_management' => in_array('user_management', $selected_permissions),
                    'menu_management' => in_array('menu_management', $selected_permissions),
                    'order_management' => in_array('order_management', $selected_permissions),
                    'review_management' => in_array('review_management', $selected_permissions), // ADD THIS LINE
                    'reports' => in_array('reports', $selected_permissions),
                    'system_settings' => in_array('system_settings', $selected_permissions)
                ];

               
                $permissionsJson = json_encode($permissions);


                $adminSql = "INSERT INTO admins (user_id, admin_name, permissions) VALUES (:user_id, :admin_name, :permissions)";
                $adminStmt = $db->prepare($adminSql);
                $adminStmt->bindParam(':user_id', $userId);
                $adminStmt->bindParam(':admin_name', $form_data['admin_name']);
                $adminStmt->bindParam(':permissions', $permissionsJson);

                if (!$adminStmt->execute()) {
                    throw new Exception("Failed to create admin profile");
                }


                $db->commit();

                $success_message = "Administrator account created successfully with the selected permissions!";


                $form_data = [
                    'email' => '',
                    'admin_name' => '',
                    'permissions' => []
                ];


                $permissionList = implode(', ', array_keys(array_filter($permissions)));
                error_log("New admin created: {$form_data['email']} with permissions [{$permissionList}] by admin ID: {$currentAdmin->getUserId()}");
            } catch (Exception $e) {

                $db->rollback();
                throw $e;
            }
        }
    } catch (Exception $e) {
        error_log("Admin creation error: " . $e->getMessage());

        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            $error_message = "An account with this email address already exists.";
        } else {
            $error_message = "An error occurred while creating the administrator account: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Create Administrator - Zuspresso</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {
                --zus-brown: #8B4513;
                --zus-cream: #F5F5DC;
                --zus-dark-brown: #654321;
                --zus-gold: #D4AF37;
            }

            body {
                background: linear-gradient(135deg, #f8f9fa, var(--zus-cream));
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .navbar {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .card {
                border: none;
                border-radius: 15px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
            }

            .card-header {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                padding: 1.5rem;
            }

            .btn-zus {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                border-radius: 10px;
                padding: 12px 24px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .btn-zus:hover {
                background: linear-gradient(135deg, var(--zus-dark-brown), var(--zus-brown));
                color: white;
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            }

            .btn-secondary {
                background: #6c757d;
                border: none;
                border-radius: 10px;
                padding: 12px 24px;
                transition: all 0.3s ease;
            }

            .form-control, .form-select {
                border-radius: 10px;
                border: 2px solid #e9ecef;
                padding: 12px 16px;
                transition: all 0.3s ease;
            }

            .form-control:focus, .form-select:focus {
                border-color: var(--zus-brown);
                box-shadow: 0 0 0 0.2rem rgba(139, 69, 19, 0.25);
            }

            .form-check-input:checked {
                background-color: var(--zus-brown);
                border-color: var(--zus-brown);
            }

            .form-check-input:focus {
                box-shadow: 0 0 0 0.25rem rgba(139, 69, 19, 0.25);
            }

            .sidebar {
                background: linear-gradient(180deg, var(--zus-cream), #ffffff);
                min-height: calc(100vh - 56px);
                border-right: 1px solid rgba(139, 69, 19, 0.1);
            }

            .sidebar .nav-link {
                color: var(--zus-dark-brown);
                border-radius: 10px;
                margin: 5px 10px;
                padding: 10px 15px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .sidebar .nav-link:hover, .sidebar .nav-link.active {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                transform: translateX(5px);
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

            .permission-card {
                border: 2px solid #e9ecef;
                border-radius: 10px;
                transition: all 0.3s ease;
                cursor: pointer;
            }

            .permission-card:hover {
                border-color: var(--zus-brown);
                background-color: rgba(139, 69, 19, 0.02);
            }

            .permission-card:has(.form-check-input:checked) {
                border-color: var(--zus-brown);
                background-color: rgba(139, 69, 19, 0.05);
            }

            .alert {
                border-radius: 10px;
                border: none;
            }

            .alert-success {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                color: #155724;
            }

            .alert-danger {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                color: #721c24;
            }

            .password-requirements {
                font-size: 0.875rem;
                color: #6c757d;
            }

            .password-requirements.valid {
                color: #28a745;
            }

            .password-requirements.invalid {
                color: #dc3545;
            }

            .permission-preview {
                background: var(--zus-cream);
                border-radius: 8px;
                padding: 1rem;
                margin-top: 1rem;
                display: none;
            }

            .permission-preview.show {
                display: block;
            }
        </style>
    </head>
    <body>
       
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" href="admin_dashboard.php">
                    <i class="fas fa-coffee"></i> Zuspresso Admin
                </a>
                <div class="navbar-nav ms-auto">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> <?= htmlspecialchars($currentAdmin->getAdminName()) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <nav class="col-md-3 col-lg-2 sidebar">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>
<?php if ($currentAdmin->hasPermission('user_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="user_management.php">
                                        <i class="fas fa-users"></i> User Management
                                    </a>
                                </li>
<?php endif; ?>

<?php if ($currentAdmin->hasPermission('menu_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="menu_management.php">
                                        <i class="fas fa-utensils"></i> Menu Management
                                    </a>
                                </li>
<?php endif; ?>

<?php if ($currentAdmin->hasPermission('order_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="order_management.php">
                                        <i class="fas fa-shopping-cart"></i> Orders
                                    </a>
                                </li>
<?php endif; ?>

<?php if ($currentAdmin->hasPermission('reports')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="reports.php">
                                        <i class="fas fa-chart-bar"></i> Reports
                                    </a>
                                </li>
<?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link active" href="admin_register.php">
                                    <i class="fas fa-user-plus"></i> Add Admin
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>

                <!-- Main content -->
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">
                            <i class="fas fa-user-plus"></i> Create New Administrator
                        </h1>
                        <div class="btn-toolbar mb-2 mb-md-0">
                            <a href="admin_dashboard.php" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Dashboard
                            </a>
                        </div>
                    </div>

<?php if (isset($permission_error)): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($permission_error) ?>
                        </div>
                    <?php else: ?>

    <?php if (!empty($success_message)): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> <?= $success_message ?>
                            </div>
                        <?php endif; ?>

    <?php if (!empty($error_message)): ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle"></i> <?= $error_message ?>
                            </div>
                        <?php endif; ?>

                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header">
                                        <h5 class="mb-0">
                                            <i class="fas fa-user-shield"></i> Administrator Details
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" id="adminForm">
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="email" class="form-label">
                                                        <i class="fas fa-envelope"></i> Email Address *
                                                    </label>
                                                    <input type="email" class="form-control" id="email" name="email" 
                                                           value="<?= htmlspecialchars($form_data['email']) ?>" required>
                                                </div>

                                                <div class="col-md-6 mb-3">
                                                    <label for="admin_name" class="form-label">
                                                        <i class="fas fa-user"></i> Full Name *
                                                    </label>
                                                    <input type="text" class="form-control" id="admin_name" name="admin_name" 
                                                           value="<?= htmlspecialchars($form_data['admin_name']) ?>" required>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="password" class="form-label">
                                                        <i class="fas fa-lock"></i> Password *
                                                    </label>
                                                    <input type="password" class="form-control" id="password" name="password" required>
                                                    <div class="password-requirements mt-2">
                                                        <small>
                                                            <i class="fas fa-info-circle"></i> Password must contain:
                                                            <ul class="mb-0 mt-1">
                                                                <li>At least 8 characters</li>
                                                                <li>One uppercase letter</li>
                                                                <li>One lowercase letter</li>
                                                                <li>One number</li>
                                                                <li>One special character (@$!%*?&)</li>
                                                            </ul>
                                                        </small>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 mb-3">
                                                    <label for="confirm_password" class="form-label">
                                                        <i class="fas fa-lock"></i> Confirm Password *
                                                    </label>
                                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                                </div>
                                            </div>

                                            <div class="mb-4">
                                                <label class="form-label">
                                                    <i class="fas fa-shield-alt"></i> Permissions *
                                                </label>
                                                <p class="text-muted mb-3">Select the permissions for this administrator. These will be applied immediately upon account creation:</p>

                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <div class="permission-card p-3" onclick="togglePermission('user_management')">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="user_management" 
                                                                       name="permissions[]" value="user_management"
    <?= in_array('user_management', $form_data['permissions']) ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="user_management">
                                                                    <strong><i class="fas fa-users"></i> User Management</strong>
                                                                    <br><small class="text-muted">Manage customer and admin accounts</small>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mb-3">
                                                        <div class="permission-card p-3" onclick="togglePermission('menu_management')">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="menu_management" 
                                                                       name="permissions[]" value="menu_management"
    <?= in_array('menu_management', $form_data['permissions']) ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="menu_management">
                                                                    <strong><i class="fas fa-utensils"></i> Menu Management</strong>
                                                                    <br><small class="text-muted">Add, edit, and remove menu items</small>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mb-3">
                                                        <div class="permission-card p-3" onclick="togglePermission('order_management')">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="order_management" 
                                                                       name="permissions[]" value="order_management"
    <?= in_array('order_management', $form_data['permissions']) ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="order_management">
                                                                    <strong><i class="fas fa-shopping-cart"></i> Order Management</strong>
                                                                    <br><small class="text-muted">Process and manage customer orders</small>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mb-3">
                                                        <div class="permission-card p-3" onclick="togglePermission('reports')">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="reports" 
                                                                       name="permissions[]" value="reports"
    <?= in_array('reports', $form_data['permissions']) ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="reports">
                                                                    <strong><i class="fas fa-chart-bar"></i> Reports & Analytics</strong>
                                                                    <br><small class="text-muted">View sales reports and analytics</small>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mb-3">
                                                        <div class="permission-card p-3" onclick="togglePermission('system_settings')">
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="checkbox" id="system_settings" 
                                                                       name="permissions[]" value="system_settings"
    <?= in_array('system_settings', $form_data['permissions']) ? 'checked' : '' ?>>
                                                                <label class="form-check-label" for="system_settings">
                                                                    <strong><i class="fas fa-cog"></i> System Settings</strong>
                                                                    <br><small class="text-muted">Configure system settings and preferences</small>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                               
                                                <div class="permission-preview" id="permissionPreview">
                                                    <h6><i class="fas fa-eye"></i> Selected Permissions Preview:</h6>
                                                    <div id="selectedPermissions">No permissions selected</div>
                                                </div>
                                            </div>

                                            <div class="d-flex justify-content-between">
                                                <a href="admin_dashboard.php" class="btn btn-secondary">
                                                    <i class="fas fa-times"></i> Cancel
                                                </a>
                                                <button type="submit" class="btn btn-zus">
                                                    <i class="fas fa-user-plus"></i> Create Administrator
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

<?php endif; ?>
                </main>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
        <script>
                                                        
                                                        function togglePermission(permissionId) {
                                                            const checkbox = document.getElementById(permissionId);
                                                            checkbox.checked = !checkbox.checked;
                                                            updatePermissionPreview();
                                                        }

                                                      
                                                        function updatePermissionPreview() {
                                                            const checkboxes = document.querySelectorAll('input[name="permissions[]"]:checked');
                                                            const preview = document.getElementById('permissionPreview');
                                                            const selectedDiv = document.getElementById('selectedPermissions');

                                                            if (checkboxes.length > 0) {
                                                                preview.classList.add('show');
                                                                const permissions = Array.from(checkboxes).map(cb => {
                                                                    const label = document.querySelector(`label[for="${cb.id}"] strong`).textContent;
                                                                    return `<span class="badge bg-primary me-1 mb-1">${label}</span>`;
                                                                });
                                                                selectedDiv.innerHTML = permissions.join('');
                                                            } else {
                                                                preview.classList.remove('show');
                                                                selectedDiv.innerHTML = 'No permissions selected';
                                                            }
                                                        }

                                                       
                                                        document.getElementById('password').addEventListener('input', function () {
                                                            const password = this.value;
                                                            const requirements = document.querySelector('.password-requirements');

                                                            
                                                            const hasMinLength = password.length >= 8;
                                                            const hasUppercase = /[A-Z]/.test(password);
                                                            const hasLowercase = /[a-z]/.test(password);
                                                            const hasNumber = /\d/.test(password);
                                                            const hasSpecial = /[@$!%*?&]/.test(password);

                                                            const isValid = hasMinLength && hasUppercase && hasLowercase && hasNumber && hasSpecial;

                                                            if (isValid) {
                                                                requirements.className = 'password-requirements valid';
                                                            } else if (password.length > 0) {
                                                                requirements.className = 'password-requirements invalid';
                                                            } else {
                                                                requirements.className = 'password-requirements';
                                                            }
                                                        });

                                                        
                                                        document.getElementById('confirm_password').addEventListener('input', function () {
                                                            const password = document.getElementById('password').value;
                                                            const confirmPassword = this.value;

                                                            if (confirmPassword.length > 0) {
                                                                if (password === confirmPassword) {
                                                                    this.setCustomValidity('');
                                                                } else {
                                                                    this.setCustomValidity('Passwords do not match');
                                                                }
                                                            } else {
                                                                this.setCustomValidity('');
                                                            }
                                                        });

                                                        
                                                        document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
                                                            checkbox.addEventListener('change', updatePermissionPreview);
                                                        });

                                                       
                                                        document.getElementById('adminForm').addEventListener('submit', function (e) {
                                                            const checkboxes = document.querySelectorAll('input[name="permissions[]"]:checked');
                                                            if (checkboxes.length === 0) {
                                                                e.preventDefault();
                                                                alert('Please select at least one permission for the administrator.');
                                                                return false;
                                                            }


                                                            const submitBtn = this.querySelector('button[type="submit"]');
                                                            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Administrator...';
                                                            submitBtn.disabled = true;
                                                        });

                                                        
                                                        const successAlert = document.querySelector('.alert-success');
                                                        if (successAlert) {
                                                            setTimeout(() => {
                                                                successAlert.style.opacity = '0';
                                                                setTimeout(() => {
                                                                    successAlert.remove();
                                                                }, 300);
                                                            }, 5000);
                                                        }

                                                        
                                                        updatePermissionPreview();

                                                       
                                                        function logout() {
                                                            if (confirm('Are you sure you want to logout?')) {
                                                                const form = document.createElement('form');
                                                                form.method = 'POST';
                                                                form.action = '../../controller/AuthController.php';

                                                                const actionInput = document.createElement('input');
                                                                actionInput.type = 'hidden';
                                                                actionInput.name = 'action';
                                                                actionInput.value = 'logout';
                                                                form.appendChild(actionInput);

                                                                document.body.appendChild(form);
                                                                form.submit();
                                                            }
                                                        }
        </script>
    </body>
</html>