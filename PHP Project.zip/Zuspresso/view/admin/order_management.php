<?php

session_start();


require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}


$currentPage = 'order_management';

try {
    
    $db = Database::getInstance()->getConnection();
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }

    
    if (!$currentAdmin->hasPermission('order_management')) {
        $permission_error = "You don't have permission to access order management. Contact your administrator to request access.";
    }
} catch (Exception $e) {
    error_log("Order Management Page Error: " . $e->getMessage());
    $error_message = "Error loading order management system. Please try refreshing the page.";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Management - Zuspresso Coffee Admin</title>

        <!-- External CSS Libraries -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

        <style>
            /* === ZUSPRESSO COFFEE THEME === */
            :root {
                --coffee-brown: #8B4513;
                --coffee-cream: #F5F5DC;
                --coffee-dark: #654321;
                --coffee-gold: #D4AF37;
                --success-green: #28a745;
                --warning-orange: #fd7e14;
                --danger-red: #dc3545;
            }

            
            body {
                background: linear-gradient(135deg, #f8f9fa, var(--coffee-cream));
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                color: #333;
            }

           
            .navbar {
                background: linear-gradient(135deg, var(--coffee-brown), var(--coffee-dark));
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .sidebar {
                background: linear-gradient(180deg, var(--coffee-cream), #ffffff);
                min-height: calc(100vh - 56px);
                border-right: 1px solid rgba(139, 69, 19, 0.1);
            }

            .sidebar .nav-link {
                color: var(--coffee-dark);
                border-radius: 10px;
                margin: 5px 10px;
                padding: 10px 15px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .sidebar .nav-link:hover,
            .sidebar .nav-link.active {
                background: linear-gradient(135deg, var(--coffee-brown), var(--coffee-dark));
                color: white;
                transform: translateX(5px);
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

            
            .card {
                border: none;
                border-radius: 15px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                overflow: hidden;
            }

            .card:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
            }

            .card-header {
                background: linear-gradient(135deg, var(--coffee-brown), var(--coffee-dark));
                color: white;
                border: none;
                padding: 1.5rem;
            }

            
            .btn-coffee {
                background: linear-gradient(135deg, var(--coffee-brown), var(--coffee-dark));
                color: white;
                border: none;
                border-radius: 10px;
                padding: 12px 24px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .btn-coffee:hover {
                background: linear-gradient(135deg, var(--coffee-dark), var(--coffee-brown));
                color: white;
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            }

          
            .form-control, .form-select {
                border-radius: 10px;
                border: 2px solid #e9ecef;
                padding: 12px 16px;
                transition: all 0.3s ease;
            }

            .form-control:focus, .form-select:focus {
                border-color: var(--coffee-brown);
                box-shadow: 0 0 0 0.2rem rgba(139, 69, 19, 0.25);
            }

           
            .alert {
                border-radius: 10px;
                border: none;
            }

            .alert-success {
                background: linear-gradient(135deg, #d4edda, #c3e6cb);
                color: #155724;
            }

            .alert-danger {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                color: #721c24;
            }

            .alert-info {
                background: linear-gradient(135deg, #cce5ff, #b8daff);
                color: #004085;
            }

           
            .status-badge {
                padding: 0.4rem 0.8rem;
                border-radius: 20px;
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

          
            .status-pending {
                background: linear-gradient(135deg, #fff3cd, #ffeaa7);
                color: #856404;
                border: 1px solid #ffeaa7;
                animation: pulse-pending 2s infinite;
            }

            @keyframes pulse-pending {
                0%, 100% {
                    transform: scale(1);
                }
                50% {
                    transform: scale(1.05);
                }
            }

            
            .status-preparing {
                background: linear-gradient(135deg, #cce5ff, #b8daff);
                color: #004085;
                border: 1px solid #0984e3;
            }

           
            .status-canceled {
                background: linear-gradient(135deg, #f8d7da, #f5c6cb);
                color: #721c24;
                border: 1px solid #d63384;
            }

           
            .status-out-of-delivery {
                background: linear-gradient(135deg, #e2e3ff, #d1d9ff);
                color: #383874;
                border: 1px solid #6c5ce7;
            }

            
            .status-ready-to-pickup {
                background: linear-gradient(135deg, #d1f2eb, #b8f5d3);
                color: #0c5460;
                border: 1px solid #00b894;
            }

            .status-unknown {
                background: #e9ecef;
                color: #6c757d;
                border: 1px solid #dee2e6;
            }

            
            .order-type-pickup {
                background: linear-gradient(135deg, #e3f2fd, #bbdefb);
                color: #1565c0;
                padding: 0.25rem 0.5rem;
                border-radius: 12px;
                font-size: 0.75rem;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
            }

            .order-type-delivery {
                background: linear-gradient(135deg, #f3e5f5, #e1bee7);
                color: #7b1fa2;
                padding: 0.25rem 0.5rem;
                border-radius: 12px;
                font-size: 0.75rem;
                font-weight: 600;
                display: inline-flex;
                align-items: center;
                gap: 0.25rem;
            }

       
            .loading-spinner {
                border: 3px solid #f3f3f3;
                border-top: 3px solid var(--coffee-brown);
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin: 20px auto;
            }

            @keyframes spin {
                0% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(360deg);
                }
            }

           
            .table th {
                background: linear-gradient(135deg, var(--coffee-cream), #ffffff);
                color: var(--coffee-dark);
                font-weight: 600;
                border-bottom: 2px solid var(--coffee-brown);
                position: sticky;
                top: 0;
                z-index: 10;
            }

            .table tbody tr {
                transition: all 0.2s ease;
            }

            .table tbody tr:hover {
                background-color: rgba(139, 69, 19, 0.05);
                transform: scale(1.01);
            }

            
            .toast-container {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
            }

            
            @media (max-width: 768px) {
                .card-header h5 {
                    font-size: 1rem;
                }

                .btn-coffee {
                    padding: 8px 16px;
                    font-size: 0.875rem;
                }

                .status-badge {
                    font-size: 0.7rem;
                    padding: 0.3rem 0.6rem;
                }
            }

           
            .visually-hidden {
                position: absolute !important;
                width: 1px !important;
                height: 1px !important;
                padding: 0 !important;
                margin: -1px !important;
                overflow: hidden !important;
                clip: rect(0, 0, 0, 0) !important;
                white-space: nowrap !important;
                border: 0 !important;
            }

            
            .btn:focus,
            .form-control:focus,
            .form-select:focus {
                outline: 2px solid var(--coffee-brown);
                outline-offset: 2px;
            }
        </style>
    </head>
    <body>
       
<?php include_once 'AdminPublic/AdminHeader.php'; ?>

        <div class="container-fluid">
            <div class="row">
               
<?php include_once 'AdminPublic/AdminSideBar.php'; ?>

                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                    
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                        <h1 class="h2">
                            <i class="fas fa-shopping-cart text-primary"></i> 
                            Order Management
                            <small class="text-muted fs-6">Manage customer pickup and delivery orders</small>
                        </h1>
                    </div>

                    
<?php if (isset($permission_error)): ?>
                        <div class="alert alert-danger">
                            <h4 class="alert-heading">
                                <i class="fas fa-exclamation-triangle"></i> Access Denied
                            </h4>
                            <p class="mb-0"><?= htmlspecialchars($permission_error) ?></p>
                            <hr>
                            <small>If you need access to order management, please contact your system administrator.</small>
                        </div>

                     
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><i class="fas fa-info-circle"></i> What You Can Do</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <a href="admin_dashboard.php" class="btn btn-coffee w-100">
                                            <i class="fas fa-tachometer-alt"></i><br>
                                            <small>Return to Dashboard</small>
                                        </a>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <a href="profile.php" class="btn btn-coffee w-100">
                                            <i class="fas fa-user"></i><br>
                                            <small>View Your Profile</small>
                                        </a>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <a href="admin_register.php" class="btn btn-coffee w-100">
                                            <i class="fas fa-user-plus"></i><br>
                                            <small>Add New Admin</small>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php else: ?>

                        
                        <div id="permissionContainer">
                            <div class="card">
                                <div class="card-body text-center py-4">
                                    <div class="loading-spinner"></div>
                                    <p class="text-muted mt-2">Verifying permissions...</p>
                                </div>
                            </div>
                        </div>

                        
                        <div id="mainContent" style="display: none;">

                            
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h6 class="card-title mb-3">
                                        <i class="fas fa-filter"></i> Filter & Search Orders
                                    </h6>
                                    <div class="row align-items-end">
                                        <div class="col-md-4">
                                            <label class="form-label fw-bold">
                                                <i class="fas fa-search"></i> Search Orders
                                            </label>
                                            <div class="input-group">
                                                <input type="text" 
                                                       class="form-control" 
                                                       id="searchInput" 
                                                       placeholder="Order ID, customer name, email..."
                                                       aria-label="Search orders">
                                                <button class="btn btn-coffee" 
                                                        type="button" 
                                                        onclick="searchOrders()"
                                                        aria-label="Search">
                                                    <i class="fas fa-search"></i>
                                                </button>
                                            </div>
                                            <small class="text-muted">Search by order number, customer name, or email</small>
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label fw-bold">
                                                <i class="fas fa-tags"></i> Order Status
                                            </label>
                                            <select class="form-select" id="statusFilter" onchange="filterOrders()">
                                                <option value="all">All Orders</option>
                                                <option value="pending">🟡 Pending (New Orders)</option>
                                                <option value="preparing">🔵 Preparing</option>
                                                <option value="canceled">🔴 Canceled</option>
                                                <option value="out for delivery">🚚 Out for Delivery</option>
                                                <option value="ready to pickup">🥤 Ready to Pickup</option>
                                                <option value="delivered">✅ Delivered</option>
                                            </select>
                                        </div>
                                        <div class="col-md-2">
                                            <label class="form-label fw-bold">Items Per Page</label>
                                            <select class="form-select" id="perPageSelect" onchange="changePerPage()">
                                                <option value="10">10</option>
                                                <option value="20" selected>20</option>
                                                <option value="50">50</option>
                                            </select>
                                        </div>
                                        <div class="col-md-3">
                                            <button class="btn btn-outline-secondary me-2" onclick="clearFilters()">
                                                <i class="fas fa-times"></i> Clear
                                            </button>
                                            <button class="btn btn-coffee" onclick="refreshOrders()">
                                                <i class="fas fa-refresh"></i> Refresh
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="card">
                                <div class="card-header">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">
                                            <i class="fas fa-list"></i> Customer Orders
                                        </h5>
                                        <div class="d-flex align-items-center gap-2">
                                            <small class="text-light opacity-75">
                                                <i class="fas fa-info-circle"></i> Order types have different workflows
                                            </small>
                                            <button class="btn btn-sm btn-outline-light" 
                                                    onclick="showBulkActions()" 
                                                    id="bulkActionsBtn" 
                                                    style="display: none;"
                                                    aria-label="Show bulk actions">
                                                <i class="fas fa-tasks"></i> Bulk Actions
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body p-0">
                                    
                                    <div id="loadingContainer" class="text-center py-5">
                                        <div class="loading-spinner"></div>
                                        <p class="text-muted">Loading customer orders...</p>
                                        <small class="text-muted">This may take a moment</small>
                                    </div>

                                   
                                    <div id="tableContainer" style="display: none;">
                                        <div class="table-responsive">
                                            <table class="table table-hover mb-0" role="table">
                                                <thead>
                                                    <tr>
                                                        <th width="50" scope="col">
                                                            <input type="checkbox" 
                                                                   class="form-check-input" 
                                                                   id="selectAll" 
                                                                   onchange="toggleSelectAll()"
                                                                   aria-label="Select all orders">
                                                        </th>
                                                        <th scope="col">Order ID & Type</th>
                                                        <th scope="col">Customer Info</th>
                                                        <th scope="col">Items</th>
                                                        <th scope="col">Total Amount</th>
                                                        <th scope="col">Status</th>
                                                        <th scope="col">Date Ordered</th>
                                                        <th width="150" scope="col">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="ordersTableBody">
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    
                                    <div id="emptyState" class="text-center py-5" style="display: none;">
                                        <i class="fas fa-coffee text-muted" style="font-size: 4rem;"></i>
                                        <h4 class="text-muted mt-3">No Orders Found</h4>
                                        <p class="text-muted">
                                            No orders match your current filters. Try adjusting your search criteria.
                                        </p>
                                        <button class="btn btn-coffee" onclick="clearFilters()">
                                            <i class="fas fa-refresh"></i> Show All Orders
                                        </button>
                                    </div>
                                </div>

                                
                                <div class="card-footer" id="paginationContainer">
                                   
                                </div>
                            </div>
                        </div>

<?php endif; ?>
                </main>
            </div>
        </div>

        
        <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="orderModalTitle">Order Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="orderModalBody">
                        
                        <div class="text-center py-3">
                            <div class="loading-spinner"></div>
                            <p class="text-muted">Loading order details...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="statusUpdateModal" tabindex="-1" aria-labelledby="statusUpdateTitle" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="statusUpdateTitle">Update Order Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Update status for <strong id="statusUpdateOrderInfo">Order #...</strong>:</p>
                        <div class="mb-3">
                            <label class="form-label fw-bold" for="newStatusSelect">New Status:</label>
                            <select class="form-select" id="newStatusSelect" aria-label="Select new order status">
                                
                            </select>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Note:</strong> Status options are filtered based on order type (pickup vs delivery) and current status.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-coffee" onclick="confirmStatusUpdate()">
                            <i class="fas fa-save"></i> Update Status
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bulk Actions Modal -->
        <div class="modal fade" id="bulkActionsModal" tabindex="-1" aria-labelledby="bulkActionsTitle" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="bulkActionsTitle">Bulk Actions</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Selected <strong id="selectedCount">0</strong> order(s) for bulk action.</p>
                        <div class="mb-3">
                            <label class="form-label fw-bold" for="bulkActionSelect">Choose Action:</label>
                            <select class="form-select" id="bulkActionSelect" aria-label="Select bulk action">
                                <option value="">Select action...</option>
                                <option value="preparing">🔵 Mark as Preparing (All Order Types)</option>
                                <option value="canceled">🔴 Mark as Canceled (All Order Types)</option>
                                <option value="out for delivery">🚚 Mark as Out for Delivery (Delivery Orders Only)</option>
                                <option value="ready to pickup">🥤 Mark as Ready to Pickup (Pickup Orders Only)</option>
                            </select>
                        </div>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>Warning:</strong> Bulk actions will only apply to compatible order types. Status changes are permanent and cannot be undone.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-coffee" onclick="confirmBulkAction()">
                            <i class="fas fa-bolt"></i> Apply Action
                        </button>
                    </div>
                </div>
            </div>
        </div>

       
        <div class="toast-container"></div>

        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

        
        <script>
                           
                            class OrderManagement {
                                constructor() {
                                    this.apiEndpoint = '../../controller/OrderManagementController.php';
                                    this.refreshInterval = 30000;

                                    this.currentPage = 1;
                                    this.currentFilters = {
                                        status: 'all',
                                        search: '',
                                        perPage: 20
                                    };
                                    this.selectedOrders = [];
                                    this.currentOrderForStatusUpdate = null;
                                    this.hasPermission = false;

                                    this.init();
                                }

                                async init() {
                                    try {
                                        await this.checkPermissions();

                                        if (this.hasPermission) {
                                            await this.loadOrders();
                                            this.setupEventListeners();
                                            this.setupAutoRefresh();
                                            this.showToast('Order management system loaded successfully!', 'success');
                                        }
                                    } catch (error) {
                                        console.error('Failed to initialize order management:', error);
                                        this.showToast('Failed to load order management system', 'error');
                                    }
                                }

                                async checkPermissions() {
                                    try {
                                        console.log('Checking permissions...');
                                        const response = await fetch(this.apiEndpoint + '?action=check_permission');
                                        const data = await response.json();

                                        if (data.success) {
                                            this.hasPermission = true;
                                            document.getElementById('mainContent').style.display = 'block';
                                            this.showPermissionStatus('success', '✅ Access Granted', `Welcome, ${data.admin_name}! You can manage customer orders.`);
                                        } else {
                                            this.hasPermission = false;
                                            this.showPermissionStatus('error', '❌ Access Denied', data.message || 'You do not have permission to access order management.');

                                            if (data.redirect) {
                                                setTimeout(() => {
                                                    window.location.href = data.redirect;
                                                }, 3000);
                                            }
                                        }
                                    } catch (error) {
                                        console.error('Permission check failed:', error);
                                        this.hasPermission = false;
                                        this.showPermissionStatus('error', '🚫 System Error', 'Unable to verify permissions. Please refresh the page.');
                                    }
                                }

                                showPermissionStatus(type, title, message) {
                                    const container = document.getElementById('permissionContainer');
                                    const iconClass = type === 'success' ? 'fa-check-circle text-success' : 'fa-exclamation-triangle text-danger';
                                    const bgClass = type === 'success' ? 'alert-success' : 'alert-danger';

                                    container.innerHTML = `
                <div class="alert ${bgClass} alert-dismissible fade show" role="alert">
                    <h4 class="alert-heading">
                        <i class="fas ${iconClass}"></i> ${title}
                    </h4>
                    <p class="mb-0">${message}</p>
                    ${type === 'error' ? '<hr><small>Contact your system administrator if you believe this is an error.</small>' : ''}
                </div>
            `;
                                }

                                setupEventListeners() {
                                    document.getElementById('searchInput').addEventListener('keypress', (e) => {
                                        if (e.key === 'Enter') {
                                            e.preventDefault();
                                            this.searchOrders();
                                        }
                                    });
                                }

                                setupAutoRefresh() {
                                    setInterval(async () => {
                                        if (this.hasPermission && this.currentPage === 1) {
                                            await this.loadOrders();
                                        }
                                    }, this.refreshInterval);
                                }

                                async loadOrders(page = 1) {
                                    if (!this.hasPermission)
                                        return;

                                    try {
                                        this.showLoading(true);

                                        const params = new URLSearchParams({
                                            action: 'get_orders',
                                            page: page,
                                            limit: this.currentFilters.perPage,
                                            status: this.currentFilters.status,
                                            search: this.currentFilters.search
                                        });

                                        const response = await fetch(`${this.apiEndpoint}?${params}`);
                                        const data = await response.json();

                                        if (data.success) {
                                            this.renderOrdersTable(data.orders);
                                            this.renderPagination(data.pagination);
                                            this.currentPage = page;

                                            document.title = `Order Management (${data.pagination.total_count}) - Zuspresso`;
                                        } else {
                                            this.showToast('Error loading orders: ' + data.message, 'error');

                                            if (response.status === 401 || response.status === 403) {
                                                this.hasPermission = false;
                                                document.getElementById('mainContent').style.display = 'none';
                                                this.showPermissionStatus('error', 'Session Expired', 'Please log in again to continue.');
                                            }
                                        }
                                    } catch (error) {
                                        console.error('Error loading orders:', error);
                                        this.showToast('Failed to load orders. Please check your connection.', 'error');
                                    } finally {
                                        this.showLoading(false);
                                }
                                }

                                renderOrdersTable(orders) {
                                    const tbody = document.getElementById('ordersTableBody');
                                    const tableContainer = document.getElementById('tableContainer');
                                    const emptyState = document.getElementById('emptyState');

                                    if (orders.length === 0) {
                                        tableContainer.style.display = 'none';
                                        emptyState.style.display = 'block';
                                        return;
                                    }

                                    tableContainer.style.display = 'block';
                                    emptyState.style.display = 'none';

                                    let html = '';
                                    orders.forEach(order => {
                                        const isSelected = this.selectedOrders.includes(order.order_id);
                                        const canManage = order.valid_next_statuses && order.valid_next_statuses.length > 0;

                                        const orderType = order.order_type || 'delivery';
                                        const orderTypeFormatted = order.order_type_formatted || (orderType === 'pickup' ? 'Pickup' : 'Delivery');
                                        const orderTypeClass = orderType === 'pickup' ? 'order-type-pickup' : 'order-type-delivery';
                                        const orderTypeIcon = orderType === 'pickup' ? 'hand-holding' : 'truck';

                                        html += `
                    <tr ${isSelected ? 'class="table-primary"' : ''}>
                        <td>
                            <input type="checkbox" class="form-check-input order-checkbox" 
                                   value="${order.order_id}" ${isSelected ? 'checked' : ''} 
                                   onchange="orderManager.toggleOrderSelection(${order.order_id})"
                                   data-order-type="${orderType}">
                        </td>
                        <td>
                            <div><strong>#${order.order_id}</strong></div>
                            <span class="${orderTypeClass}">
                                <i class="fas fa-${orderTypeIcon}"></i> ${orderTypeFormatted}
                            </span>
                        </td>
                        <td>
                            <div class="fw-bold">${order.customer_name || 'Unknown'}</div>
                            <small class="text-muted">${order.customer_email || 'Unknown'}</small>
                        </td>
                        <td>${order.item_count} item${order.item_count > 1 ? 's' : ''}</td>
                        <td class="fw-bold">RM ${parseFloat(order.total_amount).toFixed(2)}</td>
                        <td>
                            <span class="status-badge ${order.status_class}">
                                ${order.status_formatted}
                            </span>
                            ${(order.order_status === 'pending' || order.order_status === '') ? '<br><small class="text-warning"><i class="fas fa-exclamation-circle"></i> Needs Action</small>' : ''}
                        </td>
                        <td>
                            <small>${order.formatted_date}</small>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary" onclick="orderManager.viewOrderDetails(${order.order_id})" 
                                        title="View Details">
                                    <i class="fas fa-eye"></i>
                                </button>
                                ${canManage ? `
                                <button class="btn btn-outline-success" onclick="orderManager.showStatusUpdate(${order.order_id})" 
                                        title="Update Status">
                                    <i class="fas fa-edit"></i>
                                </button>
                                ` : `
                                <button class="btn btn-outline-secondary" disabled title="No actions available">
                                    <i class="fas fa-check-circle"></i>
                                </button>
                                `}
                            </div>
                        </td>
                    </tr>
                `;
                                    });

                                    tbody.innerHTML = html;
                                    this.updateBulkActionsButton();
                                }

                                showLoading(show) {
                                    document.getElementById('loadingContainer').style.display = show ? 'block' : 'none';
                                    document.getElementById('tableContainer').style.display = show ? 'none' : 'block';
                                }

                                showToast(message, type = 'success') {
                                    const container = document.querySelector('.toast-container');
                                    const id = 'toast-' + Date.now();

                                    const bgClass = type === 'error' ? 'bg-danger' :
                                            type === 'info' ? 'bg-info' : 'bg-success';

                                    const toastHtml = `
                <div class="toast align-items-center text-white ${bgClass}" role="alert" id="${id}">
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                </div>
            `;

                                    container.insertAdjacentHTML('afterbegin', toastHtml);

                                    const toastElement = document.getElementById(id);
                                    const toast = new bootstrap.Toast(toastElement, {delay: 3000});
                                    toast.show();

                                    toastElement.addEventListener('hidden.bs.toast', function () {
                                        this.remove();
                                    });
                                }

                                

                                searchOrders() {
                                    this.currentFilters.search = document.getElementById('searchInput').value.trim();
                                    this.currentPage = 1;
                                    this.loadOrders();
                                }

                                filterOrders() {
                                    this.currentFilters.status = document.getElementById('statusFilter').value;
                                    this.currentPage = 1;
                                    this.loadOrders();
                                }

                                changePerPage() {
                                    this.currentFilters.perPage = parseInt(document.getElementById('perPageSelect').value);
                                    this.currentPage = 1;
                                    this.loadOrders();
                                }

                                clearFilters() {
                                    document.getElementById('searchInput').value = '';
                                    document.getElementById('statusFilter').value = 'all';
                                    this.currentFilters = {
                                        status: 'all',
                                        search: '',
                                        perPage: this.currentFilters.perPage
                                    };
                                    this.currentPage = 1;
                                    this.loadOrders();
                                }

                                refreshOrders() {
                                    this.loadOrders(this.currentPage);
                                    this.showToast('Orders refreshed', 'success');
                                }

                                

                                async viewOrderDetails(orderId) {
                                    try {
                                        const response = await fetch(`${this.apiEndpoint}?action=get_order_details&order_id=${orderId}`);
                                        const data = await response.json();

                                        console.log('Order details response:', data); // Debug log

                                        if (data.success) {
                                            this.renderOrderDetailsModal(data.order);
                                            const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
                                            modal.show();
                                        } else {
                                            this.showToast('Error loading order details: ' + data.message, 'error');
                                        }
                                    } catch (error) {
                                        console.error('Error loading order details:', error);
                                        this.showToast('Failed to load order details', 'error');
                                    }
                                }

                                renderOrderDetailsModal(order) {
                                    const modalTitle = document.getElementById('orderModalTitle');
                                    const modalBody = document.getElementById('orderModalBody');

                                    const orderType = order.order_type || 'delivery';
                                    const orderTypeFormatted = order.order_type_formatted || (orderType === 'pickup' ? 'Pickup' : 'Delivery');
                                    const orderTypeIcon = orderType === 'pickup' ? 'hand-holding' : 'truck';

                                    modalTitle.innerHTML = `<i class="fas fa-${orderTypeIcon}"></i> Order #${order.order_id} Details (${orderTypeFormatted})`;

                                    let itemsHtml = '';
                                    if (order.items && order.items.length > 0) {
                                        itemsHtml = order.items.map(item => `
                    <tr>
                        <td>${item.menu_item_name || 'Unknown Item'}</td>
                        <td>${item.quantity}</td>
                        <td>RM ${parseFloat(item.item_price).toFixed(2)}</td>
                        <td>RM ${parseFloat(item.subtotal).toFixed(2)}</td>
                    </tr>
                `).join('');
                                    }

                                    modalBody.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="fw-bold">Customer Information</h6>
                        <p><strong>Name:</strong> ${order.customer_name}</p>
                        <p><strong>Email:</strong> ${order.customer_email}</p>
                        <p><strong>Phone:</strong> ${order.customer_phone || 'N/A'}</p>
                    </div>
                    <div class="col-md-6">
                        <h6 class="fw-bold">Order Information</h6>
                        <p><strong>Status:</strong> <span class="status-badge ${order.status_class}">${order.status_formatted}</span></p>
                        <p><strong>Type:</strong> <i class="fas fa-${orderTypeIcon}"></i> ${orderTypeFormatted}</p>
                        <p><strong>Date:</strong> ${order.formatted_date}</p>
                        <p><strong>Payment:</strong> ${order.payment_method || 'N/A'}</p>
                    </div>
                </div>
            
                <hr>
            
                <div class="row">
                    <div class="col-12">
                        <h6 class="fw-bold">${orderType === 'pickup' ? 'Pickup' : 'Delivery'} Information</h6>
                        ${orderType === 'pickup'
                                            ? '<p><strong>Pickup Location:</strong> Store Location</p>'
                                            : `<p><strong>Delivery Address:</strong> ${order.delivery_address || 'N/A'}</p>`
                                            }
                        ${order.notes ? `<p><strong>Notes:</strong> ${order.notes}</p>` : ''}
                    </div>
                </div>
            
                <hr>
            
                <h6 class="fw-bold">Order Items</h6>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsHtml}
                        </tbody>
                    </table>
                </div>
            
                <div class="row">
                    <div class="col-md-6 offset-md-6">
                        <table class="table table-sm">
                            <tr>
                                <td><strong>Subtotal:</strong></td>
                                <td class="text-end">RM ${parseFloat(order.subtotal || 0).toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td><strong>Tax:</strong></td>
                                <td class="text-end">RM ${parseFloat(order.tax_amount || 0).toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td><strong>Total:</strong></td>
                                <td class="text-end fw-bold">RM ${parseFloat(order.total_amount).toFixed(2)}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            `;
                                }

                                async showStatusUpdate(orderId) {
                                    try {
                                        console.log(`Loading order ${orderId} for status update...`); 

                                        const response = await fetch(`${this.apiEndpoint}?action=get_order_details&order_id=${orderId}`);
                                        const data = await response.json();

                                        console.log('Status update order data:', data); 

                                        if (data.success) {
                                            this.currentOrderForStatusUpdate = data.order;

                                            const orderType = data.order.order_type || 'delivery';
                                            const orderTypeFormatted = data.order.order_type_formatted || (orderType === 'pickup' ? 'Pickup' : 'Delivery');

                                            
                                            document.getElementById('statusUpdateOrderInfo').textContent =
                                                    `Order #${data.order.order_id} (${data.order.status_formatted}) - ${orderTypeFormatted} Order`;

                                            
                                            this.populateStatusOptions(data.order.valid_next_statuses, orderType);


                                            const modal = new bootstrap.Modal(document.getElementById('statusUpdateModal'));
                                            modal.show();
                                        } else {
                                            this.showToast('Error loading order details: ' + data.message, 'error');
                                        }
                                    } catch (error) {
                                        console.error('Error loading order for status update:', error);
                                        this.showToast('Failed to load order details', 'error');
                                    }
                                }

                                populateStatusOptions(validStatuses, orderType = null) {
                                    const select = document.getElementById('newStatusSelect');
                                    select.innerHTML = '<option value="">Select new status...</option>';

                                    console.log('Populating status options:', validStatuses, 'for order type:', orderType); 

                                    const statusLabels = {
                                        'preparing': 'Preparing',
                                        'canceled': 'Canceled',
                                        'out for delivery': 'Out for Delivery',
                                        'ready to pickup': 'Ready to Pickup',
                                        'delivered': 'Delivered'
                                    };

                                    let availableStatuses = validStatuses;
                                    if (!availableStatuses || availableStatuses.length === 0) {
                                        console.warn('No valid statuses provided, using defaults for', orderType);
                                        if (orderType === 'pickup') {
                                            availableStatuses = ['preparing', 'canceled', 'ready to pickup'];
                                        } else {
                                            availableStatuses = ['preparing', 'canceled', 'out for delivery'];
                                        }
                                    }

                                    availableStatuses.forEach(status => {
                                        const option = document.createElement('option');
                                        option.value = status;
                                        option.textContent = statusLabels[status] || status;
                                        select.appendChild(option);
                                    });

                                    console.log('Status options populated:', availableStatuses); 
                                }


                                async confirmStatusUpdate() {
                                    const newStatus = document.getElementById('newStatusSelect').value;

                                    console.log('Confirming status update to:', newStatus); 

                                    if (!newStatus) {
                                        this.showToast('Please select a new status', 'error');
                                        return;
                                    }

                                    if (!this.currentOrderForStatusUpdate) {
                                        this.showToast('No order selected for update', 'error');
                                        return;
                                    }

                                    try {
                                        const formData = new FormData();
                                        formData.append('action', 'update_order_status');
                                        formData.append('order_id', this.currentOrderForStatusUpdate.order_id);
                                        formData.append('new_status', newStatus);

                                        console.log('Sending status update request...'); 

                                        const response = await fetch(this.apiEndpoint, {
                                            method: 'POST',
                                            body: formData
                                        });

                                        const data = await response.json();

                                        console.log('Status update response:', data); 

                                        if (data.success) {
                                            this.showToast(data.message, 'success');

                                            
                                            const modal = bootstrap.Modal.getInstance(document.getElementById('statusUpdateModal'));
                                            modal.hide();

                                            
                                            await this.loadOrders(this.currentPage);

                                            
                                            this.currentOrderForStatusUpdate = null;
                                        } else {
                                            this.showToast('Error updating status: ' + data.message, 'error');
                                        }
                                    } catch (error) {
                                        console.error('Error updating order status:', error);
                                        this.showToast('Failed to update order status', 'error');
                                    }
                                }

                                

                                toggleOrderSelection(orderId) {
                                    const index = this.selectedOrders.indexOf(orderId);
                                    if (index > -1) {
                                        this.selectedOrders.splice(index, 1);
                                    } else {
                                        this.selectedOrders.push(orderId);
                                    }
                                    this.updateBulkActionsButton();
                                    this.loadOrders(this.currentPage);
                                }

                                toggleSelectAll() {
                                    const checkboxes = document.querySelectorAll('.order-checkbox');
                                    const selectAllCheckbox = document.getElementById('selectAll');

                                    if (selectAllCheckbox.checked) {
                                        checkboxes.forEach(cb => {
                                            if (!this.selectedOrders.includes(parseInt(cb.value))) {
                                                this.selectedOrders.push(parseInt(cb.value));
                                            }
                                        });
                                    } else {
                                        checkboxes.forEach(cb => {
                                            const index = this.selectedOrders.indexOf(parseInt(cb.value));
                                            if (index > -1) {
                                                this.selectedOrders.splice(index, 1);
                                            }
                                        });
                                    }

                                    this.updateBulkActionsButton();
                                    this.loadOrders(this.currentPage);
                                }

                                updateBulkActionsButton() {
                                    const bulkBtn = document.getElementById('bulkActionsBtn');
                                    if (this.selectedOrders.length > 0) {
                                        bulkBtn.style.display = 'inline-block';
                                    } else {
                                        bulkBtn.style.display = 'none';
                                    }
                                }

                                showBulkActions() {
                                    if (this.selectedOrders.length === 0) {
                                        this.showToast('No orders selected', 'error');
                                        return;
                                    }

                                    document.getElementById('selectedCount').textContent = this.selectedOrders.length;

                                    const modal = new bootstrap.Modal(document.getElementById('bulkActionsModal'));
                                    modal.show();
                                }

                                async confirmBulkAction() {
                                    const newStatus = document.getElementById('bulkActionSelect').value;

                                    if (!newStatus) {
                                        this.showToast('Please select an action', 'error');
                                        return;
                                    }

                                    if (this.selectedOrders.length === 0) {
                                        this.showToast('No orders selected', 'error');
                                        return;
                                    }

                                    try {
                                        const formData = new FormData();
                                        formData.append('action', 'bulk_update_status');
                                        formData.append('order_ids', JSON.stringify(this.selectedOrders));
                                        formData.append('new_status', newStatus);

                                        const response = await fetch(this.apiEndpoint, {
                                            method: 'POST',
                                            body: formData
                                        });

                                        const data = await response.json();

                                        if (data.success) {
                                            this.showToast(data.message, 'success');

                                            const modal = bootstrap.Modal.getInstance(document.getElementById('bulkActionsModal'));
                                            modal.hide();

                                            this.selectedOrders = [];
                                            document.getElementById('selectAll').checked = false;

                                            await this.loadOrders(this.currentPage);
                                        } else {
                                            this.showToast('Error with bulk action: ' + data.message, 'error');
                                        }
                                    } catch (error) {
                                        console.error('Error with bulk action:', error);
                                        this.showToast('Failed to perform bulk action', 'error');
                                    }
                                }

                                

                                renderPagination(pagination) {
                                    const container = document.getElementById('paginationContainer');

                                    if (pagination.total_pages <= 1) {
                                        container.innerHTML = `<div class="d-flex justify-content-between align-items-center p-3">
                    <small class="text-muted">Showing ${pagination.total_count} result${pagination.total_count !== 1 ? 's' : ''}</small>
                </div>`;
                                        return;
                                    }

                                    let html = `
                <div class="d-flex justify-content-between align-items-center p-3">
                    <small class="text-muted">
                        Showing ${(pagination.current_page - 1) * pagination.per_page + 1} - 
                        ${Math.min(pagination.current_page * pagination.per_page, pagination.total_count)} 
                        of ${pagination.total_count} results
                    </small>
                    <nav>
                        <ul class="pagination pagination-sm mb-0">
            `;

                                    html += `
                <li class="page-item ${!pagination.has_prev ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="orderManager.loadOrders(${pagination.current_page - 1})">Previous</a>
                </li>
            `;

                                    const startPage = Math.max(1, pagination.current_page - 2);
                                    const endPage = Math.min(pagination.total_pages, pagination.current_page + 2);

                                    for (let i = startPage; i <= endPage; i++) {
                                        html += `
                    <li class="page-item ${i === pagination.current_page ? 'active' : ''}">
                        <a class="page-link" href="#" onclick="orderManager.loadOrders(${i})">${i}</a>
                    </li>
                `;
                                    }

                                    html += `
                <li class="page-item ${!pagination.has_next ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="orderManager.loadOrders(${pagination.current_page + 1})">Next</a>
                </li>
            </ul>
        </nav>
    </div>
            `;

                                    container.innerHTML = html;
                                }
                            }

    
                            let orderManager;

                            document.addEventListener('DOMContentLoaded', function () {
                                console.log('Initializing Order Management System...');
                                orderManager = new OrderManagement();
                            });

   
                            function searchOrders() {
                                if (orderManager)
                                    orderManager.searchOrders();
                            }
                            function filterOrders() {
                                if (orderManager)
                                    orderManager.filterOrders();
                            }
                            function changePerPage() {
                                if (orderManager)
                                    orderManager.changePerPage();
                            }
                            function clearFilters() {
                                if (orderManager)
                                    orderManager.clearFilters();
                            }
                            function refreshOrders() {
                                if (orderManager)
                                    orderManager.refreshOrders();
                            }
                            function showBulkActions() {
                                if (orderManager)
                                    orderManager.showBulkActions();
                            }
                            function toggleSelectAll() {
                                if (orderManager)
                                    orderManager.toggleSelectAll();
                            }

    
                            function confirmStatusUpdate() {
                                if (orderManager) {
                                    orderManager.confirmStatusUpdate();
                                } else {
                                    console.error('OrderManager not initialized');
                                }
                            }

                            function confirmBulkAction() {
                                if (orderManager) {
                                    orderManager.confirmBulkAction();
                                } else {
                                    console.error('OrderManager not initialized');
                                }
                            }

        </script>
    </body>
</html>