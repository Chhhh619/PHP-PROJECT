<?php

session_start();

require_once '../../model/User.php';
require_once '../../model/Admin.php';
require_once '../../model/UserFactory.php';
require_once '../../database.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

try {
    $db = Database::getInstance()->getConnection();
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);
    
    
    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }
    
    
    if (!$currentAdmin->hasPermission('reports')) {
        $permission_error = "You don't have permission to view reports. Contact your administrator for access.";
    }
    
} catch (Exception $e) {
    error_log("Reports Page Error: " . $e->getMessage());
    $error_message = "Error loading page: " . $e->getMessage();
}

$currentPage = 'reports';
$adminName = isset($currentAdmin) ? $currentAdmin->getAdminName() : 'Admin';

$filters = [
    'start_date' => $_GET['start_date'] ?? date('Y-m-01'),
    'end_date' => $_GET['end_date'] ?? date('Y-m-d'),
    'report_type' => $_GET['report_type'] ?? 'summary',
    'group_by' => $_GET['group_by'] ?? 'day'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - Zuspresso Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="AdminCss/Admincss.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        .chart-container { 
            position: relative; 
            height: 400px; 
            margin: 1rem 0; 
        }
        .small-chart-container { 
            position: relative; 
            height: 250px; 
            margin: 1rem 0; 
        }
        .report-filters { 
            background: #f8f9fa; 
            border-radius: 10px; 
            padding: 1.5rem; 
            margin-bottom: 2rem; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
        }
        .metric-card { 
            background: linear-gradient(135deg, #ffffff, #f8f9fa); 
            border-left: 4px solid #8B4513; 
            border-radius: 8px; 
            padding: 1.5rem; 
            margin-bottom: 1rem; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); 
            transition: transform 0.2s ease; 
        }
        .metric-card:hover { 
            transform: translateY(-2px); 
        }
        .metric-value { 
            font-size: 2rem; 
            font-weight: bold; 
            color: #8B4513; 
        }
        .metric-label { 
            color: #6c757d; 
            font-size: 0.9rem; 
            text-transform: uppercase; 
            font-weight: 600; 
        }
        .metric-growth { 
            font-size: 0.8rem; 
            margin-top: 0.5rem; 
        }
        .growth-positive { color: #28a745; }
        .growth-negative { color: #dc3545; }
        .growth-neutral { color: #6c757d; }
        .report-section { 
            margin-bottom: 2rem; 
            display: none; 
        }
        .table-container { 
            max-height: 400px; 
            overflow-y: auto; 
        }
        .loading-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.5); 
            display: none; 
            justify-content: center; 
            align-items: center; 
            z-index: 9999; 
        }
        .loading-spinner { 
            width: 40px; 
            height: 40px; 
            border: 4px solid #f3f3f3; 
            border-top: 4px solid #8B4513; 
            border-radius: 50%; 
            animation: spin 1s linear infinite; 
        }
        .data-loading {
            text-align: center;
            padding: 2rem;
            color: #666;
        }
        .data-loading .spinner-border {
            color: #8B4513;
        }
        @keyframes spin { 
            0% { transform: rotate(0deg); } 
            100% { transform: rotate(360deg); } 
        }
    </style>
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="admin_dashboard.php">
                <i class="fas fa-coffee"></i> Zuspresso Admin
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> 
                        <?= htmlspecialchars($adminName) ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="admin_dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a></li>
                        <li><a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user"></i> Profile
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="logout()">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    
    <div id="loadingOverlay" class="loading-overlay">
        <div>
            <div class="loading-spinner"></div>
            <div class="text-white mt-3">Loading reports...</div>
        </div>
    </div>
    
    <div class="container-fluid">
        <div class="row">
            
            <nav class="col-md-3 col-lg-2 sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Dashboard
                            </a>
                        </li>
                        
                        <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('user_management')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="user_management.php">
                                <i class="fas fa-users"></i> User Management
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('menu_management')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="menu_management.php">
                                <i class="fas fa-utensils"></i> Menu Management
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('order_management')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="order_management.php">
                                <i class="fas fa-shopping-cart"></i> Orders
                            </a>
                        </li>
                        <?php endif; ?>
                         <li class="nav-item">
                                    <a class="nav-link" href="review_management.php">
                                        <i class="fas fa-star"></i> Reviews
                                    </a>
                                </li>
                        
                        <?php if (isset($currentAdmin) && $currentAdmin->hasPermission('reports')): ?>
                        <li class="nav-item">
                            <a class="nav-link active" href="reports.php">
                                <i class="fas fa-chart-bar"></i> Reports
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="admin_register.php">
                                <i class="fas fa-user-plus"></i> Add Admin
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-chart-bar"></i> Reports & Analytics
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-outline-primary" onclick="refreshReports()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>

                
                <?php if (isset($error_message)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
                </div>
                <?php endif; ?>

                <?php if (isset($permission_error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($permission_error) ?>
                </div>
                <?php else: ?>

                
                <div id="alertContainer"></div>

                
                <div class="report-filters">
                    <form id="filterForm" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Report Type</label>
                            <select name="report_type" class="form-select" onchange="updateReportType()">
                                <?php 
                                $reportTypes = [
                                    'summary' => 'Summary Overview',
                                    'sales' => 'Sales Performance',
                                    'products' => 'Product Analysis',
                                    'trends' => 'Order Trends',
                                    'customers' => 'Customer Analytics'
                                ];
                                foreach ($reportTypes as $value => $label): ?>
                                <option value="<?= $value ?>" <?= $filters['report_type'] === $value ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($label) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Start Date</label>
                            <input type="date" name="start_date" class="form-control" 
                                   value="<?= htmlspecialchars($filters['start_date']) ?>"
                                   max="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">End Date</label>
                            <input type="date" name="end_date" class="form-control" 
                                   value="<?= htmlspecialchars($filters['end_date']) ?>"
                                   max="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Group By</label>
                            <select name="group_by" class="form-select">
                                <?php 
                                $groupOptions = ['day' => 'Daily', 'week' => 'Weekly', 'month' => 'Monthly'];
                                foreach ($groupOptions as $value => $label): ?>
                                <option value="<?= $value ?>" <?= $filters['group_by'] === $value ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($label) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter"></i> Apply Filters
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="resetFilters()">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                        </div>
                    </form>
                </div>

              
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="metric-card">
                            <div class="metric-label">Today's Revenue</div>
                            <div class="metric-value" id="todayRevenue">RM 0.00</div>
                            <div class="metric-growth text-muted">
                                <small id="todayOrders">0 orders today</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="metric-card">
                            <div class="metric-label">This Month's Revenue</div>
                            <div class="metric-value" id="monthRevenue">RM 0.00</div>
                            <div class="metric-growth growth-neutral" id="revenueGrowth">
                                <i class="fas fa-minus"></i> 0% vs last month
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="metric-card">
                            <div class="metric-label">Total Orders</div>
                            <div class="metric-value" id="monthOrders">0</div>
                            <div class="metric-growth growth-neutral" id="ordersGrowth">
                                <i class="fas fa-minus"></i> 0% vs last month
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 mb-3">
                        <div class="metric-card">
                            <div class="metric-label">Avg Order Value</div>
                            <div class="metric-value" id="avgOrderValue">RM 0.00</div>
                            <div class="metric-growth text-muted">
                                <small id="uniqueCustomers">0 unique customers</small>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="report-section" id="salesSection">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-chart-line"></i> Sales Performance</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="report-section" id="productsSection">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-trophy"></i> Best Selling Products</h5>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0" id="productsTable">
                                            <thead>
                                                <tr>
                                                    <th>Rank</th>
                                                    <th>Product</th>
                                                    <th>Category</th>
                                                    <th>Qty Sold</th>
                                                    <th>Revenue</th>
                                                    <th>Orders</th>
                                                    <th>Share</th>
                                                </tr>
                                            </thead>
                                            <tbody id="productsTableBody">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-chart-pie"></i> Revenue Distribution</h6>
                                </div>
                                <div class="card-body">
                                    <div class="small-chart-container">
                                        <canvas id="productRevenueChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="report-section" id="trendsSection">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-clock"></i> Hourly Trends</h6>
                                </div>
                                <div class="card-body">
                                    <div class="small-chart-container">
                                        <canvas id="hourlyTrendsChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-calendar-week"></i> Daily Trends</h6>
                                </div>
                                <div class="card-body">
                                    <div class="small-chart-container">
                                        <canvas id="dailyTrendsChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="data-loading" id="dataLoading">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Loading report data...</p>
                </div>


                <div class="text-center py-5" id="noDataMessage" style="display: none;">
                    <i class="fas fa-chart-bar text-muted" style="font-size: 4rem;"></i>
                    <h4 class="text-muted mt-3">No Data Available</h4>
                    <p class="text-muted">Try adjusting your date range or filters.</p>
                </div>

                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        
        Chart.defaults.font.family = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
        Chart.defaults.color = '#333';
        
        
        const colors = {
            primary: '#8B4513',
            secondary: '#D4AF37', 
            success: '#28a745',
            danger: '#dc3545',
            warning: '#ffc107',
            info: '#17a2b8'
        };

   
        let salesChart = null;
        let productChart = null;
        let hourlyChart = null;
        let dailyChart = null;


        document.addEventListener('DOMContentLoaded', function() {
            console.log('Page loaded, loading data...');
            loadDashboardData();
            loadReportData();
        });


        function loadDashboardData() {
            console.log('Loading dashboard data...');
            
            const formData = new FormData();
            formData.append('action', 'dashboard_summary');
            
            fetch('../../controller/ReportsController.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Dashboard data received:', data);
                if (data.success) {
                    updateDashboardCards(data.data);
                } else {
                    console.error('Dashboard error:', data.error);
                    showAlert('Dashboard error: ' + data.error, 'danger');
                }
            })
            .catch(error => {
                console.error('Dashboard loading error:', error);
                showAlert('Failed to load dashboard data: ' + error.message, 'danger');
            });
        }


        function loadReportData() {
            console.log('Loading report data...');
            
            const reportType = document.querySelector('select[name="report_type"]').value || 'summary';
            const startDate = document.querySelector('input[name="start_date"]').value;
            const endDate = document.querySelector('input[name="end_date"]').value;
            const groupBy = document.querySelector('select[name="group_by"]').value;
            
            const formData = new FormData();
            formData.append('action', 'get_report_data');
            formData.append('report_type', reportType);
            formData.append('start_date', startDate);
            formData.append('end_date', endDate);
            formData.append('group_by', groupBy);
            

            document.getElementById('dataLoading').style.display = 'block';
            hideAllReportSections();
            
            fetch('../../controller/ReportsController.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Report data received:', data);
                document.getElementById('dataLoading').style.display = 'none';
                
                if (data.success) {
                    displayReportData(data.data);
                } else {
                    console.error('Report error:', data.error);
                    showAlert('Report error: ' + data.error, 'danger');
                    showNoDataMessage();
                }
            })
            .catch(error => {
                document.getElementById('dataLoading').style.display = 'none';
                console.error('Report loading error:', error);
                showAlert('Failed to load report data: ' + error.message, 'danger');
                showNoDataMessage();
            });
        }


        function updateDashboardCards(data) {
            console.log('Updating dashboard cards with:', data);
            
            if (data.today) {
                document.getElementById('todayRevenue').textContent = 
                    'RM ' + parseFloat(data.today.total_revenue || 0).toFixed(2);
                document.getElementById('todayOrders').textContent = 
                    (data.today.total_orders || 0) + ' orders today';
            }
            
            if (data.this_month) {
                document.getElementById('monthRevenue').textContent = 
                    'RM ' + parseFloat(data.this_month.total_revenue || 0).toFixed(2);
                document.getElementById('monthOrders').textContent = 
                    data.this_month.total_orders || 0;
                document.getElementById('avgOrderValue').textContent = 
                    'RM ' + parseFloat(data.this_month.avg_order_value || 0).toFixed(2);
                document.getElementById('uniqueCustomers').textContent = 
                    (data.this_month.unique_customers || 0) + ' unique customers';
            }
            

            if (data.growth) {
                updateGrowthIndicator('revenueGrowth', data.growth.revenue || 0);
                updateGrowthIndicator('ordersGrowth', data.growth.orders || 0);
            }
        }

        function updateGrowthIndicator(elementId, growth) {
            const element = document.getElementById(elementId);
            const absGrowth = Math.abs(growth);
            
            element.className = 'metric-growth growth-' + (growth > 0 ? 'positive' : growth < 0 ? 'negative' : 'neutral');
            
            const icon = growth > 0 ? 'arrow-up' : growth < 0 ? 'arrow-down' : 'minus';
            element.innerHTML = `<i class="fas fa-${icon}"></i> ${absGrowth}% vs last month`;
        }

       
        function displayReportData(data) {
            console.log('Displaying report data:', data);
            let hasData = false;
            
          
            if (data.salesReport && data.salesReport.length > 0) {
                console.log('Creating sales chart');
                createSalesChart(data.salesReport);
                document.getElementById('salesSection').style.display = 'block';
                hasData = true;
            }
            
          
            if (data.bestSellingProducts && data.bestSellingProducts.length > 0) {
                console.log('Creating products table');
                createProductsTable(data.bestSellingProducts);
                createProductChart(data.bestSellingProducts);
                document.getElementById('productsSection').style.display = 'block';
                hasData = true;
            }
            

            if (data.orderTrends) {
                let trendsHasData = false;
                if (data.orderTrends.hourly_trends && data.orderTrends.hourly_trends.length > 0) {
                    createHourlyChart(data.orderTrends.hourly_trends);
                    trendsHasData = true;
                }
                if (data.orderTrends.daily_trends && data.orderTrends.daily_trends.length > 0) {
                    createDailyChart(data.orderTrends.daily_trends);
                    trendsHasData = true;
                }
                if (trendsHasData) {
                    document.getElementById('trendsSection').style.display = 'block';
                    hasData = true;
                }
            }
            

            if (!hasData) {
                console.log('No data available');
                showNoDataMessage();
            } else {
                document.getElementById('noDataMessage').style.display = 'none';
            }
        }

        function hideAllReportSections() {
            document.getElementById('salesSection').style.display = 'none';
            document.getElementById('productsSection').style.display = 'none';
            document.getElementById('trendsSection').style.display = 'none';
            document.getElementById('noDataMessage').style.display = 'none';
        }

        function showNoDataMessage() {
            hideAllReportSections();
            document.getElementById('noDataMessage').style.display = 'block';
        }


        function createSalesChart(salesData) {
            const canvas = document.getElementById('salesChart');
            if (!canvas) return;
            
            if (salesChart) {
                salesChart.destroy();
            }
            
            const ctx = canvas.getContext('2d');
            
            salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: salesData.map(item => item.period),
                    datasets: [{
                        label: 'Revenue (RM)',
                        data: salesData.map(item => parseFloat(item.total_revenue)),
                        borderColor: colors.primary,
                        backgroundColor: colors.primary + '20',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }, {
                        label: 'Orders',
                        data: salesData.map(item => parseInt(item.total_orders)),
                        borderColor: colors.secondary,
                        backgroundColor: colors.secondary + '20',
                        borderWidth: 2,
                        yAxisID: 'y1'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: { display: true, text: 'Revenue (RM)' }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            title: { display: true, text: 'Orders' },
                            grid: { drawOnChartArea: false }
                        }
                    }
                }
            });
        }


        function createProductsTable(products) {
            const tbody = document.getElementById('productsTableBody');
            if (!tbody) return;
            
            tbody.innerHTML = products.map((product, index) => `
                <tr>
                    <td><span class="badge bg-warning text-dark">${index + 1}</span></td>
                    <td><strong>${escapeHtml(product.product_name)}</strong></td>
                    <td><span class="badge bg-secondary">${escapeHtml(product.category.charAt(0).toUpperCase() + product.category.slice(1))}</span></td>
                    <td>${parseInt(product.total_quantity_sold).toLocaleString()}</td>
                    <td>RM ${parseFloat(product.total_revenue).toFixed(2)}</td>
                    <td>${parseInt(product.total_orders).toLocaleString()}</td>
                    <td>${parseFloat(product.revenue_percentage || 0).toFixed(1)}%</td>
                </tr>
            `).join('');
        }


        function createProductChart(products) {
            const canvas = document.getElementById('productRevenueChart');
            if (!canvas) return;
            
            if (productChart) {
                productChart.destroy();
            }
            
            const ctx = canvas.getContext('2d');
            const topProducts = products.slice(0, 6);
            
            productChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: topProducts.map(item => item.product_name),
                    datasets: [{
                        data: topProducts.map(item => parseFloat(item.total_revenue)),
                        backgroundColor: [colors.primary, colors.secondary, colors.success, colors.danger, colors.warning, colors.info],
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom', labels: { padding: 15, usePointStyle: true } }
                    }
                }
            });
        }

  
        function createHourlyChart(hourlyData) {
            const canvas = document.getElementById('hourlyTrendsChart');
            if (!canvas) return;
            
            if (hourlyChart) {
                hourlyChart.destroy();
            }
            
            const ctx = canvas.getContext('2d');
            
            hourlyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: hourlyData.map(item => item.hour + ':00'),
                    datasets: [{
                        label: 'Orders',
                        data: hourlyData.map(item => parseInt(item.order_count)),
                        backgroundColor: colors.primary + '80',
                        borderColor: colors.primary,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: { display: true, text: 'Number of Orders' }
                        }
                    }
                }
            });
        }


        function createDailyChart(dailyData) {
            const canvas = document.getElementById('dailyTrendsChart');
            if (!canvas) return;
            
            if (dailyChart) {
                dailyChart.destroy();
            }
            
            const ctx = canvas.getContext('2d');
            
            dailyChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: dailyData.map(item => item.day_name),
                    datasets: [{
                        label: 'Orders',
                        data: dailyData.map(item => parseInt(item.order_count)),
                        backgroundColor: colors.secondary + '80',
                        borderColor: colors.secondary,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: { display: true, text: 'Number of Orders' }
                        }
                    }
                }
            });
        }


        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }

        function updateReportType() {
            loadReportData();
        }

        function resetFilters() {
            document.querySelector('select[name="report_type"]').value = 'summary';
            document.querySelector('input[name="start_date"]').value = '<?= date('Y-m-01') ?>';
            document.querySelector('input[name="end_date"]').value = '<?= date('Y-m-d') ?>';
            document.querySelector('select[name="group_by"]').value = 'day';
            loadReportData();
        }

        function refreshReports() {
            console.log('Refreshing reports...');
            loadDashboardData();
            loadReportData();
        }

        function showLoading(message = 'Processing...') {
            const overlay = document.getElementById('loadingOverlay');
            overlay.style.display = 'flex';
            if (message !== 'Processing...') {
                overlay.querySelector('.text-white').textContent = message;
            }
        }

        function hideLoading() {
            document.getElementById('loadingOverlay').style.display = 'none';
        }

        function showAlert(message, type = 'info') {
            const alertContainer = document.getElementById('alertContainer');
            const alertHTML = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : 'exclamation-circle'}"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            `;
            alertContainer.innerHTML = alertHTML;
            
            // Auto-hide success alerts
            if (type === 'success') {
                setTimeout(() => {
                    const alert = alertContainer.querySelector('.alert');
                    if (alert) {
                        const bootstrapAlert = new bootstrap.Alert(alert);
                        bootstrapAlert.close();
                    }
                }, 5000);
            }
        }

 
        document.getElementById('filterForm').addEventListener('submit', function(e) {
            e.preventDefault();
            loadReportData();
        });


        document.querySelector('input[name="start_date"]').addEventListener('change', function() {
            const startDate = new Date(this.value);
            const endDateInput = document.querySelector('input[name="end_date"]');
            const endDate = new Date(endDateInput.value);
            
            if (startDate > endDate) {
                endDateInput.value = this.value;
            }
        });

       
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '../../controller/AuthController.php';

                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'logout';
                form.appendChild(actionInput);

                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>