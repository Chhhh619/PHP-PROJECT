<?php

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}


try {
    require_once '../../model/User.php';
    require_once '../../model/Admin.php';
    require_once '../../model/UserFactory.php';
    require_once '../../database.php';

    $db = Database::getInstance()->getConnection();
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);

    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        session_destroy();
        header('Location: ../auth/login.php');
        exit();
    }

    if (!$currentAdmin->hasPermission('user_management')) {
        header('Location: admin_dashboard.php');
        exit();
    }
} catch (Exception $e) {
    error_log("User Management Page Error: " . $e->getMessage());
    $error_message = "Error loading page. Please try again.";
}

$currentPage = 'user_management';


$stats = [
    'total_users' => 0,
    'customers' => 0,
    'admins' => 0,
    'recent_registrations' => 0
];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User Management - Zuspresso Admin</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {
                --zus-brown: #8B4513;
                --zus-cream: #F5F5DC;
                --zus-dark-brown: #654321;
                --zus-gold: #D4AF37;
            }

            body {
                background: linear-gradient(135deg, #f8f9fa, var(--zus-cream));
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            .navbar {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }

            .sidebar {
                background: linear-gradient(180deg, var(--zus-cream), #ffffff);
                min-height: calc(100vh - 56px);
                border-right: 1px solid rgba(139, 69, 19, 0.1);
            }

            .sidebar .nav-link {
                color: var(--zus-dark-brown);
                border-radius: 8px;
                margin: 5px 10px;
                padding: 10px 15px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .sidebar .nav-link:hover, .sidebar .nav-link.active {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                transform: translateX(5px);
            }

            .sidebar .nav-link i {
                margin-right: 10px;
                width: 20px;
                text-align: center;
            }

            .welcome-card {
                background: linear-gradient(135deg, var(--zus-gold), #f4d03f);
                color: var(--zus-dark-brown);
                border-radius: 12px;
                padding: 2rem;
                margin-bottom: 2rem;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            }

            .stats-card {
                background: linear-gradient(135deg, #ffffff, var(--zus-cream));
                border-left: 4px solid var(--zus-brown);
                border-radius: 12px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                overflow: hidden;
            }

            .stats-card:hover {
                transform: translateY(-3px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
            }

            .stats-icon {
                font-size: 2.5rem;
                color: var(--zus-brown);
                opacity: 0.8;
            }

            .stats-number {
                font-size: 2rem;
                font-weight: bold;
                color: var(--zus-dark-brown);
            }

            .card {
                border: none;
                border-radius: 12px;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                overflow: hidden;
            }

            .card-header {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                padding: 1.5rem;
            }

            .btn-zus {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .btn-zus:hover {
                background: linear-gradient(135deg, var(--zus-dark-brown), var(--zus-brown));
                color: white;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            }

            .action-buttons .btn {
                margin: 1px;
                padding: 6px 10px;
                font-size: 0.75rem;
            }

            .btn-xs {
                padding: 0.25rem 0.5rem;
                font-size: 0.75rem;
                line-height: 1.2;
            }

            .search-filters {
                background: var(--zus-cream);
                border-radius: 12px;
                padding: 1.5rem;
                margin-bottom: 1.5rem;
            }

            .badge-role {
                font-size: 0.8rem;
                padding: 0.4rem 0.8rem;
                border-radius: 15px;
            }

            .badge-admin {
                background: linear-gradient(135deg, var(--zus-brown), var(--zus-dark-brown));
            }

            .badge-customer {
                background: linear-gradient(135deg, #28a745, #20c997);
            }

            .table thead th {
                background: var(--zus-cream);
                color: var(--zus-dark-brown);
                font-weight: 600;
                border: none;
                padding: 1rem 0.75rem;
            }

            .table tbody tr {
                border-bottom: 1px solid #f0f0f0;
                transition: background-color 0.3s ease;
            }

            .table tbody tr:hover {
                background-color: #f8f9fa;
            }

            .table tbody td {
                padding: 1rem 0.75rem;
                vertical-align: middle;
            }

            .form-control, .form-select {
                border-radius: 8px;
                border: 2px solid #e9ecef;
                padding: 12px 16px;
                transition: all 0.3s ease;
            }

            .form-control:focus, .form-select:focus {
                border-color: var(--zus-brown);
                box-shadow: 0 0 0 0.2rem rgba(139, 69, 19, 0.25);
            }

            .alert {
                border-radius: 8px;
                border: none;
            }

            .alert-floating {
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1050;
                min-width: 300px;
            }

            .loading-spinner {
                text-align: center;
                padding: 2rem;
            }

            .no-users-found {
                text-align: center;
                padding: 3rem;
                color: #6c757d;
            }

            
            .order-summary {
                min-height: 40px;
                display: flex;
                align-items: center;
                font-size: 0.85rem;
            }

            .order-quick-stats {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }

            .order-quick-stats .stat-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 0.75rem;
            }

            
            .tab-content {
                min-height: 300px;
            }

            .nav-tabs .nav-link {
                color: var(--zus-dark-brown);
                border-color: transparent;
            }

            .nav-tabs .nav-link.active {
                background-color: var(--zus-brown);
                color: white;
                border-color: var(--zus-brown);
            }

         
            .permission-group {
                background: #f8f9fa;
                border-radius: 8px;
                padding: 1rem;
                margin-bottom: 1rem;
            }

            .permission-item {
                padding: 0.75rem;
                border: 1px solid #e9ecef;
                border-radius: 6px;
                margin-bottom: 0.5rem;
                transition: all 0.3s ease;
            }

            .permission-item:hover {
                background-color: #f8f9fa;
            }

            .permission-item.selected {
                background-color: rgba(139, 69, 19, 0.1);
                border-color: var(--zus-brown);
            }

            .permission-icon {
                width: 20px;
                text-align: center;
                margin-right: 8px;
            }

           
            .status-pending { background-color: #ffc107; }
            .status-confirmed { background-color: #17a2b8; }
            .status-preparing { background-color: #007bff; }
            .status-ready { background-color: #28a745; }
            .status-delivered { background-color: #28a745; }
            .status-completed { background-color: #28a745; }
            .status-cancelled { background-color: #dc3545; }

           
            .analytics-card {
                background: linear-gradient(135deg, #ffffff, #f8f9fa);
                border: 1px solid #e9ecef;
                border-radius: 8px;
                text-align: center;
                padding: 1rem;
                height: 100%;
            }

            .analytics-card h4 {
                margin-bottom: 0.5rem;
                font-weight: bold;
            }

            .analytics-card small {
                color: #6c757d;
                font-size: 0.8rem;
            }
        </style>
    </head>
    <body>
        
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand fw-bold" href="admin_dashboard.php">
                    <i class="fas fa-coffee"></i> Zuspresso Admin
                </a>
                <div class="navbar-nav ms-auto">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> 
                            <?= htmlspecialchars($currentAdmin->getAdminName()) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a></li>

                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" onclick="logout()">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <nav class="col-md-3 col-lg-2 sidebar">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link" href="admin_dashboard.php">
                                    <i class="fas fa-tachometer-alt"></i> Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link active" href="user_management.php">
                                    <i class="fas fa-users"></i> User Management
                                </a>
                            </li>

                            <?php if ($currentAdmin->hasPermission('menu_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="menu_management.php">
                                        <i class="fas fa-utensils"></i> Menu Management
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if ($currentAdmin->hasPermission('order_management')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="order_management.php">
                                        <i class="fas fa-shopping-cart"></i> Orders
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link" href="review_management.php">
                                    <i class="fas fa-star"></i> Reviews
                                </a>
                            </li>

                            <?php if ($currentAdmin->hasPermission('reports')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="reports.php">
                                        <i class="fas fa-chart-bar"></i> Reports
                                    </a>
                                </li>
                            <?php endif; ?>

                            <li class="nav-item">
                                <a class="nav-link" href="admin_register.php">
                                    <i class="fas fa-user-plus"></i> Add Admin
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>

                
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    
                    <div id="alertContainer"></div>

                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger mt-4">
                            <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
                        </div>
                    <?php endif; ?>

                    
                    <div class="welcome-card mt-4">
                        <h1 class="h2 mb-0">
                            <i class="fas fa-users"></i> User Management
                        </h1>
                        <p class="mb-0 mt-2">Manage users, admin roles, and monitor system activity including order history.</p>
                    </div>


                    <div class="d-flex justify-content-between mb-4">
                        <div></div>
                        <div class="btn-toolbar">
                            <button class="btn btn-secondary me-2" onclick="refreshData()">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                            <a href="admin_register.php" class="btn btn-outline-secondary">
                                <i class="fas fa-user-plus"></i> Add Admin
                            </a>
                        </div>
                    </div>

                    
                    <div class="row mb-4">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card h-100">
                                <div class="card-body d-flex align-items-center">
                                    <div class="me-3">
                                        <i class="fas fa-users stats-icon"></i>
                                    </div>
                                    <div>
                                        <div class="stats-number" id="totalUsers">-</div>
                                        <div class="text-muted">Total Users</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card h-100">
                                <div class="card-body d-flex align-items-center">
                                    <div class="me-3">
                                        <i class="fas fa-user-friends stats-icon"></i>
                                    </div>
                                    <div>
                                        <div class="stats-number" id="totalCustomers">-</div>
                                        <div class="text-muted">Customers</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card h-100">
                                <div class="card-body d-flex align-items-center">
                                    <div class="me-3">
                                        <i class="fas fa-user-shield stats-icon"></i>
                                    </div>
                                    <div>
                                        <div class="stats-number" id="totalAdmins">-</div>
                                        <div class="text-muted">Admins</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card h-100">
                                <div class="card-body d-flex align-items-center">
                                    <div class="me-3">
                                        <i class="fas fa-user-plus stats-icon"></i>
                                    </div>
                                    <div>
                                        <div class="stats-number" id="newUsers">-</div>
                                        <div class="text-muted">New (30 days)</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="search-filters">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-search"></i> Search Users
                                </label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="searchInput" 
                                           placeholder="Search by email or name..." onkeyup="debounceSearch()">
                                    <button class="btn btn-outline-secondary" type="button" onclick="clearSearch()">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-filter"></i> Filter by Role
                                </label>
                                <select class="form-select" id="roleFilter" onchange="applyFilters()">
                                    <option value="all">All Users</option>
                                    <option value="customer">Customers</option>
                                    <option value="admin">Admins</option>
                                </select>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">
                                    <i class="fas fa-toggle-on"></i> Filter by Status
                                </label>
                                <select class="form-select" id="statusFilter" onchange="applyFilters()">
                                    <option value="all">All Status</option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label class="form-label">&nbsp;</label>
                                <div>
                                    <button class="btn btn-secondary w-100" onclick="resetFilters()">
                                        <i class="fas fa-undo"></i> Reset
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

              
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-table"></i> Users
                            </h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0" id="usersTable">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Orders</th>
                                            <th>Registration</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="usersTableBody">
                                        <tr>
                                            <td colspan="6" class="loading-spinner">
                                                <div class="spinner-border text-primary" role="status">
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                                <p class="mt-2">Loading users...</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

   
        <div class="modal fade" id="userDetailsModal" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-user-circle"></i> User Details
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body" id="userDetailsBody">

                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="editUserModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-edit"></i> Edit User
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <form id="editUserForm">
                        <div class="modal-body">
                            <input type="hidden" id="editUserId" name="user_id">

                            <div class="mb-3">
                                <label class="form-label">
                                    <i class="fas fa-envelope"></i> Email
                                </label>
                                <input type="email" class="form-control" id="editUserEmail" name="email" required>
                            </div>

                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="editUserActive" name="is_active">
                                <label class="form-check-label" for="editUserActive">
                                    <i class="fas fa-toggle-on"></i> Account Active
                                </label>
                            </div>

                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Note:</strong> Changes take effect immediately.
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-zus">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
        <script>
            
            let searchTimeout;
            let currentUsers = [];
            let currentAdminId = <?= $currentAdmin->getUserId() ?>;

            
            document.addEventListener('DOMContentLoaded', function () {
                loadUsers();
                refreshStats();
            });

            
            function debounceSearch() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(function () {
                    applyFilters();
                }, 500);
            }

            function clearSearch() {
                document.getElementById('searchInput').value = '';
                applyFilters();
            }

            
            function applyFilters() {
                const searchTerm = document.getElementById('searchInput').value.toLowerCase();
                const roleFilter = document.getElementById('roleFilter').value;
                const statusFilter = document.getElementById('statusFilter').value;

                filterTable(searchTerm, roleFilter, statusFilter);
            }


            function filterTable(searchTerm = '', roleFilter = 'all', statusFilter = 'all') {
                const rows = document.querySelectorAll('#usersTableBody tr[data-user-id]');
                let visibleCount = 0;

                rows.forEach(row => {
                    const email = row.cells[1].textContent.toLowerCase();
                    const name = row.cells[0].textContent.toLowerCase();
                    const role = row.dataset.role;
                    const status = row.dataset.status;

                    const matchesSearch = searchTerm === '' ||
                            email.includes(searchTerm) ||
                            name.includes(searchTerm);
                    const matchesRole = roleFilter === 'all' || role === roleFilter;
                    const matchesStatus = statusFilter === 'all' || status === statusFilter;

                    if (matchesSearch && matchesRole && matchesStatus) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });


                if (visibleCount === 0 && rows.length > 0) {
                    showNoResultsMessage();
                } else {
                    hideNoResultsMessage();
                }
            }

            function resetFilters() {
                document.getElementById('searchInput').value = '';
                document.getElementById('roleFilter').value = 'all';
                document.getElementById('statusFilter').value = 'all';
                filterTable();
            }

            
            function loadUsers() {
                const url = '../../controller/UserController.php?action=list&ajax=1';

                fetch(url)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                            }
                            return response.text();
                        })
                        .then(text => {
                            try {
                                const data = JSON.parse(text);

                                if (data.success) {
                                    updateUsersTable(data.users || []);
                                    if (data.stats) {
                                        updateStats(data.stats);
                                    }
                                    currentUsers = data.users || [];
                                } else {
                                    showAlert('Error loading users: ' + data.message, 'danger');
                                    showEmptyTable();
                                }
                            } catch (parseError) {
                                showAlert('Error parsing response', 'danger');
                                showEmptyTable();
                            }
                        })
                        .catch(error => {
                            showAlert('Error: ' + error.message, 'danger');
                            showEmptyTable();
                        });
            }

         
            function updateUsersTable(users) {
                const tbody = document.getElementById('usersTableBody');

                if (!users || users.length === 0) {
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="6" class="no-users-found">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <p>No users found</p>
                            </td>
                        </tr>
                    `;
                    return;
                }

                tbody.innerHTML = users.map(user => {
                    return `
                        <tr data-user-id="${user.user_id}" 
                            data-role="${user.role}" 
                            data-status="${user.is_active ? 'active' : 'inactive'}">
                            <td>
                                <strong>${escapeHtml(user.full_name || user.display_name || 'N/A')}</strong>
                                ${user.role === 'admin' ? `<br><small class="text-muted"><i class="fas fa-user-shield"></i> Admin: ${escapeHtml(user.admin_name || 'N/A')}</small>` : ''}
                                ${user.loyalty_points !== null && user.loyalty_points !== undefined ? `<br><small class="text-muted"><i class="fas fa-coins"></i> ${parseInt(user.loyalty_points).toLocaleString()} points</small>` : ''}
                            </td>
                            <td>${escapeHtml(user.email)}</td>
                            <td>
                                <span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-customer'} badge-role">
                                    <i class="fas ${user.role === 'admin' ? 'fa-user-shield' : 'fa-user'}"></i>
                                    ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                                </span>
                            </td>
                            <td>
                                ${user.role === 'customer' ? `
                                <div id="orderSummary-${user.user_id}" class="order-summary">
                                    <div class="spinner-border spinner-border-sm text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </div>
                                ` : '<small class="text-muted">N/A</small>'}
                            </td>
                            <td>
                                <small>${new Date(user.created_at).toLocaleDateString('en-US', {month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'})}</small>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-sm btn-info" onclick="viewUser(${user.user_id})" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                
                                    ${user.role === 'admin' ? `
                                    <button class="btn btn-sm btn-primary" onclick="editAdminRole(${user.user_id})" title="Edit Admin Role & Permissions">
                                        <i class="fas fa-user-shield"></i>
                                    </button>
                                    ` : ''}
                                    
                                    ${user.role === 'customer' ? `
                                    <button class="btn btn-sm btn-success" onclick="viewUserOrders(${user.user_id})" title="View Orders">
                                        <i class="fas fa-shopping-cart"></i>
                                    </button>
                                    ` : ''}
                                
                                    <button class="btn btn-sm btn-warning" onclick="editUser(${user.user_id})" title="Edit Basic Info">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                
                                    <button class="btn btn-sm ${user.is_active ? 'btn-secondary' : 'btn-success'}" 
                                            onclick="toggleUserStatus(${user.user_id}, '${user.is_active ? 'deactivate' : 'activate'}')"
                                            title="${user.is_active ? 'Deactivate' : 'Activate'}">
                                        <i class="fas ${user.is_active ? 'fa-user-slash' : 'fa-user-check'}"></i>
                                    </button>
                                
                                    ${user.user_id != currentAdminId ? `
                                    <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.user_id}, '${escapeHtml(user.email)}')" title="Delete User">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    ` : ''}
                                </div>
                            </td>
                        </tr>
                    `;
                }).join('');

  
                users.forEach(user => {
                    if (user.role === 'customer') {
                        loadOrderSummary(user.user_id);
                    }
                });
            }


            function loadOrderSummary(userId) {
                const summaryElement = document.getElementById(`orderSummary-${userId}`);
                if (!summaryElement) return;

                fetch(`../../service/OrderManagmentService.php?action=getUserOrders&user_id=${userId}&limit=1`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            const orderData = data.data;
                            if (orderData.total_count > 0) {
                                summaryElement.innerHTML = `
                                    <div class="order-quick-stats">
                                        <div class="stat-item">
                                            <span class="text-primary fw-bold">${orderData.total_count} orders</span>
                                            <button class="btn btn-xs btn-outline-primary ms-2" onclick="viewUserOrders(${userId})" title="View Orders">
                                                <i class="fas fa-shopping-cart"></i>
                                            </button>
                                        </div>
                                        <div class="stat-item">
                                            <small class="text-success">$${orderData.total_amount_spent.toFixed(2)} total</small>
                                        </div>
                                    </div>
                                `;
                            } else {
                                summaryElement.innerHTML = '<small class="text-muted">No orders</small>';
                            }
                        } else {
                            summaryElement.innerHTML = '<small class="text-muted text-warning">Error loading</small>';
                        }
                    })
                    .catch(error => {
                        summaryElement.innerHTML = '<small class="text-muted text-danger">Failed</small>';
                    });
            }

            
            function viewUser(userId) {

                const modal = new bootstrap.Modal(document.getElementById('userDetailsModal'));
                document.getElementById('userDetailsBody').innerHTML = `
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="mt-2">Loading user details...</p>
                    </div>
                `;
                modal.show();


                Promise.all([
                    fetch(`../../controller/UserController.php?action=view&id=${userId}&ajax=1`),
                    fetch(`../../service/OrderManagmentService.php?action=getUserOrders&user_id=${userId}&limit=5&include_details=true`)
                ])
                .then(responses => Promise.all(responses.map(r => r.json())))
                .then(([userData, orderData]) => {
                    if (userData.success) {
                        showEnhancedUserDetails(userData.user, orderData);
                    } else {
                        showAlert('Error loading user: ' + userData.message, 'danger');
                    }
                })
                .catch(error => {
                    showAlert('Error: ' + error.message, 'danger');
                    document.getElementById('userDetailsBody').innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> Failed to load user details
                        </div>
                    `;
                });
            }

            
            function showEnhancedUserDetails(user, orderData) {
                const orders = orderData.success ? orderData.data.orders : [];
                const totalSpent = orderData.success ? orderData.data.total_amount_spent : 0;
                const orderCount = orderData.success ? orderData.data.total_count : 0;

                const body = document.getElementById('userDetailsBody');
                body.innerHTML = `
                    <!-- User Tabs -->
                    <ul class="nav nav-tabs" id="userDetailsTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" 
                                    data-bs-target="#profile" type="button" role="tab">
                                <i class="fas fa-user"></i> Profile
                            </button>
                        </li>
                        ${user.role === 'customer' ? `
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="orders-tab" data-bs-toggle="tab" 
                                    data-bs-target="#orders" type="button" role="tab">
                                <i class="fas fa-shopping-cart"></i> Orders (${orderCount})
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="analytics-tab" data-bs-toggle="tab" 
                                    data-bs-target="#analytics" type="button" role="tab">
                                <i class="fas fa-chart-bar"></i> Analytics
                            </button>
                        </li>
                        ` : ''}
                    </ul>

                    <!-- Tab Content -->
                    <div class="tab-content mt-3" id="userDetailsTabsContent">
                        <!-- Profile Tab -->
                        <div class="tab-pane fade show active" id="profile" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6><i class="fas fa-envelope"></i> Contact Info</h6>
                                    <p><strong>Email:</strong> ${escapeHtml(user.email)}</p>
                                    <p><strong>Phone:</strong> ${escapeHtml(user.phone || 'N/A')}</p>
                                    <p><strong>Role:</strong> ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}</p>
                                    <p><strong>Status:</strong> <span class="badge ${user.is_active ? 'bg-success' : 'bg-danger'}">${user.is_active ? 'Active' : 'Inactive'}</span></p>
                                    ${user.role === 'admin' ? `<p><strong>Admin Name:</strong> ${escapeHtml(user.admin_name || 'N/A')}</p>` : ''}
                                </div>
                                <div class="col-md-6">
                                    <h6><i class="fas fa-info-circle"></i> Account Details</h6>
                                    <p><strong>Registration:</strong> ${new Date(user.created_at).toLocaleDateString()}</p>
                                    ${user.first_name ? `<p><strong>Name:</strong> ${escapeHtml(user.first_name)} ${escapeHtml(user.last_name || '')}</p>` : ''}
                                    ${user.loyalty_points !== null ? `<p><strong>Loyalty Points:</strong> ${parseInt(user.loyalty_points).toLocaleString()}</p>` : ''}
                                    ${user.last_login ? `<p><strong>Last Login:</strong> ${new Date(user.last_login).toLocaleDateString()}</p>` : ''}
                                    ${user.date_of_birth ? `<p><strong>DOB:</strong> ${new Date(user.date_of_birth).toLocaleDateString()}</p>` : ''}
                                    ${user.role === 'admin' && user.permissions ? `
                                    <div class="mt-3">
                                        <h6><i class="fas fa-key"></i> Admin Permissions</h6>
                                        ${formatPermissions(user.permissions)}
                                    </div>
                                    ` : ''}
                                </div>
                            </div>
                        </div>

                        ${user.role === 'customer' ? `
                        <!-- Orders Tab -->
                        <div class="tab-pane fade" id="orders" role="tabpanel">
                            <div class="row mb-3">
                                <div class="col-md-3">
                                    <div class="analytics-card bg-primary text-white">
                                        <h4>${orderCount}</h4>
                                        <small>Total Orders</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="analytics-card bg-success text-white">
                                        <h4>$${totalSpent.toFixed(2)}</h4>
                                        <small>Total Spent</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="analytics-card bg-info text-white">
                                        <h4>$${orderCount > 0 ? (totalSpent / orderCount).toFixed(2) : '0.00'}</h4>
                                        <small>Avg Order Value</small>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="analytics-card bg-warning text-white">
                                        <h4>${orders.filter(o => o.order_status === 'delivered' || o.order_status === 'completed').length}</h4>
                                        <small>Completed</small>
                                    </div>
                                </div>
                            </div>

                            ${orders.length > 0 ? `
                            <h6><i class="fas fa-shopping-cart"></i> Recent Orders</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${orders.map(order => `
                                            <tr>
                                                <td><strong>#${order.order_id}</strong></td>
                                                <td>${order.formatted_date}</td>
                                                <td>$${parseFloat(order.total_amount).toFixed(2)}</td>
                                                <td><span class="badge ${getOrderStatusClass(order.order_status)}">${order.status_formatted}</span></td>
                                                <td><span class="badge bg-secondary">${order.order_type}</span></td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                            ${orderCount > 5 ? `
                            <div class="text-center mt-3">
                                <button class="btn btn-outline-primary btn-sm" onclick="viewUserOrders(${user.user_id})">
                                    <i class="fas fa-list"></i> View All Orders (${orderCount})
                                </button>
                            </div>
                            ` : ''}
                            ` : `
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-shopping-cart fa-3x mb-3"></i>
                                <p>No orders found for this customer</p>
                            </div>
                            `}
                        </div>

                        <!-- Analytics Tab -->
                        <div class="tab-pane fade" id="analytics" role="tabpanel">
                            <div id="analyticsContent">
                                <div class="text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading analytics...</span>
                                    </div>
                                    <p class="mt-2">Loading customer analytics...</p>
                                </div>
                            </div>
                        </div>
                        ` : ''}
                    </div>
                `;

                
                if (user.role === 'customer') {
                    document.getElementById('analytics-tab').addEventListener('shown.bs.tab', function() {
                        loadCustomerAnalytics(user.user_id);
                    });
                }
            }


            function loadCustomerAnalytics(userId) {
                const analyticsContent = document.getElementById('analyticsContent');
                
                fetch(`../../service/OrderManagmentService.php?action=getCustomerAnalytics&customer_id=${userId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            displayCustomerAnalytics(data.data);
                        } else {
                            analyticsContent.innerHTML = `
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle"></i> 
                                    Unable to load analytics: ${data.error?.message || 'Unknown error'}
                                </div>
                            `;
                        }
                    })
                    .catch(error => {
                        analyticsContent.innerHTML = `
                            <div class="alert alert-danger">
                                <i class="fas fa-times-circle"></i> 
                                Error loading analytics: ${error.message}
                            </div>
                        `;
                    });
            }

            
            function displayCustomerAnalytics(analytics) {
                const analyticsContent = document.getElementById('analyticsContent');
                
                const frequencyColors = {
                    'frequent': 'success',
                    'regular': 'primary', 
                    'occasional': 'warning',
                    'no_orders': 'secondary'
                };
                
                const frequencyLabels = {
                    'frequent': 'Frequent Customer',
                    'regular': 'Regular Customer',
                    'occasional': 'Occasional Customer', 
                    'no_orders': 'No Recent Orders'
                };
                
                analyticsContent.innerHTML = `
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card h-100">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-chart-line"></i> Order Metrics</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row text-center">
                                        <div class="col-6 mb-3">
                                            <div class="analytics-card">
                                                <h4 class="text-primary">${analytics.total_orders}</h4>
                                                <small>Total Orders</small>
                                            </div>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <div class="analytics-card">
                                                <h4 class="text-success">$${parseFloat(analytics.total_spent).toFixed(2)}</h4>
                                                <small>Total Spent</small>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="analytics-card">
                                                <h4 class="text-info">$${parseFloat(analytics.avg_order_value).toFixed(2)}</h4>
                                                <small>Avg Order</small>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="analytics-card">
                                                <h4 class="text-warning">${analytics.completed_orders}</h4>
                                                <small>Completed</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <div class="card h-100">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0"><i class="fas fa-user-clock"></i> Customer Profile</h6>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <span class="badge bg-${frequencyColors[analytics.order_frequency]} fs-6">
                                            ${frequencyLabels[analytics.order_frequency]}
                                        </span>
                                    </div>
                                    
                                    ${analytics.last_order_date ? `
                                    <p><strong>Last Order:</strong><br>
                                       <small class="text-muted">${new Date(analytics.last_order_date).toLocaleDateString('en-US', {
                                           weekday: 'long',
                                           year: 'numeric', 
                                           month: 'long',
                                           day: 'numeric'
                                       })}</small>
                                    </p>
                                    ` : '<p class="text-muted">No orders yet</p>'}
                                    
                                    ${analytics.total_orders > 0 ? `
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-success" role="progressbar" 
                                             style="width: ${(analytics.completed_orders / analytics.total_orders * 100)}%">
                                        </div>
                                    </div>
                                    <small class="text-muted">
                                        ${Math.round(analytics.completed_orders / analytics.total_orders * 100)}% completion rate
                                    </small>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }

            
            function viewUserOrders(userId) {
                
                const modalHtml = `
                    <div class="modal fade" id="userOrdersModal" tabindex="-1">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">
                                        <i class="fas fa-shopping-cart"></i> Customer Orders
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div id="userOrdersContent">
                                        <div class="text-center">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading orders...</span>
                                            </div>
                                            <p class="mt-2">Loading customer orders...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;

               
                const existingModal = document.getElementById('userOrdersModal');
                if (existingModal) {
                    existingModal.remove();
                }

                
                document.body.insertAdjacentHTML('beforeend', modalHtml);

                
                const modal = new bootstrap.Modal(document.getElementById('userOrdersModal'));
                modal.show();

                
                Promise.all([
                    fetch(`../../controller/UserController.php?action=view&id=${userId}&ajax=1`),
                    fetch(`../../service/OrderManagmentService.php?action=getUserOrders&user_id=${userId}&limit=20&include_details=true`),
                    fetch(`../../service/OrderManagmentService.php?action=getCustomerAnalytics&customer_id=${userId}`)
                ])
                .then(responses => Promise.all(responses.map(r => r.json())))
                .then(([userData, orderData, analyticsData]) => {
                    displayUserOrdersModal(userData.user, orderData, analyticsData);
                })
                .catch(error => {
                    document.getElementById('userOrdersContent').innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Error loading orders: ${error.message}
                        </div>
                    `;
                });
            }

    
            function displayUserOrdersModal(user, orderData, analyticsData) {
                const orders = orderData.success ? orderData.data.orders : [];
                
                document.getElementById('userOrdersContent').innerHTML = `
                    <!-- Orders Table -->
                    <div class="card">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">
                                <i class="fas fa-list"></i> Order History 
                                ${orders.length > 0 ? `(${orders.length} of ${orderData.data.total_count})` : ''}
                            </h6>
                        </div>
                        <div class="card-body p-0">
                            ${orders.length > 0 ? `
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Items</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Type</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${orders.map(order => `
                                            <tr>
                                                <td><strong>#${order.order_id}</strong></td>
                                                <td>${order.formatted_date}</td>
                                                <td>
                                                    ${order.items ? `
                                                        <small>${order.items.length} items</small>
                                                        <div class="text-muted" style="font-size: 0.75rem;">
                                                            ${order.items.slice(0, 2).map(item => item.menu_item_name || item.name).join(', ')}
                                                            ${order.items.length > 2 ? '...' : ''}
                                                        </div>
                                                    ` : '-'}
                                                </td>
                                                <td>
                                                    <strong>$${parseFloat(order.total_amount).toFixed(2)}</strong>
                                                    ${order.subtotal ? `<br><small class="text-muted">Subtotal: $${parseFloat(order.subtotal).toFixed(2)}</small>` : ''}
                                                </td>
                                                <td>
                                                    <span class="badge ${getOrderStatusClass(order.order_status)}">
                                                        ${order.status_formatted}
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary">
                                                        ${order.order_type}
                                                    </span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-xs btn-outline-primary" onclick="viewOrderDetails(${order.order_id})" title="View Order Details">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                            ` : `
                            <div class="text-center py-5">
                                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No Orders Found</h5>
                                <p class="text-muted">This customer hasn't placed any orders yet.</p>
                            </div>
                            `}
                        </div>
                    </div>
                `;
            }


            function viewOrderDetails(orderId) {
                fetch(`/Zuspresso/service/OrderManagmentService.php?action=getOrderStatus&order_id=${orderId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`Order #${orderId}\nStatus: ${data.data.status_formatted}\nType: ${data.data.order_type}\nLast Updated: ${new Date(data.data.last_updated).toLocaleString()}`);
                            
                        } else {
                            showAlert('Error loading order details', 'danger');
                        }
                    })
                    .catch(error => {
                        showAlert('Error: ' + error.message, 'danger');
                    });
            }


            function getOrderStatusClass(status) {
                const statusClasses = {
                    'pending': 'bg-warning text-dark',
                    'confirmed': 'bg-info', 
                    'preparing': 'bg-primary',
                    'ready': 'bg-success',
                    'delivered': 'bg-success',
                    'cancelled': 'bg-danger',
                    'completed': 'bg-success'
                };
                return statusClasses[status] || 'bg-secondary';
            }


            function editAdminRole(userId) {
                fetch(`../../controller/UserController.php?action=view&id=${userId}&ajax=1`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.user.role === 'admin') {
                                showAdminRoleModal(data.user);
                            } else {
                                showAlert('User is not an admin or could not load admin data', 'danger');
                            }
                        })
                        .catch(error => {
                            showAlert('Error loading admin data: ' + error.message, 'danger');
                        });
            }

            function showAdminRoleModal(user) {
              
                let permissions = {};
                try {
                    permissions = JSON.parse(user.permissions || '{}');
                } catch (e) {
                    permissions = {};
                }

                const modalHtml = `
                    <div class="modal fade" id="adminRoleModal" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">
                                        <i class="fas fa-user-shield"></i> Edit Admin Permissions
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form id="adminRoleForm">
                                    <div class="modal-body">
                                        <input type="hidden" id="adminUserId" name="user_id" value="${user.user_id}">
                                    
                                        <div class="alert alert-info">
                                            <i class="fas fa-info-circle"></i>
                                            <strong>Admin:</strong> ${escapeHtml(user.admin_name || 'Unknown')} (${escapeHtml(user.email)})
                                        </div>
                                    
                                        <div class="mb-3">
                                            <label for="adminName" class="form-label">
                                                <i class="fas fa-user"></i> Admin Display Name
                                            </label>
                                            <input type="text" class="form-control" id="adminName" name="admin_name" 
                                                   value="${escapeHtml(user.admin_name || '')}" required>
                                        </div>
                                    
                                        <div class="mb-4">
                                            <h6 class="fw-bold">
                                                <i class="fas fa-key"></i> Permissions
                                            </h6>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="permission-item ${permissions.user_management ? 'selected' : ''}">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="perm_user_management" 
                                                                   name="permissions[]" value="user_management" 
                                                                   ${permissions.user_management ? 'checked' : ''}>
                                                            <label class="form-check-label" for="perm_user_management">
                                                                <i class="fas fa-users text-primary permission-icon"></i>
                                                                <strong>User Management</strong>
                                                                <small class="d-block text-muted">Manage customers and admin accounts</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                
                                                    <div class="permission-item ${permissions.menu_management ? 'selected' : ''}">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="perm_menu_management" 
                                                                   name="permissions[]" value="menu_management" 
                                                                   ${permissions.menu_management ? 'checked' : ''}>
                                                            <label class="form-check-label" for="perm_menu_management">
                                                                <i class="fas fa-utensils text-success permission-icon"></i>
                                                                <strong>Menu Management</strong>
                                                                <small class="d-block text-muted">Add, edit, and manage menu items</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                
                                                    <div class="permission-item ${permissions.order_management ? 'selected' : ''}">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="perm_order_management" 
                                                                   name="permissions[]" value="order_management" 
                                                                   ${permissions.order_management ? 'checked' : ''}>
                                                            <label class="form-check-label" for="perm_order_management">
                                                                <i class="fas fa-shopping-cart text-warning permission-icon"></i>
                                                                <strong>Order Management</strong>
                                                                <small class="d-block text-muted">View and manage customer orders</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                                <div class="col-md-6">
                                                    <div class="permission-item ${permissions.reports ? 'selected' : ''}">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="perm_reports" 
                                                                   name="permissions[]" value="reports" 
                                                                   ${permissions.reports ? 'checked' : ''}>
                                                            <label class="form-check-label" for="perm_reports">
                                                                <i class="fas fa-chart-bar text-info permission-icon"></i>
                                                                <strong>Reports & Analytics</strong>
                                                                <small class="d-block text-muted">Access sales reports and analytics</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                
                                                    <div class="permission-item ${permissions.system_settings ? 'selected' : ''}">
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" id="perm_system_settings" 
                                                                   name="permissions[]" value="system_settings" 
                                                                   ${permissions.system_settings ? 'checked' : ''}>
                                                            <label class="form-check-label" for="perm_system_settings">
                                                                <i class="fas fa-cogs text-danger permission-icon"></i>
                                                                <strong>System Settings</strong>
                                                                <small class="d-block text-muted">Modify system configurations</small>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                        ${user.user_id == currentAdminId ? `
                                        <div class="alert alert-warning">
                                            <i class="fas fa-exclamation-triangle"></i>
                                            <strong>Note:</strong> You are editing your own permissions. User Management permission cannot be removed from your own account.
                                        </div>
                                        ` : `
                                        <div class="alert alert-warning">
                                            <i class="fas fa-exclamation-triangle"></i>
                                            <strong>Warning:</strong> Removing permissions will immediately affect the admin's access to those areas.
                                        </div>
                                        `}
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                            <i class="fas fa-times"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-zus">
                                            <i class="fas fa-save"></i> Update Permissions
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                `;

                
                const existingModal = document.getElementById('adminRoleModal');
                if (existingModal) {
                    existingModal.remove();
                }


                document.body.insertAdjacentHTML('beforeend', modalHtml);


                document.querySelectorAll('#adminRoleModal input[type="checkbox"]').forEach(checkbox => {
                    checkbox.addEventListener('change', function () {
                        const permissionItem = this.closest('.permission-item');
                        if (this.checked) {
                            permissionItem.classList.add('selected');
                        } else {
                            permissionItem.classList.remove('selected');
                        }
                    });
                });


                if (user.user_id == currentAdminId) {
                    const userMgmtCheckbox = document.getElementById('perm_user_management');
                    if (userMgmtCheckbox) {
                        userMgmtCheckbox.disabled = true;
                        userMgmtCheckbox.checked = true;
                    }
                }


                document.getElementById('adminRoleForm').addEventListener('submit', handleAdminRoleUpdate);

 
                new bootstrap.Modal(document.getElementById('adminRoleModal')).show();
            }

            function handleAdminRoleUpdate(e) {
                e.preventDefault();

                const formData = new FormData(e.target);
                const submitBtn = e.target.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;

                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
                submitBtn.disabled = true;

                fetch('../../controller/UserController.php?action=update_admin_role', {
                    method: 'POST',
                    body: formData
                })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                showAlert(data.message, 'success');
                                bootstrap.Modal.getInstance(document.getElementById('adminRoleModal')).hide();
                                loadUsers(); 
                            } else {
                                showAlert(data.message || 'Failed to update admin permissions', 'danger');
                            }
                        })
                        .catch(error => {
                            showAlert('Error updating admin permissions: ' + error.message, 'danger');
                        })
                        .finally(() => {
                            submitBtn.innerHTML = originalText;
                            submitBtn.disabled = false;
                        });
            }

            function showEmptyTable() {
                const tbody = document.getElementById('usersTableBody');
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="no-users-found">
                            <i class="fas fa-exclamation-triangle fa-3x text-muted mb-3"></i>
                            <p>Failed to load users. Please try refreshing.</p>
                            <button class="btn btn-secondary btn-sm" onclick="loadUsers()">Retry</button>
                        </td>
                    </tr>
                `;
            }


            function updateStats(stats) {
                document.getElementById('totalUsers').textContent = parseInt(stats.total_users || 0).toLocaleString();
                document.getElementById('totalCustomers').textContent = parseInt(stats.customers || 0).toLocaleString();
                document.getElementById('totalAdmins').textContent = parseInt(stats.admins || 0).toLocaleString();
                document.getElementById('newUsers').textContent = parseInt(stats.recent_registrations || 0).toLocaleString();
            }


            function refreshStats() {
                fetch('../../controller/UserController.php?action=stats&ajax=1')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success && data.stats) {
                                updateStats(data.stats);
                            }
                        })
                        .catch(error => {
                            console.error('Stats error:', error);
                        });
            }

            function formatPermissions(permissionsJson) {
                try {
                    const permissions = JSON.parse(permissionsJson);
                    const permissionLabels = {
                        'user_management': 'User Management',
                        'menu_management': 'Menu Management',
                        'order_management': 'Order Management',
                        'reports': 'Reports & Analytics',
                        'system_settings': 'System Settings'
                    };

                    const activePermissions = Object.keys(permissions)
                            .filter(key => permissions[key])
                            .map(key => permissionLabels[key] || key);

                    if (activePermissions.length === 0) {
                        return '<small class="text-muted">No permissions assigned</small>';
                    }

                    return activePermissions.map(perm =>
                            `<span class="badge bg-primary me-1 mb-1">${perm}</span>`
                    ).join('');
                } catch (e) {
                    return '<small class="text-muted">Error parsing permissions</small>';
                }
            }


            function editUser(userId) {
                fetch(`../../controller/UserController.php?action=view&id=${userId}&ajax=1`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById('editUserId').value = data.user.user_id;
                                document.getElementById('editUserEmail').value = data.user.email;
                                document.getElementById('editUserActive').checked = data.user.is_active == 1;

                                new bootstrap.Modal(document.getElementById('editUserModal')).show();
                            } else {
                                showAlert('Error loading user: ' + data.message, 'danger');
                            }
                        })
                        .catch(error => {
                            showAlert('Error: ' + error.message, 'danger');
                        });
            }


            document.getElementById('editUserForm').addEventListener('submit', function (e) {
                e.preventDefault();

                const formData = new FormData(this);
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;

                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                submitBtn.disabled = true;

                fetch('../../controller/UserController.php?action=edit', {
                    method: 'POST',
                    body: formData
                })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                showAlert(data.message, 'success');
                                bootstrap.Modal.getInstance(document.getElementById('editUserModal')).hide();
                                loadUsers(); 
                            } else {
                                showAlert(data.message, 'danger');
                            }
                        })
                        .catch(error => {
                            showAlert('Error: ' + error.message, 'danger');
                        })
                        .finally(() => {
                            submitBtn.innerHTML = originalText;
                            submitBtn.disabled = false;
                        });
            });

          
            function toggleUserStatus(userId, action) {
                const message = action === 'activate' ? 'activate' : 'deactivate';

                if (confirm(`Are you sure you want to ${message} this user?`)) {
                    const formData = new FormData();
                    formData.append('user_id', userId);

                    fetch('../../controller/UserController.php?action=toggle_status', {
                        method: 'POST',
                        body: formData
                    })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    showAlert(data.message, 'success');
                                    loadUsers();
                                } else {
                                    showAlert(data.message, 'danger');
                                }
                            })
                            .catch(error => {
                                showAlert('Error: ' + error.message, 'danger');
                            });
                }
            }


            function deleteUser(userId, email) {
                if (confirm(`Are you sure you want to deactivate "${email}"?\n\nThis will deactivate their account.`)) {
                    const formData = new FormData();
                    formData.append('user_id', userId);

                    fetch('../../controller/UserController.php?action=delete', {
                        method: 'POST',
                        body: formData
                    })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    showAlert(data.message, 'success');
                                    loadUsers();
                                } else {
                                    showAlert(data.message, 'danger');
                                }
                            })
                            .catch(error => {
                                showAlert('Error: ' + error.message, 'danger');
                            });
                }
            }

            
            function refreshData() {
                loadUsers();
                refreshStats();
                showAlert('Data refreshed', 'success');
            }


            function showNoResultsMessage() {
                const tbody = document.getElementById('usersTableBody');
                if (!document.getElementById('noResultsRow')) {
                    const row = document.createElement('tr');
                    row.id = 'noResultsRow';
                    row.innerHTML = `
                        <td colspan="6" class="no-users-found">
                            <i class="fas fa-search fa-3x text-muted mb-3"></i>
                            <p>No users match your search criteria</p>
                            <button class="btn btn-secondary btn-sm" onclick="resetFilters()">Clear Filters</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                }
            }

            function hideNoResultsMessage() {
                const row = document.getElementById('noResultsRow');
                if (row) {
                    row.remove();
                }
            }


            function showAlert(message, type) {
                const alertDiv = document.createElement('div');
                alertDiv.className = `alert alert-${type} alert-dismissible fade show alert-floating`;
                alertDiv.innerHTML = `
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;

                document.getElementById('alertContainer').appendChild(alertDiv);


                setTimeout(() => {
                    if (alertDiv && alertDiv.parentNode) {
                        alertDiv.remove();
                    }
                }, 5000);
            }

            
            function escapeHtml(text) {
                if (text === null || text === undefined)
                    return '';
                const div = document.createElement('div');
                div.textContent = text.toString();
                return div.innerHTML;
            }

            
            function logout() {
                if (confirm('Are you sure you want to logout?')) {
                    
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '../../controller/AuthController.php';

                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'logout';
                    form.appendChild(actionInput);

                    document.body.appendChild(form);
                    form.submit();
                }
            }


            setInterval(() => {
                refreshStats();
            }, 300000);
        </script>
    </body>
</html>