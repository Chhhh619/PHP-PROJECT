<?php
/**
 * Zuspresso Online Ordering System
 * Login View - FIXED REDIRECT LOOP
 * 
 * @author Cheng Jun Yang
 * @module User Management & Authentication
 * @version 1.0.4
 * @modified 2025-07-19
 */
session_start();


if (isset($_SESSION['user_id']) && isset($_SESSION['user_role'])) {
    $redirect_url = '';
    switch ($_SESSION['user_role']) {
        case 'admin':
            $redirect_url = '/Zuspresso/view/admin/admin_dashboard.php';
            break;
        case 'customer':
            $redirect_url = '/Zuspresso/view/user/dashboard.php';
            break;
        default:
           
            session_destroy();
            break;
    }

    if ($redirect_url) {
        header("Location: $redirect_url");
        exit;
    }
}


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login - Zuspresso</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="../../assets/css/login.css">
    </head>
    <body>
        <div class="login-container">
            <div class="logo">
                <div class="logo-icon"></div>
                <h1>Zuspresso</h1>
                <p>Welcome back! Please sign in to your account</p>
            </div>

            
            <?php if (isset($_GET['message']) && $_GET['message'] === 'registered'): ?>
                <div class="alert alert-success">
                    🎉 Registration successful! Please log in with your credentials.
                </div>
            <?php endif; ?>

            <!-- Show logout message -->
            <?php if (isset($_GET['message']) && $_GET['message'] === 'logged_out'): ?>
                <div class="alert alert-info">
                    👋 You have been logged out successfully.
                </div>
            <?php endif; ?>

            <!-- Alert container for AJAX responses -->
            <div id="alert-container"></div>

            <form id="loginForm" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="action" value="login">

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-wrapper">
                        <input type="email" id="email" name="email" placeholder="customer@gmail.com" required>
                        <span class="input-icon">📧</span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrapper">
                        <input type="password" id="password" name="password" placeholder="Enter your password" required>
                        <span class="input-icon">🔒</span>
                    </div>
                </div>

                <button type="submit" class="btn" id="loginBtn">
                    Sign In
                </button>

                <div class="loading" id="loading">
                    <div class="loading-spinner"></div>
                    <span>Authenticating...</span>
                </div>
            </form>

            <div class="links">
                <p>Don't have an account? <a href="register.php">Create one here</a></p>
                <p><a href="../../index.php">← Back to Home</a></p>
            </div>
        </div>

        <script>
            document.getElementById('loginForm').addEventListener('submit', function (e) {
                e.preventDefault();

                const form = this;
                const formData = new FormData(form);
                const submitBtn = document.getElementById('loginBtn');
                const loading = document.getElementById('loading');
                const alertContainer = document.getElementById('alert-container');

         
                submitBtn.disabled = true;
                submitBtn.textContent = 'Signing In...';
                loading.style.display = 'block';
                alertContainer.innerHTML = '';

                fetch('/Zuspresso/controller/AuthController.php', {
                    method: 'POST',
                    body: formData
                })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                            }
                            return response.json();
                        })
                        .then(data => {
                   
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Sign In';
                            loading.style.display = 'none';

                            if (data.success) {
                         
                                alertContainer.innerHTML = `
                            <div class="alert alert-success">
                                ✅ ${data.message} Redirecting...
                            </div>
                        `;

                               
                                setTimeout(() => {
                                    if (data.redirect) {
                                        window.location.href = data.redirect;
                                    } else {
                                  
                                        window.location.reload();
                                    }
                                }, 1000);

                            } else {
                        
                                alertContainer.innerHTML = `
                            <div class="alert alert-error">
                                ❌ ${data.message}
                            </div>
                        `;
                            }
                        })
                        .catch(error => {
                            console.error('Login error:', error);
                            submitBtn.disabled = false;
                            submitBtn.textContent = 'Sign In';
                            loading.style.display = 'none';

                            alertContainer.innerHTML = `
                        <div class="alert alert-error">
                            ⚠️ Connection error: ${error.message}. Please check your controller path.
                        </div>
                    `;
                        });
            });
        </script>
    </body>
</html>