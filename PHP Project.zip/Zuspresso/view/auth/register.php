<?php
/**
 * Zuspresso Online Ordering System
 * Customer Registration Page - Using Database Class
 * 
 * @author Cheng Jun Yang
 * @module User Management & Authentication
 * @version 1.0.2
 * @updated 2025-09-06
 */

session_start();


if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}


require_once '../../database.php';
require_once '../../model/UserFactory.php';

$errors = [];
$success_message = '';
$form_data = [];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
    
        $db = Database::getInstance();
        $pdo = $db->getConnection();
        
     
        if (!$pdo) {
            throw new Exception('Database connection not available');
        }
        
       
        $form_data = [
            'email' => filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL),
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'first_name' => trim($_POST['first_name'] ?? ''),
            'last_name' => trim($_POST['last_name'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'date_of_birth' => $_POST['date_of_birth'] ?? ''
        ];
        
    
        if (empty($form_data['email'])) {
            $errors[] = 'Email is required';
        } elseif (!filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address';
        }
        
        if (empty($form_data['password'])) {
            $errors[] = 'Password is required';
        } elseif (strlen($form_data['password']) < 8) {
            $errors[] = 'Password must be at least 8 characters long';
        }
        
        if ($form_data['password'] !== $form_data['confirm_password']) {
            $errors[] = 'Passwords do not match';
        }
        
        if (empty($form_data['first_name'])) {
            $errors[] = 'First name is required';
        }
        
        if (empty($form_data['last_name'])) {
            $errors[] = 'Last name is required';
        }
        
        if (empty($errors)) {
            $userFactory = new UserFactory($pdo);
            
        
            unset($form_data['confirm_password']);
            
            $newCustomer = $userFactory->registerCustomer($form_data);
            
            if ($newCustomer) {
                $success_message = 'Registration successful! You can now log in with your credentials.';
     
                $form_data = [];
            } else {
                $errors[] = 'Registration failed. Please try again.';
            }
        }
        
    } catch (Exception $e) {
       
        if (strpos($e->getMessage(), 'Email address is already registered') !== false) {
            $errors[] = 'This email address is already registered. Please use a different email or try logging in.';
        } elseif (strpos($e->getMessage(), 'Password must be') !== false) {
            $errors[] = 'Password must contain at least 8 characters with uppercase, lowercase, number, and special character';
        } elseif (strpos($e->getMessage(), 'Database connection') !== false) {
            $errors[] = 'Database connection error. Please try again later.';
        } else {
            $errors[] = 'Registration failed: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Zuspresso</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/register.css">
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h1>Join Zuspresso</h1>
            <p>Create your account to start ordering</p>
        </div>
        
        <div class="register-form">
            <!-- Display errors -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <ul class="error-list">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <!-- Display success message -->
            <?php if ($success_message): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="register.php">
                <div class="form-group">
                    <label for="email">Email Address <span class="required">*</span></label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>" 
                           required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Password <span class="required">*</span></label>
                        <input type="password" id="password" name="password"    
                               placeholder="Min. 8 characters" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name <span class="required">*</span></label>
                        <input type="text" id="first_name" name="first_name" 
                               value="<?php echo htmlspecialchars($form_data['first_name'] ?? ''); ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name <span class="required">*</span></label>
                        <input type="text" id="last_name" name="last_name" 
                               value="<?php echo htmlspecialchars($form_data['last_name'] ?? ''); ?>" 
                               required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($form_data['phone'] ?? ''); ?>" 
                           placeholder="Optional">
                </div>
                
                <div class="form-group">
                    <label for="date_of_birth">Date of Birth</label>
                    <input type="date" id="date_of_birth" name="date_of_birth" 
                           value="<?php echo htmlspecialchars($form_data['date_of_birth'] ?? ''); ?>">
                </div>
                
                <button type="submit" class="register-btn">Create Account</button>
            </form>
            
            <div class="login-link">
                Already have an account? <a href="login.php">Sign In</a>
            </div>
        </div>
    </div>

    <script>
       
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (password !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
        
      
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const hasUppercase = /[A-Z]/.test(password);
            const hasLowercase = /[a-z]/.test(password);
            const hasNumber = /\d/.test(password);
            const hasSpecial = /[@$!%*?&]/.test(password);
            const isLongEnough = password.length >= 8;
            
            if (!isLongEnough || !hasUppercase || !hasLowercase || !hasNumber || !hasSpecial) {
                this.setCustomValidity('Password must be at least 8 characters with uppercase, lowercase, number, and special character');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>