<?php
/**
author : Cheng Jun Yang
 */
session_start();
require_once 'database.php';


if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_role'] === 'customer') {
        header('Location: view/user/dashboard.php');
        exit;
    } elseif ($_SESSION['user_role'] === 'admin') {
        header('Location: view/admin/admin_dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zuspresso - Premium Coffee Experience</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
                background-color: #f8f9fa;
                color: #2c2c2c;
                line-height: 1.6;
                overflow-x: hidden;
            }

            /* Header Navigation */
            .navbar {
                background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
                padding: 1rem 0;
                box-shadow: 0 2px 20px rgba(0,0,0,0.1);
                position: sticky;
                top: 0;
                z-index: 1000;
            }

            .nav-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 2rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .logo {
                display: flex;
                align-items: center;
                font-size: 1.8rem;
                font-weight: 700;
                color: white;
            }

            .logo-icon {
                margin-right: 0.5rem;
                font-size: 2rem;
            }

            .nav-links {
                display: flex;
                align-items: center;
                gap: 2rem;
            }

            .nav-link {
                color: white;
                text-decoration: none;
                font-weight: 500;
                padding: 0.5rem 1rem;
                border-radius: 25px;
                transition: all 0.3s ease;
            }

            .nav-link:hover {
                background: rgba(255,255,255,0.15);
                transform: translateY(-1px);
            }

            .auth-buttons {
                display: flex;
                gap: 1rem;
            }

            .btn-login {
                background: rgba(255,255,255,0.1);
                border: 2px solid rgba(255,255,255,0.3);
                color: white;
                padding: 0.5rem 1.5rem;
                border-radius: 25px;
                text-decoration: none;
                font-weight: 500;
                transition: all 0.3s ease;
            }

            .btn-login:hover {
                background: rgba(255,255,255,0.2);
                transform: translateY(-1px);
            }

            .btn-register {
                background: white;
                color: #8B4513;
                padding: 0.5rem 1.5rem;
                border-radius: 25px;
                text-decoration: none;
                font-weight: 600;
                transition: all 0.3s ease;
            }

            .btn-register:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 20px rgba(255,255,255,0.3);
            }

            /* Hero Section */
            .hero {
                background: linear-gradient(135deg, #8B4513 0%, #D2691E 50%, #CD853F 100%);
                color: white;
                text-align: center;
                padding: 6rem 2rem;
                position: relative;
                overflow: hidden;
            }

            .hero::before {
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="25" cy="25" r="2" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="3" fill="white" opacity="0.05"/><circle cx="50" cy="10" r="1" fill="white" opacity="0.1"/></svg>');
                animation: float 20s infinite linear;
            }

            @keyframes float {
                0% {
                    transform: translate(-50%, -50%) rotate(0deg);
                }
                100% {
                    transform: translate(-50%, -50%) rotate(360deg);
                }
            }

            .hero-content {
                position: relative;
                z-index: 2;
                max-width: 800px;
                margin: 0 auto;
            }

            .hero h1 {
                font-size: 4rem;
                font-weight: 700;
                margin-bottom: 1rem;
                animation: fadeInUp 1s ease;
            }

            .hero p {
                font-size: 1.3rem;
                margin-bottom: 2rem;
                opacity: 0.9;
                animation: fadeInUp 1s ease 0.2s both;
            }

            .hero-buttons {
                display: flex;
                gap: 1rem;
                justify-content: center;
                flex-wrap: wrap;
                animation: fadeInUp 1s ease 0.4s both;
            }

            .btn-hero {
                padding: 1rem 2rem;
                border-radius: 30px;
                font-weight: 600;
                text-decoration: none;
                transition: all 0.3s ease;
                font-size: 1.1rem;
            }

            .btn-primary {
                background: white;
                color: #8B4513;
            }

            .btn-primary:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 30px rgba(255,255,255,0.3);
            }

            .btn-secondary {
                background: transparent;
                color: white;
                border: 2px solid white;
            }

            .btn-secondary:hover {
                background: white;
                color: #8B4513;
                transform: translateY(-3px);
            }

            /* Features Section */
            .features {
                padding: 5rem 2rem;
                background: white;
            }

            .container {
                max-width: 1200px;
                margin: 0 auto;
            }

            .section-header {
                text-align: center;
                margin-bottom: 4rem;
            }

            .section-header h2 {
                font-size: 2.5rem;
                color: #2c2c2c;
                margin-bottom: 1rem;
            }

            .section-header p {
                font-size: 1.2rem;
                color: #666;
                max-width: 600px;
                margin: 0 auto;
            }

            .features-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 3rem;
            }

            .feature-card {
                background: white;
                padding: 2.5rem;
                border-radius: 20px;
                box-shadow: 0 4px 30px rgba(0,0,0,0.08);
                text-align: center;
                transition: all 0.3s ease;
                position: relative;
                overflow: hidden;
            }

            .feature-card:hover {
                transform: translateY(-10px);
                box-shadow: 0 20px 50px rgba(0,0,0,0.15);
            }

            .feature-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 4px;
                background: linear-gradient(90deg, #8B4513, #D2691E);
            }

            .feature-icon {
                font-size: 3rem;
                margin-bottom: 1rem;
                display: block;
            }

            .feature-card h3 {
                font-size: 1.5rem;
                color: #2c2c2c;
                margin-bottom: 1rem;
            }

            .feature-card p {
                color: #666;
                line-height: 1.8;
            }

            /* Stats Section */
            .stats {
                background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
                color: white;
                padding: 4rem 2rem;
            }

            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 2rem;
                max-width: 800px;
                margin: 0 auto;
            }

            .stat-item {
                text-align: center;
            }

            .stat-number {
                font-size: 3rem;
                font-weight: 700;
                margin-bottom: 0.5rem;
                display: block;
            }

            .stat-label {
                font-size: 1.1rem;
                opacity: 0.9;
            }

            /* CTA Section */
            .cta {
                background: #f8f9fa;
                padding: 5rem 2rem;
                text-align: center;
            }

            .cta-content {
                max-width: 600px;
                margin: 0 auto;
            }

            .cta h2 {
                font-size: 2.5rem;
                color: #2c2c2c;
                margin-bottom: 1rem;
            }

            .cta p {
                font-size: 1.2rem;
                color: #666;
                margin-bottom: 2rem;
            }

            /* Footer */
            .footer {
                background: #2c2c2c;
                color: white;
                padding: 3rem 2rem 1rem;
            }

            .footer-content {
                max-width: 1200px;
                margin: 0 auto;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 2rem;
                margin-bottom: 2rem;
            }

            .footer-section h3 {
                margin-bottom: 1rem;
                color: #D2691E;
            }

            .footer-section p, .footer-section a {
                color: #ccc;
                text-decoration: none;
                line-height: 1.8;
            }

            .footer-section a:hover {
                color: white;
            }

            .footer-bottom {
                border-top: 1px solid #444;
                padding-top: 1rem;
                text-align: center;
                color: #999;
            }

            /* Responsive Design */
            @media (max-width: 768px) {
                .nav-links {
                    display: none;
                }

                .hero h1 {
                    font-size: 2.5rem;
                }

                .hero-buttons {
                    flex-direction: column;
                    align-items: center;
                }

                .btn-hero {
                    width: 250px;
                }

                .features-grid {
                    grid-template-columns: 1fr;
                }

                .stats-grid {
                    grid-template-columns: repeat(2, 1fr);
                }
            }

            /* Animations */
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .feature-card {
                animation: fadeInUp 0.6s ease forwards;
            }

            .feature-card:nth-child(2) {
                animation-delay: 0.1s;
            }
            .feature-card:nth-child(3) {
                animation-delay: 0.2s;
            }
        </style>
    </head>
    <body>
   
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <span class="logo-icon">☕</span>
                    Zuspresso
                </div>

                <div class="nav-links">
                    <a href="#features" class="nav-link">Features</a>
                    <a href="#about" class="nav-link">About</a>
                    <a href="#contact" class="nav-link">Contact</a>
                </div>

                <div class="auth-buttons">
                    <a href="view/auth/login.php" class="btn-login">Login</a>
                    <a href="view/auth/register.php" class="btn-register">Register</a>
                </div>
            </div>
        </nav>

      
        <section class="hero">
            <div class="hero-content">
                <h1>Welcome to Zuspresso</h1>
                <p>Experience premium coffee like never before. Order online, earn rewards, and enjoy the perfect cup every time.</p>
                <div class="hero-buttons">
                    <a href="view/auth/register.php" class="btn-hero btn-primary">Get Started</a>
                    <a href="#features" class="btn-hero btn-secondary">Learn More</a>
                </div>
            </div>
        </section>

        
        <section class="features" id="features">
            <div class="container">
                <div class="section-header">
                    <h2>Why Choose Zuspresso?</h2>
                    <p>Discover the features that make us the perfect choice for your coffee needs</p>
                </div>

                <div class="features-grid">
                    <div class="feature-card">
                        <span class="feature-icon">🛍️</span>
                        <h3>Easy Online Ordering</h3>
                        <p>Browse our full menu, customize your order, and pay securely online. Pick up in-store or get it delivered to your doorstep.</p>
                    </div>

                    <div class="feature-card">
                        <span class="feature-icon">🎁</span>
                        <h3>Rewards Program</h3>
                        <p>Earn loyalty points with every purchase. Redeem points for free drinks, exclusive merchandise, and special discounts.</p>
                    </div>

                    <div class="feature-card">
                        <span class="feature-icon">☕</span>
                        <h3>Premium Quality</h3>
                        <p>We source the finest coffee beans from around the world and craft each cup with precision and care for the perfect taste.</p>
                    </div>
                </div>
            </div>
        </section>

     
        <section class="stats">
            <div class="container">
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-number">10K+</span>
                        <span class="stat-label">Happy Customers</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">50+</span>
                        <span class="stat-label">Coffee Varieties</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">15</span>
                        <span class="stat-label">Store Locations</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">99%</span>
                        <span class="stat-label">Satisfaction Rate</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Call to Action -->
        <section class="cta">
            <div class="container">
                <div class="cta-content">
                    <h2>Ready to Start Your Coffee Journey?</h2>
                    <p>Join thousands of coffee lovers who trust Zuspresso for their daily caffeine fix. Register now and get your first order discount!</p>
                    <a href="view/auth/register.php" class="btn-hero btn-primary">Join Zuspresso Today</a>
                </div>
            </div>
        </section>

        <footer class="footer">
            <div class="footer-content">
                <div class="footer-section branding">
                    <h3>Zuspresso</h3>
                    <p><strong>Premium coffee, not a luxury.</strong> Delivered with speed, quality, and your satisfaction in mind.</p>
                </div>
                <div class="footer-section links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="view/auth/login.php">Login</a></li>
                        <li><a href="view/auth/register.php">Register</a></li>
                        <li><a href="#features">Features</a></li>
                    </ul>
                </div>
                <div class="footer-section connect">
                    <h4>Follow Us</h4>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-instagram"></i> Instagram</a>
                        <a href="#"><i class="fab fa-facebook"></i> Facebook</a>
                        <a href="#"><i class="fab fa-tiktok"></i> TikTok</a>
                        <a href="#"><i class="fab fa-twitter"></i> Twitter</a>
                        <a href="#"><i class="fab fa-youtube"></i> YouTube</a>
                    </div>
                    <p>© 2025 Zuspresso (M) Sdn Bhd</p>
                    <ul class="legal">
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms &amp; Conditions</a></li>
                        <li><a href="#">Personal Data Protection Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>Last updated: <?php echo date('Y-m-d H:i:s'); ?></p>
            </div>
        </footer>


        <script>
            
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

        
            window.addEventListener('scroll', function () {
                const navbar = document.querySelector('.navbar');
                if (window.scrollY > 100) {
                    navbar.style.background = 'linear-gradient(135deg, rgba(139, 69, 19, 0.95) 0%, rgba(210, 105, 30, 0.95) 100%)';
                    navbar.style.backdropFilter = 'blur(10px)';
                } else {
                    navbar.style.background = 'linear-gradient(135deg, #8B4513 0%, #D2691E 100%)';
                    navbar.style.backdropFilter = 'none';
                }
            });

          
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, observerOptions);

            
            document.querySelectorAll('.feature-card').forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                card.style.transition = 'all 0.6s ease';
                observer.observe(card);
            });
        </script>
    </body>
</html>