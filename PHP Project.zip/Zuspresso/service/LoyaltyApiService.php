<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

session_start();

require_once '../model/LoyaltyService.php';
require_once '../model/Customer.php';
require_once '../model/Reward.php';
require_once '../model/RewardRedemption.php';
require_once '../model/LoyaltyTransaction.php';
require_once '../model/SecurityValidator.php';
require_once '../model/JWTHelper.php';
require_once '../model/strategies/PointCalculationStrategy.php';
require_once '../model/strategies/BasicPointStrategy.php';
require_once '../model/strategies/VIPPointStrategy.php';
require_once '../model/strategies/BonusPointStrategy.php';
require_once '../model/strategies/BronzePointStrategy.php';
require_once '../model/strategies/SilverPointStrategy.php';
require_once '../model/strategies/GoldPointStrategy.php';
require_once '../model/strategies/PlatinumPointStrategy.php';
require_once '../model/strategies/PromotionPointStrategy.php';

class LoyaltyApiController {

    private $loyaltyService;
    private $customerModel;
    private $rewardModel;
    private $rewardRedemptionModel;
    private $loyaltyTransactionModel;
    private $securityValidator;
    private $rateLimits = [
        'redeem' => ['max' => 3, 'window' => 300],
        'api_get' => ['max' => 60, 'window' => 300],
        'api_post' => ['max' => 20, 'window' => 300]
    ];

    public function __construct() {
        $this->validateSessionAndAuth();

        $this->loyaltyService = new LoyaltyService();
        $this->customerModel = new Customer();
        $this->rewardModel = new Reward();
        $this->rewardRedemptionModel = new RewardRedemption();
        $this->loyaltyTransactionModel = new LoyaltyTransaction();
        $this->securityValidator = new SecurityValidator();

        $this->initializePointStrategy();
    }

    public function handleApiRequest() {
        try {
            $this->setApiSecurityHeaders();
            
            $method = $_SERVER['REQUEST_METHOD'];
            $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            $segments = array_filter(explode('/', $uri));
            
            SecurityValidator::logAction($_SESSION['user_id'], 'api_access', [
                'method' => $method,
                'uri' => $uri,
                'ip_address' => SecurityValidator::getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);

            if (isset($_POST['action']) || isset($_GET['action'])) {
                $action = $_POST['action'] ?? $_GET['action'] ?? '';
                $this->executeLegacyApiAction($action);
            } else {
                $this->executeRestAction($method, $segments);
            }
        } catch (Exception $e) {
            $this->handleGlobalApiError($e);
        }
    }

    private function executeRestAction($method, $segments) {
        $segments = array_values(array_filter($segments, function($segment) {
            return !in_array(strtolower($segment), ['loyalty', 'api', 'loyaltyapicontroller.php']);
        }));

        $resource = $segments[0] ?? 'rewards';
        $id = $segments[1] ?? null;
        $subResource = $segments[2] ?? null;

        switch ($method) {
            case 'GET':
                $this->handleGetRequest($resource, $id, $subResource);
                break;
                
            case 'POST':
                $this->handlePostRequest($resource, $id, $subResource);
                break;
                
            case 'PUT':
                $this->handlePutRequest($resource, $id, $subResource);
                break;
                
            case 'DELETE':
                $this->handleDeleteRequest($resource, $id, $subResource);
                break;
                
            default:
                throw new Exception("Method not allowed: " . $method);
        }
    }

    private function handleGetRequest($resource, $id, $subResource) {
        switch ($resource) {
            case 'rewards':
                if ($id && $subResource === 'redemptions') {
                    $this->getRewardRedemptions($id);
                } else {
                    $this->getAvailableRewards();
                }
                break;
                
            case 'redemptions':
                if ($id) {
                    $this->getRedemptionById($id);
                } else {
                    $this->getRedemptionHistory();
                }
                break;
                
            case 'transactions':
                $this->getPointsHistory();
                break;
                
            case 'summary':
                $this->getLoyaltySummary();
                break;
                
            case 'customers':
                if ($id && $subResource === 'points') {
                    $this->getCustomerPoints($id);
                } elseif ($id && $subResource === 'tier') {
                    $this->getCustomerTier($id);
                }
                break;
                
            default:
                throw new Exception("Resource not found: " . $resource);
        }
    }

    private function handlePostRequest($resource, $id, $subResource) {
        switch ($resource) {
            case 'rewards':
                if ($id && $subResource === 'redeem') {
                    $this->redeemRewardById($id);
                }
                break;
                
            case 'points':
                if ($subResource === 'award') {
                    $this->awardOrderPoints();
                }
                break;
                
            case 'strategy':
                $this->setPointStrategy();
                break;
                
            default:
                throw new Exception("Resource not found or method not allowed: " . $resource);
        }
    }

    private function handlePutRequest($resource, $id, $subResource) {
        throw new Exception("PUT method not implemented yet");
    }

    private function handleDeleteRequest($resource, $id, $subResource) {
        throw new Exception("DELETE method not implemented yet");
    }

    private function executeLegacyApiAction($action) {
        $allowedActions = [
            'redeem', 'getRewards', 'getHistory', 'getTransactions',
            'getSummary', 'awardPoints', 'setStrategy', 'compareStrategies'
        ];

        if (!in_array($action, $allowedActions)) {
            SecurityValidator::logAction($_SESSION['user_id'], 'api_invalid_action', [
                'action' => $action,
                'allowed_actions' => $allowedActions
            ]);
            throw new Exception("Invalid action requested");
        }

        switch ($action) {
            case 'redeem':
                $this->redeemReward();
                break;
            case 'getRewards':
                $this->getAvailableRewards();
                break;
            case 'getHistory':
                $this->getRedemptionHistory();
                break;
            case 'getTransactions':
                $this->getPointsHistory();
                break;
            case 'getSummary':
                $this->getLoyaltySummary();
                break;
            case 'awardPoints':
                $this->awardOrderPoints();
                break;
            case 'setStrategy':
                $this->setPointStrategy();
                break;
            default:
                throw new Exception("Invalid action: " . $action);
        }
    }

    private function redeemRewardById($rewardId) {
        $_POST['reward_id'] = $rewardId;
        $this->redeemReward();
    }

    private function getCustomerPoints($customerId) {
        try {
            $this->checkRateLimit('api_get');

            $customer = $this->customerModel->where('customer_id', '=', $customerId)
                    ->where('user_id', '=', $_SESSION['user_id'])
                    ->first();
            if (!$customer) {
                throw new Exception("Customer not found or access denied");
            }

            $points = $this->loyaltyService->getCustomerPoints($customerId);
            
            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'customer_id' => $customerId,
                    'loyalty_points' => $points
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getCustomerPoints');
        }
    }

    private function getCustomerTier($customerId) {
        try {
            $this->checkRateLimit('api_get');

            $customer = $this->customerModel->where('customer_id', '=', $customerId)
                    ->where('user_id', '=', $_SESSION['user_id'])
                    ->first();
            if (!$customer) {
                throw new Exception("Customer not found or access denied");
            }

            $tier = $this->loyaltyService->getLoyaltyTier($customerId);
            $tierInfo = $this->loyaltyService->getTierInfo($customerId);
            
            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'customer_id' => $customerId,
                    'tier' => $tier,
                    'tier_info' => $tierInfo
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getCustomerTier');
        }
    }

    private function getRedemptionById($redemptionId) {
        try {
            $this->checkRateLimit('api_get');

            $redemption = RewardRedemption::getById($redemptionId);
            if (!$redemption || $redemption['customer_id'] != $_SESSION['user_id']) {
                throw new Exception("Redemption not found or access denied");
            }

            $this->sendJsonResponse([
                'success' => true,
                'data' => $redemption
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getRedemptionById');
        }
    }

    private function getRewardRedemptions($rewardId) {
        try {
            $this->checkRateLimit('api_get');
            
            $redemptions = RewardRedemption::getByRewardId($rewardId);
            
            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'reward_id' => $rewardId,
                    'redemptions' => $redemptions
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getRewardRedemptions');
        }
    }

    private function redeemReward() {
        try {
            $this->checkRateLimit('redeem');
            $this->validateRequestMethod('POST');

            $rewardId = $this->validateAndSanitizeInput($_POST['reward_id'] ?? null, 'int', 'reward_id');

            if ($rewardId <= 0) {
                throw new InvalidArgumentException("Valid reward ID is required");
            }

            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $reward = $this->rewardModel->where('reward_id', '=', $rewardId)
                    ->where('is_active', '=', 1)
                    ->first();
            if (!$reward) {
                SecurityValidator::logAction($_SESSION['user_id'], 'invalid_reward_redemption_attempt', [
                    'reward_id' => $rewardId,
                    'customer_id' => $customer['customer_id']
                ]);
                throw new Exception("Reward not found or not available");
            }

            if (isset($reward['stock_quantity']) && $reward['stock_quantity'] !== null && $reward['stock_quantity'] <= 0) {
                throw new Exception("This reward is currently out of stock");
            }

            $idempotencyKey = $this->generateSecureIdempotencyKey('redemption', $rewardId);

            $result = $this->loyaltyService->redeemRewardWithSecurity(
                    $_SESSION['user_id'],
                    $rewardId,
                    $idempotencyKey
            );

            if ($result['success']) {
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => 'Reward redeemed successfully!',
                    'data' => [
                        'redemption_code' => $result['redemption_code'],
                        'reward_name' => $result['reward_name'],
                        'points_used' => $result['points_used'],
                        'remaining_points' => $result['remaining_points'],
                        'redemption_id' => $result['redemption_id'],
                        'expires_at' => date('M j, Y', strtotime('+30 days'))
                    ],
                    'strategy_info' => [
                        'name' => $this->loyaltyService->getCurrentStrategy()['name'],
                        'description' => $this->loyaltyService->getCurrentStrategy()['description']
                    ],
                    'customer_tier' => $this->loyaltyService->getLoyaltyTier($customer['customer_id'])
                ]);
            } else {
                throw new Exception("Redemption failed: Unknown error occurred");
            }
        } catch (Exception $e) {
            $this->handleRedemptionApiError($e);
        }
    }

    private function getAvailableRewards() {
        try {
            $this->checkRateLimit('api_get');

            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $userPoints = $this->loyaltyService->getCustomerPoints($customer['customer_id']);
            $tier = $this->loyaltyService->getLoyaltyTier($customer['customer_id']);
            $rewards = $this->loyaltyService->getAvailableRewards($customer['customer_id']);
            $strategy = $this->loyaltyService->getCurrentStrategy();

            foreach ($rewards as &$reward) {
                $reward['estimated_orders_needed'] = $this->calculateOrdersNeeded($reward['points_required'], $userPoints);
                $reward['tier_discount_available'] = $this->calculateTierDiscount($tier, $reward['points_required']);
            }

            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'rewards' => $rewards,
                    'customer_info' => [
                        'user_points' => $userPoints,
                        'tier' => $tier,
                        'strategy' => $strategy['name'],
                        'strategy_description' => $strategy['description']
                    ],
                    'statistics' => [
                        'total_rewards' => count($rewards),
                        'affordable_rewards' => count(array_filter($rewards, function ($r) {
                                    return $r['affordable'];
                                }))
                    ]
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getAvailableRewards');
        }
    }

    private function getRedemptionHistory() {
        try {
            $this->checkRateLimit('api_get');

            $status = $_GET['status'] ?? null;
            $limit = min(50, max(1, (int) ($_GET['limit'] ?? 20)));

            $redemptions = RewardRedemption::getCustomerRedemptions($_SESSION['user_id'], $status, $limit);

            foreach ($redemptions as &$redemption) {
                $redemption['can_cancel'] = $this->canCancelRedemption($redemption);
                $redemption['usage_instructions'] = $this->getUsageInstructions($redemption);
                $redemption['time_until_expiry'] = $this->getTimeUntilExpiry($redemption['expires_at']);
            }

            $stats = RewardRedemption::getRedemptionStats($_SESSION['user_id'], 'month');

            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'redemptions' => $redemptions,
                    'statistics' => $stats,
                    'filters_applied' => [
                        'status' => $status,
                        'limit' => $limit
                    ]
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getRedemptionHistory');
        }
    }

    private function getPointsHistory() {
        try {
            $this->checkRateLimit('api_get');

            $limit = min(100, max(1, (int) ($_GET['limit'] ?? 20)));
            $type = $_GET['type'] ?? null;
            $period = $_GET['period'] ?? null;

            if ($type) {
                $transactions = LoyaltyTransaction::getTransactionsByType($_SESSION['user_id'], $type, $limit);
            } else {
                $transactions = LoyaltyTransaction::getCustomerTransactions($_SESSION['user_id'], $limit);
            }

            $stats = LoyaltyTransaction::getTransactionStats($_SESSION['user_id'], $period);
            $recentActivity = LoyaltyTransaction::getRecentActivity($_SESSION['user_id'], 30);

            $this->sendJsonResponse([
                'success' => true,
                'data' => [
                    'transactions' => $transactions,
                    'statistics' => $stats,
                    'recent_activity' => $recentActivity,
                    'strategy_info' => [
                        'name' => $this->loyaltyService->getCurrentStrategy()['name'],
                        'description' => $this->loyaltyService->getCurrentStrategy()['description']
                    ],
                    'filters_applied' => [
                        'type' => $type,
                        'period' => $period,
                        'limit' => $limit
                    ]
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getPointsHistory');
        }
    }

    private function getLoyaltySummary() {
        try {
            $this->checkRateLimit('api_get');

            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $summary = $this->loyaltyService->getCustomerLoyaltySummary($customer['customer_id']);
            $summary['tier_benefits'] = $this->getTierBenefits($summary['tier']);
            $summary['earning_potential'] = $this->calculateEarningPotential($customer['customer_id']);
            $summary['strategy_comparison'] = $this->getStrategyComparison();

            $this->sendJsonResponse([
                'success' => true,
                'data' => $summary
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'getLoyaltySummary');
        }
    }

    private function awardOrderPoints() {
        try {
            $this->checkRateLimit('api_post');
            $this->validateRequestMethod('POST');

            $customerId = $this->validateAndSanitizeInput($_POST['customer_id'] ?? null, 'int', 'customer_id');
            $orderAmount = $this->validateAndSanitizeInput($_POST['order_amount'] ?? null, 'float', 'order_amount');
            $orderId = $this->validateAndSanitizeInput($_POST['order_id'] ?? null, 'int', 'order_id');

            $orderItems = $_POST['order_items'] ?? null;
            if ($orderItems && is_string($orderItems)) {
                $orderItems = json_decode($orderItems, true);
            }

            if ($orderAmount <= 0) {
                throw new InvalidArgumentException("Order amount must be positive");
            }

            $customer = $this->customerModel->where('customer_id', '=', $customerId)
                    ->where('user_id', '=', $_SESSION['user_id'])
                    ->first();
            if (!$customer) {
                SecurityValidator::logAction($_SESSION['user_id'], 'unauthorized_points_award', [
                    'attempted_customer_id' => $customerId,
                    'order_id' => $orderId
                ]);
                throw new Exception("Unauthorized: Customer mismatch");
            }

            $result = $this->loyaltyService->awardOrderPoints($customerId, $orderAmount, $orderId, $orderItems);

            if ($result['success']) {
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => 'Points awarded successfully',
                    'data' => [
                        'points_awarded' => $result['points_added'],
                        'new_balance' => $result['new_balance'],
                        'strategy_used' => $result['strategy_used'] ?? 'Unknown',
                        'order_amount' => $orderAmount,
                        'order_id' => $orderId
                    ]
                ]);
            } else {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $result['message'] ?? 'Failed to award points'
                ]);
            }
        } catch (Exception $e) {
            $this->handleApiError($e, 'awardOrderPoints');
        }
    }

    private function setPointStrategy() {
        try {
            $this->checkRateLimit('api_post');
            $this->validateRequestMethod('POST');

            $this->validateAdminOrSpecialAccess();

            $strategyType = $this->validateAndSanitizeInput($_POST['strategy_type'] ?? null, 'string', 'strategy_type');
            $multiplier = (float) ($_POST['multiplier'] ?? 1.0);

            switch ($strategyType) {
                case 'promotion':
                    $this->loyaltyService->setPointStrategy(new PromotionPointStrategy($multiplier, "Manual Promotion"));
                    break;
                case 'platinum':
                    $this->loyaltyService->setPointStrategy(new PlatinumPointStrategy());
                    break;
                case 'gold':
                    $this->loyaltyService->setPointStrategy(new GoldPointStrategy());
                    break;
                case 'silver':
                    $this->loyaltyService->setPointStrategy(new SilverPointStrategy());
                    break;
                case 'bronze':
                case 'basic':
                default:
                    $this->loyaltyService->setPointStrategy(new BronzePointStrategy());
                    break;
            }

            $currentStrategy = $this->loyaltyService->getCurrentStrategy();

            SecurityValidator::logAction($_SESSION['user_id'], 'strategy_changed', [
                'new_strategy' => $currentStrategy['name'],
                'strategy_type' => $strategyType,
                'multiplier' => $multiplier
            ]);

            $this->sendJsonResponse([
                'success' => true,
                'message' => 'Point calculation strategy updated',
                'data' => [
                    'strategy_name' => $currentStrategy['name'],
                    'strategy_description' => $currentStrategy['description'],
                    'strategy_type' => $strategyType,
                    'multiplier' => $multiplier
                ]
            ]);
        } catch (Exception $e) {
            $this->handleApiError($e, 'setPointStrategy');
        }
    }

    private function validateSessionAndAuth() {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
            SecurityValidator::logAction('unknown', 'api_unauthorized_access', [
                'ip_address' => SecurityValidator::getClientIP(),
                'endpoint' => $_SERVER['REQUEST_URI'] ?? 'unknown'
            ]);
            $this->sendJsonResponse(['success' => false, 'message' => 'Unauthorized access'], 401);
        }

        if ($_SESSION['user_role'] !== 'customer') {
            SecurityValidator::logAction($_SESSION['user_id'], 'api_invalid_role', [
                'role' => $_SESSION['user_role'],
                'required' => 'customer'
            ]);
            $this->sendJsonResponse(['success' => false, 'message' => 'Invalid user role'], 403);
        }

        $this->validateSessionSecurity();
    }

    private function validateSessionSecurity() {
        $now = time();

        if (isset($_SESSION['last_activity']) && ($now - $_SESSION['last_activity']) > 14400) {
            SecurityValidator::logAction($_SESSION['user_id'], 'api_session_timeout', []);
            session_destroy();
            $this->sendJsonResponse(['success' => false, 'message' => 'Session expired'], 401);
        }

        $_SESSION['last_activity'] = $now;
    }

    private function initializePointStrategy() {
        try {
            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if ($customer) {
                $tier = $this->loyaltyService->getLoyaltyTier($customer['customer_id']);

                switch ($tier) {
                    case 'Platinum':
                        $strategy = new PlatinumPointStrategy();
                        break;
                    case 'Gold':
                        $strategy = new GoldPointStrategy();
                        break;
                    case 'Silver':
                        $strategy = new SilverPointStrategy();
                        break;
                    case 'Bronze':
                    default:
                        $strategy = new BronzePointStrategy();
                        break;
                }

                $this->loyaltyService->setPointStrategy($strategy);
            }
        } catch (Exception $e) {
            error_log("Error initializing point strategy: " . $e->getMessage());
            $this->loyaltyService->setPointStrategy(new BronzePointStrategy());
        }
    }

    private function setApiSecurityHeaders() {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Content-Type: application/json');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
    }

    private function validateAndSanitizeInput($input, $type, $fieldName = 'input') {
        if ($input === null || $input === '') {
            throw new InvalidArgumentException("$fieldName is required");
        }

        $validated = SecurityValidator::validateInput($input, $type);

        if ($type === 'string') {
            if (!SecurityValidator::checkXSS($validated) || !SecurityValidator::checkSQLInjection($validated)) {
                SecurityValidator::logAction($_SESSION['user_id'], 'malicious_input_detected', [
                    'field' => $fieldName,
                    'input' => substr($input, 0, 50)
                ]);
                throw new InvalidArgumentException("Invalid characters detected in $fieldName");
            }
        }

        return $validated;
    }

    private function checkRateLimit($action) {
        if (!isset($this->rateLimits[$action])) {
            return true;
        }

        $limits = $this->rateLimits[$action];

        if (!SecurityValidator::checkRateLimit($_SESSION['user_id'], $action, $limits['max'], $limits['window'])) {
            SecurityValidator::logAction($_SESSION['user_id'], 'api_rate_limit_exceeded', [
                'action' => $action,
                'limit' => $limits['max'],
                'window' => $limits['window']
            ]);
            throw new Exception("Rate limit exceeded. Please try again later.");
        }

        return true;
    }

    private function validateRequestMethod($expectedMethod) {
        $currentMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

        if ($currentMethod !== $expectedMethod) {
            SecurityValidator::logAction($_SESSION['user_id'], 'api_invalid_method', [
                'expected' => $expectedMethod,
                'received' => $currentMethod
            ]);
            throw new Exception("Invalid request method. Expected: $expectedMethod");
        }
    }

    private function generateSecureIdempotencyKey($operation, $resourceId) {
        $components = [
            $operation,
            $_SESSION['user_id'],
            $resourceId,
            date('Y-m-d-H'),
            session_id()
        ];

        return 'api_' . hash('sha256', implode('_', $components));
    }

    private function calculateOrdersNeeded($requiredPoints, $currentPoints) {
        $pointsNeeded = max(0, $requiredPoints - $currentPoints);
        if ($pointsNeeded <= 0) return 0;

        $averageOrderAmount = 25;
        $points = $this->loyaltyService->calculatePointsForOrder($averageOrderAmount);
        
        return $points > 0 ? ceil($pointsNeeded / $points) : 999;
    }

    private function calculateTierDiscount($tier, $basePoints) {
        $discounts = [
            'Diamond' => 0.15,
            'Platinum' => 0.10,
            'Gold' => 0.05,
            'Silver' => 0.02,
            'Bronze' => 0.00
        ];

        $discount = $discounts[$tier] ?? 0;
        $discountedPoints = floor($basePoints * (1 - $discount));

        return [
            'discount_percent' => $discount * 100,
            'points_saved' => $basePoints - $discountedPoints,
            'final_points' => max(1, $discountedPoints)
        ];
    }

    private function canCancelRedemption($redemption) {
        return $redemption['status'] === RewardRedemption::STATUS_ACTIVE &&
                !$redemption['is_expired'] &&
                strtotime($redemption['redeemed_at']) > (time() - 3600);
    }

    private function getUsageInstructions($redemption) {
        return [
            'Present code to staff during checkout',
            'Valid until: ' . ($redemption['formatted_expiry_date'] ?? 'N/A'),
            'Single use only',
            'Cannot be exchanged for cash'
        ];
    }

    private function getTimeUntilExpiry($expiryDate) {
        if (!$expiryDate) return null;

        $now = time();
        $expiry = strtotime($expiryDate);
        $diff = $expiry - $now;

        if ($diff <= 0) return 'Expired';
        if ($diff < 3600) return floor($diff / 60) . ' minutes';
        if ($diff < 86400) return floor($diff / 3600) . ' hours';

        return floor($diff / 86400) . ' days';
    }

    private function getTierBenefits($tier) {
        $benefits = [
            'Bronze' => ['Basic points earning', 'Access to standard rewards'],
            'Silver' => ['1.5x points earning', '2% reward discounts', 'Priority support'],
            'Gold' => ['1.8x points earning', '5% reward discounts', 'Exclusive rewards'],
            'Platinum' => ['2.0x points earning', '10% reward discounts', 'VIP events'],
            'Diamond' => ['2.5x points earning', '15% reward discounts', 'Personal account manager']
        ];

        return $benefits[$tier] ?? $benefits['Bronze'];
    }

    private function calculateEarningPotential($customerId) {
        $stats = $this->loyaltyService->getCustomerStats($customerId);
        $monthlyAverage = $stats['monthly_earned'] ?? 0;

        return [
            'monthly_average' => $monthlyAverage,
            'yearly_projection' => $monthlyAverage * 12,
            'next_tier_timeframe' => $this->calculateNextTierTime($customerId, $monthlyAverage)
        ];
    }

    private function calculateNextTierTime($customerId, $monthlyAverage) {
        $tierInfo = $this->loyaltyService->getTierInfo($customerId);

        if (!$tierInfo['next_tier'] || $monthlyAverage <= 0) {
            return 'Max tier reached or insufficient data';
        }

        $pointsNeeded = $tierInfo['points_to_next'];
        $monthsNeeded = ceil($pointsNeeded / $monthlyAverage);

        if ($monthsNeeded <= 1) return 'Less than a month';
        if ($monthsNeeded <= 12) return "$monthsNeeded months";

        $yearsNeeded = ceil($monthsNeeded / 12);
        return "$yearsNeeded year" . ($yearsNeeded > 1 ? 's' : '');
    }

    private function getStrategyComparison() {
        return $this->loyaltyService->testAllStrategies(100, null, [
            ['item_id' => 15, 'quantity' => 2, 'category' => 'coffee'],
            ['item_id' => 12, 'quantity' => 1, 'category' => 'cham']
        ]);
    }

    private function validateAdminOrSpecialAccess() {
        SecurityValidator::logAction($_SESSION['user_id'], 'strategy_change_requested', [
            'user_role' => $_SESSION['user_role']
        ]);
    }

    private function sendJsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);

        $data['metadata'] = [
            'timestamp' => date('c'),
            'request_id' => uniqid('api_'),
            'user_id' => $_SESSION['user_id'],
            'version' => '4.0',
            'service_type' => 'loyalty_api'
        ];

        echo json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
        exit;
    }

    private function handleRedemptionApiError($e) {
        SecurityValidator::logAction($_SESSION['user_id'], 'api_redemption_error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        error_log("API Redemption error: " . $e->getMessage());

        $statusCode = ($e instanceof InvalidArgumentException) ? 400 : 500;
        $this->sendJsonResponse([
            'success' => false,
            'message' => $this->getSecureErrorMessage($e),
            'error_type' => 'redemption_error'
        ], $statusCode);
    }

    private function handleApiError($e, $context = 'general') {
        SecurityValidator::logAction($_SESSION['user_id'] ?? 'unknown', 'api_error', [
            'context' => $context,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);

        error_log("LoyaltyAPI error [$context]: " . $e->getMessage());

        $statusCode = ($e instanceof InvalidArgumentException) ? 400 : 500;
        $this->sendJsonResponse([
            'success' => false,
            'message' => $this->getSecureErrorMessage($e),
            'context' => $context
        ], $statusCode);
    }

    private function handleGlobalApiError($e) {
        SecurityValidator::logAction($_SESSION['user_id'] ?? 'unknown', 'api_fatal_error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        error_log("FATAL LoyaltyAPI error: " . $e->getMessage());

        if (!headers_sent()) {
            $this->sendJsonResponse([
                'success' => false,
                'message' => 'API service temporarily unavailable. Please try again later.',
                'error_type' => 'system_error'
            ], 500);
        }
    }

    private function getSecureErrorMessage($e) {
        $message = $e->getMessage();

        $errorMappings = [
            'Customer record not found' => 'Your account information could not be verified.',
            'Rate limit exceeded' => 'Too many requests. Please wait before trying again.',
            'Invalid reward' => 'The selected reward is not available.',
            'Insufficient points' => 'You don\'t have enough points for this reward.',
            'out of stock' => 'This reward is currently out of stock.',
            'already redeemed' => 'You have already redeemed this reward recently.'
        ];

        foreach ($errorMappings as $internal => $friendly) {
            if (stripos($message, $internal) !== false) {
                return $friendly;
            }
        }

        return 'An error occurred while processing your request.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET' || 
    $_SERVER['REQUEST_METHOD'] === 'PUT' || $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    try {
        $apiController = new LoyaltyApiController();
        $apiController->handleApiRequest();
    } catch (Exception $e) {
        error_log("CRITICAL LoyaltyAPI error: " . $e->getMessage());

        if (!headers_sent()) {
            header('Content-Type: application/json', true, 500);
            echo json_encode([
                'success' => false,
                'message' => 'API service temporarily unavailable. Please try again later.',
                'timestamp' => date('c'),
                'error_type' => 'system_error'
            ]);
        }
    }
} else {
    header('Content-Type: application/json', true, 405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
}
?>