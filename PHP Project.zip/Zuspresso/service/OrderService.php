<?php

/**
 * Order Service - Web Service API
 * Author: Tang Wei Chiun
 * 
 * Exposes order functionality for consumption by other modules
 */
require_once '../model/OrderItem.php';
require_once '../model/Order.php';

class OrderService {

    private $orderItemModel;
    private $orderModel;

    public function __construct() {
        // Enable error reporting for debugging
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $this->orderItemModel = new OrderItem();
        $this->orderModel = new Order();

        // Set JSON header for all responses
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');

        // Handle preflight OPTIONS request
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }

    /**
     * Web Service: Get Order Items
     * URL: /OrderService.php?action=get_order_items&order_id=123
     * Method: GET
     * 
     * @param int order_id - Order ID (required)
     * @param int customer_id - Customer ID (optional, for validation)
     * @return JSON response with order items
     */

    public function getOrderItems() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $customerId = $this->validateInput($_GET['customer_id'] ?? null, 'int');

            if (!$orderId || $orderId <= 0) {
                $this->sendErrorResponse(400, "INVALID_ORDER_ID", "Valid order_id parameter is required");
                return;
            }

            // Optional: Validate customer ownership if customer_id provided
            if ($customerId) {
                $order = $this->orderModel->find($orderId);
                if (!$order || $order->customer_id != $customerId) {
                    $this->sendErrorResponse(403, "ACCESS_DENIED", "You don't have permission to view this order");
                    return;
                }
            }

            // Get order items using the OrderItem model
            $orderItems = $this->orderItemModel->getOrderItems($orderId);

            if (empty($orderItems)) {
                $this->sendSuccessResponse([
                    'success' => true,
                    'message' => 'No items found for this order',
                    'data' => [
                        'order_id' => $orderId,
                        'items' => [],
                        'total_items' => 0
                    ],
                    'metadata' => [
                        'service' => 'OrderService',
                        'version' => '1.0',
                        'timestamp' => date('Y-m-d H:i:s'),
                        'request_id' => uniqid('req_')
                    ]
                ]);
                return;
            }

            // Format the items for response
            $formattedItems = [];
            $totalQuantity = 0;

            foreach ($orderItems as $item) {
                // IMPORTANT: Add category to the response
                $formattedItems[] = [
                    'order_item_id' => $item['order_item_id'],
                    'item_id' => $item['item_id'],
                    'item_name' => $item['item_name'],
                    'item_price' => (float) $item['item_price'],
                    'quantity' => (int) $item['quantity'],
                    'subtotal' => (float) $item['item_price'] * (int) $item['quantity'],
                    'category' => $item['category'] ?? null, 
                    'customizations' => json_decode($item['customizations'] ?? '[]', true)
                ];
                $totalQuantity += (int) $item['quantity'];
            }

            $response = [
                'success' => true,
                'message' => 'Order items retrieved successfully',
                'data' => [
                    'order_id' => $orderId,
                    'items' => $formattedItems,
                    'total_items' => count($formattedItems),
                    'total_quantity' => $totalQuantity
                ],
                'metadata' => [
                    'service' => 'OrderService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];

            $this->sendSuccessResponse($response);
        } catch (Exception $e) {
            error_log("OrderService::getOrderItems error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve order items: " . $e->getMessage());
        }
    }

    /**
     * Web Service: Get Order Details (includes items and order info)
     * URL: /OrderService.php?action=get_order_details&order_id=123
     * Method: GET
     */
    public function getOrderDetails() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $customerId = $this->validateInput($_GET['customer_id'] ?? null, 'int');

            if (!$orderId || $orderId <= 0) {
                $this->sendErrorResponse(400, "INVALID_ORDER_ID", "Valid order_id parameter is required");
                return;
            }

            // Get order details
            $order = $this->orderModel->find($orderId);
            if (!$order) {
                $this->sendErrorResponse(404, "ORDER_NOT_FOUND", "Order not found");
                return;
            }

            // Validate customer ownership if customer_id provided
            if ($customerId && $order->customer_id != $customerId) {
                $this->sendErrorResponse(403, "ACCESS_DENIED", "You don't have permission to view this order");
                return;
            }

            // Get order items
            $orderItems = $this->orderItemModel->getOrderItems($orderId);

            // Format items
            $formattedItems = [];
            foreach ($orderItems as $item) {
                $formattedItems[] = [
                    'order_item_id' => $item['order_item_id'],
                    'item_id' => $item['item_id'],
                    'item_name' => $item['item_name'],
                    'item_price' => (float) $item['item_price'],
                    'quantity' => (int) $item['quantity'],
                    'subtotal' => (float) $item['item_price'] * (int) $item['quantity'],
                    'customizations' => json_decode($item['customizations'] ?? '[]', true)
                ];
            }

            $response = [
                'success' => true,
                'message' => 'Order details retrieved successfully',
                'data' => [
                    'order_id' => $order->order_id,
                    'customer_id' => $order->customer_id,
                    'total_amount' => (float) $order->total_amount,
                    'subtotal' => (float) $order->subtotal,
                    'tax_amount' => (float) $order->tax_amount,
                    'order_type' => $order->order_type,
                    'order_status' => $order->order_status,
                    'created_at' => $order->created_at,
                    'delivery_address' => $order->delivery_address,
                    'phone' => $order->phone,
                    'notes' => $order->notes,
                    'items' => $formattedItems,
                    'item_count' => count($formattedItems)
                ],
                'metadata' => [
                    'service' => 'OrderService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];

            $this->sendSuccessResponse($response);
        } catch (Exception $e) {
            error_log("OrderService::getOrderDetails error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve order details: " . $e->getMessage());
        }
    }

    /**
     * API Documentation endpoint
     */
    public function getDocumentation() {
        $documentation = [
            'service_name' => 'Order Service API',
            'version' => '1.0',
            'author' => 'Tang Wei Chiun',
            'description' => 'RESTful API for managing orders and order items',
            'base_url' => 'http://' . $_SERVER['HTTP_HOST'] . '/OrderService.php',
            'endpoints' => [
                [
                    'action' => 'get_order_items',
                    'method' => 'GET',
                    'url' => '/OrderService.php?action=get_order_items&order_id={id}',
                    'description' => 'Get all items for a specific order',
                    'parameters' => [
                        'order_id' => 'integer (required) - Order ID',
                        'customer_id' => 'integer (optional) - Customer ID for validation'
                    ],
                    'response' => 'JSON with order items array'
                ],
                [
                    'action' => 'get_order_details',
                    'method' => 'GET',
                    'url' => '/OrderService.php?action=get_order_details&order_id={id}',
                    'description' => 'Get complete order details including items',
                    'parameters' => [
                        'order_id' => 'integer (required) - Order ID',
                        'customer_id' => 'integer (optional) - Customer ID for validation'
                    ],
                    'response' => 'JSON with complete order information'
                ]
            ]
        ];

        $this->sendSuccessResponse($documentation);
    }

    /**
     * Input validation
     */
    private function validateInput($value, $type) {
        if ($value === null || $value === '') {
            return null;
        }

        switch ($type) {
            case 'int':
                $filtered = filter_var($value, FILTER_VALIDATE_INT);
                if ($filtered === false || $filtered < 0) {
                    return null;
                }
                return $filtered;

            default:
                return null;
        }
    }

    /**
     * Send successful JSON response
     */
    private function sendSuccessResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    /**
     * Send error JSON response
     */
    private function sendErrorResponse($statusCode, $errorCode, $message) {
        http_response_code($statusCode);
        echo json_encode([
            'success' => false,
            'error' => [
                'code' => $errorCode,
                'message' => $message,
                'status_code' => $statusCode
            ],
            'metadata' => [
                'service' => 'OrderService',
                'version' => '1.0',
                'timestamp' => date('Y-m-d H:i:s'),
                'request_id' => uniqid('req_')
            ]
                ], JSON_PRETTY_PRINT);
        exit;
    }
}

// Handle incoming requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $service = new OrderService();
    $action = $_GET['action'] ?? '';

    switch ($action) {
        case 'get_order_items':
            $service->getOrderItems();
            break;

        case 'get_order_details':
            $service->getOrderDetails();
            break;

        case 'documentation':
        case 'docs':
            $service->getDocumentation();
            break;

        default:
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => [
                    'code' => 'INVALID_ACTION',
                    'message' => 'Invalid or missing action parameter',
                    'available_actions' => ['get_order_items', 'get_order_details', 'documentation']
                ]
                    ], JSON_PRETTY_PRINT);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'METHOD_NOT_ALLOWED',
            'message' => 'Only GET method is supported'
        ]
            ], JSON_PRETTY_PRINT);
}
?>