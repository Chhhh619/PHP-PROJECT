<?php

require_once __DIR__ . '/../model/OrderManagementModel.php';

class OrderManagementService {
    private $orderModel;
    
    public function __construct() {
        $this->orderModel = new OrderManagementModel();
        
        
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        
        
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    
 
    public function getUserOrders() {
        try {
            
            $userId = $this->validateInput($_GET['user_id'] ?? null, 'int');
            $limit = $this->validateInput($_GET['limit'] ?? 10, 'int');
            $includeDetails = filter_var($_GET['include_details'] ?? 'true', FILTER_VALIDATE_BOOLEAN);
            
            if (!$userId || $userId <= 0) {
                $this->sendErrorResponse(400, "INVALID_USER_ID", "Valid user_id parameter is required");
                return;
            }
            
            if ($limit < 1 || $limit > 50) $limit = 10;
            
            
            $filters = ['customer_id' => $userId];
            $result = $this->orderModel->getAllForAdmin($filters, 1, $limit);
            
            if (empty($result['orders'])) {
                $response = [
                    'success' => true,
                    'data' => [
                        'orders' => [],
                        'total_count' => 0,
                        'total_amount_spent' => 0
                    ]
                ];
                $this->sendSuccessResponse($response);
                return;
            }
            
            $orders = [];
            $totalAmountSpent = 0;
            
            foreach ($result['orders'] as $order) {
                $orderData = [
                    'order_id' => $order->order_id,
                    'total_amount' => (float)$order->total_amount,
                    'order_status' => $order->order_status,
                    'order_type' => $order->order_type ?? 'delivery',
                    'created_at' => $order->created_at,
                    'formatted_date' => $order->getFormattedDate(),
                    'status_formatted' => $order->getStatusFormatted()
                ];
                
               
                if ($includeDetails) {
                    $orderDetails = $order->getOrderDetails();
                    $orderData['items'] = $orderDetails['items'] ?? [];
                    $orderData['subtotal'] = $orderDetails['subtotal'] ?? 0;
                    $orderData['tax_amount'] = $orderDetails['tax_amount'] ?? 0;
                }
                
                $orders[] = $orderData;
                $totalAmountSpent += (float)$order->total_amount;
            }
            
            $response = [
                'success' => true,
                'data' => [
                    'orders' => $orders,
                    'total_count' => $result['total_count'],
                    'total_amount_spent' => $totalAmountSpent
                ],
                'metadata' => [
                    'service' => 'OrderService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("OrderService::getUserOrders error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve orders: " . $e->getMessage());
        }
    }
    

    public function getCustomerAnalytics() {
        try {
            $customerId = $this->validateInput($_GET['customer_id'] ?? null, 'int');
            $startDate = $_GET['start_date'] ?? date('Y-m-01');
            $endDate = $_GET['end_date'] ?? date('Y-m-d');
            
            if (!$customerId || $customerId <= 0) {
                $this->sendErrorResponse(400, "INVALID_CUSTOMER_ID", "Valid customer_id parameter is required");
                return;
            }
            

            $sql = "
                SELECT 
                    COUNT(*) as total_orders,
                    COALESCE(SUM(total_amount), 0) as total_spent,
                    COALESCE(AVG(total_amount), 0) as avg_order_value,
                    MAX(created_at) as last_order_date,
                    COUNT(CASE WHEN order_status = 'delivered' THEN 1 END) as completed_orders
                FROM orders 
                WHERE customer_id = :customer_id 
                AND created_at >= :start_date 
                AND created_at <= :end_date
            ";
            
            $analytics = $this->orderModel->query($sql, [
                'customer_id' => $customerId,
                'start_date' => $startDate,
                'end_date' => $endDate . ' 23:59:59'
            ]);
            
            $data = $analytics[0] ?? [
                'total_orders' => 0,
                'total_spent' => 0,
                'avg_order_value' => 0,
                'last_order_date' => null,
                'completed_orders' => 0
            ];
            

            $totalOrders = (int)$data['total_orders'];
            $daysDiff = max(1, (strtotime($endDate) - strtotime($startDate)) / (60 * 60 * 24));
            $ordersPerWeek = ($totalOrders / $daysDiff) * 7;
            
            if ($ordersPerWeek >= 2) {
                $frequency = 'frequent';
            } elseif ($ordersPerWeek >= 0.5) {
                $frequency = 'regular';
            } elseif ($totalOrders > 0) {
                $frequency = 'occasional';
            } else {
                $frequency = 'no_orders';
            }
            
            $response = [
                'success' => true,
                'data' => [
                    'total_orders' => $totalOrders,
                    'total_spent' => (float)$data['total_spent'],
                    'avg_order_value' => (float)$data['avg_order_value'],
                    'last_order_date' => $data['last_order_date'],
                    'order_frequency' => $frequency,
                    'completed_orders' => (int)$data['completed_orders']
                ],
                'metadata' => [
                    'service' => 'OrderService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("OrderService::getCustomerAnalytics error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve analytics: " . $e->getMessage());
        }
    }
    

    
    public function getOrderStatus() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            
            if (!$orderId || $orderId <= 0) {
                $this->sendErrorResponse(400, "INVALID_ORDER_ID", "Valid order_id parameter is required");
                return;
            }
            
            $order = $this->orderModel->find($orderId);
            
            if (!$order) {
                $this->sendErrorResponse(404, "ORDER_NOT_FOUND", "Order not found");
                return;
            }
            
            $response = [
                'success' => true,
                'data' => [
                    'order_id' => $order->order_id,
                    'order_status' => $order->order_status,
                    'status_formatted' => $order->getStatusFormatted(),
                    'order_type' => $order->order_type,
                    'last_updated' => $order->updated_at ?? $order->created_at
                ],
                'metadata' => [
                    'service' => 'OrderService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("OrderService::getOrderStatus error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve order status: " . $e->getMessage());
        }
    }
    

    private function validateInput($value, $type, $maxLength = null) {
        if ($value === null || $value === '') {
            return null;
        }
        
        switch ($type) {
            case 'int':
                $filtered = filter_var($value, FILTER_VALIDATE_INT);
                if ($filtered === false || $filtered < 0) {
                    return null;
                }
                return $filtered;
                
            case 'string':
                $filtered = trim(strip_tags($value));
                $filtered = htmlspecialchars($filtered, ENT_QUOTES, 'UTF-8');
                
                if ($maxLength && strlen($filtered) > $maxLength) {
                    return null;
                }
                
                return $filtered;
                
            default:
                return null;
        }
    }
    

    private function sendSuccessResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    private function sendErrorResponse($statusCode, $errorCode, $message) {
        http_response_code($statusCode);
        echo json_encode([
            'success' => false,
            'error' => [
                'code' => $errorCode,
                'message' => $message,
                'status_code' => $statusCode
            ],
            'metadata' => [
                'service' => 'OrderService',
                'version' => '1.0',
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ], JSON_PRETTY_PRINT);
        exit;
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'POST') {
    $service = new OrderManagementService();
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'getUserOrders':
            $service->getUserOrders();
            break;
            
        case 'getCustomerAnalytics':
            $service->getCustomerAnalytics();
            break;
            
        case 'getOrderStatus':
            $service->getOrderStatus();
            break;
            
        default:
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => [
                    'code' => 'INVALID_ACTION',
                    'message' => 'Invalid or missing action parameter',
                    'available_actions' => ['getUserOrders', 'getCustomerAnalytics', 'getOrderStatus']
                ]
            ], JSON_PRETTY_PRINT);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'METHOD_NOT_ALLOWED',
            'message' => 'Only GET and POST methods are supported'
        ]
    ], JSON_PRETTY_PRINT);
}
?>