<?php
/**
author : Cheng Jun Yang
 */

require_once __DIR__ . '/../model/ProductReview.php';
require_once __DIR__ . '/../model/observer/ReviewObserver.php';

class ReviewService {
    private $reviewModel;
    
    public function __construct() {
        
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        
        $this->reviewModel = new ProductReview();
        
        
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *'); // Allow cross-origin requests
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }
    

    public function getItemReviews() {
        try {
           
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            $page = $this->validateInput($_GET['page'] ?? 1, 'int');
            $limit = $this->validateInput($_GET['limit'] ?? 10, 'int');
            
            if (!$itemId || $itemId <= 0) {
                $this->sendErrorResponse(400, "INVALID_ITEM_ID", "Valid item_id parameter is required");
                return;
            }
            
            if ($page < 1) $page = 1;
            if ($limit < 1 || $limit > 50) $limit = 10; 
            

            $reviews = $this->reviewModel->getReviewsPaginated($itemId, $page, $limit);
            
            
            $stats = $this->reviewModel->getCachedReviewSummary($itemId);
            
           
            $starDisplay = $this->reviewModel->generateStarDisplay($stats['average_rating']);
            
            
            $totalReviews = $stats['total_reviews'];
            $totalPages = ceil($totalReviews / $limit);
            $hasNext = $page < $totalPages;
            $hasPrevious = $page > 1;
            
           
            $response = [
                'success' => true,
                'message' => 'Reviews retrieved successfully',
                'data' => [
                    'reviews' => $reviews,
                    'statistics' => [
                        'total_reviews' => $totalReviews,
                        'average_rating' => $stats['average_rating'],
                        'rating_distribution' => [
                            '5_star' => $stats['rating_5_count'],
                            '4_star' => $stats['rating_4_count'],
                            '3_star' => $stats['rating_3_count'],
                            '2_star' => $stats['rating_2_count'],
                            '1_star' => $stats['rating_1_count']
                        ],
                        'star_display' => $starDisplay
                    ],
                    'pagination' => [
                        'current_page' => $page,
                        'per_page' => $limit,
                        'total_pages' => $totalPages,
                        'total_items' => $totalReviews,
                        'has_next' => $hasNext,
                        'has_previous' => $hasPrevious,
                        'next_page' => $hasNext ? $page + 1 : null,
                        'previous_page' => $hasPrevious ? $page - 1 : null
                    ]
                ],
                'metadata' => [
                    'service' => 'ReviewService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("ReviewService::getItemReviews error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve reviews: " . $e->getMessage());
        }
    }
    

    public function getCustomerReviews() {
        try {
            
            $customerId = $this->validateInput($_GET['customer_id'] ?? null, 'int');
            $limit = $this->validateInput($_GET['limit'] ?? 20, 'int');
            
            if (!$customerId || $customerId <= 0) {
                $this->sendErrorResponse(400, "INVALID_CUSTOMER_ID", "Valid customer_id parameter is required");
                return;
            }
            
            if ($limit < 1 || $limit > 100) $limit = 20; // Cap limit at 100
            
            
            $reviews = $this->reviewModel->getCustomerReviews($customerId, $limit);
            
            
            $customerStats = $this->calculateCustomerStats($reviews);
            
            
            $response = [
                'success' => true,
                'message' => 'Customer reviews retrieved successfully',
                'data' => [
                    'customer_id' => $customerId,
                    'reviews' => $reviews,
                    'customer_statistics' => $customerStats,
                    'total_reviews' => count($reviews)
                ],
                'metadata' => [
                    'service' => 'ReviewService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("ReviewService::getCustomerReviews error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve customer reviews: " . $e->getMessage());
        }
    }
    

    public function getReviewSummary() {
        try {
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            
            if (!$itemId || $itemId <= 0) {
                $this->sendErrorResponse(400, "INVALID_ITEM_ID", "Valid item_id parameter is required");
                return;
            }
            
            $stats = $this->reviewModel->getCachedReviewSummary($itemId);
            $starDisplay = $this->reviewModel->generateStarDisplay($stats['average_rating']);
            
            $response = [
                'success' => true,
                'message' => 'Review summary retrieved successfully',
                'data' => [
                    'item_id' => $itemId,
                    'total_reviews' => $stats['total_reviews'],
                    'average_rating' => $stats['average_rating'],
                    'star_display' => $starDisplay,
                    'rating_distribution' => [
                        '5_star' => $stats['rating_5_count'],
                        '4_star' => $stats['rating_4_count'],
                        '3_star' => $stats['rating_3_count'],
                        '2_star' => $stats['rating_2_count'],
                        '1_star' => $stats['rating_1_count']
                    ]
                ],
                'metadata' => [
                    'service' => 'ReviewService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("ReviewService::getReviewSummary error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to retrieve review summary: " . $e->getMessage());
        }
    }
    

    public function canCustomerReview() {
        try {
            $customerId = $this->validateInput($_GET['customer_id'] ?? null, 'int');
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            
            if (!$customerId || !$itemId || !$orderId) {
                $this->sendErrorResponse(400, "MISSING_PARAMETERS", "customer_id, item_id, and order_id are required");
                return;
            }
            
            $canReview = $this->reviewModel->canCustomerReview($customerId, $itemId, $orderId);
            $existingReview = $this->reviewModel->getExistingReview($customerId, $itemId, $orderId);
            
            $response = [
                'success' => true,
                'message' => 'Review permission checked successfully',
                'data' => [
                    'can_review' => $canReview,
                    'has_existing_review' => $existingReview !== null,
                    'existing_review_id' => $existingReview ? $existingReview->review_id : null,
                    'action_available' => $canReview ? ($existingReview ? 'update' : 'create') : 'none'
                ],
                'metadata' => [
                    'service' => 'ReviewService',
                    'version' => '1.0',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'request_id' => uniqid('req_')
                ]
            ];
            
            $this->sendSuccessResponse($response);
            
        } catch (Exception $e) {
            error_log("ReviewService::canCustomerReview error: " . $e->getMessage());
            $this->sendErrorResponse(500, "INTERNAL_ERROR", "Failed to check review permission: " . $e->getMessage());
        }
    }
    

    private function calculateCustomerStats($reviews) {
        if (empty($reviews)) {
            return [
                'total_reviews' => 0,
                'average_rating' => 0,
                'most_recent_review' => null,
                'review_frequency' => 'none'
            ];
        }
        
        $totalRating = 0;
        $ratingCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
        
        foreach ($reviews as $review) {
            $totalRating += $review['rating'];
            $ratingCounts[$review['rating']]++;
        }
        
        $avgRating = round($totalRating / count($reviews), 2);
        $mostRecentReview = $reviews[0] ?? null; // Assuming sorted by date DESC
        
        return [
            'total_reviews' => count($reviews),
            'average_rating' => $avgRating,
            'rating_distribution' => $ratingCounts,
            'most_recent_review' => $mostRecentReview ? $mostRecentReview['created_at'] : null
        ];
    }
    

    private function validateInput($value, $type, $maxLength = null) {
        if ($value === null || $value === '') {
            return null;
        }
        
        switch ($type) {
            case 'int':
                $filtered = filter_var($value, FILTER_VALIDATE_INT);
                if ($filtered === false || $filtered < 0) {
                    return null;
                }
                return $filtered;
                
            case 'string':
                $filtered = trim(strip_tags($value));
                $filtered = htmlspecialchars($filtered, ENT_QUOTES, 'UTF-8');
                
                if ($maxLength && strlen($filtered) > $maxLength) {
                    return null;
                }
                
                return $filtered;
                
            default:
                return null;
        }
    }
    

    private function sendSuccessResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
    

    private function sendErrorResponse($statusCode, $errorCode, $message) {
        http_response_code($statusCode);
        echo json_encode([
            'success' => false,
            'error' => [
                'code' => $errorCode,
                'message' => $message,
                'status_code' => $statusCode
            ],
            'metadata' => [
                'service' => 'ReviewService',
                'version' => '1.0',
                'timestamp' => date('Y-m-d H:i:s'),
                'request_id' => uniqid('req_')
            ]
        ], JSON_PRETTY_PRINT);
        exit;
    }
    

    public function getDocumentation() {
        $documentation = [
            'service_name' => 'Review Service API',
            'version' => '1.0',
            'author' => 'Cheng Jun Yang',
            'description' => 'RESTful API for managing product reviews and ratings',
            'base_url' => 'http://' . $_SERVER['HTTP_HOST'] . '/ReviewService.php',
            'endpoints' => [
                [
                    'action' => 'get_item_reviews',
                    'method' => 'GET',
                    'url' => '/ReviewService.php?action=get_item_reviews&item_id={id}',
                    'description' => 'Get paginated reviews for a specific item',
                    'parameters' => [
                        'item_id' => 'integer (required) - Item ID',
                        'page' => 'integer (optional) - Page number, default: 1',
                        'limit' => 'integer (optional) - Reviews per page, default: 10, max: 50'
                    ],
                    'response' => 'JSON with reviews array, statistics, and pagination info'
                ],
                [
                    'action' => 'get_customer_reviews',
                    'method' => 'GET',
                    'url' => '/ReviewService.php?action=get_customer_reviews&customer_id={id}',
                    'description' => 'Get all reviews by a specific customer',
                    'parameters' => [
                        'customer_id' => 'integer (required) - Customer ID',
                        'limit' => 'integer (optional) - Max reviews to return, default: 20, max: 100'
                    ],
                    'response' => 'JSON with customer reviews and statistics'
                ],
                [
                    'action' => 'get_review_summary',
                    'method' => 'GET',
                    'url' => '/ReviewService.php?action=get_review_summary&item_id={id}',
                    'description' => 'Get review summary statistics for an item',
                    'parameters' => [
                        'item_id' => 'integer (required) - Item ID'
                    ],
                    'response' => 'JSON with summary statistics only'
                ],
                [
                    'action' => 'can_review',
                    'method' => 'GET',
                    'url' => '/ReviewService.php?action=can_review&customer_id={cid}&item_id={iid}&order_id={oid}',
                    'description' => 'Check if customer can review an item',
                    'parameters' => [
                        'customer_id' => 'integer (required) - Customer ID',
                        'item_id' => 'integer (required) - Item ID',
                        'order_id' => 'integer (required) - Order ID'
                    ],
                    'response' => 'JSON with review permission status'
                ]
            ]
        ];
        
        $this->sendSuccessResponse($documentation);
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'POST') {
    $service = new ReviewService();
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'get_item_reviews':
            $service->getItemReviews();
            break;
            
        case 'get_customer_reviews':
            $service->getCustomerReviews();
            break;
            
        case 'get_review_summary':
            $service->getReviewSummary();
            break;
            
        case 'can_review':
            $service->canCustomerReview();
            break;
            
        case 'documentation':
        case 'docs':
            $service->getDocumentation();
            break;
            
        default:
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'error' => [
                    'code' => 'INVALID_ACTION',
                    'message' => 'Invalid or missing action parameter',
                    'available_actions' => ['get_item_reviews', 'get_customer_reviews', 'get_review_summary', 'can_review', 'documentation']
                ]
            ], JSON_PRETTY_PRINT);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'METHOD_NOT_ALLOWED',
            'message' => 'Only GET and POST methods are supported'
        ]
    ], JSON_PRETTY_PRINT);
}
?>