<?php
/**
 * Zuspresso Menu Item Web Service
 * RESTful API for Menu Items
 * 
 * @author Tang Wei Chiun
 * @module Order Management Web Service
 * @version 1.0
 * 
 * Available Endpoints:
 * GET /api/menu-items/{id} - Get single menu item by ID
 * GET /api/menu-items - Get all available menu items
 * GET /api/menu-items/category/{category} - Get items by category
 * GET /api/categories - Get all categories
 * GET /api/menu-items/search?q={query} - Search menu items
 */

// Enable CORS for cross-origin requests from teammates
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include required models
require_once '../model/BaseModel.php';
require_once '../model/MenuItem.php';

class MenuItemService {
    
    private $menuItem;
    private $requestMethod;
    private $endpoint;
    private $params;
    
    public function __construct() {
        $this->menuItem = new MenuItem();
        $this->requestMethod = $_SERVER["REQUEST_METHOD"];
        $this->parseRequest();
    }
    
    /**
     * Parse the incoming request URL
     */
    private function parseRequest() {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri = explode('/', $uri);
        
        // Find where 'api' starts in the URL
        $apiIndex = array_search('api', $uri);
        
        if ($apiIndex !== false && isset($uri[$apiIndex + 1])) {
            $this->endpoint = $uri[$apiIndex + 1];
            
            // Get additional parameters
            $this->params = array_slice($uri, $apiIndex + 2);
        }
    }
    
    /**
     * Process the API request
     */
    public function processRequest() {
        try {
            // Only allow GET requests for menu items (read-only for other modules)
            if ($this->requestMethod !== 'GET') {
                $this->sendResponse(405, [
                    'error' => 'Method not allowed',
                    'message' => 'Only GET requests are allowed for menu items'
                ]);
                return;
            }
            
            switch ($this->endpoint) {
                case 'menu-items':
                    $this->handleMenuItemsRequest();
                    break;
                    
                case 'categories':
                    $this->handleCategoriesRequest();
                    break;
                    
                default:
                    $this->sendResponse(404, [
                        'error' => 'Endpoint not found',
                        'message' => 'The requested endpoint does not exist'
                    ]);
            }
        } catch (Exception $e) {
            $this->sendResponse(500, [
                'error' => 'Internal server error',
                'message' => $e->getMessage()
            ]);
        }
    }
    
    /**
     * Handle menu items requests
     */
    private function handleMenuItemsRequest() {
        // Check if searching for specific item by ID
        if (!empty($this->params[0]) && is_numeric($this->params[0])) {
            $this->getMenuItemById($this->params[0]);
        }
        // Check if filtering by category
        elseif (!empty($this->params[0]) && $this->params[0] === 'category' && !empty($this->params[1])) {
            $this->getMenuItemsByCategory($this->params[1]);
        }
        // Check if searching
        elseif (!empty($_GET['search'])) {
            $this->searchMenuItems($_GET['search']);
        }
        // Return all menu items
        else {
            $this->getAllMenuItems();
        }
    }
    
    /**
     * Get single menu item by ID
     * GET /api/menu-items/{id}
     */
    private function getMenuItemById($itemId) {
        $item = $this->menuItem->find($itemId);
        
        if (!$item) {
            $this->sendResponse(404, [
                'error' => 'Item not found',
                'message' => "Menu item with ID {$itemId} not found"
            ]);
            return;
        }
        
        // Format response with all necessary fields for rewards module
        $response = [
            'item_id' => (int)$item->item_id,
            'name' => $item->name,
            'category' => $item->category,
            'price' => (float)$item->price,
            'description' => $item->description,
            'is_available' => (bool)$item->is_available,
            'stock_quantity' => $item->stock_quantity ? (int)$item->stock_quantity : null,
            'low_stock_threshold' => $item->low_stock_threshold ? (int)$item->low_stock_threshold : null,
            'image_path' => $item->image_path,
            'created_at' => $item->created_at,
            'updated_at' => $item->updated_at
        ];
        
        // Add computed fields that might be useful for rewards
        $response['formatted_price'] = 'RM ' . number_format($item->price, 2);
        $response['is_low_stock'] = ($item->stock_quantity && $item->low_stock_threshold) ? 
            ($item->stock_quantity <= $item->low_stock_threshold) : false;
        
        $this->sendResponse(200, $response);
    }
    
    /**
     * Get all available menu items
     * GET /api/menu-items
     */
    private function getAllMenuItems() {
        // Use ORM to get all available items
        $items = $this->menuItem
            ->where('is_available', '=', 1)
            ->orderBy('category', 'ASC')
            ->orderBy('name', 'ASC')
            ->get();
        
        $response = [
            'total_items' => count($items),
            'items' => $this->formatMenuItems($items)
        ];
        
        $this->sendResponse(200, $response);
    }
    
    /**
     * Get menu items by category
     * GET /api/menu-items/category/{category}
     */
    private function getMenuItemsByCategory($category) {
        // Decode URL-encoded category name
        $category = urldecode($category);
        
        // Use ORM to get items by category
        $items = $this->menuItem
            ->where('category', '=', $category)
            ->where('is_available', '=', 1)
            ->orderBy('name', 'ASC')
            ->get();
        
        if (empty($items)) {
            $this->sendResponse(404, [
                'error' => 'No items found',
                'message' => "No menu items found in category '{$category}'"
            ]);
            return;
        }
        
        $response = [
            'category' => $category,
            'total_items' => count($items),
            'items' => $this->formatMenuItems($items)
        ];
        
        $this->sendResponse(200, $response);
    }
    
    /**
     * Search menu items
     * GET /api/menu-items/search?q={query}
     */
    private function searchMenuItems($searchTerm) {
        // Use ORM to search items
        $items = $this->menuItem
            ->where('is_available', '=', 1)
            ->whereLike('name', '%' . $searchTerm . '%')
            ->orderBy('name', 'ASC')
            ->get();
        
        $response = [
            'search_term' => $searchTerm,
            'total_results' => count($items),
            'items' => $this->formatMenuItems($items)
        ];
        
        $this->sendResponse(200, $response);
    }
    
    /**
     * Handle categories request
     * GET /api/categories
     */
    private function handleCategoriesRequest() {
        // Get distinct categories using ORM
        $results = $this->menuItem
            ->select(['category', 'COUNT(*) as item_count'])
            ->where('is_available', '=', 1)
            ->groupBy(['category'])
            ->orderBy('category', 'ASC')
            ->get();
        
        $categories = [];
        foreach ($results as $row) {
            $categories[] = [
                'name' => $row['category'],
                'item_count' => (int)$row['item_count'],
                'display_name' => ucfirst($row['category'])
            ];
        }
        
        $response = [
            'total_categories' => count($categories),
            'categories' => $categories
        ];
        
        $this->sendResponse(200, $response);
    }
    
    /**
     * Format menu items for response
     */
    private function formatMenuItems($items) {
        $formatted = [];
        
        foreach ($items as $item) {
            $formatted[] = [
                'item_id' => (int)$item['item_id'],
                'name' => $item['name'],
                'category' => $item['category'],
                'price' => (float)$item['price'],
                'description' => $item['description'],
                'is_available' => (bool)$item['is_available'],
                'stock_quantity' => isset($item['stock_quantity']) ? (int)$item['stock_quantity'] : null,
                'formatted_price' => 'RM ' . number_format($item['price'], 2)
            ];
        }
        
        return $formatted;
    }
    
    /**
     * Send JSON response
     */
    private function sendResponse($statusCode, $data) {
        http_response_code($statusCode);
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit();
    }
}

// Initialize and process the request
$service = new MenuItemService();
$service->processRequest();
?>