<?php

/**
author : Cheng Jun Yang
 */

ob_start();


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}


function outputJson($data, $status = 200) {
    http_response_code($status);
    if (ob_get_level()) {
        ob_clean();
    }
    echo json_encode($data);
    exit;
}

try {
   
    require_once __DIR__ . '/../database.php';
    require_once __DIR__ . '/../model/BaseModel.php';
    
   
    class AuthUser extends BaseModel {
        protected $table = 'users';
        protected $primaryKey = 'user_id';
        protected $fillable = ['email', 'password_hash', 'role', 'is_active'];
        
        public function __construct() {
        
            $this->db = Database::getInstance()->getConnection();
        }
    }

    $action = $_POST['action'] ?? 'login';
    
    if ($action === 'logout') {
        session_destroy();
        header("Location: /Zuspresso/index.php");
        exit;
    }
    
    
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        outputJson(['success' => false, 'message' => 'Email and password are required']);
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        outputJson(['success' => false, 'message' => 'Invalid email format']);
    }
    
 
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
        outputJson(['success' => false, 'message' => 'Invalid security token']);
    }
    
    
    $userModel = new AuthUser();
    
   
    $user = $userModel->select([
        'u.user_id', 'u.email', 'u.password_hash', 'u.role', 'u.is_active',
        'c.first_name', 'c.last_name', 'c.customer_id',
        'a.admin_name', 'a.admin_id'
    ])
    ->from('users u')
    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
    ->where('u.email', '=', $email)
    ->where('u.is_active', '=', 1)
    ->first();
    
    if (!$user) {
        outputJson(['success' => false, 'message' => 'Invalid email or password']);
    }
    
   
    if (!password_verify($password, $user['password_hash'])) {
        outputJson(['success' => false, 'message' => 'Invalid email or password']);
    }
    
 
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['login_time'] = time();
    $_SESSION['authenticated'] = true;
    
    
    if ($user['role'] === 'admin') {
        $_SESSION['admin_id'] = $user['admin_id'];
        $_SESSION['display_name'] = $user['admin_name'] ?: 'Admin';
        
        
        $adminModel = new class extends BaseModel {
            protected $table = 'admins';
            protected $primaryKey = 'admin_id';
            
            public function __construct() {
                $this->db = Database::getInstance()->getConnection();
            }
        };
        
        $adminModel->updateById($user['admin_id'], ['last_login' => date('Y-m-d H:i:s')]);
        
        $redirect_url = '/Zuspresso/view/admin/admin_dashboard.php';
        
    } elseif ($user['role'] === 'customer') {
        $_SESSION['customer_id'] = $user['customer_id'];
        $_SESSION['display_name'] = trim($user['first_name'] . ' ' . $user['last_name']) ?: 'Customer';
        
        $redirect_url = '/Zuspresso/view/user/dashboard.php';
        
    } else {
        outputJson(['success' => false, 'message' => 'Invalid user role']);
    }
    
  
    try {
        $authLogModel = new class extends BaseModel {
            protected $table = 'auth_logs';
            protected $fillable = ['user_id', 'email', 'action', 'ip_address', 'user_agent'];
            
            public function __construct() {
                $this->db = Database::getInstance()->getConnection();
            }
        };
        
        $authLogModel->create([
            'user_id' => $user['user_id'],
            'email' => $email,
            'action' => 'login_success',
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
    } catch (Exception $e) {
     
        error_log("Login logging failed: " . $e->getMessage());
    }
    
 
    outputJson([
        'success' => true,
        'message' => 'Login successful!',
        'redirect' => $redirect_url,
        'user' => [
            'id' => $user['user_id'],
            'email' => $user['email'],
            'role' => $user['role'],
            'display_name' => $_SESSION['display_name']
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Auth error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    outputJson(['success' => false, 'message' => 'Authentication system error: ' . $e->getMessage()]);
}
?>