<?php
/**
 * Menu Management Controller 
 * 
 */


ob_start();


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


header('Content-Type: application/json');

try {
    
    require_once '../model/MenuItem.php';
    require_once '../model/User.php';
    require_once '../model/Admin.php';
    require_once '../model/UserFactory.php';
    require_once '../database.php';

    
    if (ob_get_level()) {
        ob_clean();
    }

    
    $menuController = new MenuController();
    $menuController->handleRequest();
    
} catch (Exception $e) {
    error_log("Menu Controller had a hiccup: " . $e->getMessage());
    
    if (ob_get_level()) {
        ob_clean();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Something went wrong with the menu system: ' . $e->getMessage()
    ]);
}

class MenuController {
    private $adminInfo;
    private $imageUploadPath;
    private $imageWebPath;
    
    public function __construct() {
        
        $this->ensureAdminCanManageMenu();
        
        $this->imageUploadPath = '../assets/itemImage/';
        $this->imageWebPath = 'assets/itemImage/';
        
        $this->ensureUploadDirectoryExists();
    }
    
    
    public function handleRequest() {
        $action = $_GET['action'] ?? $_POST['action'] ?? '';
        
        switch ($action) {
            case 'create':
                $this->addDeliciousNewMenuItem();
                break;
            case 'update':
                $this->updateExistingMenuItem();
                break;
            case 'delete':
                $this->removeMenuItemSafely();
                break;
            case 'get':
                $this->getSpecificMenuItem();
                break;
            case 'list':
                $this->getAllMenuItemsWithFilters();
                break;
            case 'toggle_availability':
                $this->toggleItemAvailability();
                break;
            case 'check_permission':
                $this->checkUserPermissions();
                break;
            default:
                $this->sendErrorResponse('Unknown action requested', 400);
        }
    }
    
    
    private function ensureAdminCanManageMenu() {
      
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
            $this->sendErrorResponse('Please log in to manage the menu', 401, '/Zuspresso/index.php');
        }
        
        
        if ($_SESSION['user_role'] !== 'admin') {
            $this->sendErrorResponse('Only admins can manage menu items', 403);
        }
        
        
        try {
            $database = Database::getInstance()->getConnection();
            $userFactory = new UserFactory($database);
            $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);
            
            if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
                $this->sendErrorResponse('Invalid admin session - please log in again', 401);
            }
            
           
            if (!$currentAdmin->hasPermission('menu_management')) {
                $this->sendErrorResponse('You need menu management permissions to do this', 403);
            }
            
            
            $this->adminInfo = [
                'admin_id' => $currentAdmin->getAdminId(),
                'admin_name' => $currentAdmin->getAdminName()
            ];
            
        } catch (Exception $e) {
            error_log("Admin validation hiccup: " . $e->getMessage());
            $this->sendErrorResponse('Error checking admin permissions', 500);
        }
    }
    

    private function ensureUploadDirectoryExists() {
        if (!file_exists($this->imageUploadPath)) {
            mkdir($this->imageUploadPath, 0755, true);
        }
    }
    

    private function processImageUpload($fileInputName) {
       
        if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        
        $uploadedFile = $_FILES[$fileInputName];
        
       
        if ($uploadedFile['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Image upload failed: ' . $this->getHumanFriendlyUploadError($uploadedFile['error']));
        }
        
       
        $allowedImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($uploadedFile['type'], $allowedImageTypes)) {
            throw new Exception('Please upload a valid image file (JPEG, PNG, GIF, or WebP)');
        }
        
       
        $maxSizeInBytes = 5 * 1024 * 1024; // 5MB should be plenty for a menu item photo
        if ($uploadedFile['size'] > $maxSizeInBytes) {
            throw new Exception('Image too large! Please keep it under 5MB to help our site load quickly.');
        }
        
        $fileExtension = pathinfo($uploadedFile['name'], PATHINFO_EXTENSION);
        $uniqueFilename = 'menu_' . uniqid() . '_' . time() . '.' . strtolower($fileExtension);
        $fullFilePath = $this->imageUploadPath . $uniqueFilename;
        
        if (!move_uploaded_file($uploadedFile['tmp_name'], $fullFilePath)) {
            throw new Exception('Failed to save the uploaded image. Please try again.');
        }
        
 
        return $this->imageWebPath . $uniqueFilename;
    }
    

    private function deleteImageFile($imagePath) {
        if ($imagePath && file_exists('../' . $imagePath)) {
            unlink('../' . $imagePath);
        }
    }
    

    private function getHumanFriendlyUploadError($errorCode) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File is too large (server limit)',
            UPLOAD_ERR_FORM_SIZE => 'File is too large (form limit)',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded - please try again',
            UPLOAD_ERR_NO_TMP_DIR => 'Server configuration error - missing temp folder',
            UPLOAD_ERR_CANT_WRITE => 'Server cannot write file to disk',
            UPLOAD_ERR_EXTENSION => 'File upload blocked by server extension'
        ];
        
        return $errorMessages[$errorCode] ?? 'Unknown upload error occurred';
    }
    

    private function checkUserPermissions() {
        $this->sendSuccessResponse([
            'message' => 'Menu management access confirmed!',
            'admin_name' => $this->adminInfo['admin_name'],
            'admin_id' => $this->adminInfo['admin_id']
        ]);
    }


    private function addDeliciousNewMenuItem() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendErrorResponse('Menu item creation requires a POST request', 405);
        }
        
        try {
            
            $newItemData = [
                'name' => trim($_POST['name'] ?? ''),
                'description' => trim($_POST['description'] ?? ''),
                'price' => floatval($_POST['price'] ?? 0),
                'category' => trim($_POST['category'] ?? ''),
                'is_available' => isset($_POST['is_available']) ? 1 : 0,
                'stock_quantity' => intval($_POST['stock_quantity'] ?? 100),
                'low_stock_threshold' => intval($_POST['low_stock_threshold'] ?? 10)
            ];
            
           
            $imagePath = null;
            try {
                $imagePath = $this->processImageUpload('image');
                if ($imagePath) {
                    $newItemData['image_path'] = $imagePath;
                }
            } catch (Exception $e) {
                $this->sendErrorResponse('Image upload issue: ' . $e->getMessage());
            }
            
           
            $menuItem = new MenuItem();
            $createdItem = $menuItem->create($newItemData);
            
            if ($createdItem) {
                $this->sendSuccessResponse([
                    'message' => 'New menu item added successfully! Your customers will love it.',
                    'item' => $createdItem->toArray()
                ]);
            } else {
                
                if ($imagePath) {
                    $this->deleteImageFile($imagePath);
                }
                $this->sendErrorResponse('Failed to save the new menu item to database');
            }
            
        } catch (Exception $e) {
            error_log("Error creating menu item: " . $e->getMessage());
            $this->sendErrorResponse('Could not create menu item: ' . $e->getMessage());
        }
    }

  
    private function updateExistingMenuItem() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendErrorResponse('Menu item updates require a POST request', 405);
        }
        
        try {
            $itemId = intval($_POST['item_id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendErrorResponse('Valid item ID required for updates');
            }
            
            
            $menuItem = new MenuItem();
            $existingItem = $menuItem->find($itemId);
            
            if (!$existingItem) {
                $this->sendErrorResponse('Could not find that menu item to update');
            }
            
            
            $updateData = [];
            
            if (isset($_POST['name']) && !empty(trim($_POST['name']))) {
                $updateData['name'] = trim($_POST['name']);
            }
            if (isset($_POST['description']) && !empty(trim($_POST['description']))) {
                $updateData['description'] = trim($_POST['description']);
            }
            if (isset($_POST['price']) && is_numeric($_POST['price'])) {
                $updateData['price'] = floatval($_POST['price']);
            }
            if (isset($_POST['category']) && !empty(trim($_POST['category']))) {
                $updateData['category'] = trim($_POST['category']);
            }
            if (isset($_POST['is_available'])) {
                $updateData['is_available'] = $_POST['is_available'] ? 1 : 0;
            }
            if (isset($_POST['stock_quantity']) && is_numeric($_POST['stock_quantity'])) {
                $updateData['stock_quantity'] = intval($_POST['stock_quantity']);
            }
            if (isset($_POST['low_stock_threshold']) && is_numeric($_POST['low_stock_threshold'])) {
                $updateData['low_stock_threshold'] = intval($_POST['low_stock_threshold']);
            }
            
           
            $oldImagePath = $existingItem->image_path;
            try {
                $newImagePath = $this->processImageUpload('image');
                if ($newImagePath) {
                    $updateData['image_path'] = $newImagePath;
                }
            } catch (Exception $e) {
                $this->sendErrorResponse('Image upload issue: ' . $e->getMessage());
            }
            
            if (empty($updateData)) {
                $this->sendErrorResponse('No valid updates provided');
            }
            
           
            $updatedItem = $existingItem->update($updateData);
            
            if ($updatedItem) {
                
                if (isset($updateData['image_path']) && $oldImagePath) {
                    $this->deleteImageFile($oldImagePath);
                }
                
                $this->sendSuccessResponse([
                    'message' => 'Menu item updated successfully!',
                    'item' => $updatedItem->toArray()
                ]);
            } else {
              
                if (isset($updateData['image_path'])) {
                    $this->deleteImageFile($updateData['image_path']);
                }
                $this->sendErrorResponse('Failed to save menu item updates');
            }
            
        } catch (Exception $e) {
            error_log("Error updating menu item: " . $e->getMessage());
            $this->sendErrorResponse('Could not update menu item: ' . $e->getMessage());
        }
    }


    private function removeMenuItemSafely() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendErrorResponse('Menu item deletion requires a POST request', 405);
        }
        
        try {
            $itemId = intval($_POST['item_id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendErrorResponse('Valid item ID required for deletion');
            }
            
           
            $menuItem = new MenuItem();
            $existingItem = $menuItem->find($itemId);
            
            if (!$existingItem) {
                $this->sendErrorResponse('Could not find that menu item to delete');
            }
            
           
            $orderItemsCount = $menuItem
                ->select('COUNT(*) as order_count')
                ->from('order_items')
                ->where('item_id', $itemId)
                ->first();
            
            $hasBeenOrdered = ($orderItemsCount['order_count'] ?? 0) > 0;
            
            if ($hasBeenOrdered) {
                
                $existingItem->update(['is_available' => 0]);
                
                $this->sendSuccessResponse([
                    'message' => 'Item marked as unavailable since it appears in order history',
                    'soft_delete' => true
                ]);
            } else {
               
                $imagePath = $existingItem->image_path;
                
                if ($existingItem->delete()) {
                    
                    if ($imagePath) {
                        $this->deleteImageFile($imagePath);
                    }
                    
                    $this->sendSuccessResponse([
                        'message' => 'Menu item completely removed from system!'
                    ]);
                } else {
                    $this->sendErrorResponse('Failed to delete menu item from database');
                }
            }
            
        } catch (Exception $e) {
            error_log("Error deleting menu item: " . $e->getMessage());
            $this->sendErrorResponse('Could not delete menu item: ' . $e->getMessage());
        }
    }

   
    private function getSpecificMenuItem() {
        try {
            $itemId = intval($_GET['item_id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendErrorResponse('Valid item ID required');
            }
            
            // Find the item using ORM
            $menuItem = new MenuItem();
            $item = $menuItem->find($itemId);
            
            if ($item) {
                $this->sendSuccessResponse([
                    'item' => $item->toArray()
                ]);
            } else {
                $this->sendErrorResponse('Could not find that menu item');
            }
            
        } catch (Exception $e) {
            error_log("Error getting menu item: " . $e->getMessage());
            $this->sendErrorResponse('Could not retrieve menu item: ' . $e->getMessage());
        }
    }

    
    private function getAllMenuItemsWithFilters() {
        try {
            
            $page = max(1, intval($_GET['page'] ?? 1));
            $itemsPerPage = min(50, max(5, intval($_GET['limit'] ?? 10))); 
            
            $filters = [];
            
            
            if (!empty($_GET['category'])) {
                $filters['category'] = trim($_GET['category']);
            }
            
            
            if (isset($_GET['availability']) && $_GET['availability'] !== '') {
                $filters['availability'] = intval($_GET['availability']);
            }
            
           
            if (!empty($_GET['search'])) {
                $filters['search'] = trim($_GET['search']);
            }
            
            
            $result = MenuItem::getWithFilters($filters, $page, $itemsPerPage);
            
            $this->sendSuccessResponse([
                'items' => $result['items'],
                'pagination' => $result['pagination']
            ]);
            
        } catch (Exception $e) {
            error_log("Error listing menu items: " . $e->getMessage());
            $this->sendErrorResponse('Could not load menu items: ' . $e->getMessage());
        }
    }

    
    private function toggleItemAvailability() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendErrorResponse('Availability toggle requires a POST request', 405);
        }
        
        try {
            $itemId = intval($_POST['item_id'] ?? 0);
            
            if ($itemId <= 0) {
                $this->sendErrorResponse('Valid item ID required');
            }
            
            
            $menuItem = new MenuItem();
            $existingItem = $menuItem->find($itemId);
            
            if (!$existingItem) {
                $this->sendErrorResponse('Could not find that menu item');
            }
            
            
            $newAvailability = $existingItem->is_available ? 0 : 1;
            $updatedItem = $existingItem->update(['is_available' => $newAvailability]);
            
            if ($updatedItem) {
                $statusWord = $newAvailability ? 'available' : 'unavailable';
                $this->sendSuccessResponse([
                    'message' => "Item marked as {$statusWord}!",
                    'item' => $updatedItem->toArray()
                ]);
            } else {
                $this->sendErrorResponse('Failed to update item availability');
            }
            
        } catch (Exception $e) {
            error_log("Error toggling availability: " . $e->getMessage());
            $this->sendErrorResponse('Could not toggle availability: ' . $e->getMessage());
        }
    }
    
    
    private function sendSuccessResponse($data) {
        if (ob_get_level()) {
            ob_clean();
        }
        
        echo json_encode(array_merge(['success' => true], $data));
        exit;
    }
    
    
    private function sendErrorResponse($message, $statusCode = 400, $redirectUrl = null) {
        if (ob_get_level()) {
            ob_clean();
        }
        
        http_response_code($statusCode);
        
        $response = [
            'success' => false,
            'message' => $message
        ];
        
        if ($redirectUrl) {
            $response['redirect'] = $redirectUrl;
        }
        
        echo json_encode($response);
        exit;
    }
}


exit;
?>