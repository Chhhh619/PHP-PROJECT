<?php

/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun & Tan Cheng Hong (Rewards Integration)
 * @module Order Management with Complete Rewards Integration
 * @version 2.2 - Fixed Discount Calculation and Order Totals
 */
session_start();
require_once '../model/BaseModel.php';
require_once '../model/Customer.php';
require_once '../model/CartModel.php';
require_once '../model/OrderModel.php';
require_once '../model/MenuItem.php';
require_once '../model/LoyaltyService.php';
require_once '../model/RewardRedemption.php';
require_once '../model/Reward.php';
require_once '../model/SecurityValidator.php';
require_once '../model/OutputSecurity.php';
require_once '../model/OrderState.php';

class OrderController {

    private $cartModel;
    private $orderModel;
    private $menuItemModel;
    private $loyaltyService;

    public function __construct() {
        $this->cartModel = new CartModel();
        $this->orderModel = new OrderModel();
        $this->menuItemModel = new MenuItem();
        $this->loyaltyService = new LoyaltyService();
    }

    public function handleRequest() {
        // Check session
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
            $this->sendJsonResponse(['success' => false, 'message' => 'Unauthorized access'], 401);
            return;
        }

        $action = $_POST['action'] ?? $_GET['action'] ?? '';

        try {
            switch ($action) {
                case 'add_to_cart':
                    $this->addToCart();
                    break;
                case 'update_cart':
                    $this->updateCart();
                    break;
                case 'remove_from_cart':
                    $this->removeFromCart();
                    break;
                case 'clear_cart':
                    $this->clearCart();
                    break;
                case 'get_cart':
                    $this->getCart();
                    break;
                case 'place_order':
                    $this->placeOrder();
                    break;
                case 'get_available_vouchers':
                    $this->getAvailableVouchers();
                    break;
                case 'apply_voucher':
                    $this->applyVoucher();
                    break;
                case 'remove_voucher':
                    $this->removeVoucher();
                    break;
                case 'get_free_items':
                    $this->getFreeItems();
                    break;
                case 'add_free_item_to_cart':
                    $this->addFreeItemToCart();
                    break;
                case 'confirm_received':
                    $this->confirmOrderReceived();
                    break;
                case 'submit_review':
                    $this->submitReview();
                    break;
                case 'submit_feedback':
                    $this->submitFeedback();
                    break;
                case 'update_order_status':
                    $this->updateOrderStatus();
                    break;
                case 'get_order_state':
                    $this->getOrderStateInfo();
                    break;
                default:
                    $this->sendJsonResponse(['success' => false, 'message' => 'Invalid action: ' . $action], 400);
            }
        } catch (Exception $e) {
            $this->sendJsonResponse([
                'success' => false,
                'message' => $e->getMessage()
                    ], 500);
        }
    }

    private function getCart() {
        $cartItems = $_SESSION['cart'] ?? [];
        $cartTotals = $this->getCartTotals();

        $this->sendJsonResponse([
            'success' => true,
            'cart_items' => $cartItems,
            'cart_totals' => $cartTotals
        ]);
    }

    private function addToCart() {
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $quantity = (int) ($_POST['quantity'] ?? 1);
        $customizations = $_POST['customizations'] ?? '[]';

        if ($itemId <= 0 || $quantity <= 0) {
            throw new Exception('Invalid item ID or quantity');
        }

        // Get item details from database
        $item = $this->menuItemModel->find($itemId);
        if (!$item || !$item->is_available) {
            throw new Exception('Item not found or not available');
        }

        // Initialize cart session if not exists
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Create cart key
        $cartKey = 'item_' . $itemId . '_' . md5(json_encode($customizations));

        // Add or update item in session cart
        if (isset($_SESSION['cart'][$cartKey])) {
            $_SESSION['cart'][$cartKey]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$cartKey] = [
                'item_id' => $item->item_id,
                'name' => $item->name,
                'price' => $item->price,
                'category' => $item->category,
                'quantity' => $quantity,
                'customizations' => json_decode($customizations, true) ?: [],
                'added_at' => time()
            ];
        }

        // Calculate updated cart totals
        $cartTotals = $this->getCartTotals();

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Item added to cart successfully',
            'cart_totals' => $cartTotals
        ]);
    }

    private function updateCart() {
        $cartKey = $_POST['cart_key'] ?? '';
        $quantity = (int) ($_POST['quantity'] ?? 0);

        if (empty($cartKey)) {
            throw new Exception('Invalid cart key');
        }

        if (!isset($_SESSION['cart'][$cartKey])) {
            throw new Exception('Cart item not found');
        }

        if ($quantity <= 0) {
            unset($_SESSION['cart'][$cartKey]);
        } else {
            $_SESSION['cart'][$cartKey]['quantity'] = $quantity;
        }

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Cart updated successfully'
        ]);
    }

    private function removeFromCart() {
        $cartKey = $_POST['cart_key'] ?? '';

        if (empty($cartKey)) {
            throw new Exception('Invalid cart key');
        }

        if (isset($_SESSION['cart'][$cartKey])) {
            unset($_SESSION['cart'][$cartKey]);
        }

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Item removed from cart'
        ]);
    }

    private function clearCart() {
        $_SESSION['cart'] = [];
        unset($_SESSION['applied_voucher']);

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Cart cleared successfully'
        ]);
    }

    private function getAvailableVouchers() {
        $customer = Customer::getByUserId($_SESSION['user_id']);
        if (!$customer) {
            throw new Exception("Customer not found");
        }

        // Get active redemptions that can be used as vouchers
        $redemptions = RewardRedemption::getCustomerRedemptions($_SESSION['user_id']);
        $availableVouchers = [];

        foreach ($redemptions as $redemption) {
            if ($redemption['status'] === 'active' &&
                    (!$redemption['expires_at'] || strtotime($redemption['expires_at']) > time())) {

                $availableVouchers[] = [
                    'redemption_id' => $redemption['redemption_id'],
                    'redemption_code' => $redemption['redemption_code'],
                    'reward_name' => $redemption['reward_name'],
                    'reward_type' => $redemption['reward_type'],
                    'reward_value' => $redemption['reward_value'],
                    'expires_at' => $redemption['expires_at']
                ];
            }
        }

        $this->sendJsonResponse([
            'success' => true,
            'vouchers' => $availableVouchers
        ]);
    }

    private function getFreeItems() {
        $voucherCode = $_POST['voucher_code'] ?? '';

        if (empty($voucherCode)) {
            throw new Exception('Voucher code is required');
        }

        // Validate voucher
        $voucher = $this->loyaltyService->validateRedemptionCode($voucherCode);
        if (!$voucher) {
            throw new Exception('Invalid or expired voucher code');
        }

        // Check if voucher belongs to current user
        if ($voucher['customer_id'] != $_SESSION['user_id']) {
            throw new Exception('This voucher does not belong to you');
        }

        // Get reward details
        $reward = Reward::getById($voucher['reward_id']);
        if (!$reward || $reward['reward_type'] !== 'free_item') {
            throw new Exception('This voucher is not for free items');
        }

        // Get menu items that can be free
        $freeItems = [];
        $menuItems = MenuItem::getAvailable();

        foreach ($menuItems as $item) {
            if (in_array($item['category'], ['coffee', 'tea', 'frappe']) && $item['price'] <= 15.00) {
                $freeItems[] = [
                    'item_id' => $item['item_id'],
                    'name' => $item['name'],
                    'description' => $item['description'],
                    'price' => $item['price'],
                    'category' => $item['category']
                ];
            }
        }

        $this->sendJsonResponse([
            'success' => true,
            'free_items' => $freeItems,
            'voucher' => $voucher
        ]);
    }

    private function applyVoucher() {
        $redemptionCode = $_POST['redemption_code'] ?? '';

        if (empty($redemptionCode)) {
            throw new Exception('Voucher code is required');
        }

        // Validate voucher
        $voucher = $this->loyaltyService->validateRedemptionCode($redemptionCode);
        if (!$voucher) {
            throw new Exception('Invalid or expired voucher code');
        }

        // Check if voucher belongs to current user
        if ($voucher['customer_id'] != $_SESSION['user_id']) {
            throw new Exception('This voucher does not belong to you');
        }

        // Get reward details
        $reward = Reward::getById($voucher['reward_id']);
        if (!$reward) {
            throw new Exception('Reward not found');
        }

        // Handle different reward types
        if ($reward['reward_type'] === 'free_item') {
            throw new Exception('Please select a free item first');
        }

        // Calculate discount
        $cartTotals = $this->getCartTotals();
        $discount = 0;

        if ($reward['reward_type'] === 'discount') {
            $discount = $cartTotals['subtotal'] * ($reward['reward_value'] / 100);
        } elseif ($reward['reward_type'] === 'voucher') {
            $discount = min($reward['reward_value'], $cartTotals['subtotal']);
        }

        // Store voucher information
        $_SESSION['applied_voucher'] = [
            'redemption_code' => $redemptionCode,
            'redemption_id' => $voucher['redemption_id'],
            'reward_id' => $reward['reward_id'],
            'reward_name' => $reward['name'],
            'reward_type' => $reward['reward_type'],
            'reward_value' => $reward['reward_value'],
            'calculated_discount' => $discount,
            'voucher_data' => $voucher
        ];

        // Recalculate totals with discount applied
        $newCartTotals = $this->getCartTotals();

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Voucher applied successfully',
            'reward_type' => $reward['reward_type'],
            'discount' => $discount,
            'new_totals' => $newCartTotals
        ]);
    }

    private function addFreeItemToCart() {
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $redemptionCode = $_POST['redemption_code'] ?? '';

        if ($itemId <= 0 || empty($redemptionCode)) {
            throw new Exception('Invalid item ID or voucher code');
        }

        // Validate voucher again
        $voucher = $this->loyaltyService->validateRedemptionCode($redemptionCode);
        if (!$voucher || $voucher['customer_id'] != $_SESSION['user_id']) {
            throw new Exception('Invalid voucher');
        }

        // Get item details
        $item = $this->menuItemModel->find($itemId);
        if (!$item) {
            throw new Exception('Item not found');
        }

        // Add free item to cart
        $cartKey = 'free_' . $itemId . '_' . time();

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        $_SESSION['cart'][$cartKey] = [
            'item_id' => $item->item_id,
            'name' => $item->name . ' (FREE)',
            'price' => 0.00,
            'original_price' => $item->price,
            'category' => $item->category,
            'quantity' => 1,
            'customizations' => [],
            'is_free_item' => true,
            'voucher_code' => $redemptionCode,
            'added_at' => time()
        ];

        // Store the voucher as used for free item
        $_SESSION['applied_voucher'] = [
            'redemption_code' => $redemptionCode,
            'redemption_id' => $voucher['redemption_id'],
            'reward_name' => 'Free ' . $item->name,
            'reward_type' => 'free_item',
            'free_item_id' => $itemId,
            'calculated_discount' => 0,
            'voucher_data' => $voucher
        ];

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Free item added to cart successfully'
        ]);
    }

    private function removeVoucher() {
        // Remove applied voucher
        unset($_SESSION['applied_voucher']);

        // Remove any free items from cart
        if (isset($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $key => $item) {
                if (isset($item['is_free_item']) && $item['is_free_item']) {
                    unset($_SESSION['cart'][$key]);
                }
            }
        }

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Voucher removed successfully'
        ]);
    }

    private function getCartTotals() {
        $cart = $_SESSION['cart'] ?? [];
        $subtotal = 0;
        $itemCount = 0;

        foreach ($cart as $item) {
            $subtotal += $item['price'] * $item['quantity'];
            $itemCount += $item['quantity'];
        }

        $discount = 0;

        // Apply voucher discount if available
        if (isset($_SESSION['applied_voucher'])) {
            $appliedVoucher = $_SESSION['applied_voucher'];

            if ($appliedVoucher['reward_type'] === 'discount') {
                $discount = $subtotal * ($appliedVoucher['reward_value'] / 100);
            } elseif ($appliedVoucher['reward_type'] === 'voucher') {
                $discount = min($appliedVoucher['reward_value'], $subtotal);
            }
        }

        $discountedSubtotal = $subtotal - $discount;
        $taxRate = 0.06; // 6% SST
        $tax = $discountedSubtotal * $taxRate;
        $total = $discountedSubtotal + $tax;

        return [
            'original_subtotal' => round($subtotal, 2),
            'discount' => round($discount, 2),
            'subtotal' => round($discountedSubtotal, 2),
            'tax' => round($tax, 2),
            'total' => round($total, 2),
            'item_count' => $itemCount,
            'has_discount' => $discount > 0
        ];
    }

    private function placeOrder() {
        // Validate cart
        $cartItems = $_SESSION['cart'] ?? [];
        if (empty($cartItems)) {
            throw new Exception('Cart is empty');
        }

        // Get customer
        $customer = Customer::getByUserId($_SESSION['user_id']);
        if (!$customer) {
            throw new Exception('Customer not found');
        }

        // Calculate totals
        $cartTotals = $this->getCartTotals();
        $originalSubtotal = $cartTotals['original_subtotal'];
        $discount = $cartTotals['discount'];
        $finalSubtotal = $cartTotals['subtotal'];
        $finalTax = $cartTotals['tax'];
        $finalTotal = $cartTotals['total'];

        $usedVoucher = null;
        $voucherCode = null;

        if (isset($_SESSION['applied_voucher'])) {
            $usedVoucher = $_SESSION['applied_voucher'];
            $voucherCode = $usedVoucher['redemption_code'];
        }

        // Add delivery fee if delivery
        $orderType = $_POST['order_type'] ?? 'delivery';
        $deliveryFee = 0;
        if ($orderType === 'delivery') {
            $deliveryFee = 3.00;
            $finalTotal += $deliveryFee;
        }

        // Prepare order data
        $orderData = [
            'customer_id' => $_SESSION['user_id'],
            'total_amount' => $finalTotal,
            'subtotal' => $finalSubtotal,
            'tax_amount' => $finalTax,
            'delivery_fee' => $deliveryFee,
            'discount_amount' => $discount,
            'voucher_code' => $voucherCode,
            'order_type' => $orderType,
            'delivery_address' => $_POST['delivery_address'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'notes' => $_POST['notes'] ?? '',
            'payment_method' => $_POST['payment_method'] ?? 'cash',
            'order_status' => 'pending'
        ];

        try {
            // Begin transaction
            $this->orderModel->beginTransaction();

            // Create order
            $orderId = $this->createSimpleOrder($orderData, $cartItems);
            if (!$orderId) {
                throw new Exception('Failed to create order');
            }

            // Mark voucher as used if one was applied
            if ($usedVoucher && isset($usedVoucher['redemption_code'])) {
                $this->loyaltyService->useRedemptionCode($usedVoucher['redemption_code']);
            }

            // Award loyalty points for the order
            $pointsEarned = $this->awardLoyaltyPoints($customer->customer_id, $finalSubtotal, $orderId);

            // Clear cart and applied vouchers
            $_SESSION['cart'] = [];
            unset($_SESSION['applied_voucher']);

            $this->orderModel->commit();

            $this->sendJsonResponse([
                'success' => true,
                'message' => 'Order placed successfully',
                'order_id' => $orderId,
                'points_earned' => $pointsEarned,
                'final_total' => $finalTotal,
                'discount_applied' => $discount
            ]);
        } catch (Exception $e) {
            $this->orderModel->rollback();
            throw $e;
        }
    }

    private function createSimpleOrder($orderData, $cartItems) {
        $sql = "INSERT INTO orders (
            customer_id, total_amount, subtotal, tax_amount, delivery_fee, 
            discount_amount, voucher_code, order_type, delivery_address, 
            phone, notes, payment_method, order_status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->orderModel->getDb()->prepare($sql);
        $result = $stmt->execute([
            $orderData['customer_id'],
            $orderData['total_amount'],
            $orderData['subtotal'],
            $orderData['tax_amount'],
            $orderData['delivery_fee'],
            $orderData['discount_amount'],
            $orderData['voucher_code'],
            $orderData['order_type'],
            $orderData['delivery_address'],
            $orderData['phone'],
            $orderData['notes'],
            $orderData['payment_method'],
            $orderData['order_status']
        ]);

        if (!$result) {
            throw new Exception("Failed to create order");
        }

        $orderId = $this->orderModel->getDb()->lastInsertId();

        // Insert order items
        foreach ($cartItems as $item) {
            $subtotal = $item['price'] * $item['quantity'];

            $itemSql = "INSERT INTO order_items (
                order_id, item_id, item_name, item_price, quantity, 
                subtotal, is_free_item, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";

            $itemStmt = $this->orderModel->getDb()->prepare($itemSql);
            $itemResult = $itemStmt->execute([
                $orderId,
                $item['item_id'],
                $item['name'],
                $item['price'],
                $item['quantity'],
                $subtotal,
                isset($item['is_free_item']) ? 1 : 0
            ]);

            if (!$itemResult) {
                throw new Exception("Failed to create order items");
            }
        }

        return $orderId;
    }

    private function awardLoyaltyPoints($customerId, $orderAmount, $orderId) {
        try {
            $cartItems = $_SESSION['cart'] ?? [];
            $orderItems = [];

            foreach ($cartItems as $item) {
                $orderItems[] = [
                    'item_id' => $item['item_id'],
                    'category' => $item['category'] ?? 'unknown',
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'name' => $item['name']
                ];
            }

            $result = $this->loyaltyService->awardOrderPoints($customerId, $orderAmount, $orderId, $orderItems);

            if ($result && $result['success']) {
                return $result['points_added'];
            }

            return 0;
        } catch (Exception $e) {
            error_log("Failed to award loyalty points for order {$orderId}: " . $e->getMessage());
            return 0;
        }
    }

    private function confirmOrderReceived() {
        $orderId = (int) ($_POST['order_id'] ?? 0);

        if ($orderId <= 0) {
            throw new Exception('Invalid order ID');
        }

        try {
            // Use State Pattern to transition to delivered
            $orderContext = new OrderContext($orderId);

            // Check if current state allows transition to delivered
            if (!$orderContext->getNextPossibleStates() ||
                    !in_array('delivered', $orderContext->getNextPossibleStates())) {
                throw new Exception('Order cannot be marked as received in current state');
            }

            // Transition to delivered state
            $result = $orderContext->transitionTo('delivered');

            if ($result) {
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => 'Order confirmed as received'
                ]);
            } else {
                throw new Exception('Failed to confirm order receipt');
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    private function submitReview() {
        $orderId = (int) ($_POST['order_id'] ?? 0);
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $rating = (int) ($_POST['rating'] ?? 0);
        $reviewText = $_POST['review_text'] ?? '';

        if ($orderId <= 0 || $itemId <= 0 || $rating < 1 || $rating > 5) {
            throw new Exception('Invalid review data');
        }

        // Insert review
        $sql = "INSERT INTO product_reviews (customer_id, order_id, item_id, rating, review_text, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())";

        $stmt = $this->orderModel->getDb()->prepare($sql);
        $success = $stmt->execute([$_SESSION['user_id'], $orderId, $itemId, $rating, $reviewText]);

        if (!$success) {
            throw new Exception('Failed to submit review');
        }

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Review submitted successfully'
        ]);
    }

    private function submitFeedback() {
        $orderId = (int) ($_POST['order_id'] ?? 0);
        $feedbackText = trim($_POST['feedback_text'] ?? '');

        // Validate order ID
        if ($orderId <= 0) {
            throw new Exception('Invalid order ID');
        }

        // Validate feedback text is not empty
        if (empty($feedbackText)) {
            throw new Exception('Feedback cannot be empty. Please provide your feedback.');
        }

        // Minimum length validation
        if (strlen($feedbackText) < 10) {
            throw new Exception('Please provide more detailed feedback (at least 10 characters).');
        }

        // Maximum length validation to prevent abuse
        if (strlen($feedbackText) > 1000) {
            throw new Exception('Feedback is too long. Please limit to 1000 characters.');
        }

        // Insert feedback
        $sql = "INSERT INTO order_feedback (customer_id, order_id, feedback_text, created_at) 
                VALUES (?, ?, ?, NOW())";

        $stmt = $this->orderModel->getDb()->prepare($sql);
        $success = $stmt->execute([$_SESSION['user_id'], $orderId, $feedbackText]);

        if (!$success) {
            throw new Exception('Failed to submit feedback');
        }

        $this->sendJsonResponse([
            'success' => true,
            'message' => 'Feedback submitted successfully'
        ]);
    }

    private function sendJsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    private function updateOrderStatus() {
        $orderId = (int) ($_POST['order_id'] ?? 0);
        $newStatus = $_POST['new_status'] ?? '';

        if ($orderId <= 0 || empty($newStatus)) {
            throw new Exception('Invalid order ID or status');
        }

        // Use State Pattern to handle status transition
        $result = OrderStateManager::updateOrderStatus($orderId, $newStatus);

        if ($result) {
            $this->sendJsonResponse([
                'success' => true,
                'message' => 'Order status updated successfully'
            ]);
        } else {
            throw new Exception('Invalid status transition');
        }
    }

    private function getOrderStateInfo() {
        $orderId = (int) ($_GET['order_id'] ?? 0);

        if ($orderId <= 0) {
            throw new Exception('Invalid order ID');
        }

        $stateInfo = OrderStateManager::getOrderStateInfo($orderId);

        if ($stateInfo) {
            $this->sendJsonResponse([
                'success' => true,
                'state_info' => $stateInfo
            ]);
        } else {
            throw new Exception('Could not get order state');
        }
    }
}

// Handle the request
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new OrderController();
    $controller->handleRequest();
}
?>