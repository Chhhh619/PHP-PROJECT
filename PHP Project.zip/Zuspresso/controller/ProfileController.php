<?php
/**
author : Cheng Jun Yang
 */
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'customer') {
    header('Location: ../view/auth/login.php');
    exit;
}

require_once '../model/Customer.php';
require_once '../model/BaseModel.php';
require_once '../database.php';


class UserModel extends BaseModel {
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['email', 'password_hash', 'role', 'is_active'];
    
    public function __construct($database_connection = null) {
        if ($database_connection) {
            $this->db = $database_connection;
            $this->resetQuery();
        } else {
            parent::__construct();
        }
    }
    
  
    private function resetQuery() {
        $this->selectColumns = ['*'];
        $this->whereConditions = [];
        $this->joinClauses = [];
        $this->orderByClause = '';
        $this->limitClause = '';
        $this->groupByClause = '';
        $this->havingConditions = [];
        $this->queryParams = [];
        $this->currentTable = $this->table;
        return $this;
    }
}

class ProfileController {
    private $customerModel;
    private $userModel;
    private $db;
    private $user_id;
    private $redirectUrl = '../view/user/EditProfile.php';
    
    public function __construct() {
      
        $this->db = Database::getInstance()->getConnection();
        $this->user_id = $_SESSION['user_id'];
        
 
        $this->customerModel = new CustomerModel($this->db);
        $this->userModel = new UserModel($this->db);
    }
    
    public function handleRequest() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('error=invalid_request');
        }
        
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'update_profile':
                $this->updateProfile();
                break;
            default:
                $this->redirect('error=invalid_action');
        }
    }
    
    private function updateProfile() {
        try {
         
            $this->customerModel->beginTransaction();
            
        
            $firstName = trim($_POST['first_name'] ?? '');
            $lastName = trim($_POST['last_name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
         
            if (!$this->validateProfileData($firstName, $lastName, $phone)) {
                $this->customerModel->rollback();
                return;
            }
            
         
            $customerData = [
                'first_name' => $firstName,
                'last_name' => $lastName,
                'phone' => $phone ?: null
            ];
            
            $profileUpdateSuccess = $this->customerModel
                ->where('user_id', '=', $this->user_id)
                ->updateWhere($customerData);
            
            if (!$profileUpdateSuccess) {
                $this->customerModel->rollback();
                $this->redirect('error=update_failed');
            }
            
          
            $passwordUpdateSuccess = true;
            if (!empty($currentPassword) && !empty($newPassword)) {
                $passwordUpdateSuccess = $this->updatePassword($currentPassword, $newPassword, $confirmPassword);
                
                if (!$passwordUpdateSuccess) {
                    $this->customerModel->rollback();
                    return; 
                }
            }
            
     
            $this->customerModel->commit();
            
         
            if (!empty($newPassword) && $passwordUpdateSuccess) {
                $this->redirect('success=password_updated');
            } else {
                $this->redirect('success=profile_updated');
            }
            
        } catch (Exception $e) {
   
            if ($this->customerModel->inTransaction()) {
                $this->customerModel->rollback();
            }
            
            error_log("Profile update error: " . $e->getMessage());
            $this->redirect('error=update_failed&debug=' . urlencode($e->getMessage()));
        }
    }
    
    private function validateProfileData($firstName, $lastName, $phone) {
   
        if (empty($firstName) || empty($lastName)) {
            $this->redirect('error=invalid_name');
            return false;
        }
        
        if (!preg_match('/^[a-zA-Z\s\'-]{2,50}$/', $firstName) || 
            !preg_match('/^[a-zA-Z\s\'-]{2,50}$/', $lastName)) {
            $this->redirect('error=invalid_name');
            return false;
        }
        
     
        if (!empty($phone)) {
            $cleanPhone = preg_replace('/\D/', '', $phone);
            if (strlen($cleanPhone) < 10 || strlen($cleanPhone) > 15) {
                $this->redirect('error=invalid_phone');
                return false;
            }
        }
        
        return true;
    }
    
    private function updatePassword($currentPassword, $newPassword, $confirmPassword) {
        try {
          
            if ($newPassword !== $confirmPassword) {
                $this->redirect('error=password_mismatch');
                return false;
            }
            
         
            $user = $this->userModel
                ->select(['password_hash'])
                ->where('user_id', '=', $this->user_id)
                ->first();
            
            if (!$user || !password_verify($currentPassword, $user['password_hash'])) {
                $this->redirect('error=current_password_incorrect');
                return false;
            }
            
           
            if (!$this->isPasswordSecure($newPassword)) {
                $this->redirect('error=password_insecure');
                return false;
            }
            
       
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $result = $this->userModel
                ->where('user_id', '=', $this->user_id)
                ->updateWhere(['password_hash' => $hashedPassword]);
            
            return $result;
            
        } catch (Exception $e) {
            error_log("Password update error: " . $e->getMessage());
            $this->redirect('error=update_failed&debug=' . urlencode($e->getMessage()));
            return false;
        }
    }
    
    private function isPasswordSecure($password) {
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
    }
    
    private function redirect($params = '') {
        $url = $this->redirectUrl;
        if (!empty($params)) {
            $url .= '?' . $params;
        }
        header("Location: $url");
        exit;
    }
}


try {
    $controller = new ProfileController();
    $controller->handleRequest();
} catch (Exception $e) {
    error_log("ProfileController error: " . $e->getMessage());
    header('Location: ../view/user/EditProfile.php?error=system_error&debug=' . urlencode($e->getMessage()));
    exit;
}