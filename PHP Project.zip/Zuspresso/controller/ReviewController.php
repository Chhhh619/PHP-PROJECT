<?php
/**
author : Cheng Jun Yang
 */


require_once __DIR__ . '/../model/ProductReview.php';
require_once __DIR__ . '/../model/observer/ReviewObserver.php';

class ReviewController {

    private $reviewModel;
    private $reviewManager;
    private $orderServiceUrl; 

    public function __construct() {
        session_start();

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        $this->reviewModel = new ProductReview();
        $this->reviewManager = new ReviewManager($this->reviewModel);
        
      
        $this->orderServiceUrl = "http://localhost/Zuspresso/service/OrderService.php";
    }

   
    private function getOrderItemsFromOrderService($orderId, $customerId) {
        try {
          
            $apiUrl = $this->orderServiceUrl . "?action=get_order_items&order_id=" . $orderId . "&customer_id=" . $customerId;
            
            error_log("Calling OrderService API: " . $apiUrl);
            
          
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Accept: application/json'
            ]);
            
        
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            
            error_log("OrderService API Response - HTTP Code: $httpCode");
            error_log("OrderService API Response Body: " . $response);
            
            if ($curlError) {
                error_log("cURL Error: " . $curlError);
                return null;
            }
            
            if ($httpCode === 200) {
                $data = json_decode($response, true);
                if ($data && $data['success']) {
                    return $data['data'];
                }
            }
            
            return null;
            
        } catch (Exception $e) {
            error_log("Error calling OrderService API: " . $e->getMessage());
            return null;
        }
    }

   
    public function showOrderItemsForReviewWithAPI() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $customerId = $this->getCustomerId();

            if (!$orderId || !$customerId) {
                throw new Exception("Invalid order ID or customer not logged in");
            }

   
            error_log("Getting order items from OrderService for order_id: $orderId, customer_id: $customerId");
            
            $orderData = $this->getOrderItemsFromOrderService($orderId, $customerId);
            
            if (!$orderData) {
                throw new Exception("Could not retrieve order items from OrderService. Please make sure the order exists and belongs to you.");
            }
            
            $orderItems = $orderData['items'];
            error_log("Retrieved " . count($orderItems) . " items from OrderService");
            
            if (empty($orderItems)) {
                $items = [];
            } else {
        
                $items = [];
                foreach ($orderItems as $orderItem) {
               
                    $existingReview = $this->reviewModel->getExistingReview(
                        $customerId, 
                        $orderItem['item_id'], 
                        $orderId
                    );
                    
                  
                    $items[] = [
                        'item_id' => $orderItem['item_id'],
                        'item_name' => $orderItem['item_name'],
                        'item_price' => $orderItem['item_price'],
                        'quantity' => $orderItem['quantity'],
                        'subtotal' => $orderItem['subtotal'],
                        'customizations' => $orderItem['customizations'],
                        // Review information
                        'review_id' => $existingReview ? $existingReview->review_id : null,
                        'rating' => $existingReview ? $existingReview->rating : null,
                        'review_text' => $existingReview ? $existingReview->review_text : null,
                        // Indicate this came from API
                        'data_source' => 'OrderService API'
                    ];
                }
            }

            $pageTitle = "Rate Your Order Items";

         
            include __DIR__ . '/../view/user/review_order_items.php';
            
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

   
    public function showReviewFormWithAPI() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            $customerId = $this->getCustomerId();

            if (!$orderId || !$itemId || !$customerId) {
                throw new Exception("Missing required parameters: orderId=$orderId, itemId=$itemId, customerId=$customerId");
            }

           
            $orderData = $this->getOrderItemsFromOrderService($orderId, $customerId);
            
            if (!$orderData) {
                throw new Exception("Could not validate order through OrderService API");
            }
            
           
            $orderItem = null;
            foreach ($orderData['items'] as $item) {
                if ($item['item_id'] == $itemId) {
                    $orderItem = $item;
                    break;
                }
            }
            
            if (!$orderItem) {
                throw new Exception("Item not found in this order");
            }

           
            if (!$this->reviewModel->canCustomerReview($customerId, $itemId, $orderId)) {
                throw new Exception("You are not authorized to review this item. Make sure you have purchased this item and the order is delivered.");
            }

          
            $existingReview = [];
            $existingReviewObj = $this->reviewModel->getExistingReview($customerId, $itemId, $orderId);
            if ($existingReviewObj) {
                $existingReview = $existingReviewObj->toArray();
            }

            
            $itemDetails = [
                'item_name' => $orderItem['item_name'],
                'item_price' => $orderItem['item_price'],
                'quantity' => $orderItem['quantity'],
                'subtotal' => $orderItem['subtotal'],
                'customizations' => $orderItem['customizations'],
                'api_validated' => true // Indicator that this was validated through API
            ];

            $csrfToken = $this->generateCSRFToken();
            $pageTitle = "Write a Review ";

          
            include __DIR__ . '/../view/user/add_review.php';
            
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    
    public function submitReviewWithAPI() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception("Invalid request method");
            }

            $this->validateCSRFToken();

            $data = $this->validateReviewData($_POST);
            $customerId = $this->getCustomerId();

            if (!$customerId) {
                throw new Exception("Customer not logged in");
            }

        
            $orderData = $this->getOrderItemsFromOrderService($data['order_id'], $customerId);
            
            if (!$orderData) {
                throw new Exception("Could not validate order through OrderService API");
            }
            
          
            $itemFound = false;
            foreach ($orderData['items'] as $item) {
                if ($item['item_id'] == $data['item_id']) {
                    $itemFound = true;
                    error_log("Item {$data['item_id']} found in order {$data['order_id']} via OrderService API");
                    break;
                }
            }
            
            if (!$itemFound) {
                throw new Exception("Item validation failed through OrderService API. This item does not exist in the specified order.");
            }

            $data['customer_id'] = $customerId;

          
            if (!$this->reviewModel->canCustomerReview($customerId, $data['item_id'], $data['order_id'])) {
                throw new Exception("You are not authorized to review this item");
            }

        
            $existingReview = $this->reviewModel->getExistingReview($customerId, $data['item_id'], $data['order_id']);

            if ($existingReview) {
              
                $this->reviewModel->updateById($existingReview->review_id, $data);
                $message = "Review updated successfully!";
            } else {
             
                $this->reviewModel->create($data);
                $message = "Review submitted successfully!";
            }

        
            $this->redirect("ReviewController.php?action=show_order_items_api&order_id=" . $data['order_id'] . "&success=" . urlencode($message));
            
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

   
    public function showOrderItemsForReview() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $customerId = $this->getCustomerId();

            if (!$orderId || !$customerId) {
                throw new Exception("Invalid order ID or customer not logged in");
            }

            $items = $this->reviewModel->getOrderItemsForReview($orderId, $customerId);

            if (empty($items)) {
                $items = [];
            }

            $pageTitle = "Rate Your Order Items";

            include __DIR__ . '/../view/user/review_order_items.php';
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    public function showReviewForm() {
        try {
            $orderId = $this->validateInput($_GET['order_id'] ?? null, 'int');
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            $customerId = $this->getCustomerId();

            if (!$orderId || !$itemId || !$customerId) {
                throw new Exception("Missing required parameters: orderId=$orderId, itemId=$itemId, customerId=$customerId");
            }

            if (!$this->reviewModel->canCustomerReview($customerId, $itemId, $orderId)) {
                throw new Exception("You are not authorized to review this item. Make sure you have purchased this item and the order is delivered.");
            }

            $existingReview = [];
            $existingReviewObj = $this->reviewModel->getExistingReview($customerId, $itemId, $orderId);
            if ($existingReviewObj) {
                $existingReview = $existingReviewObj->toArray();
            }

            $itemDetails = $this->getItemDetails($itemId, $orderId);
            if (!$itemDetails) {
                $itemDetails = [
                    'item_name' => 'Unknown Item',
                    'item_price' => 0,
                    'quantity' => 1
                ];
            }

            $csrfToken = $this->generateCSRFToken();
            $pageTitle = "Write a Review";

            include __DIR__ . '/../view/user/add_review.php';
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    public function submitReview() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception("Invalid request method");
            }

            $this->validateCSRFToken();

            $data = $this->validateReviewData($_POST);
            $customerId = $this->getCustomerId();

            if (!$customerId) {
                throw new Exception("Customer not logged in");
            }

            $data['customer_id'] = $customerId;

            if (!$this->reviewModel->canCustomerReview($customerId, $data['item_id'], $data['order_id'])) {
                throw new Exception("You are not authorized to review this item");
            }

            $existingReview = $this->reviewModel->getExistingReview($customerId, $data['item_id'], $data['order_id']);

            if ($existingReview) {
                $this->reviewModel->updateById($existingReview->review_id, $data);
                $message = "Review updated successfully!";
            } else {
                $this->reviewModel->create($data);
                $message = "Review submitted successfully!";
            }

            $this->redirect("ReviewController.php?action=show_order_items&order_id=" . $data['order_id'] . "&success=" . urlencode($message));
        } catch (Exception $e) {
            $this->handleError($e->getMessage());
        }
    }

    public function getItemReviews() {
        try {
            $itemId = $this->validateInput($_GET['item_id'] ?? null, 'int');
            $limit = $this->validateInput($_GET['limit'] ?? 10, 'int');
            $page = $this->validateInput($_GET['page'] ?? 1, 'int');

            if (!$itemId) {
                throw new Exception("Item ID is required");
            }

            $reviews = $this->reviewModel->getReviewsPaginated($itemId, $page, $limit);
            $stats = $this->reviewModel->getCachedReviewSummary($itemId);
            $starDisplay = $this->reviewModel->generateStarDisplay($stats['average_rating']);

            $response = [
                'success' => true,
                'reviews' => $reviews,
                'statistics' => $stats,
                'star_display' => $starDisplay,
                'current_page' => $page,
                'per_page' => $limit,
                'total_reviews' => $stats['total_reviews']
            ];

            header('Content-Type: application/json');
            echo json_encode($response);
        } catch (Exception $e) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function getCustomerReviews() {
        try {
            $customerId = $this->getCustomerId();
            $limit = $this->validateInput($_GET['limit'] ?? null, 'int');

            if (!$customerId) {
                throw new Exception("Customer not logged in");
            }

            $reviews = $this->reviewModel->getCustomerReviews($customerId, $limit);

            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'reviews' => $reviews]);
                return;
            }

            $pageTitle = "My Reviews";
            include __DIR__ . '/../view/user/customer_reviews.php';
        } catch (Exception $e) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            } else {
                $this->handleError($e->getMessage());
            }
        }
    }

    
    private function validateReviewData($data) {
        $validated = [];

        $validated['order_id'] = $this->validateInput($data['order_id'] ?? null, 'int');
        $validated['item_id'] = $this->validateInput($data['item_id'] ?? null, 'int');
        $validated['rating'] = $this->validateInput($data['rating'] ?? null, 'int');

        if (!$validated['order_id'] || !$validated['item_id'] || !$validated['rating']) {
            throw new Exception("Order ID, Item ID, and Rating are required");
        }

        if ($validated['rating'] < 1 || $validated['rating'] > 5) {
            throw new Exception("Rating must be between 1 and 5");
        }

        $validated['review_text'] = $this->validateInput($data['review_text'] ?? '', 'string', 1000);

        return $validated;
    }

    private function validateInput($value, $type, $maxLength = null) {
        if ($value === null || $value === '') {
            return null;
        }

        switch ($type) {
            case 'int':
                $filtered = filter_var($value, FILTER_VALIDATE_INT);
                if ($filtered === false || $filtered < 0) {
                    throw new Exception("Invalid integer value");
                }
                return $filtered;

            case 'string':
                $filtered = trim(strip_tags($value));
                $filtered = htmlspecialchars($filtered, ENT_QUOTES, 'UTF-8');

                if ($maxLength && strlen($filtered) > $maxLength) {
                    throw new Exception("Text exceeds maximum length of $maxLength characters");
                }

                return $filtered;

            default:
                throw new Exception("Invalid validation type");
        }
    }

    private function getCustomerId() {
        return $_SESSION['user_id'] ?? null;
    }

    private function isAdmin() {
        return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
    }

    private function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    private function validateCSRFToken() {
        $token = $_POST['csrf_token'] ?? '';

        if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
            throw new Exception("Invalid CSRF token");
        }
    }

    private function getItemDetails($itemId, $orderId) {
        try {
            return $this->reviewModel->select(['item_name', 'item_price', 'quantity'])
                            ->from('order_items')
                            ->where('item_id', $itemId)
                            ->where('order_id', $orderId)
                            ->first();
        } catch (Exception $e) {
            return null;
        }
    }

    private function handleError($message) {
        $_SESSION['error_message'] = $message;

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => $message]);
            exit();
        }

        echo "<div style='padding: 20px; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;'>";
        echo "<h3>Error</h3>";
        echo "<p>" . htmlspecialchars($message) . "</p>";
        echo "<a href='javascript:history.back()'>Go Back</a>";
        echo "</div>";
    }

    private function redirect($url) {
        header("Location: $url");
        exit();
    }
}

if (isset($_GET['action'])) {
    $controller = new ReviewController();
    $action = $_GET['action'];

    switch ($action) {
        case 'show_order_items':
            $controller->showOrderItemsForReview();
            break;
        case 'show_form':
            $controller->showReviewForm();
            break;
        case 'submit':
            $controller->submitReview();
            break;
        case 'get_reviews':
            $controller->getItemReviews();
            break;
        case 'delete':
            $controller->deleteReview();
            break;
        case 'customer_reviews':
            $controller->getCustomerReviews();
            break;
    
        case 'show_order_items_api':
            $controller->showOrderItemsForReviewWithAPI();
            break;
        case 'show_form_api':
            $controller->showReviewFormWithAPI();
            break;
        case 'submit_api':
            $controller->submitReviewWithAPI();
            break;
        default:
            header("HTTP/1.0 404 Not Found");
            echo "Action not found";
    }
} 

?>