<?php
/**
 * Reports Controller for Zuspresso Admin
 */

ob_start();
session_start();

header('Content-Type: application/json');


error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

try {
    
    require_once '../model/BaseModel.php';
    require_once '../model/User.php';
    require_once '../model/Admin.php';
    require_once '../model/UserFactory.php';
    require_once '../model/ReportsModel.php';
    require_once '../database.php';

    
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
        throw new Exception('Unauthorized access');
    }

    
    $db = Database::getInstance()->getConnection();
    $userFactory = new UserFactory($db);
    $currentAdmin = $userFactory->createUserById($_SESSION['user_id']);
    
    if (!$currentAdmin || !($currentAdmin instanceof Admin)) {
        throw new Exception('Invalid admin session');
    }
    
   
    if (!$currentAdmin->hasPermission('reports')) {
        throw new Exception('Access denied - insufficient permissions');
    }

    
    $reportsModel = new ReportsModel();
    
   
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    
    ob_clean();
    
    
    switch ($action) {
        case 'dashboard_summary':
            getDashboardSummary($reportsModel);
            break;
            
        case 'get_report_data':
            getReportData($reportsModel);
            break;
            
        default:
            throw new Exception('Invalid action: ' . $action);
    }

} catch (Exception $e) {
    ob_clean();
    error_log("ReportsController Error: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}


function getDashboardSummary($reportsModel) {
    try {
        $summary = $reportsModel->getDashboardSummary();
        
        echo json_encode([
            'success' => true,
            'data' => $summary
        ]);
        
    } catch (Exception $e) {
        throw new Exception('Failed to get dashboard summary: ' . $e->getMessage());
    }
}


function getReportData($reportsModel) {
    try {
        
        $reportType = $_POST['report_type'] ?? 'summary';
        $startDate = $_POST['start_date'] ?? date('Y-m-01');
        $endDate = $_POST['end_date'] ?? date('Y-m-d');
        $groupBy = $_POST['group_by'] ?? 'day';
        
        $responseData = [];
        
        
        switch ($reportType) {
            case 'summary':
            case 'sales':
                $responseData['salesReport'] = $reportsModel->getSalesReport($startDate, $endDate, $groupBy);
                $responseData['bestSellingProducts'] = $reportsModel->getBestSellingProducts($startDate, $endDate, 10);
                break;
                
            case 'products':
                $responseData['bestSellingProducts'] = $reportsModel->getBestSellingProducts($startDate, $endDate, 20);
                $responseData['categoryPerformance'] = $reportsModel->getCategoryPerformance($startDate, $endDate);
                break;
                
            case 'trends':
                $responseData['orderTrends'] = $reportsModel->getOrderTrends($startDate, $endDate);
                break;
                
            case 'customers':
                $responseData['customerAnalytics'] = $reportsModel->getCustomerAnalytics($startDate, $endDate);
                break;
                
            default:
               
                $responseData['salesReport'] = $reportsModel->getSalesReport($startDate, $endDate, $groupBy);
                $responseData['bestSellingProducts'] = $reportsModel->getBestSellingProducts($startDate, $endDate, 10);
                $responseData['orderTrends'] = $reportsModel->getOrderTrends($startDate, $endDate);
                break;
        }
        
        echo json_encode([
            'success' => true,
            'data' => $responseData
        ]);
        
    } catch (Exception $e) {
        throw new Exception('Failed to get report data: ' . $e->getMessage());
    }
}
?>