<?php
/**
 * Order Management Controller 
 * 
 */

ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (isset($_GET['ajax']) || isset($_POST['ajax']) || 
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) {
    header('Content-Type: application/json');
}

try {
    require_once '../model/OrderManagementModel.php';
    require_once '../model/User.php';
    require_once '../model/Admin.php';
    require_once '../model/UserFactory.php';
    require_once '../database.php';

    class OrderManagementController {
        private $orderModel;
        private $currentAdmin;
        private $db;
        
        public function __construct() {
            try {
                $this->db = Database::getInstance()->getConnection();
                $this->orderModel = new OrderManagementModel();
                $this->authenticateAdmin();
            } catch (Exception $e) {
                error_log("OrderManagementController initialization error: " . $e->getMessage());
                
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'System error. Please try again.'
                    ]);
                } else {
                    $this->redirectWithError("System error occurred.");
                }
            }
        }
        
        private function authenticateAdmin() {
            // Check if user is logged in and has admin role
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Authentication required',
                        'redirect' => '../auth/login.php'
                    ], 401);
                } else {
                    header('Location: ../auth/login.php');
                    exit();
                }
            }
            
            try {
                $userFactory = new UserFactory($this->db);
                $this->currentAdmin = $userFactory->createUserById($_SESSION['user_id']);
                
                if (!$this->currentAdmin || !($this->currentAdmin instanceof Admin)) {
                    session_destroy();
                    if ($this->isAjaxRequest()) {
                        $this->sendJsonResponse([
                            'success' => false,
                            'message' => 'Invalid session',
                            'redirect' => '../auth/login.php'
                        ], 403);
                    } else {
                        header('Location: ../auth/login.php');
                        exit();
                    }
                }
                
            } catch (Exception $e) {
                error_log("Admin authentication error: " . $e->getMessage());
                session_destroy();
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Access validation failed'
                    ], 500);
                } else {
                    header('Location: ../auth/login.php');
                    exit();
                }
            }
        }
        
        public function handleRequest() {
            $action = $_GET['action'] ?? $_POST['action'] ?? 'get_orders';
            
            try {
                switch ($action) {
                    case 'check_permission':
                        $this->checkPermission();
                        break;
                    case 'get_orders':
                        $this->getOrders();
                        break;
                    case 'get_order_details':
                        $this->getOrderDetails();
                        break;
                    case 'update_order_status':
                        $this->updateOrderStatus();
                        break;
                    case 'bulk_update_status':
                        $this->bulkUpdateStatus();
                        break;
                    case 'get_order_stats':
                        $this->getOrderStats();
                        break;
                    default:
                        $this->getOrders();
                }
            } catch (Exception $e) {
                error_log("Request handling error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false, 
                    'message' => 'Error: ' . $e->getMessage()
                ], 500);
            }
        }
        
        
        private function checkPermission() {
            try {
                
                $hasPermission = $this->currentAdmin->hasPermission('order_management');
                
                if ($hasPermission) {
                    $this->sendJsonResponse([
                        'success' => true,
                        'message' => 'Permission granted',
                        'admin_name' => $this->currentAdmin->getAdminName(),
                        'permissions' => $this->currentAdmin->getPermissions()
                    ]);
                } else {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Access denied - You do not have permission to manage orders. Contact your administrator.',
                        'redirect' => '../../view/admin/admin_dashboard.php'
                    ], 403);
                }
                
            } catch (Exception $e) {
                error_log("Permission check error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Unable to verify permissions. Please try again.'
                ], 500);
            }
        }
        

        private function getOrders() {
            // Verify permission first
            if (!$this->currentAdmin->hasPermission('order_management')) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Access denied - insufficient permissions'
                ], 403);
                return;
            }
            
            try {
                $filters = [
                    'status' => $_GET['status'] ?? 'all',
                    'search' => $_GET['search'] ?? '',
                ];
                $page = (int)($_GET['page'] ?? 1);
                $limit = (int)($_GET['limit'] ?? 20);
                
                $result = $this->orderModel->getAllForAdmin($filters, $page, $limit);
                
                
                $ordersArray = [];
                foreach ($result['orders'] as $order) {
                    $ordersArray[] = $order->toArray();
                }
                
                $this->sendJsonResponse([
                    'success' => true,
                    'orders' => $ordersArray,
                    'pagination' => [
                        'current_page' => $result['current_page'],
                        'total_pages' => $result['total_pages'],
                        'total_count' => $result['total_count'],
                        'per_page' => $result['per_page'],
                        'has_prev' => $result['current_page'] > 1,
                        'has_next' => $result['current_page'] < $result['total_pages']
                    ]
                ]);
                
            } catch (Exception $e) {
                error_log("Get orders error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Failed to load orders: ' . $e->getMessage()
                ]);
            }
        }
        
       
        private function getOrderDetails() {
            if (!$this->currentAdmin->hasPermission('order_management')) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Access denied - insufficient permissions'
                ], 403);
                return;
            }
            
            try {
                $orderId = $_GET['order_id'] ?? null;
                
                if (!$orderId || !is_numeric($orderId)) {
                    throw new Exception("Invalid order ID");
                }
                
                $order = $this->orderModel->find((int)$orderId);
                
                if (!$order) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Order not found'
                    ]);
                    return;
                }
                
                $orderDetails = $order->getOrderDetails();
                
                if (!$orderDetails) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Order details not found'
                    ]);
                    return;
                }
                
                $this->sendJsonResponse([
                    'success' => true,
                    'order' => $orderDetails
                ]);
                
            } catch (Exception $e) {
                error_log("Get order details error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Error loading order details: ' . $e->getMessage()
                ]);
            }
        }
        
     
        private function updateOrderStatus() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            if (!$this->currentAdmin->hasPermission('order_management')) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Access denied - insufficient permissions'
                ], 403);
                return;
            }
            
            try {
                $orderId = $_POST['order_id'] ?? null;
                $newStatus = $_POST['new_status'] ?? null;
                
                if (!$orderId || !is_numeric($orderId)) {
                    throw new Exception("Invalid order ID");
                }
                
                if (empty($newStatus)) {
                    throw new Exception("New status is required");
                }
                
                $order = $this->orderModel->find((int)$orderId);
                
                if (!$order) {
                    throw new Exception("Order not found");
                }
                
                $success = $order->updateStatus($newStatus, $this->currentAdmin->getUserId());
                
                if ($success) {
                    $this->sendJsonResponse([
                        'success' => true,
                        'message' => "Order #{$orderId} status updated to '{$newStatus}' successfully"
                    ]);
                } else {
                    throw new Exception("Failed to update order status");
                }
                
            } catch (Exception $e) {
                error_log("Update order status error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        

        private function bulkUpdateStatus() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            if (!$this->currentAdmin->hasPermission('order_management')) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Access denied - insufficient permissions'
                ], 403);
                return;
            }
            
            try {
                $orderIdsJson = $_POST['order_ids'] ?? null;
                $newStatus = $_POST['new_status'] ?? null;
                
                if (empty($orderIdsJson)) {
                    throw new Exception("Order IDs are required");
                }
                
                if (empty($newStatus)) {
                    throw new Exception("New status is required");
                }
                
                $orderIds = json_decode($orderIdsJson, true);
                
                if (!is_array($orderIds) || empty($orderIds)) {
                    throw new Exception("Invalid order IDs format");
                }
                
                $result = OrderManagementModel::bulkUpdateStatus($orderIds, $newStatus, $this->currentAdmin->getUserId());
                
                $message = "{$result['updated_count']} orders updated successfully";
                if ($result['invalid_count'] > 0) {
                    $message .= ". {$result['invalid_count']} orders could not be updated due to status restrictions.";
                }
                
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => $message,
                    'updated_count' => $result['updated_count'],
                    'invalid_count' => $result['invalid_count'],
                    'invalid_reasons' => $result['invalid_reasons']
                ]);
                
            } catch (Exception $e) {
                error_log("Bulk update status error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        

        private function getOrderStats() {
            if (!$this->currentAdmin->hasPermission('order_management')) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Access denied - insufficient permissions'
                ], 403);
                return;
            }
            
            try {
                $stats = [
                    'total_orders' => $this->orderModel->count(),
                    'pending_orders' => $this->orderModel->countOrdersByStatus('pending'),
                    'preparing_orders' => $this->orderModel->countOrdersByStatus('preparing'),
                    'ready_orders' => $this->orderModel->countOrdersByStatus('ready to pickup'),
                    'out_for_delivery' => $this->orderModel->countOrdersByStatus('out for delivery'),
                    'delivered_orders' => $this->orderModel->countOrdersByStatus('delivered'),
                    'canceled_orders' => $this->orderModel->countOrdersByStatus('canceled'),
                ];
                
                $this->sendJsonResponse([
                    'success' => true,
                    'stats' => $stats
                ]);
                
            } catch (Exception $e) {
                error_log("Get order stats error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Failed to load statistics: ' . $e->getMessage()
                ]);
            }
        }
        
        private function sendJsonResponse($data, $httpCode = 200) {
            // Clean output buffer
            if (ob_get_level()) {
                ob_clean();
            }
            
            http_response_code($httpCode);
            header('Content-Type: application/json');
            header('Cache-Control: no-cache, must-revalidate');
            
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
            exit();
        }
        
        private function isAjaxRequest() {
            return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                   strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ||
                   isset($_GET['ajax']) ||
                   isset($_POST['ajax']);
        }
        
        private function redirectWithError($message) {
            $_SESSION['error_message'] = $message;
            header('Location: ../../view/admin/admin_dashboard.php');
            exit();
        }
    }


    if (basename($_SERVER['PHP_SELF']) === 'OrderManagementController.php') {
        $controller = new OrderManagementController();
        $controller->handleRequest();
    }

} catch (Exception $e) {
    error_log("Order Management Controller error: " . $e->getMessage());
    
    if (ob_get_level()) {
        ob_clean();
    }
    
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'System error: ' . $e->getMessage()
    ]);
}

exit;
?>