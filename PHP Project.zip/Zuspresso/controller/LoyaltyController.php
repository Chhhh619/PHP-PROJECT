<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

session_start();

require_once '../model/LoyaltyService.php';
require_once '../model/Customer.php';
require_once '../model/Reward.php';
require_once '../model/RewardRedemption.php';
require_once '../model/LoyaltyTransaction.php';
require_once '../model/SecurityValidator.php';
require_once '../model/JWTHelper.php';
require_once '../model/strategies/PointCalculationStrategy.php';
require_once '../model/strategies/BasicPointStrategy.php';
require_once '../model/strategies/VIPPointStrategy.php';
require_once '../model/strategies/BonusPointStrategy.php';
require_once '../model/strategies/BronzePointStrategy.php';
require_once '../model/strategies/SilverPointStrategy.php';
require_once '../model/strategies/GoldPointStrategy.php';
require_once '../model/strategies/PlatinumPointStrategy.php';
require_once '../model/strategies/PromotionPointStrategy.php';

class LoyaltyController {

    private $loyaltyService;
    private $customerModel;
    private $rewardModel;
    private $rewardRedemptionModel;
    private $loyaltyTransactionModel;
    private $securityValidator;
    private $rateLimits = [
        'redeem' => ['max' => 3, 'window' => 300],
        'web_action' => ['max' => 30, 'window' => 300]
    ];

    public function __construct() {
        $this->validateSessionAndAuth();

        $this->loyaltyService = new LoyaltyService();
        $this->customerModel = new Customer();
        $this->rewardModel = new Reward();
        $this->rewardRedemptionModel = new RewardRedemption();
        $this->loyaltyTransactionModel = new LoyaltyTransaction();
        $this->securityValidator = new SecurityValidator();

        $this->initializePointStrategy();
    }

    public function handleWebRequest() {
        try {
            $this->setWebSecurityHeaders();

            $action = $this->getAndValidateWebAction();

            SecurityValidator::logAction($_SESSION['user_id'], 'web_access', [
                'action' => $action,
                'method' => $_SERVER['REQUEST_METHOD'],
                'ip_address' => SecurityValidator::getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);

            $this->executeWebAction($action);
        } catch (Exception $e) {
            $this->handleGlobalWebError($e);
        }
    }

    private function getAndValidateWebAction() {
        $action = $_POST['action'] ?? $_GET['action'] ?? 'dashboard';

        $allowedWebActions = [
            'dashboard', 'redeem', 'view_rewards', 'view_history', 
            'view_transactions', 'view_summary', 'ajax_redeem'
        ];

        if (!in_array($action, $allowedWebActions)) {
            SecurityValidator::logAction($_SESSION['user_id'], 'web_invalid_action', [
                'action' => $action,
                'allowed_actions' => $allowedWebActions
            ]);
            throw new Exception("Invalid web action requested");
        }

        return $action;
    }

    private function executeWebAction($action) {
        switch ($action) {
            case 'dashboard':
                $this->showDashboard();
                break;
            case 'redeem':
                $this->processRedemption();
                break;
            case 'view_rewards':
                $this->showRewardsPage();
                break;
            case 'view_history':
                $this->showHistoryPage();
                break;
            case 'view_transactions':
                $this->showTransactionsPage();
                break;
            case 'view_summary':
                $this->showSummaryPage();
                break;
            case 'ajax_redeem':
                $this->handleAjaxRedemption();
                break;
            default:
                $this->showDashboard();
        }
    }

    private function showDashboard() {
        try {
            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $data = [
                'customer' => $customer,
                'loyalty_points' => $this->loyaltyService->getCustomerPoints($customer['customer_id']),
                'loyalty_tier' => $this->loyaltyService->getLoyaltyTier($customer['customer_id']),
                'promotion_status' => $this->loyaltyService->getTuesdayPromotionStatus(),
                'available_rewards' => $this->loyaltyService->getAvailableRewards($customer['customer_id']),
                'recent_transactions' => LoyaltyTransaction::getCustomerTransactions($_SESSION['user_id'], 5),
                'tier_progress' => $this->loyaltyService->getTierProgress($customer['customer_id'])
            ];

            $this->renderWebPage('dashboard', $data);
        } catch (Exception $e) {
            $this->handleWebError($e, 'dashboard');
        }
    }

    private function processRedemption() {
        try {
            $this->checkRateLimit('redeem');
            $this->validateRequestMethod('POST');

            $rewardId = $this->validateAndSanitizeInput($_POST['reward_id'] ?? null, 'int', 'reward_id');

            if ($rewardId <= 0) {
                throw new InvalidArgumentException("Valid reward ID is required");
            }

            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $reward = $this->rewardModel->where('reward_id', '=', $rewardId)
                    ->where('is_active', '=', 1)
                    ->first();
            if (!$reward) {
                SecurityValidator::logAction($_SESSION['user_id'], 'invalid_reward_redemption_attempt', [
                    'reward_id' => $rewardId,
                    'customer_id' => $customer['customer_id']
                ]);
                throw new Exception("Reward not found or not available");
            }

            if (isset($reward['stock_quantity']) && $reward['stock_quantity'] !== null && $reward['stock_quantity'] <= 0) {
                throw new Exception("This reward is currently out of stock");
            }

            $idempotencyKey = $this->generateSecureIdempotencyKey('redemption', $rewardId);

            $result = $this->loyaltyService->redeemRewardWithSecurity(
                    $_SESSION['user_id'],
                    $rewardId,
                    $idempotencyKey
            );

            if ($result['success']) {
                $_SESSION['redemption_success'] = [
                    'message' => 'Reward redeemed successfully!',
                    'redemption_code' => $result['redemption_code'],
                    'reward_name' => $result['reward_name'],
                    'points_used' => $result['points_used'],
                    'remaining_points' => $result['remaining_points']
                ];

                header('Location: rewards.php?action=view_rewards&success=1');
                exit;
            } else {
                throw new Exception("Redemption failed: Unknown error occurred");
            }
        } catch (Exception $e) {
            $_SESSION['redemption_error'] = $e->getMessage();
            header('Location: rewards.php?action=view_rewards&error=1');
            exit;
        }
    }

    private function handleAjaxRedemption() {
        try {
            $this->checkRateLimit('redeem');
            $this->validateRequestMethod('POST');

            $rewardId = $this->validateAndSanitizeInput($_POST['reward_id'] ?? null, 'int', 'reward_id');

            if ($rewardId <= 0) {
                throw new InvalidArgumentException("Valid reward ID is required");
            }

            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $reward = $this->rewardModel->where('reward_id', '=', $rewardId)
                    ->where('is_active', '=', 1)
                    ->first();
            if (!$reward) {
                SecurityValidator::logAction($_SESSION['user_id'], 'invalid_reward_redemption_attempt', [
                    'reward_id' => $rewardId,
                    'customer_id' => $customer['customer_id']
                ]);
                throw new Exception("Reward not found or not available");
            }

            if (isset($reward['stock_quantity']) && $reward['stock_quantity'] !== null && $reward['stock_quantity'] <= 0) {
                throw new Exception("This reward is currently out of stock");
            }

            $idempotencyKey = $this->generateSecureIdempotencyKey('redemption', $rewardId);

            $result = $this->loyaltyService->redeemRewardWithSecurity(
                    $_SESSION['user_id'],
                    $rewardId,
                    $idempotencyKey
            );

            if ($result['success']) {
                $this->sendJsonResponse([
                    'success' => true,
                    'message' => 'Reward redeemed successfully!',
                    'data' => [
                        'redemption_code' => $result['redemption_code'],
                        'reward_name' => $result['reward_name'],
                        'points_used' => $result['points_used'],
                        'remaining_points' => $result['remaining_points'],
                        'redemption_id' => $result['redemption_id'],
                        'expires_at' => date('M j, Y', strtotime('+30 days'))
                    ],
                    'strategy_info' => [
                        'name' => $this->loyaltyService->getCurrentStrategy()['name'],
                        'description' => $this->loyaltyService->getCurrentStrategy()['description']
                    ],
                    'customer_tier' => $this->loyaltyService->getLoyaltyTier($customer['customer_id'])
                ]);
            } else {
                throw new Exception("Redemption failed: Unknown error occurred");
            }
        } catch (Exception $e) {
            $this->handleRedemptionWebError($e);
        }
    }

    private function showRewardsPage() {
        try {
            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $data = [
                'customer' => $customer,
                'loyalty_points' => $this->loyaltyService->getCustomerPoints($customer['customer_id']),
                'loyalty_tier' => $this->loyaltyService->getLoyaltyTier($customer['customer_id']),
                'available_rewards' => $this->loyaltyService->getAvailableRewards($customer['customer_id']),
                'promotion_status' => $this->loyaltyService->getTuesdayPromotionStatus()
            ];

            if (isset($_SESSION['redemption_success'])) {
                $data['success_message'] = $_SESSION['redemption_success'];
                unset($_SESSION['redemption_success']);
            }

            if (isset($_SESSION['redemption_error'])) {
                $data['error_message'] = $_SESSION['redemption_error'];
                unset($_SESSION['redemption_error']);
            }

            $this->renderWebPage('rewards', $data);
        } catch (Exception $e) {
            $this->handleWebError($e, 'rewards');
        }
    }

    private function showHistoryPage() {
        try {
            $redemptions = RewardRedemption::getCustomerRedemptions($_SESSION['user_id']);

            foreach ($redemptions as &$redemption) {
                $redemption['can_cancel'] = $this->canCancelRedemption($redemption);
                $redemption['usage_instructions'] = $this->getUsageInstructions($redemption);
                $redemption['time_until_expiry'] = $this->getTimeUntilExpiry($redemption['expires_at']);
            }

            $data = [
                'redemptions' => $redemptions,
                'statistics' => RewardRedemption::getRedemptionStats($_SESSION['user_id'], 'month')
            ];

            $this->renderWebPage('history', $data);
        } catch (Exception $e) {
            $this->handleWebError($e, 'history');
        }
    }

    private function showTransactionsPage() {
        try {
            $limit = min(50, max(1, (int) ($_GET['limit'] ?? 20)));
            $type = $_GET['type'] ?? null;

            if ($type) {
                $transactions = LoyaltyTransaction::getTransactionsByType($_SESSION['user_id'], $type, $limit);
            } else {
                $transactions = LoyaltyTransaction::getCustomerTransactions($_SESSION['user_id'], $limit);
            }

            $data = [
                'transactions' => $transactions,
                'statistics' => LoyaltyTransaction::getTransactionStats($_SESSION['user_id'], 'month'),
                'strategy_info' => $this->loyaltyService->getCurrentStrategy(),
                'filters' => [
                    'type' => $type,
                    'limit' => $limit
                ]
            ];

            $this->renderWebPage('transactions', $data);
        } catch (Exception $e) {
            $this->handleWebError($e, 'transactions');
        }
    }

    private function showSummaryPage() {
        try {
            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if (!$customer) {
                throw new Exception("Customer record not found");
            }

            $summary = $this->loyaltyService->getCustomerLoyaltySummary($customer['customer_id']);
            $summary['tier_benefits'] = $this->getTierBenefits($summary['tier']);
            $summary['earning_potential'] = $this->calculateEarningPotential($customer['customer_id']);
            $summary['strategy_comparison'] = $this->getStrategyComparison();

            $data = [
                'summary' => $summary,
                'tier_progress' => $this->loyaltyService->getTierProgress($customer['customer_id'])
            ];

            $this->renderWebPage('summary', $data);
        } catch (Exception $e) {
            $this->handleWebError($e, 'summary');
        }
    }

    private function renderWebPage($page, $data = []) {
        extract($data);
        
        $viewFile = "../views/loyalty/{$page}.php";
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            header('Location: rewards.php');
            exit;
        }
    }

    private function validateSessionAndAuth() {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
            SecurityValidator::logAction('unknown', 'web_unauthorized_access', [
                'ip_address' => SecurityValidator::getClientIP(),
                'endpoint' => $_SERVER['REQUEST_URI'] ?? 'unknown'
            ]);
            header('Location: ../auth/login.php');
            exit;
        }

        if ($_SESSION['user_role'] !== 'customer') {
            SecurityValidator::logAction($_SESSION['user_id'], 'web_invalid_role', [
                'role' => $_SESSION['user_role'],
                'required' => 'customer'
            ]);
            header('Location: ../auth/login.php');
            exit;
        }

        $this->validateSessionSecurity();
    }

    private function validateSessionSecurity() {
        $now = time();

        if (isset($_SESSION['last_activity']) && ($now - $_SESSION['last_activity']) > 14400) {
            SecurityValidator::logAction($_SESSION['user_id'], 'web_session_timeout', []);
            session_destroy();
            header('Location: ../auth/login.php?timeout=1');
            exit;
        }

        $_SESSION['last_activity'] = $now;
    }

    private function initializePointStrategy() {
        try {
            $customer = $this->customerModel->where('user_id', '=', $_SESSION['user_id'])->first();
            if ($customer) {
                $tier = $this->loyaltyService->getLoyaltyTier($customer['customer_id']);

                switch ($tier) {
                    case 'Platinum':
                        $strategy = new PlatinumPointStrategy();
                        break;
                    case 'Gold':
                        $strategy = new GoldPointStrategy();
                        break;
                    case 'Silver':
                        $strategy = new SilverPointStrategy();
                        break;
                    case 'Bronze':
                    default:
                        $strategy = new BronzePointStrategy();
                        break;
                }

                $this->loyaltyService->setPointStrategy($strategy);
            }
        } catch (Exception $e) {
            error_log("Error initializing point strategy: " . $e->getMessage());
            $this->loyaltyService->setPointStrategy(new BronzePointStrategy());
        }
    }

    private function setWebSecurityHeaders() {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    private function validateAndSanitizeInput($input, $type, $fieldName = 'input') {
        if ($input === null || $input === '') {
            throw new InvalidArgumentException("$fieldName is required");
        }

        $validated = SecurityValidator::validateInput($input, $type);

        if ($type === 'string') {
            if (!SecurityValidator::checkXSS($validated) || !SecurityValidator::checkSQLInjection($validated)) {
                SecurityValidator::logAction($_SESSION['user_id'], 'malicious_input_detected', [
                    'field' => $fieldName,
                    'input' => substr($input, 0, 50)
                ]);
                throw new InvalidArgumentException("Invalid characters detected in $fieldName");
            }
        }

        return $validated;
    }

    private function checkRateLimit($action) {
        if (!isset($this->rateLimits[$action])) {
            return true;
        }

        $limits = $this->rateLimits[$action];

        if (!SecurityValidator::checkRateLimit($_SESSION['user_id'], $action, $limits['max'], $limits['window'])) {
            SecurityValidator::logAction($_SESSION['user_id'], 'web_rate_limit_exceeded', [
                'action' => $action,
                'limit' => $limits['max'],
                'window' => $limits['window']
            ]);
            throw new Exception("Too many attempts. Please wait before trying again.");
        }

        return true;
    }

    private function validateRequestMethod($expectedMethod) {
        $currentMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';

        if ($currentMethod !== $expectedMethod) {
            SecurityValidator::logAction($_SESSION['user_id'], 'web_invalid_method', [
                'expected' => $expectedMethod,
                'received' => $currentMethod
            ]);
            throw new Exception("Invalid request method. Expected: $expectedMethod");
        }
    }

    private function generateSecureIdempotencyKey($operation, $resourceId) {
        $components = [
            $operation,
            $_SESSION['user_id'],
            $resourceId,
            date('Y-m-d-H'),
            session_id()
        ];

        return 'web_' . hash('sha256', implode('_', $components));
    }

    private function canCancelRedemption($redemption) {
        return $redemption['status'] === RewardRedemption::STATUS_ACTIVE &&
                !$redemption['is_expired'] &&
                strtotime($redemption['redeemed_at']) > (time() - 3600);
    }

    private function getUsageInstructions($redemption) {
        return [
            'Present code to staff during checkout',
            'Valid until: ' . ($redemption['formatted_expiry_date'] ?? 'N/A'),
            'Single use only',
            'Cannot be exchanged for cash'
        ];
    }

    private function getTimeUntilExpiry($expiryDate) {
        if (!$expiryDate) return null;

        $now = time();
        $expiry = strtotime($expiryDate);
        $diff = $expiry - $now;

        if ($diff <= 0) return 'Expired';
        if ($diff < 3600) return floor($diff / 60) . ' minutes';
        if ($diff < 86400) return floor($diff / 3600) . ' hours';

        return floor($diff / 86400) . ' days';
    }

    private function getTierBenefits($tier) {
        $benefits = [
            'Bronze' => ['Basic points earning', 'Access to standard rewards'],
            'Silver' => ['1.5x points earning', '2% reward discounts', 'Priority support'],
            'Gold' => ['1.8x points earning', '5% reward discounts', 'Exclusive rewards'],
            'Platinum' => ['2.0x points earning', '10% reward discounts', 'VIP events'],
            'Diamond' => ['2.5x points earning', '15% reward discounts', 'Personal account manager']
        ];

        return $benefits[$tier] ?? $benefits['Bronze'];
    }

    private function calculateEarningPotential($customerId) {
        $stats = $this->loyaltyService->getCustomerStats($customerId);
        $monthlyAverage = $stats['monthly_earned'] ?? 0;

        return [
            'monthly_average' => $monthlyAverage,
            'yearly_projection' => $monthlyAverage * 12,
            'next_tier_timeframe' => $this->calculateNextTierTime($customerId, $monthlyAverage)
        ];
    }

    private function calculateNextTierTime($customerId, $monthlyAverage) {
        $tierInfo = $this->loyaltyService->getTierInfo($customerId);

        if (!$tierInfo['next_tier'] || $monthlyAverage <= 0) {
            return 'Max tier reached or insufficient data';
        }

        $pointsNeeded = $tierInfo['points_to_next'];
        $monthsNeeded = ceil($pointsNeeded / $monthlyAverage);

        if ($monthsNeeded <= 1) return 'Less than a month';
        if ($monthsNeeded <= 12) return "$monthsNeeded months";

        $yearsNeeded = ceil($monthsNeeded / 12);
        return "$yearsNeeded year" . ($yearsNeeded > 1 ? 's' : '');
    }

    private function getStrategyComparison() {
        return $this->loyaltyService->testAllStrategies(100, null, [
            ['item_id' => 15, 'quantity' => 2, 'category' => 'coffee'],
            ['item_id' => 12, 'quantity' => 1, 'category' => 'cham']
        ]);
    }

    private function sendJsonResponse($data, $statusCode = 200) {
        header('Content-Type: application/json');
        http_response_code($statusCode);

        $data['metadata'] = [
            'timestamp' => date('c'),
            'request_id' => uniqid('web_'),
            'user_id' => $_SESSION['user_id'],
            'version' => '4.0',
            'service_type' => 'loyalty_web'
        ];

        echo json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
        exit;
    }

    private function handleRedemptionWebError($e) {
        SecurityValidator::logAction($_SESSION['user_id'], 'web_redemption_error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        error_log("Web Redemption error: " . $e->getMessage());

        $statusCode = ($e instanceof InvalidArgumentException) ? 400 : 500;
        $this->sendJsonResponse([
            'success' => false,
            'message' => $this->getSecureErrorMessage($e),
            'error_type' => 'redemption_error'
        ], $statusCode);
    }

    private function handleWebError($e, $context = 'general') {
        SecurityValidator::logAction($_SESSION['user_id'] ?? 'unknown', 'web_error', [
            'context' => $context,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);

        error_log("LoyaltyWeb error [$context]: " . $e->getMessage());

        $_SESSION['error_message'] = "An error occurred. Please try again.";
        header('Location: rewards.php');
        exit;
    }

    private function handleGlobalWebError($e) {
        SecurityValidator::logAction($_SESSION['user_id'] ?? 'unknown', 'web_fatal_error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        error_log("FATAL LoyaltyWeb error: " . $e->getMessage());

        $_SESSION['error_message'] = "A system error occurred. Please try again later.";
        header('Location: rewards.php');
        exit;
    }

    private function getSecureErrorMessage($e) {
        $message = $e->getMessage();

        $errorMappings = [
            'Customer record not found' => 'Your account information could not be verified.',
            'Rate limit exceeded' => 'Too many requests. Please wait before trying again.',
            'Invalid reward' => 'The selected reward is not available.',
            'Insufficient points' => 'You don\'t have enough points for this reward.',
            'out of stock' => 'This reward is currently out of stock.',
            'already redeemed' => 'You have already redeemed this reward recently.'
        ];

        foreach ($errorMappings as $internal => $friendly) {
            if (stripos($message, $internal) !== false) {
                return $friendly;
            }
        }

        return 'An error occurred while processing your request.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $webController = new LoyaltyController();
        $webController->handleWebRequest();
    } catch (Exception $e) {
        error_log("CRITICAL LoyaltyWeb error: " . $e->getMessage());
        
        $_SESSION['error_message'] = "System temporarily unavailable. Please try again later.";
        header('Location: rewards.php');
        exit;
    }
} else {
    header('HTTP/1.1 405 Method Not Allowed');
    echo "Method not allowed for web interface";
}
?>