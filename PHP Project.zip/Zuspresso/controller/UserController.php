<?php


ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (isset($_GET['ajax']) || isset($_POST['ajax']) || 
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')) {
    header('Content-Type: application/json');
}

try {
    require_once '../model/UserManagement.php';
    require_once '../model/User.php';
    require_once '../model/Admin.php';
    require_once '../model/UserFactory.php';
    require_once '../database.php';

    class UserController {
        private $userManagement;
        private $currentAdmin;
        private $db;
        
        public function __construct() {
            try {
                $this->db = Database::getInstance()->getConnection();
                $this->userManagement = new UserManagement();
                $this->authenticateAdmin();
            } catch (Exception $e) {
                error_log("UserController initialization error: " . $e->getMessage());
                
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'System error. Please try again.'
                    ]);
                } else {
                    $this->redirectWithError("System error occurred.");
                }
            }
        }
        
        private function authenticateAdmin() {
            
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Authentication required',
                        'redirect' => '../auth/login.php'
                    ], 401);
                } else {
                    header('Location: ../auth/login.php');
                    exit();
                }
            }
            
            try {
                $userFactory = new UserFactory($this->db);
                $this->currentAdmin = $userFactory->createUserById($_SESSION['user_id']);
                
                if (!$this->currentAdmin || !($this->currentAdmin instanceof Admin)) {
                    session_destroy();
                    if ($this->isAjaxRequest()) {
                        $this->sendJsonResponse([
                            'success' => false,
                            'message' => 'Invalid session',
                            'redirect' => '../auth/login.php'
                        ], 403);
                    } else {
                        header('Location: ../auth/login.php');
                        exit();
                    }
                }
                
               
                if (!$this->currentAdmin->hasPermission('user_management')) {
                    if ($this->isAjaxRequest()) {
                        $this->sendJsonResponse([
                            'success' => false,
                            'message' => 'Access denied - insufficient permissions'
                        ], 403);
                    } else {
                        header('Location: ../../view/admin/admin_dashboard.php');
                        exit();
                    }
                }
                
            } catch (Exception $e) {
                error_log("Admin authentication error: " . $e->getMessage());
                session_destroy();
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Access validation failed'
                    ], 500);
                } else {
                    header('Location: ../auth/login.php');
                    exit();
                }
            }
        }
        
        public function handleRequest() {
            $action = $_GET['action'] ?? $_POST['action'] ?? 'list';
            
            try {
                switch ($action) {
                    case 'list':
                        $this->listUsers();
                        break;
                    case 'view':
                        $this->viewUser();
                        break;
                    case 'edit':
                        $this->editUser();
                        break;
                    case 'toggle_status':
                        $this->toggleUserStatus();
                        break;
                    case 'delete':
                        $this->deleteUser();
                        break;
                    case 'search':
                        $this->searchUsers();
                        break;
                    case 'filter':
                        $this->filterUsers();
                        break;
                    case 'stats':
                        $this->getUserStats();
                        break;
                    case 'update_admin_role':
                        $this->updateAdminRole();
                        break;
                    case 'get_admin_permissions':
                        $this->getAdminPermissions();
                        break;
                    default:
                        $this->listUsers();
                }
            } catch (Exception $e) {
                error_log("Request handling error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false, 
                    'message' => 'Error: ' . $e->getMessage()
                ], 500);
            }
        }
        
        private function updateAdminRole() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            try {
                $userId = $_POST['user_id'] ?? null;
                $adminName = trim($_POST['admin_name'] ?? '');
                $permissions = $_POST['permissions'] ?? [];
                

                if (!$userId || !is_numeric($userId)) {
                    throw new Exception("Invalid user ID");
                }
                
                if (empty($adminName)) {
                    throw new Exception("Admin name is required");
                }
                
                
                $userProfile = $this->userManagement->getUserWithProfile((int)$userId);
                if (!$userProfile || $userProfile['role'] !== 'admin') {
                    throw new Exception("User not found or is not an admin");
                }
                
                
                if ($userId == $this->currentAdmin->getUserId()) {
                    if (!in_array('user_management', $permissions)) {
                        throw new Exception("You cannot remove your own user management permissions");
                    }
                }
                
                
                $permissionsList = [
                    'user_management' => in_array('user_management', $permissions),
                    'menu_management' => in_array('menu_management', $permissions),
                    'order_management' => in_array('order_management', $permissions),
                    'reports' => in_array('reports', $permissions),
                    'system_settings' => in_array('system_settings', $permissions)
                ];
                
                $permissionsJson = json_encode($permissionsList);
                

                $success = $this->userManagement->updateAdminPermissions((int)$userId, $adminName, $permissionsJson);
                
                if ($success) {
                    error_log("Admin permissions updated for user ID {$userId} by admin ID {$this->currentAdmin->getUserId()}");
                    
                    $this->sendJsonResponse([
                        'success' => true,
                        'message' => 'Admin permissions updated successfully'
                    ]);
                } else {
                    throw new Exception("Failed to update admin permissions");
                }
                
            } catch (Exception $e) {
                error_log("Update admin role error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        
        private function getAdminPermissions() {
            try {
                $userId = $_GET['user_id'] ?? null;
                
                if (!$userId || !is_numeric($userId)) {
                    throw new Exception("Invalid user ID");
                }
                
                $permissions = $this->userManagement->getAdminPermissions((int)$userId);
                $availablePermissions = $this->userManagement->getAvailablePermissions();
                
                $this->sendJsonResponse([
                    'success' => true,
                    'permissions' => $permissions,
                    'available_permissions' => $availablePermissions
                ]);
                
            } catch (Exception $e) {
                error_log("Get admin permissions error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        
        private function listUsers() {
            try {
                $filter = $_GET['filter'] ?? 'all';
                $status = $_GET['status'] ?? 'all';
                $search = $_GET['search'] ?? '';
                $page = (int)($_GET['page'] ?? 1);
                $perPage = 20;

                $users = [];
                $totalCount = 0;

                
                if (!empty($search)) {
                    $users = $this->userManagement->searchUsers($search);
                    $totalCount = count($users);
                    
                    
                    $offset = ($page - 1) * $perPage;
                    $users = array_slice($users, $offset, $perPage);
                    

                } elseif ($filter !== 'all' || $status !== 'all') {
                    $filters = [];
                    if ($filter !== 'all') $filters['role'] = $filter;
                    if ($status !== 'all') $filters['is_active'] = ($status === 'active') ? 1 : 0;
                    
                    $users = $this->userManagement->getPaginatedUsers($page, $perPage, $filters);
                    $totalCount = $this->userManagement->getUserCount($filters);
                    

                } else {
                    $users = $this->userManagement->getPaginatedUsers($page, $perPage);
                    $totalCount = $this->userManagement->getUserCount();
                }
                
                $stats = $this->userManagement->getUserStats();
                

                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => true,
                        'users' => $users,
                        'stats' => $stats,
                        'pagination' => [
                            'current_page' => $page,
                            'per_page' => $perPage,
                            'total' => $totalCount,
                            'total_pages' => ceil($totalCount / $perPage)
                        ]
                    ]);
                } else {

                    $this->loadView('user_management', [
                        'users' => $users,
                        'stats' => $stats,
                        'currentAdmin' => $this->currentAdmin,
                        'pagination' => [
                            'current_page' => $page,
                            'per_page' => $perPage,
                            'total' => $totalCount,
                            'total_pages' => ceil($totalCount / $perPage)
                        ]
                    ]);
                }
                
            } catch (Exception $e) {
                error_log("List users error: " . $e->getMessage());
                if ($this->isAjaxRequest()) {
                    $this->sendJsonResponse([
                        'success' => false, 
                        'message' => 'Failed to load users: ' . $e->getMessage()
                    ]);
                } else {
                    throw $e;
                }
            }
        }
        
        private function viewUser() {
            $userId = $_GET['id'] ?? null;
            
            if (!$userId || !is_numeric($userId)) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid user ID'
                ]);
                return;
            }
            
            try {
                $user = $this->userManagement->getUserWithProfile((int)$userId);
                
                if (!$user) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'User not found'
                    ]);
                    return;
                }
                
                $this->sendJsonResponse([
                    'success' => true,
                    'user' => $user
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Error loading user: ' . $e->getMessage()
                ]);
            }
        }
        
        private function editUser() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            try {
                $userId = $_POST['user_id'] ?? null;
                $email = trim($_POST['email'] ?? '');
                $isActive = isset($_POST['is_active']) ? 1 : 0;
                
                if (!$userId || !is_numeric($userId)) {
                    throw new Exception("Invalid user ID");
                }
                
                if (empty($email)) {
                    throw new Exception("Email is required");
                }
                
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email format");
                }
                
 
                $updateData = ['email' => $email, 'is_active' => $isActive];
                $success = $this->userManagement->updateUserDetails((int)$userId, $updateData);
                
                $this->sendJsonResponse([
                    'success' => $success,
                    'message' => $success ? 'User updated successfully' : 'Failed to update user'
                ]);
                
            } catch (Exception $e) {
                error_log("Edit user error: " . $e->getMessage());
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        
        private function toggleUserStatus() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            try {
                $userId = $_POST['user_id'] ?? null;
                
                if (!$userId || !is_numeric($userId)) {
                    throw new Exception("Invalid user ID");
                }
                

                if ($userId == $this->currentAdmin->getUserId()) {
                    throw new Exception("You cannot deactivate your own account");
                }
                
                $success = $this->userManagement->toggleUserStatus((int)$userId);
                
                $this->sendJsonResponse([
                    'success' => $success,
                    'message' => $success ? 'User status updated successfully' : 'Failed to update status'
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        
        private function deleteUser() {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Invalid request method'
                ], 405);
                return;
            }
            
            try {
                $userId = $_POST['user_id'] ?? null;
                
                if (!$userId || !is_numeric($userId)) {
                    throw new Exception("Invalid user ID");
                }
                
                // Prevent self-deletion
                if ($userId == $this->currentAdmin->getUserId()) {
                    throw new Exception("You cannot delete your own account");
                }
                
                $success = $this->userManagement->softDelete((int)$userId);
                
                $this->sendJsonResponse([
                    'success' => $success,
                    'message' => $success ? 'User deactivated successfully' : 'Failed to deactivate user'
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => $e->getMessage()
                ]);
            }
        }
        
        private function searchUsers() {
            try {
                $searchTerm = $_GET['q'] ?? '';
                
                if (strlen(trim($searchTerm)) < 2) {
                    $this->sendJsonResponse([
                        'success' => false,
                        'message' => 'Search term must be at least 2 characters'
                    ]);
                    return;
                }
                
                $users = $this->userManagement->searchUsers($searchTerm);
                
                $this->sendJsonResponse([
                    'success' => true,
                    'users' => $users
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Search failed: ' . $e->getMessage()
                ]);
            }
        }
        
        private function filterUsers() {
            try {
                $role = $_GET['role'] ?? 'all';
                $status = $_GET['status'] ?? 'all';
                
                $users = [];
                
                if ($role !== 'all' && $status !== 'all') {
                    $filters = [
                        'role' => $role,
                        'is_active' => ($status === 'active') ? 1 : 0
                    ];
                    $users = $this->userManagement->getPaginatedUsers(1, 100, $filters);
                } elseif ($role !== 'all') {
                    $users = $this->userManagement->getUsersByRole($role);
                } elseif ($status !== 'all') {
                    $isActive = ($status === 'active') ? 1 : 0;
                    $users = $this->userManagement->getUsersByStatus($isActive);
                } else {
                    $users = $this->userManagement->getAllUsersWithProfiles();
                }
                
                $this->sendJsonResponse([
                    'success' => true,
                    'users' => $users
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Filter operation failed: ' . $e->getMessage()
                ]);
            }
        }
        
        private function getUserStats() {
            try {
                $stats = $this->userManagement->getUserStats();
                
                $this->sendJsonResponse([
                    'success' => true,
                    'stats' => $stats
                ]);
                
            } catch (Exception $e) {
                $this->sendJsonResponse([
                    'success' => false,
                    'message' => 'Failed to load statistics: ' . $e->getMessage()
                ]);
            }
        }
        
        private function loadView($viewName, $data = []) {
            extract($data);
            include "../../view/admin/{$viewName}.php";
        }
        
        private function sendJsonResponse($data, $httpCode = 200) {

            if (ob_get_level()) {
                ob_clean();
            }
            
            http_response_code($httpCode);
            header('Content-Type: application/json');
            header('Cache-Control: no-cache, must-revalidate');
            
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
            exit();
        }
        
        private function isAjaxRequest() {
            return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
                   strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ||
                   isset($_GET['ajax']) ||
                   isset($_POST['ajax']);
        }
        
        private function redirectWithError($message) {
            $_SESSION['error_message'] = $message;
            header('Location: ../../view/admin/admin_dashboard.php');
            exit();
        }
    }

 
    if (basename($_SERVER['PHP_SELF']) === 'UserController.php') {
        $controller = new UserController();
        $controller->handleRequest();
    }

} catch (Exception $e) {
    error_log("User Controller error: " . $e->getMessage());
    
    if (ob_get_level()) {
        ob_clean();
    }
    
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'System error: ' . $e->getMessage()
    ]);
}

exit;
?>