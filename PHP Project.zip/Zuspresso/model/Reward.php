<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

require_once 'BaseModel.php';

class Reward extends BaseModel {
    protected $table = 'rewards';
    protected $primaryKey = 'reward_id';
    protected $fillable = [
        'name', 'description', 'reward_type', 'reward_value', 'points_required',
        'stock_quantity', 'is_active', 'valid_from', 'valid_until'
    ];

    const TYPE_DISCOUNT = 'discount';
    const TYPE_FREE_ITEM = 'free_item';
    const TYPE_MERCHANDISE = 'merchandise';
    const TYPE_VOUCHER = 'voucher';

    public static function getActive() {
        $instance = new self();
        return $instance->findAll([
            'is_active' => 1
        ], 'points_required ASC');
    }

    public static function getById($reward_id) {
        $instance = new self();
        $result = $instance->find($reward_id);
        return $result ? $result->toArray() : null;
    }

    public function isAvailable() {
        if (!$this->attributes['is_active']) {
            return false;
        }

        $now = date('Y-m-d H:i:s');
        
        if (isset($this->attributes['valid_from']) && $this->attributes['valid_from'] && $this->attributes['valid_from'] > $now) {
            return false;
        }
        
        if (isset($this->attributes['valid_until']) && $this->attributes['valid_until'] && $this->attributes['valid_until'] < $now) {
            return false;
        }
        
        if (isset($this->attributes['stock_quantity']) && $this->attributes['stock_quantity'] !== null && $this->attributes['stock_quantity'] <= 0) {
            return false;
        }
        
        return true;
    }

    public function decrementStock() {
        if (isset($this->attributes['stock_quantity']) && $this->attributes['stock_quantity'] !== null && $this->attributes['stock_quantity'] > 0) {
            $newStock = $this->attributes['stock_quantity'] - 1;
            return $this->update(['stock_quantity' => $newStock]);
        }
        return true;
    }
}