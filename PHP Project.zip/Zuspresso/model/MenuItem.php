<?php
/**
 * MenuItem Model - Fully ORM-Powered & Human-Friendly
 * 
 * This model represents a delicious menu item in our coffee shop!
 * It handles everything from finding your favorite latte to checking if we have enough stock.
 * 
 * @author Coffee Enthusiast Developer
 * @module Menu Item Management
 * @version 2.0 - Now with 100% more ORM goodness!
 */

require_once 'BaseModel.php';

class MenuItem extends BaseModel {

    protected $table = 'menu_items';
    protected $primaryKey = 'item_id';
    
    // These are the fields we can safely update
    protected $fillable = [
        'name', 'description', 'price', 'category',
        'is_available', 'stock_quantity', 'low_stock_threshold', 'image_path'
    ];

    /**
     * Find a menu item by its exact name (like searching for "Spanish Latte")
     * Perfect for when customers know exactly what they want!
     */
    public static function findByName($itemName) {
        $menuFinder = new self();
        
        $item = $menuFinder
            ->select('*')
            ->where('name', $itemName)
            ->where('is_available', 1)
            ->first();
            
        return $item;
    }

    /**
     * Search for menu items that match a search term
     * Great for when customers type "latte" and want to see all latte options
     */
    public static function searchByName($searchTerm) {
        $menuSearcher = new self();
        
        $results = $menuSearcher
            ->select('*')
            ->where('is_available', 1)
            ->whereLike('name', "%{$searchTerm}%")
            ->orderBy('name', 'ASC')
            ->get();
            
        return $results;
    }

    /**
     * Get all available menu items, nicely organized by category
     * This is what customers see on our menu board!
     */
    public static function getAvailableItems() {
        $menuLister = new self();
        
        $availableItems = $menuLister
            ->select('*')
            ->where('is_available', 1)
            ->orderBy('category', 'ASC')
            ->orderBy('name', 'ASC')
            ->get();
            
        return $availableItems;
    }
    
    /**
     * Get menu items with advanced filtering (for admin management)
     * This is the power tool for admins to find exactly what they're looking for!
     */
    public static function getWithFilters($filters = [], $page = 1, $itemsPerPage = 10) {
        $menuManager = new self();
        
        // Start building our query - like making a custom coffee order!
        $query = $menuManager->select('*');
        
        // Filter by category if specified (e.g., only show coffee items)
        if (!empty($filters['category'])) {
            $query->where('category', $filters['category']);
        }
        
        // Filter by availability if specified
        if (isset($filters['availability']) && $filters['availability'] !== '') {
            $query->where('is_available', (int)$filters['availability']);
        }
        
        // Search in name or description if search term provided
        if (!empty($filters['search'])) {
            $searchTerm = "%{$filters['search']}%";
            // Using a closure for complex WHERE conditions
            $query->where(function($q) use ($searchTerm) {
                return "name LIKE '{$searchTerm}' OR description LIKE '{$searchTerm}'";
            });
        }
        
        // Get total count for pagination (before applying limit)
        $totalItems = $menuManager
            ->select('COUNT(*) as total')
            ->from($menuManager->table);
            
        // Apply the same filters to count query
        if (!empty($filters['category'])) {
            $totalItems->where('category', $filters['category']);
        }
        if (isset($filters['availability']) && $filters['availability'] !== '') {
            $totalItems->where('is_available', (int)$filters['availability']);
        }
        if (!empty($filters['search'])) {
            $searchTerm = "%{$filters['search']}%";
            $totalItems->where(function($q) use ($searchTerm) {
                return "name LIKE '{$searchTerm}' OR description LIKE '{$searchTerm}'";
            });
        }
        
        $totalCount = $totalItems->first()['total'] ?? 0;
        
        // Apply pagination and sorting to main query
        $offset = ($page - 1) * $itemsPerPage;
        $items = $query
            ->orderBy('created_at', 'DESC')
            ->limit($itemsPerPage, $offset)
            ->get();
        
        // Return both items and pagination info
        return [
            'items' => $items,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => ceil($totalCount / $itemsPerPage),
                'total_items' => $totalCount,
                'items_per_page' => $itemsPerPage,
                'has_previous' => $page > 1,
                'has_next' => $page < ceil($totalCount / $itemsPerPage)
            ]
        ];
    }
    
    /**
     * Get all unique categories from our menu
     * Useful for building category filter dropdowns
     */
    public static function getAllCategories() {
        $categoryFinder = new self();
        
        $categories = $categoryFinder
            ->select('DISTINCT category')
            ->where('is_available', 1)
            ->orderBy('category', 'ASC')
            ->get();
            
        return array_column($categories, 'category');
    }
    
    /**
     * Get low stock items that need attention
     * Helps managers know when to reorder ingredients!
     */
    public static function getLowStockItems() {
        $stockChecker = new self();
        
        // Find items where current stock is at or below the threshold
        $lowStockItems = $stockChecker
            ->select('*')
            ->where('is_available', 1)
            ->where('stock_quantity', '<=', 'low_stock_threshold')  // This compares columns
            ->orderBy('stock_quantity', 'ASC')
            ->get();
            
        return $lowStockItems;
    }
    
    /**
     * Update stock quantity after an order
     * Keeps our inventory accurate when customers buy our delicious drinks!
     */
    public function reduceStock($quantity) {
        if ($this->stock_quantity < $quantity) {
            throw new Exception("Not enough stock! We only have {$this->stock_quantity} left of {$this->name}");
        }
        
        $newStockLevel = $this->stock_quantity - $quantity;
        
        return $this->update([
            'stock_quantity' => $newStockLevel
        ]);
    }
    
    /**
     * Check if this item is currently available for ordering
     * More detailed than just checking the is_available flag
     */
    public function isOrderable() {
        return $this->is_available == 1 && $this->stock_quantity > 0;
    }
    
    /**
     * Check if this item is running low on stock
     */
    public function isLowStock() {
        return $this->stock_quantity <= $this->low_stock_threshold;
    }
    
    /**
     * Get the web-friendly URL for this item's image
     * Returns null if no image is set (we'll show a placeholder instead)
     */
    public function getImageUrl() {
        return $this->image_path ? $this->image_path : null;
    }

    /**
     * Check if this item has an image uploaded
     */
    public function hasImage() {
        return !empty($this->image_path);
    }

    /**
     * Get nicely formatted price with RM currency
     * Because "RM 13.90" looks better than "13.9"
     */
    public function getFormattedPrice() {
        return 'RM ' . number_format($this->price, 2);
    }
    
    /**
     * Get a human-friendly category name
     * Converts "frappe" to "Frappe" for better display
     */
    public function getFormattedCategory() {
        return ucfirst($this->category);
    }
    
    /**
     * Get availability status as human-readable text
     */
    public function getAvailabilityStatus() {
        if (!$this->is_available) {
            return 'Unavailable';
        }
        
        if ($this->stock_quantity <= 0) {
            return 'Out of Stock';
        }
        
        if ($this->isLowStock()) {
            return 'Low Stock';
        }
        
        return 'Available';
    }
    
    /**
     * Get CSS class for availability status styling
     */
    public function getAvailabilityClass() {
        if (!$this->is_available) {
            return 'danger';
        }
        
        if ($this->stock_quantity <= 0) {
            return 'danger';
        }
        
        if ($this->isLowStock()) {
            return 'warning';
        }
        
        return 'success';
    }

    /**
     * Enhanced toArray with all the computed fields admins and customers need
     * Makes our API responses much more useful!
     */
    public function toArray() {
        $baseData = parent::toArray();
        
        // Add all our computed/formatted fields
        return array_merge($baseData, [
            'formatted_price' => $this->getFormattedPrice(),
            'formatted_category' => $this->getFormattedCategory(),
            'has_image' => $this->hasImage(),
            'image_url' => $this->getImageUrl(),
            'is_orderable' => $this->isOrderable(),
            'is_low_stock' => $this->isLowStock(),
            'availability_status' => $this->getAvailabilityStatus(),
            'availability_class' => $this->getAvailabilityClass(),
            'stock_status' => $this->stock_quantity . ' units',
            'created_date' => date('M d, Y', strtotime($this->created_at ?? 'now'))
        ]);
    }
    
    /**
     * Validate menu item data before saving
     * Prevents common mistakes like negative prices or empty names
     */
    public function validateItemData($data) {
        $errors = [];
        
        // Name is required and should be reasonable length
        if (empty($data['name']) || strlen(trim($data['name'])) < 2) {
            $errors[] = "Item name must be at least 2 characters long";
        }
        
        // Description should be meaningful
        if (empty($data['description']) || strlen(trim($data['description'])) < 10) {
            $errors[] = "Description should be at least 10 characters to help customers understand the item";
        }
        
        // Price must be positive
        if (!isset($data['price']) || !is_numeric($data['price']) || $data['price'] <= 0) {
            $errors[] = "Price must be a positive number";
        }
        
        // Category should be from our allowed list
        $allowedCategories = ['coffee', 'tea', 'frappe', 'cham', 'chocolate', 'refresher', 'specialty'];
        if (empty($data['category']) || !in_array($data['category'], $allowedCategories)) {
            $errors[] = "Category must be one of: " . implode(', ', $allowedCategories);
        }
        
        // Stock quantities should be non-negative
        if (isset($data['stock_quantity']) && (!is_numeric($data['stock_quantity']) || $data['stock_quantity'] < 0)) {
            $errors[] = "Stock quantity cannot be negative";
        }
        
        if (isset($data['low_stock_threshold']) && (!is_numeric($data['low_stock_threshold']) || $data['low_stock_threshold'] < 0)) {
            $errors[] = "Low stock threshold cannot be negative";
        }
        
        return $errors;
    }
    
    /**
     * Create a new menu item with validation
     * Overrides parent create method to add our validation
     */
    public function create($data) {
        // Validate the data first
        $validationErrors = $this->validateItemData($data);
        if (!empty($validationErrors)) {
            throw new Exception("Validation failed: " . implode(', ', $validationErrors));
        }
        
        // Set default values for optional fields
        $data['is_available'] = $data['is_available'] ?? 1;
        $data['stock_quantity'] = $data['stock_quantity'] ?? 100;
        $data['low_stock_threshold'] = $data['low_stock_threshold'] ?? 10;
        
        return parent::create($data);
    }
    
    /**
     * Update menu item with validation
     * Overrides parent update method to add our validation
     */
    public function update($data) {
        // Only validate fields that are being updated
        $fieldsToValidate = array_intersect_key($data, array_flip($this->fillable));
        if (!empty($fieldsToValidate)) {
            $validationErrors = $this->validateItemData(array_merge($this->attributes, $fieldsToValidate));
            if (!empty($validationErrors)) {
                throw new Exception("Validation failed: " . implode(', ', $validationErrors));
            }
        }
        
        return parent::update($data);
    }
}
?>