<?php
/**
author : Cheng Jun Yang
 */

require_once 'User.php';

class Admin extends User {
    private $admin_id;
    private $admin_name;
    private $permissions;
    private $last_login;
    
   
    public function getDisplayName() {
        return $this->admin_name;
    }
    
  
    public function getPermissions() {
        if (empty($this->permissions)) {
        
            return [
                'user_management' => true,
                'menu_management' => true,
                'order_management' => true,
                'reports' => true,
                'system_settings' => true
            ];
        }
        
        $decoded = json_decode($this->permissions, true);
        return $decoded ?: [];
    }
    
   
    public function getDashboardUrl() {
        return '/view/admin/admin_dashboard.php';
    }
    
   
    public function loadSpecificData() {
        try {
         
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['user_id', 'admin_name', 'permissions', 'last_login'];
            };
            
            $data = $adminModel->where('user_id', '=', $this->user_id)->first();
            
            if ($data) {
                $this->admin_id = $data['admin_id'];
                $this->admin_name = $data['admin_name'];
                $this->permissions = $data['permissions'];
                $this->last_login = $data['last_login'];
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Admin data loading failed: " . $e->getMessage());
            return false;
        }
    }
    
  
    public function updateProfile($admin_name, $permissions = null) {
      
        if (empty($admin_name)) {
            throw new InvalidArgumentException("Admin name is required");
        }
        
        if (!$this->isValidName($admin_name)) {
            throw new InvalidArgumentException("Admin name must contain only letters, spaces, and common punctuation");
        }
        
        
        if ($permissions !== null) {
            if (!is_array($permissions)) {
                throw new InvalidArgumentException("Permissions must be an array");
            }
            $permissions = json_encode($permissions);
        }
        
        try {
          
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['admin_name', 'permissions'];
            };
            
            $updateData = ['admin_name' => $this->sanitizeString($admin_name)];
            
            if ($permissions !== null) {
                $updateData['permissions'] = $permissions;
            }
            
            $result = $adminModel->where('user_id', '=', $this->user_id)->update($updateData);
            
            if ($result) {
                $this->admin_name = $admin_name;
                if ($permissions !== null) {
                    $this->permissions = $permissions;
                }
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Admin profile update failed: " . $e->getMessage());
            return false;
        }
    }
    
    
    public function updateLastLogin() {
        try {
            
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['last_login'];
            };
            
            $result = $adminModel->where('user_id', '=', $this->user_id)
                                ->update(['last_login' => date('Y-m-d H:i:s')]);
            
            if ($result) {
                $this->last_login = date('Y-m-d H:i:s');
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Last login update failed: " . $e->getMessage());
            return false;
        }
    }
    
  
    public function hasPermission($permission) {
        $permissions = $this->getPermissions();
        return isset($permissions[$permission]) && $permissions[$permission] === true;
    }
    
    
    public function addPermission($permission, $value = true) {
        $permissions = $this->getPermissions();
        $permissions[$permission] = $value;
        
        try {
           
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['permissions'];
            };
            
            $permissions_json = json_encode($permissions);
            $result = $adminModel->where('user_id', '=', $this->user_id)
                                ->update(['permissions' => $permissions_json]);
            
            if ($result) {
                $this->permissions = $permissions_json;
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Permission addition failed: " . $e->getMessage());
            return false;
        }
    }
    
  
    public function removePermission($permission) {
        $permissions = $this->getPermissions();
        unset($permissions[$permission]);
        
        try {
         
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['permissions'];
            };
            
            $permissions_json = json_encode($permissions);
            $result = $adminModel->where('user_id', '=', $this->user_id)
                                ->update(['permissions' => $permissions_json]);
            
            if ($result) {
                $this->permissions = $permissions_json;
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Permission removal failed: " . $e->getMessage());
            return false;
        }
    }
    
   
    public function getSystemStats() {
        if (!$this->hasPermission('reports')) {
            throw new Exception("Insufficient permissions to view system statistics");
        }
        
        try {
            $stats = [];
            
          
            $userModel = new class extends BaseModel {
                protected $table = 'users';
                protected $primaryKey = 'user_id';
            };
            
        
            $stats['total_users'] = $userModel->where('is_active', '=', 1)->count();
            
            
            $customerModel = new class extends BaseModel {
                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
            };
            
         
            $stats['total_customers'] = $customerModel->count();
            
         
            $adminModel = new class extends BaseModel {
                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
            };
            
          
            $stats['total_admins'] = $adminModel->count();
            
         
            $thirtyDaysAgo = date('Y-m-d H:i:s', strtotime('-30 days'));
            $stats['recent_registrations'] = $userModel->where('created_at', '>=', $thirtyDaysAgo)->count();
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("System stats query failed: " . $e->getMessage());
            return false;
        }
    }
    
    
    public function getProfileData() {
        return [
            'user_id' => $this->user_id,
            'email' => $this->email,
            'role' => $this->role,
            'admin_id' => $this->admin_id,
            'admin_name' => $this->admin_name,
            'display_name' => $this->getDisplayName(),
            'permissions' => $this->getPermissions(),
            'last_login' => $this->last_login,
            'created_at' => $this->created_at,
            'is_active' => $this->is_active
        ];
    }
    
    
    public function getAdminId() { return $this->admin_id; }
    public function getAdminName() { return $this->admin_name; }
    public function getLastLoginTime() { return $this->last_login; }
    
   
    protected function isValidName($name) {
        return preg_match('/^[a-zA-Z\s\'-]{2,50}$/', $name);
    }
}