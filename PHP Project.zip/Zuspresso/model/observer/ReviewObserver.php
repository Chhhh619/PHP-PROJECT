<?php
/**
author : Cheng Jun Yang
 */

interface ReviewObserver {

    public function update(ReviewEvent $event);
}

class ReviewEvent {

    private $eventType;
    private $reviewData;
    private $itemId;
    private $customerId;
    private $oldReviewData;

    public function __construct($eventType, $reviewData, $itemId = null, $customerId = null, $oldReviewData = null) {
        $this->eventType = $eventType;
        $this->reviewData = $reviewData;
        $this->itemId = $itemId;
        $this->customerId = $customerId;
        $this->oldReviewData = $oldReviewData;
    }

    public function getEventType() {
        return $this->eventType;
    }

    public function getReviewData() {
        return $this->reviewData;
    }

    public function getItemId() {
        return $this->itemId;
    }

    public function getCustomerId() {
        return $this->customerId;
    }

    public function getOldReviewData() {
        return $this->oldReviewData;
    }
}

class ReviewSubject {

    private $observers = [];

    public function attach(ReviewObserver $observer) {
        $this->observers[] = $observer;
    }

    public function detach(ReviewObserver $observer) {
        $key = array_search($observer, $this->observers, true);
        if ($key !== false) {
            unset($this->observers[$key]);
        }
    }

    public function notify(ReviewEvent $event) {
        foreach ($this->observers as $observer) {
            $observer->update($event);
        }
    }
}

class ReviewSummaryObserver implements ReviewObserver {

    private $reviewModel;

    public function __construct($reviewModel) {
        $this->reviewModel = $reviewModel;
    }

    public function update(ReviewEvent $event) {
        $eventType = $event->getEventType();
        $itemId = $event->getItemId();

        if (in_array($eventType, ['review_created', 'review_updated', 'review_deleted']) && $itemId) {
            $this->updateSummary($itemId);
        }
    }

    private function updateSummary($itemId) {
        try {
            $this->reviewModel->updateReviewSummary($itemId);
            error_log("Review summary updated for item ID: $itemId");
        } catch (Exception $e) {
            error_log("Failed to update review summary for item ID $itemId: " . $e->getMessage());
        }
    }
}

class ReviewNotificationObserver implements ReviewObserver {

    public function update(ReviewEvent $event) {
        $eventType = $event->getEventType();
        $reviewData = $event->getReviewData();

        switch ($eventType) {
            case 'review_created':
                $this->sendReviewCreatedNotification($reviewData);
                break;
            case 'review_updated':
                $this->sendReviewUpdatedNotification($reviewData, $event->getOldReviewData());
                break;
            case 'review_deleted':
                $this->sendReviewDeletedNotification($reviewData);
                break;
        }
    }

    private function sendReviewCreatedNotification($reviewData) {

        error_log("Review created notification sent for review ID: " . $reviewData['review_id']);
    }

    private function sendReviewUpdatedNotification($reviewData, $oldReviewData) {

        error_log("Review updated notification sent for review ID: " . $reviewData['review_id']);
    }

    private function sendReviewDeletedNotification($reviewData) {

        error_log("Review deleted notification sent for review ID: " . $reviewData['review_id']);
    }
}

class ReviewCacheObserver implements ReviewObserver {

    public function update(ReviewEvent $event) {
        $eventType = $event->getEventType();
        $itemId = $event->getItemId();

        if (in_array($eventType, ['review_created', 'review_updated', 'review_deleted']) && $itemId) {
            $this->invalidateCache($itemId);
        }
    }

    private function invalidateCache($itemId) {

        error_log("Cache invalidated for item ID: $itemId");
    }
}

class ReviewAnalyticsObserver implements ReviewObserver {

    public function update(ReviewEvent $event) {
        $eventType = $event->getEventType();
        $reviewData = $event->getReviewData();

        switch ($eventType) {
            case 'review_created':
                $this->trackReviewCreated($reviewData);
                break;
            case 'review_updated':
                $this->trackReviewUpdated($reviewData);
                break;
        }
    }

    private function trackReviewCreated($reviewData) {

        error_log("Analytics: Review created with rating " . $reviewData['rating']);
    }

    private function trackReviewUpdated($reviewData) {

        error_log("Analytics: Review updated with rating " . $reviewData['rating']);
    }
}

class ReviewManager {

    private $reviewSubject;
    private $reviewModel;

    public function __construct($reviewModel) {
        $this->reviewModel = $reviewModel;
        $this->reviewSubject = new ReviewSubject();
        $this->setupObservers();
    }

    private function setupObservers() {

        $this->reviewSubject->attach(new ReviewSummaryObserver($this->reviewModel));
        $this->reviewSubject->attach(new ReviewNotificationObserver());
        $this->reviewSubject->attach(new ReviewCacheObserver());
        $this->reviewSubject->attach(new ReviewAnalyticsObserver());
    }

    public function createReview($reviewData) {
        try {

            $review = $this->reviewModel->create($reviewData);

            $event = new ReviewEvent(
                    'review_created',
                    $review->toArray(),
                    $reviewData['item_id'],
                    $reviewData['customer_id']
            );
            $this->reviewSubject->notify($event);

            return $review;
        } catch (Exception $e) {
            error_log("Failed to create review: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateReview($reviewId, $reviewData) {
        try {

            $oldReview = $this->reviewModel->find($reviewId);
            $oldReviewData = $oldReview ? $oldReview->toArray() : null;

            $review = $this->reviewModel->find($reviewId);
            if (!$review) {
                throw new Exception("Review not found");
            }

            $updatedReview = $review->update($reviewData);

            $event = new ReviewEvent(
                    'review_updated',
                    $updatedReview->toArray(),
                    $updatedReview->item_id,
                    $updatedReview->customer_id,
                    $oldReviewData
            );
            $this->reviewSubject->notify($event);

            return $updatedReview;
        } catch (Exception $e) {
            error_log("Failed to update review: " . $e->getMessage());
            throw $e;
        }
    }

    public function deleteReview($reviewId) {
        try {
            $review = $this->reviewModel->find($reviewId);
            if (!$review) {
                throw new Exception("Review not found");
            }

            $reviewData = $review->toArray();
            $itemId = $review->item_id;
            $customerId = $review->customer_id;

          
            $review->delete();

           
            $event = new ReviewEvent(
                    'review_deleted',
                    $reviewData,
                    $itemId,
                    $customerId
            );
            $this->reviewSubject->notify($event);

            return true;
        } catch (Exception $e) {
            error_log("Failed to delete review: " . $e->getMessage());
            throw $e;
        }
    }

    public function addObserver(ReviewObserver $observer) {
        $this->reviewSubject->attach($observer);
    }

    public function removeObserver(ReviewObserver $observer) {
        $this->reviewSubject->detach($observer);
    }
}
