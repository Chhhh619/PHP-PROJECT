<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

require_once 'BaseModel.php';

class LoyaltyTransaction extends BaseModel {
    protected $table = 'loyalty_transactions';
    protected $primaryKey = 'transaction_id';
    protected $fillable = [
        'customer_id', 'transaction_type', 'points', 'description',
        'reference_type', 'reference_id'
    ];

    const TYPE_EARNED = 'earned';
    const TYPE_REDEEMED = 'redeemed';
    const TYPE_EXPIRED = 'expired';
    const TYPE_BONUS = 'bonus';
    const TYPE_ADJUSTMENT = 'adjustment';

    const REF_ORDER = 'order';
    const REF_REDEMPTION = 'redemption';
    const REF_MANUAL = 'manual';
    const REF_PROMOTION = 'promotion';

    public static function getCustomerTransactions($customerId, $limit = null) {
        $instance = new self();
        $conditions = ['customer_id' => $customerId];
        $orderBy = 'created_at DESC';
        
        return $instance->findAll($conditions, $orderBy, $limit);
    }

    public static function calculateCustomerPoints($customerId) {
        $instance = new self();
        $transactions = $instance->findAll(['customer_id' => $customerId]);
        
        $totalPoints = 0;
        foreach ($transactions as $transaction) {
            $totalPoints += $transaction['points'];
        }
        
        return $totalPoints;
    }

    public static function getMonthlyEarned($customerId) {
        $instance = new self();
        $transactions = $instance->findAll([
            'customer_id' => $customerId,
            'transaction_type' => self::TYPE_EARNED
        ]);
        
        $monthlyPoints = 0;
        $currentMonth = date('n');
        $currentYear = date('Y');
        
        foreach ($transactions as $transaction) {
            $transactionDate = strtotime($transaction['created_at']);
            if (date('n', $transactionDate) == $currentMonth && date('Y', $transactionDate) == $currentYear) {
                $monthlyPoints += $transaction['points'];
            }
        }
        
        return $monthlyPoints;
    }

    public static function recordTransaction($customer_id, $points, $transaction_type, $description, $reference_id = null, $reference_type = null) {
        $instance = new self();
        
        $data = [
            'customer_id' => $customer_id,
            'transaction_type' => $transaction_type,
            'points' => $points,
            'description' => $description
        ];
        
        if ($reference_id) {
            $data['reference_id'] = $reference_id;
        }
        
        if ($reference_type) {
            $data['reference_type'] = $reference_type;
        }
        
        return $instance->create($data);
    }

    public static function getTransactionsByType($customerId, $transactionType, $limit = null) {
        $instance = new self();
        return $instance->findAll([
            'customer_id' => $customerId,
            'transaction_type' => $transactionType
        ], 'created_at DESC', $limit);
    }

    public static function getTransactionsByDateRange($customerId, $startDate, $endDate) {
        $instance = new self();
        $allTransactions = $instance->findAll(['customer_id' => $customerId], 'created_at DESC');
        
        $filteredTransactions = [];
        foreach ($allTransactions as $transaction) {
            $transactionDate = $transaction['created_at'];
            if ($transactionDate >= $startDate && $transactionDate <= $endDate) {
                $filteredTransactions[] = $transaction;
            }
        }
        
        return $filteredTransactions;
    }
}