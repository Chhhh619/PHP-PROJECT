<?php

/**
author : Cheng Jun Yang
 */

require_once 'BaseModel.php';

class ProductReview extends BaseModel {

    protected $table = 'product_reviews';
    protected $primaryKey = 'review_id';
    protected $fillable = [
        'order_id', 'item_id', 'customer_id', 'rating', 'review_text'
    ];

    public function getItemReviews($itemId, $limit = null, $status = 'active') {

        $query = $this->select([
                    'product_reviews.*',
                    'CONCAT(c.first_name, " ", c.last_name) as customer_name',
                    'mi.name as item_name'
                ])
                ->leftJoin('customers c', 'product_reviews.customer_id', '=', 'c.user_id') 
                ->leftJoin('menu_items mi', 'product_reviews.item_id', '=', 'mi.item_id') 
                ->where('product_reviews.item_id', $itemId)
                ->orderBy('product_reviews.created_at', 'DESC');

        if ($limit) {
            $query->limit($limit);
        }

        return $query->get();
    }

    public function getOrderItemsForReview($orderId, $customerId) {
        $orderItemModel = new class extends BaseModel {
            protected $table = 'order_items';
            protected $primaryKey = 'order_item_id'; 
        };

        $orderItems = $orderItemModel->where('order_id', $orderId)->get();

        $existingReviews = $this->where('customer_id', $customerId)
                ->where('order_id', $orderId)
                ->get();

        $result = [];
        foreach ($orderItems as $item) {
            $reviewData = null;
            foreach ($existingReviews as $review) {
                if ($review['item_id'] == $item['item_id']) {
                    $reviewData = $review;
                    break;
                }
            }

            $result[] = [
                'item_id' => $item['item_id'],
                'item_name' => $item['item_name'],
                'item_price' => $item['item_price'],
                'quantity' => $item['quantity'],
                'review_id' => $reviewData['review_id'] ?? null,
                'rating' => $reviewData['rating'] ?? null,
                'review_text' => $reviewData['review_text'] ?? null
            ];
        }

        return $result;
    }

    public function canCustomerReview($customerId, $itemId, $orderId) {
 
        $count = $this->select(['COUNT(*) as count'])
                ->from('orders o')
                ->join('order_items oi', 'o.order_id', '=', 'oi.order_id')
                ->where('o.customer_id', $customerId)
                ->where('oi.item_id', $itemId)
                ->where('o.order_id', $orderId)
                ->whereIn('o.order_status', ['delivered'])
                ->first();

        return $count && $count['count'] > 0;
    }

    public function reviewExists($customerId, $itemId, $orderId) {
        $review = $this->select(['review_id'])
                ->where('customer_id', $customerId)
                ->where('item_id', $itemId)
                ->where('order_id', $orderId)
                ->first();

        return $review !== null;
    }

    public function getExistingReview($customerId, $itemId, $orderId) {
        $result = $this->where('customer_id', $customerId)
                ->where('item_id', $itemId)
                ->where('order_id', $orderId)
                ->first();

        if ($result) {
            $this->attributes = $result;
            return $this;
        }
        return null;
    }

    public function getItemRatingStats($itemId) {
        $totalReviews = $this->where('item_id', $itemId)->count();
        $averageRating = $this->where('item_id', $itemId)->avg('rating');


        $ratingDistribution = $this->select([
                    'SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as rating_5',
                    'SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as rating_4',
                    'SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as rating_3',
                    'SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as rating_2',
                    'SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as rating_1'
                ])
                ->where('item_id', $itemId)
                ->first();

        return [
            'total_reviews' => $totalReviews ?: 0,
            'average_rating' => $averageRating ? round($averageRating, 2) : 0,
            'rating_5_count' => $ratingDistribution['rating_5'] ?? 0, // Fixed: added _count suffix
            'rating_4_count' => $ratingDistribution['rating_4'] ?? 0,
            'rating_3_count' => $ratingDistribution['rating_3'] ?? 0,
            'rating_2_count' => $ratingDistribution['rating_2'] ?? 0,
            'rating_1_count' => $ratingDistribution['rating_1'] ?? 0
        ];
    }

    public function updateReviewSummary($itemId) {
        $stats = $this->getItemRatingStats($itemId);

        $summaryModel = new class extends BaseModel {
            protected $table = 'review_summary';
            protected $primaryKey = 'item_id';
            protected $fillable = [
                'item_id', 'total_reviews', 'average_rating',
                'rating_1_count', 'rating_2_count', 'rating_3_count',
                'rating_4_count', 'rating_5_count'
            ];
        };

        $summaryData = [
            'item_id' => $itemId,
            'total_reviews' => $stats['total_reviews'],
            'average_rating' => $stats['average_rating'],
            'rating_1_count' => $stats['rating_1_count'], 
            'rating_2_count' => $stats['rating_2_count'],
            'rating_3_count' => $stats['rating_3_count'],
            'rating_4_count' => $stats['rating_4_count'],
            'rating_5_count' => $stats['rating_5_count']
        ];

        return $summaryModel->upsert($summaryData, [
                    'total_reviews', 'average_rating', 'rating_1_count',
                    'rating_2_count', 'rating_3_count', 'rating_4_count',
                    'rating_5_count'
        ]);
    }

    public function create($data) {
        if (!isset($data['rating']) || $data['rating'] < 1 || $data['rating'] > 5) {
            throw new Exception("Rating must be between 1 and 5");
        }

        $data['created_at'] = date('Y-m-d H:i:s');
        return parent::create($data);
    }

    public function update($data) {
        if (isset($data['rating']) && ($data['rating'] < 1 || $data['rating'] > 5)) {
            throw new Exception("Rating must be between 1 and 5");
        }

        return parent::update($data);
    }

    public function getCustomerReviews($customerId, $limit = null) {
   
        $query = $this->select([
                    'product_reviews.*',
                    'mi.name as item_name', 
                    'o.created_at as order_date'
                ])
                ->join('menu_items mi', 'product_reviews.item_id', '=', 'mi.item_id') 
                ->join('orders o', 'product_reviews.order_id', '=', 'o.order_id')
                ->where('product_reviews.customer_id', $customerId)
                ->orderBy('product_reviews.created_at', 'DESC');

        if ($limit) {
            $query->limit($limit);
        }

        return $query->get();
    }

    public function getReviewsPaginated($itemId, $page = 1, $limit = 10) {
       
        return $this->select([
                            'product_reviews.*',
                            'CONCAT(c.first_name, " ", c.last_name) as customer_name', 
                            'mi.name as item_name' // Fixed
                        ])
                        ->join('customers c', 'product_reviews.customer_id', '=', 'c.user_id') 
                        ->join('menu_items mi', 'product_reviews.item_id', '=', 'mi.item_id') 
                        ->where('product_reviews.item_id', $itemId)
                        ->orderBy('product_reviews.created_at', 'DESC')
                        ->paginate($page, $limit);
    }

    public function generateStarDisplay($rating, $maxStars = 5) {
        $fullStars = floor($rating);
        $halfStar = ($rating - $fullStars) >= 0.5 ? 1 : 0;
        $emptyStars = $maxStars - $fullStars - $halfStar;

        $display = str_repeat('★', $fullStars);
        if ($halfStar) {
            $display .= '☆';
        }
        $display .= str_repeat('☆', $emptyStars);

        return $display;
    }

    public function getCachedReviewSummary($itemId) {
        $summaryModel = new class extends BaseModel {
            protected $table = 'review_summary';
            protected $primaryKey = 'item_id';
        };

        $result = $summaryModel->where('item_id', $itemId)->first();

        if ($result) {
            return $result;
        }


        $this->updateReviewSummary($itemId);
        return $summaryModel->where('item_id', $itemId)->first();
    }
}
?>