<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun & Ong Zhi Yao
 * @module Order Management Function
 * @version 1.0
 */
require_once 'BaseModel.php';

class OrderFeedback extends BaseModel {
    protected $table = 'order_feedback';
    protected $primaryKey = 'feedback_id';
    protected $fillable = [
        'order_id', 'customer_id', 'feedback_text'
    ];
}