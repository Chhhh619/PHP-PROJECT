<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Order Management Function 
 * @version 2.0
 */
require_once 'BaseModel.php';
require_once 'Order.php';
require_once 'OrderItem.php';
require_once 'ProductReview.php';
require_once 'OrderFeedback.php';

class OrderModel extends BaseModel {
    
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    protected $fillable = [
        'customer_id', 'total_amount', 'subtotal', 'tax_amount',
        'delivery_fee', 'discount_amount', 'voucher_code', 
        'order_type', 'delivery_address', 'phone', 'notes',
        'payment_method', 'order_status', 'is_received', 'received_at'
    ];
    
    private $orderItem;
    private $productReview;
    private $orderFeedback;

    public function __construct() {
        parent::__construct();
        $this->orderItem = new OrderItem();
        $this->productReview = new ProductReview();
        $this->orderFeedback = new OrderFeedback();
    }

    /**
     * Create a new order using ORM
     */
    public function createOrder($orderData) {
        try {
            $this->beginTransaction();

            // Prepare order data with all fields
            $orderFields = [
                'customer_id' => $orderData['customer_id'],
                'total_amount' => $orderData['totals']['total'],
                'subtotal' => $orderData['totals']['subtotal'],
                'tax_amount' => $orderData['totals']['tax'],
                'delivery_fee' => $orderData['delivery_fee'] ?? 0,
                'discount_amount' => $orderData['discount_amount'] ?? 0,
                'voucher_code' => $orderData['voucher_code'] ?? null,
                'order_type' => $orderData['order_type'],
                'delivery_address' => $orderData['delivery_address'],
                'phone' => $orderData['phone'],
                'notes' => $orderData['notes'] ?? '',
                'payment_method' => $orderData['payment_method'],
                'payment_details' => isset($orderData['payment_details']) ? 
                    json_encode($orderData['payment_details']) : null,
                'order_status' => 'pending'
            ];

            // Create order using ORM
            $order = $this->create($orderFields);

            if (!$order) {
                throw new Exception('Failed to create order');
            }

            // Add order items using ORM
            foreach ($orderData['items'] as $cartKey => $item) {
                $orderItemData = [
                    'order_id' => $order->order_id,
                    'item_id' => $item['item_id'],
                    'item_name' => $item['name'],
                    'item_price' => $item['price'],
                    'quantity' => $item['quantity'],
                    'customizations' => json_encode($item['customizations'] ?? [])
                ];

                $orderItem = $this->orderItem->create($orderItemData);

                if (!$orderItem) {
                    throw new Exception('Failed to add order item');
                }
            }

            $this->commit();
            return $order->order_id;
            
        } catch (Exception $e) {
            $this->rollback();
            error_log("Error creating order: " . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Get all orders for a customer using ORM
     */
    public function getCustomerOrders($customer_id) {
        try {
            // Use ORM to get orders
            $orders = $this->where('customer_id', '=', $customer_id)
                          ->orderBy('created_at', 'DESC')
                          ->get();

            // Format each order
            $formattedOrders = [];
            foreach ($orders as $order) {
                // Get order items count using ORM
                $itemCount = $this->orderItem
                    ->where('order_id', '=', $order['order_id'])
                    ->sum('quantity');

                // Format the order data
                $formattedOrder = [
                    'order_id' => $order['order_id'],
                    'customer_id' => $order['customer_id'],
                    'total_amount' => $order['total_amount'],
                    'subtotal' => $order['subtotal'],
                    'tax_amount' => $order['tax_amount'],
                    'delivery_fee' => $order['delivery_fee'] ?? 0,
                    'discount_amount' => $order['discount_amount'] ?? 0,
                    'voucher_code' => $order['voucher_code'] ?? null,
                    'delivery_address' => $order['delivery_address'],
                    'phone' => $order['phone'],
                    'notes' => $order['notes'],
                    'payment_method' => $order['payment_method'],
                    'order_type' => $order['order_type'],
                    'order_status' => $order['order_status'],
                    'is_received' => $order['is_received'],
                    'received_at' => $order['received_at'],
                    'created_at' => $this->formatDateTime($order['created_at']),
                    'status_label' => $this->getStatusLabel($order['order_status']),
                    'formatted_total' => 'RM ' . number_format($order['total_amount'], 2),
                    'item_count' => $itemCount
                ];

                $formattedOrders[] = $formattedOrder;
            }

            return $formattedOrders;
            
        } catch (Exception $e) {
            error_log("Error getting customer orders: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get order details with all items using ORM
     */
    public function getOrderDetails($order_id, $customer_id) {
        try {
            // Get the order using ORM
            $order = $this->find($order_id);

            if (!$order || $order->customer_id != $customer_id) {
                return null;
            }

            // Get order items using ORM
            $items = $this->orderItem
                ->where('order_id', '=', $order_id)
                ->get();

            // Format items
            $formattedItems = [];
            foreach ($items as $item) {
                $formattedItems[] = [
                    'order_item_id' => $item['order_item_id'],
                    'item_id' => $item['item_id'],
                    'item_name' => $item['item_name'],
                    'item_price' => $item['item_price'],
                    'quantity' => $item['quantity'],
                    'customizations' => json_decode($item['customizations'], true),
                    'subtotal' => floatval($item['item_price']) * intval($item['quantity'])
                ];
            }

            // Calculate item count
            $itemCount = array_sum(array_column($formattedItems, 'quantity'));

            // Format the complete order details
            return [
                'order_id' => $order->order_id,
                'customer_id' => $order->customer_id,
                'total_amount' => $order->total_amount,
                'subtotal' => $order->subtotal,
                'tax_amount' => $order->tax_amount,
                'delivery_fee' => $order->delivery_fee ?? 0,
                'discount_amount' => $order->discount_amount ?? 0,
                'voucher_code' => $order->voucher_code ?? null,
                'delivery_address' => $order->delivery_address,
                'phone' => $order->phone,
                'notes' => $order->notes,
                'payment_method' => $order->payment_method,
                'order_type' => $order->order_type,
                'order_status' => $order->order_status,
                'is_received' => $order->is_received,
                'received_at' => $order->received_at,
                'created_at' => $this->formatDateTime($order->created_at),
                'status_label' => $this->getStatusLabel($order->order_status),
                'formatted_total' => 'RM ' . number_format($order->total_amount, 2),
                'item_count' => $itemCount,
                'items' => $formattedItems
            ];
            
        } catch (Exception $e) {
            error_log("Error getting order details: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Add review using ORM
     */
    public function addReview($review_data) {
        try {
            // Check if review exists using ORM
            $existingReview = $this->productReview
                ->where('order_id', '=', $review_data['order_id'])
                ->where('item_id', '=', $review_data['item_id'])
                ->where('customer_id', '=', $review_data['customer_id'])
                ->first();

            if ($existingReview) {
                // Update existing review using ORM
                $this->productReview
                    ->where('review_id', '=', $existingReview['review_id'])
                    ->updateWhere([
                        'rating' => $review_data['rating'],
                        'review_text' => $review_data['review_text']
                    ]);
            } else {
                // Create new review using ORM
                $this->productReview->create($review_data);
            }

            return true;
            
        } catch (Exception $e) {
            throw new Exception('Failed to save review: ' . $e->getMessage());
        }
    }

    /**
     * Check if order can be reviewed using ORM
     */
    public function canReviewOrder($order_id, $customer_id) {
        // Get order items using ORM
        $items = $this->orderItem
            ->where('order_id', '=', $order_id)
            ->get();

        if (empty($items)) {
            return false;
        }

        // Check if customer can review at least one item
        foreach ($items as $item) {
            if ($this->productReview->canCustomerReview($customer_id, $item['item_id'], $order_id)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get order reviews using ORM
     */
    public function getOrderReviews($order_id, $customer_id) {
        // Get all items with their reviews using ORM
        $items = $this->productReview->getOrderItemsForReview($order_id, $customer_id);

        // Index by item_id
        $indexed = [];
        foreach ($items as $item) {
            if ($item['review_id']) {
                $indexed[$item['item_id']] = [
                    'item_id' => $item['item_id'],
                    'item_name' => $item['item_name'],
                    'review_id' => $item['review_id'],
                    'rating' => $item['rating'],
                    'review_title' => $item['review_title'],
                    'review_text' => $item['review_text'],
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }
        }

        return $indexed;
    }

    /**
     * Submit feedback using ORM
     */
    public function submitFeedback($feedback_data) {
        try {
            // Check if feedback exists using ORM
            $existing = $this->orderFeedback
                ->where('order_id', '=', $feedback_data['order_id'])
                ->where('customer_id', '=', $feedback_data['customer_id'])
                ->first();

            if ($existing) {
                // Update existing feedback using ORM
                $this->orderFeedback
                    ->where('feedback_id', '=', $existing['feedback_id'])
                    ->updateWhere([
                        'feedback_text' => $feedback_data['feedback_text']
                    ]);
            } else {
                // Create new feedback using ORM
                $this->orderFeedback->create($feedback_data);
            }

            return true;
            
        } catch (Exception $e) {
            throw new Exception('Failed to submit feedback: ' . $e->getMessage());
        }
    }

    /**
     * Confirm order received using ORM
     */
    public function confirmOrderReceived($order_id, $customer_id) {
        try {
            $order = $this->find($order_id);

            if (!$order || $order->customer_id != $customer_id) {
                throw new Exception('Order not found');
            }

            if ($order->order_status !== 'delivered') {
                throw new Exception('Only delivered orders can be confirmed as received');
            }

            // Update order using ORM
            return $order->update([
                'is_received' => 1,
                'received_at' => date('Y-m-d H:i:s')
            ]);
            
        } catch (Exception $e) {
            throw new Exception('Failed to confirm order receipt: ' . $e->getMessage());
        }
    }

    /**
     * Get customer statistics using ORM
     */
    public function getCustomerStats($customer_id) {
        // Use ORM aggregation methods
        $totalOrders = $this->where('customer_id', '=', $customer_id)->count();
        $totalSpent = $this->where('customer_id', '=', $customer_id)->sum('total_amount');
        $avgOrderValue = $this->where('customer_id', '=', $customer_id)->avg('total_amount');
        
        // Get last order date using ORM
        $lastOrder = $this->where('customer_id', '=', $customer_id)
                          ->orderBy('created_at', 'DESC')
                          ->limit(1)
                          ->first();

        return [
            'total_orders' => $totalOrders,
            'total_spent' => (float) $totalSpent,
            'avg_order_value' => (float) $avgOrderValue,
            'last_order_date' => $lastOrder ? 
                $this->formatDateTime($lastOrder['created_at']) : null
        ];
    }

    /**
     * Helper: Format datetime
     */
    private function formatDateTime($datetime) {
        return date('M j, Y g:i A', strtotime($datetime));
    }

    /**
     * Helper: Get status label
     */
    private function getStatusLabel($status) {
        $labels = [
            'pending' => 'Order Received',
            'confirmed' => 'Confirmed',
            'preparing' => 'Preparing',
            'ready' => 'Ready for Pickup',
            'delivered' => 'Delivered',
            'cancelled' => 'Cancelled'
        ];

        return $labels[$status] ?? ucfirst($status);
    }
}