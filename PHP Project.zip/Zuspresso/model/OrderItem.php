<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Order Item Model 
 * @version 1.0
 */
require_once 'BaseModel.php';

class OrderItem extends BaseModel {
    protected $table = 'order_items';
    protected $primaryKey = 'order_item_id';
    protected $fillable = [
        'order_id', 'item_id', 'item_name', 
        'item_price', 'quantity', 'customizations'
    ];
    
    /**
     * Get items for a specific order
     */
    public function getOrderItems($orderId) {
        return $this->findAll(['order_id' => $orderId]);
    }
    
    /**
     * Calculate subtotal for the item
     */
    public function getSubtotal() {
        return $this->item_price * $this->quantity;
    }
    
    /**
     * Get the associated menu item details
     */
    public function getMenuItem() {
        require_once 'MenuItem.php';
        $menuItem = new MenuItem();
        return $menuItem->find($this->item_id);
    }
    
    /**
     * Parse customizations from JSON
     */
    public function getCustomizations() {
        if ($this->customizations) {
            return json_decode($this->customizations, true);
        }
        return [];
    }
    
    /**
     * Check if item has been reviewed
     */
    public function hasReview($customerId) {
        require_once 'ProductReview.php';
        $review = new ProductReview();
        $results = $review->findAll([
            'order_id' => $this->order_id,
            'item_id' => $this->item_id,
            'customer_id' => $customerId
        ]);
        return !empty($results);
    }
    
    /**
     * Get review for this item
     */
    public function getReview($customerId) {
        require_once 'ProductReview.php';
        $review = new ProductReview();
        $results = $review->findAll([
            'order_id' => $this->order_id,
            'item_id' => $this->item_id,
            'customer_id' => $customerId
        ], null, 1);
        return !empty($results) ? $results[0] : null;
    }
    
    /**
     * Update stock quantity after order
     */
    public function updateStock() {
        require_once 'MenuItem.php';
        $menuItem = new MenuItem();
        $item = $menuItem->find($this->item_id);
        
        if ($item && $item->stock_quantity !== null) {
            $newStock = $item->stock_quantity - $this->quantity;
            if ($newStock < 0) $newStock = 0;
            $item->update(['stock_quantity' => $newStock]);
        }
    }
}