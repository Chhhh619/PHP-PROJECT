<?php


require_once 'BaseModel.php';

class ReportsModel extends BaseModel {
    
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    protected $fillable = [
        'customer_id', 'total_amount', 'subtotal', 'tax_amount', 
        'delivery_fee', 'discount_amount', 'order_status', 'order_type', 
        'payment_method', 'created_at', 'updated_at'
    ];
    
    public function __construct() {
        parent::__construct();
    }
    

    public function getSalesReport($startDate = null, $endDate = null, $groupBy = 'day') {
        if (!$startDate) $startDate = date('Y-m-01');
        if (!$endDate) $endDate = date('Y-m-d');
        
        try {
            
            $orders = $this->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->orderBy('created_at', 'ASC')
                          ->get();
            
            
            $groupedData = [];
            
            foreach ($orders as $order) {
                $period = $this->formatDateForGrouping($order['created_at'], $groupBy);
                
                if (!isset($groupedData[$period])) {
                    $groupedData[$period] = [
                        'period' => $period,
                        'total_orders' => 0,
                        'total_revenue' => 0,
                        'total_subtotal' => 0,
                        'total_tax' => 0,
                        'total_delivery_fees' => 0,
                        'total_discounts' => 0,
                        'completed_orders' => 0,
                        'cancelled_orders' => 0
                    ];
                }
                
                $groupedData[$period]['total_orders']++;
                $groupedData[$period]['total_revenue'] += floatval($order['total_amount']);
                $groupedData[$period]['total_subtotal'] += floatval($order['subtotal'] ?? 0);
                $groupedData[$period]['total_tax'] += floatval($order['tax_amount'] ?? 0);
                $groupedData[$period]['total_delivery_fees'] += floatval($order['delivery_fee'] ?? 0);
                $groupedData[$period]['total_discounts'] += floatval($order['discount_amount'] ?? 0);
                
                if ($order['order_status'] === 'delivered') {
                    $groupedData[$period]['completed_orders']++;
                }
                if ($order['order_status'] === 'cancelled') {
                    $groupedData[$period]['cancelled_orders']++;
                }
            }
            
            
            $results = [];
            foreach ($groupedData as $data) {
                $data['avg_order_value'] = $data['total_orders'] > 0 ? $data['total_revenue'] / $data['total_orders'] : 0;
                $results[] = $data;
            }
            
           
            usort($results, function($a, $b) {
                return strcmp($a['period'], $b['period']);
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getSalesReport error: " . $e->getMessage());
            return [];
        }
    }
    

    public function getBestSellingProducts($startDate = null, $endDate = null, $limit = 10) {
        if (!$startDate) $startDate = date('Y-m-01');
        if (!$endDate) $endDate = date('Y-m-d');
        $endDateTime = $endDate . ' 23:59:59';
        
        try {
            
            $orderItems = $this->select('oi.item_id, oi.quantity, oi.subtotal, oi.item_price, o.order_id, mi.name as product_name, mi.category, mi.price as current_price')
                              ->from('order_items oi')
                              ->join('orders o', 'oi.order_id', '=', 'o.order_id', 'INNER')
                              ->join('menu_items mi', 'oi.item_id', '=', 'mi.item_id', 'INNER')
                              ->whereBetween('o.created_at', $startDate, $endDateTime)
                              ->whereIn('o.order_status', ['delivered', 'preparing', 'ready'])
                              ->where('oi.is_free_item', 0)
                              ->get();
            
           
            $totalRevenue = array_sum(array_column($orderItems, 'subtotal'));
            if ($totalRevenue == 0) $totalRevenue = 1; // Avoid division by zero
            
           
            $productData = [];
            $orderCounts = [];
            
            foreach ($orderItems as $item) {
                $itemId = $item['item_id'];
                
                if (!isset($productData[$itemId])) {
                    $productData[$itemId] = [
                        'item_id' => $itemId,
                        'product_name' => $item['product_name'],
                        'category' => $item['category'],
                        'current_price' => $item['current_price'],
                        'total_quantity_sold' => 0,
                        'total_revenue' => 0,
                        'price_sum' => 0,
                        'price_count' => 0
                    ];
                    $orderCounts[$itemId] = [];
                }
                
                $productData[$itemId]['total_quantity_sold'] += intval($item['quantity']);
                $productData[$itemId]['total_revenue'] += floatval($item['subtotal']);
                $productData[$itemId]['price_sum'] += floatval($item['item_price']);
                $productData[$itemId]['price_count']++;
                
                
                $orderCounts[$itemId][$item['order_id']] = true;
            }
            
          
            $results = [];
            foreach ($productData as $itemId => $data) {
                $results[] = [
                    'item_id' => $data['item_id'],
                    'product_name' => $data['product_name'],
                    'category' => $data['category'],
                    'current_price' => $data['current_price'],
                    'total_quantity_sold' => $data['total_quantity_sold'],
                    'total_revenue' => $data['total_revenue'],
                    'avg_selling_price' => $data['price_count'] > 0 ? $data['price_sum'] / $data['price_count'] : 0,
                    'total_orders' => count($orderCounts[$itemId]),
                    'revenue_percentage' => round(($data['total_revenue'] / $totalRevenue) * 100, 2)
                ];
            }
            
            
            usort($results, function($a, $b) {
                if ($a['total_quantity_sold'] == $b['total_quantity_sold']) {
                    return $b['total_revenue'] <=> $a['total_revenue'];
                }
                return $b['total_quantity_sold'] <=> $a['total_quantity_sold'];
            });
            
            return array_slice($results, 0, $limit);
            
        } catch (Exception $e) {
            error_log("getBestSellingProducts error: " . $e->getMessage());
            return [];
        }
    }
    

    public function getOrderTrends($startDate = null, $endDate = null) {
        if (!$startDate) $startDate = date('Y-m-01');
        if (!$endDate) $endDate = date('Y-m-d');
        
        $trends = [];
        $trends['hourly_trends'] = $this->getHourlyTrends($startDate, $endDate);
        $trends['daily_trends'] = $this->getDailyTrends($startDate, $endDate);
        $trends['order_type_distribution'] = $this->getOrderTypeDistribution($startDate, $endDate);
        $trends['payment_method_distribution'] = $this->getPaymentMethodDistribution($startDate, $endDate);
        
        return $trends;
    }
    
 
    private function getHourlyTrends($startDate, $endDate) {
        try {
           
            $orders = $this->select('created_at, total_amount')
                          ->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->where('order_status', '!=', 'cancelled')
                          ->get();
            
            
            $hourlyData = [];
            for ($i = 0; $i < 24; $i++) {
                $hourlyData[$i] = [
                    'hour' => $i,
                    'order_count' => 0,
                    'hourly_revenue' => 0,
                    'revenue_sum' => 0
                ];
            }
            
            foreach ($orders as $order) {
                $hour = intval(date('H', strtotime($order['created_at'])));
                $hourlyData[$hour]['order_count']++;
                $hourlyData[$hour]['hourly_revenue'] += floatval($order['total_amount']);
                $hourlyData[$hour]['revenue_sum'] += floatval($order['total_amount']);
            }
            
           
            foreach ($hourlyData as &$data) {
                $data['avg_order_value'] = $data['order_count'] > 0 ? $data['hourly_revenue'] / $data['order_count'] : 0;
            }
            
            return array_values($hourlyData);
            
        } catch (Exception $e) {
            error_log("getHourlyTrends error: " . $e->getMessage());
            return [];
        }
    }
    

    private function getDailyTrends($startDate, $endDate) {
        try {
            
            $orders = $this->select('created_at, total_amount')
                          ->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->where('order_status', '!=', 'cancelled')
                          ->get();
            
            
            $dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            $dailyData = [];
            for ($i = 0; $i < 7; $i++) {
                $dailyData[$i] = [
                    'day_name' => $dayNames[$i],
                    'day_number' => $i + 1, // MySQL DAYOFWEEK starts at 1
                    'order_count' => 0,
                    'daily_revenue' => 0
                ];
            }
            
            foreach ($orders as $order) {
                $dayOfWeek = intval(date('w', strtotime($order['created_at']))); // 0 = Sunday
                $dailyData[$dayOfWeek]['order_count']++;
                $dailyData[$dayOfWeek]['daily_revenue'] += floatval($order['total_amount']);
            }
            
            
            foreach ($dailyData as &$data) {
                $data['avg_order_value'] = $data['order_count'] > 0 ? $data['daily_revenue'] / $data['order_count'] : 0;
            }
            
            return array_values($dailyData);
            
        } catch (Exception $e) {
            error_log("getDailyTrends error: " . $e->getMessage());
            return [];
        }
    }
    

    private function getOrderTypeDistribution($startDate, $endDate) {
        try {
            $endDateTime = $endDate . ' 23:59:59';
            
           
            $totalCount = $this->whereBetween('created_at', $startDate, $endDateTime)
                              ->where('order_status', '!=', 'cancelled')
                              ->count();
            
            if ($totalCount == 0) $totalCount = 1; // Avoid division by zero
            
            
            $orders = $this->select('order_type, total_amount')
                          ->whereBetween('created_at', $startDate, $endDateTime)
                          ->where('order_status', '!=', 'cancelled')
                          ->get();
            
           
            $typeData = [];
            foreach ($orders as $order) {
                $type = $order['order_type'] ?? 'unknown';
                
                if (!isset($typeData[$type])) {
                    $typeData[$type] = [
                        'order_type' => $type,
                        'count' => 0,
                        'revenue' => 0
                    ];
                }
                
                $typeData[$type]['count']++;
                $typeData[$type]['revenue'] += floatval($order['total_amount']);
            }
            
           
            $results = [];
            foreach ($typeData as $data) {
                $data['percentage'] = round(($data['count'] / $totalCount) * 100, 2);
                $results[] = $data;
            }
            
           
            usort($results, function($a, $b) {
                return $b['count'] <=> $a['count'];
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getOrderTypeDistribution error: " . $e->getMessage());
            return [];
        }
    }
    

    private function getPaymentMethodDistribution($startDate, $endDate) {
        try {
            $endDateTime = $endDate . ' 23:59:59';
            
            
            $totalCount = $this->whereBetween('created_at', $startDate, $endDateTime)
                              ->where('order_status', '!=', 'cancelled')
                              ->count();
            
            if ($totalCount == 0) $totalCount = 1; 
            
           
            $orders = $this->select('payment_method, total_amount')
                          ->whereBetween('created_at', $startDate, $endDateTime)
                          ->where('order_status', '!=', 'cancelled')
                          ->get();
            
            
            $methodData = [];
            foreach ($orders as $order) {
                $method = $order['payment_method'] ?? 'unknown';
                
                if (!isset($methodData[$method])) {
                    $methodData[$method] = [
                        'payment_method' => $method,
                        'count' => 0,
                        'revenue' => 0
                    ];
                }
                
                $methodData[$method]['count']++;
                $methodData[$method]['revenue'] += floatval($order['total_amount']);
            }
            
            
            $results = [];
            foreach ($methodData as $data) {
                $data['percentage'] = round(($data['count'] / $totalCount) * 100, 2);
                $results[] = $data;
            }
            
          
            usort($results, function($a, $b) {
                return $b['count'] <=> $a['count'];
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getPaymentMethodDistribution error: " . $e->getMessage());
            return [];
        }
    }
    
 
    public function getCategoryPerformance($startDate = null, $endDate = null) {
        if (!$startDate) $startDate = date('Y-m-01');
        if (!$endDate) $endDate = date('Y-m-d');
        $endDateTime = $endDate . ' 23:59:59';
        
        try {
            
            $orderItems = $this->select('oi.item_id, oi.quantity, oi.subtotal, oi.item_price, o.order_id, mi.category')
                              ->from('order_items oi')
                              ->join('orders o', 'oi.order_id', '=', 'o.order_id', 'INNER')
                              ->join('menu_items mi', 'oi.item_id', '=', 'mi.item_id', 'INNER')
                              ->whereBetween('o.created_at', $startDate, $endDateTime)
                              ->whereIn('o.order_status', ['delivered', 'preparing', 'ready'])
                              ->where('oi.is_free_item', 0)
                              ->get();
            
          
            $totalRevenue = array_sum(array_column($orderItems, 'subtotal'));
            if ($totalRevenue == 0) $totalRevenue = 1;
            
           
            $categoryData = [];
            $uniqueProducts = [];
            $orderCounts = [];
            
            foreach ($orderItems as $item) {
                $category = $item['category'];
                
                if (!isset($categoryData[$category])) {
                    $categoryData[$category] = [
                        'category' => $category,
                        'total_quantity_sold' => 0,
                        'total_revenue' => 0,
                        'price_sum' => 0,
                        'price_count' => 0
                    ];
                    $uniqueProducts[$category] = [];
                    $orderCounts[$category] = [];
                }
                
                $categoryData[$category]['total_quantity_sold'] += intval($item['quantity']);
                $categoryData[$category]['total_revenue'] += floatval($item['subtotal']);
                $categoryData[$category]['price_sum'] += floatval($item['item_price']);
                $categoryData[$category]['price_count']++;
                
                
                $uniqueProducts[$category][$item['item_id']] = true;
                $orderCounts[$category][$item['order_id']] = true;
            }
            
           
            $results = [];
            foreach ($categoryData as $category => $data) {
                $results[] = [
                    'category' => $category,
                    'unique_products' => count($uniqueProducts[$category]),
                    'total_quantity_sold' => $data['total_quantity_sold'],
                    'total_revenue' => $data['total_revenue'],
                    'avg_price' => $data['price_count'] > 0 ? $data['price_sum'] / $data['price_count'] : 0,
                    'total_orders' => count($orderCounts[$category]),
                    'revenue_percentage' => round(($data['total_revenue'] / $totalRevenue) * 100, 2)
                ];
            }
            
            
            usort($results, function($a, $b) {
                return $b['total_revenue'] <=> $a['total_revenue'];
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getCategoryPerformance error: " . $e->getMessage());
            return [];
        }
    }
    

    public function getCustomerAnalytics($startDate = null, $endDate = null) {
        if (!$startDate) $startDate = date('Y-m-01');
        if (!$endDate) $endDate = date('Y-m-d');
        
        try {
           
            $orders = $this->select('customer_id, order_id, total_amount, order_status')
                          ->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->get();
            
            
            $uniqueCustomers = [];
            $totalOrders = count($orders);
            $totalRevenue = 0;
            $completedOrders = 0;
            
            foreach ($orders as $order) {
                $uniqueCustomers[$order['customer_id']] = true;
                $totalRevenue += floatval($order['total_amount']);
                
                if ($order['order_status'] === 'delivered') {
                    $completedOrders++;
                }
            }
            
            $totalCustomers = count($uniqueCustomers);
            
            return [
                'total_customers' => $totalCustomers,
                'total_orders' => $totalOrders,
                'total_revenue' => $totalRevenue,
                'avg_order_value' => $totalOrders > 0 ? $totalRevenue / $totalOrders : 0,
                'orders_per_customer' => $totalCustomers > 0 ? round($totalOrders / $totalCustomers, 2) : 0,
                'completed_orders' => $completedOrders,
                'completion_rate' => $totalOrders > 0 ? round(($completedOrders / $totalOrders) * 100, 2) : 0
            ];
            
        } catch (Exception $e) {
            error_log("getCustomerAnalytics error: " . $e->getMessage());
            return [
                'total_customers' => 0,
                'total_orders' => 0,
                'total_revenue' => 0,
                'avg_order_value' => 0,
                'orders_per_customer' => 0,
                'completed_orders' => 0,
                'completion_rate' => 0
            ];
        }
    }
    

    public function getDashboardSummary() {
        try {
            $today = date('Y-m-d');
            $thisMonth = date('Y-m-01');
            $lastMonth = date('Y-m-01', strtotime('-1 month'));
            $lastMonthEnd = date('Y-m-t', strtotime('-1 month'));
            
            $todayStats = $this->getDayStats($today);
            $thisMonthStats = $this->getPeriodStats($thisMonth, $today);
            $lastMonthStats = $this->getPeriodStats($lastMonth, $lastMonthEnd);
            
            $revenueGrowth = $this->calculateGrowth($thisMonthStats['total_revenue'], $lastMonthStats['total_revenue']);
            $ordersGrowth = $this->calculateGrowth($thisMonthStats['total_orders'], $lastMonthStats['total_orders']);
            
            return [
                'today' => $todayStats,
                'this_month' => $thisMonthStats,
                'last_month' => $lastMonthStats,
                'growth' => [
                    'revenue' => $revenueGrowth,
                    'orders' => $ordersGrowth
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Dashboard Summary Error: " . $e->getMessage());
            return [
                'today' => $this->getEmptyStats(),
                'this_month' => $this->getEmptyStats(),
                'last_month' => $this->getEmptyStats(),
                'growth' => ['revenue' => 0, 'orders' => 0]
            ];
        }
    }
    

    private function getDayStats($date) {
        try {
            $orders = $this->select('total_amount, order_status')
                          ->whereBetween('created_at', $date, $date . ' 23:59:59')
                          ->get();
            
            $totalOrders = count($orders);
            $totalRevenue = 0;
            $completedOrders = 0;
            
            foreach ($orders as $order) {
                $totalRevenue += floatval($order['total_amount']);
                if ($order['order_status'] === 'delivered') {
                    $completedOrders++;
                }
            }
            
            return [
                'total_orders' => $totalOrders,
                'total_revenue' => $totalRevenue,
                'avg_order_value' => $totalOrders > 0 ? $totalRevenue / $totalOrders : 0,
                'completed_orders' => $completedOrders
            ];
            
        } catch (Exception $e) {
            error_log("Day Stats Error: " . $e->getMessage());
            return $this->getEmptyStats();
        }
    }
    

    private function getPeriodStats($startDate, $endDate) {
        try {
            $orders = $this->select('customer_id, total_amount, order_status')
                          ->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->get();
            
            $totalOrders = count($orders);
            $totalRevenue = 0;
            $completedOrders = 0;
            $uniqueCustomers = [];
            
            foreach ($orders as $order) {
                $totalRevenue += floatval($order['total_amount']);
                $uniqueCustomers[$order['customer_id']] = true;
                
                if ($order['order_status'] === 'delivered') {
                    $completedOrders++;
                }
            }
            
            return [
                'total_orders' => $totalOrders,
                'total_revenue' => $totalRevenue,
                'avg_order_value' => $totalOrders > 0 ? $totalRevenue / $totalOrders : 0,
                'completed_orders' => $completedOrders,
                'unique_customers' => count($uniqueCustomers)
            ];
            
        } catch (Exception $e) {
            error_log("Period Stats Error: " . $e->getMessage());
            $default = $this->getEmptyStats();
            $default['unique_customers'] = 0;
            return $default;
        }
    }
    

    public function getAllOrders($limit = 50) {
        return $this->orderBy('created_at', 'DESC')->limit($limit)->get();
    }
    

    public function getOrdersByStatus($status, $limit = 50) {
        return $this->where('order_status', $status)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }
    
    public function getOrdersByCustomer($customerId, $limit = 20) {
        return $this->where('customer_id', $customerId)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }
    

    public function getTotalRevenue($startDate = null, $endDate = null) {
        $query = $this->whereIn('order_status', ['delivered', 'preparing', 'ready']);
        
        if ($startDate) {
            $query->where('created_at', '>=', $startDate);
        }
        
        if ($endDate) {
            $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }
        
        return $query->sum('total_amount') ?: 0;
    }
    

    public function getOrderCount($startDate = null, $endDate = null) {
        $query = $this;
        
        if ($startDate) {
            $query = $query->where('created_at', '>=', $startDate);
        }
        
        if ($endDate) {
            $query = $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }
        
        return $query->count();
    }


    public function getRepeatCustomers($minOrders = 2) {
        try {
            
            $orders = $this->select('customer_id, total_amount, created_at')
                          ->orderBy('customer_id')
                          ->orderBy('created_at')
                          ->get();
            
            
            $customerData = [];
            foreach ($orders as $order) {
                $customerId = $order['customer_id'];
                
                if (!isset($customerData[$customerId])) {
                    $customerData[$customerId] = [
                        'customer_id' => $customerId,
                        'order_count' => 0,
                        'total_spent' => 0,
                        'first_order' => $order['created_at'],
                        'last_order' => $order['created_at']
                    ];
                }
                
                $customerData[$customerId]['order_count']++;
                $customerData[$customerId]['total_spent'] += floatval($order['total_amount']);
                $customerData[$customerId]['last_order'] = $order['created_at'];
            }
            
           
            $results = [];
            foreach ($customerData as $data) {
                if ($data['order_count'] >= $minOrders) {
                    $data['avg_order_value'] = $data['total_spent'] / $data['order_count'];
                    $results[] = $data;
                }
            }
            
           
            usort($results, function($a, $b) {
                return $b['order_count'] <=> $a['order_count'];
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getRepeatCustomers error: " . $e->getMessage());
            return [];
        }
    }


    public function getDailyOrderCounts($days = 30) {
        try {
            $startDate = date('Y-m-d', strtotime("-{$days} days"));
            $endDate = date('Y-m-d');
            
            
            $orders = $this->select('created_at')
                          ->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                          ->get();
            
           
            $dailyCounts = [];
            foreach ($orders as $order) {
                $date = date('Y-m-d', strtotime($order['created_at']));
                
                if (!isset($dailyCounts[$date])) {
                    $dailyCounts[$date] = [
                        'order_date' => $date,
                        'order_count' => 0
                    ];
                }
                
                $dailyCounts[$date]['order_count']++;
            }
            
            
            $results = array_values($dailyCounts);
            usort($results, function($a, $b) {
                return strcmp($a['order_date'], $b['order_date']);
            });
            
            return $results;
            
        } catch (Exception $e) {
            error_log("getDailyOrderCounts error: " . $e->getMessage());
            return [];
        }
    }
    

    private function formatDateForGrouping($dateString, $groupBy) {
        $timestamp = strtotime($dateString);
        
        switch ($groupBy) {
            case 'hour': 
                return date('Y-m-d H:00:00', $timestamp);
            case 'day': 
                return date('Y-m-d', $timestamp);
            case 'week': 
                return date('Y-W', $timestamp);
            case 'month': 
                return date('Y-m', $timestamp);
            case 'year': 
                return date('Y', $timestamp);
            default: 
                return date('Y-m-d', $timestamp);
        }
    }
    

    private function getEmptyStats() {
        return [
            'total_orders' => 0,
            'total_revenue' => 0,
            'avg_order_value' => 0,
            'completed_orders' => 0
        ];
    }
    

    private function calculateGrowth($current, $previous) {
        if ($previous == 0) {
            return $current > 0 ? 100 : 0;
        }
        return round((($current - $previous) / $previous) * 100, 2);
    }
}
?>