<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Order Management Function
 * @version 1.0
 */
require_once 'BaseModel.php';

class Order extends BaseModel {
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    protected $fillable = [
        'customer_id', 'total_amount', 'subtotal', 'tax_amount',
        'order_type', 'delivery_address', 'phone', 'notes',
        'payment_method', 'order_status', 'is_received', 'received_at'
    ];
}
