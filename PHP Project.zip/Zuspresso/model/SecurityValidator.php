<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

class SecurityValidator {
    
    public static function checkRateLimit($userId, $action, $maxAttempts = 5, $timeWindow = 300) {
        $cacheKey = "rate_limit_{$action}_{$userId}";
        $cacheFile = sys_get_temp_dir() . '/' . md5($cacheKey) . '.json';
        
        $now = time();
        $attempts = [];
        
        if (file_exists($cacheFile)) {
            $content = file_get_contents($cacheFile);
            $data = json_decode($content, true);
            if ($data && isset($data['attempts'])) {
                $attempts = $data['attempts'];
            }
        }
        
        $attempts = array_filter($attempts, function($timestamp) use ($now, $timeWindow) {
            return ($now - $timestamp) < $timeWindow;
        });
        
        if (count($attempts) >= $maxAttempts) {
            return false;
        }
        
        $attempts[] = $now;
        
        file_put_contents($cacheFile, json_encode(['attempts' => $attempts]));
        
        return true;
    }
    
    public static function logAction($userId, $action, $details = []) {
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'user_id' => $userId,
            'action' => $action,
            'details' => $details,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        
        $logFile = __DIR__ . '/../logs/security_' . date('Y-m-d') . '.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        file_put_contents($logFile, json_encode($logEntry) . "\n", FILE_APPEND | LOCK_EX);
    }
    
    public static function validateInput($input, $type, $options = []) {
        switch ($type) {
            case 'int':
                $result = filter_var($input, FILTER_VALIDATE_INT, $options);
                if ($result === false) {
                    throw new InvalidArgumentException("Invalid integer value");
                }
                return $result;
                
            case 'float':
                $result = filter_var($input, FILTER_VALIDATE_FLOAT, $options);
                if ($result === false) {
                    throw new InvalidArgumentException("Invalid float value");
                }
                return $result;
                
            case 'email':
                $result = filter_var($input, FILTER_VALIDATE_EMAIL);
                if ($result === false) {
                    throw new InvalidArgumentException("Invalid email address");
                }
                return $result;
                
            case 'string':
                $maxLength = $options['max_length'] ?? 255;
                $input = trim($input);
                if (strlen($input) > $maxLength) {
                    throw new InvalidArgumentException("String too long (max: {$maxLength})");
                }
                // Remove potentially dangerous characters
                return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
                
            case 'alphanumeric':
                if (!ctype_alnum($input)) {
                    throw new InvalidArgumentException("Input must be alphanumeric");
                }
                return $input;
                
            default:
                throw new InvalidArgumentException("Unknown validation type: {$type}");
        }
    }
    
    public static function checkSQLInjection($input) {
        $dangerousPatterns = [
            '/(\bunion\b.*\bselect\b)/i',
            '/(\bselect\b.*\bfrom\b)/i',
            '/(\binsert\b.*\binto\b)/i',
            '/(\bdelete\b.*\bfrom\b)/i',
            '/(\bupdate\b.*\bset\b)/i',
            '/(\bdrop\b.*\btable\b)/i',
            '/(--|#|\/\*)/i',
            '/(\bor\b.*=.*\bor\b)/i',
            '/(\'.*\bor\b.*\')/i'
        ];
        
        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return false;
            }
        }
        
        return true;
    }
    
    public static function checkXSS($input) {
        $dangerousPatterns = [
            '/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/mi',
            '/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/mi',
            '/javascript:/i',
            '/on\w+\s*=/i', // onclick, onload, etc.
            '/<object\b/i',
            '/<embed\b/i'
        ];
        
        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $input)) {
                return false;
            }
        }
        
        return true;
    }
    
    public static function generateSecureToken($length = 32) {
        return bin2hex(random_bytes($length / 2));
    }
    
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3          // 3 threads
        ]);
    }
    

    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public static function sanitizeFileUpload($file, $allowedTypes = [], $maxSize = 1048576) {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new Exception("Invalid file upload");
        }
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("File upload error: " . $file['error']);
        }
        
        if ($file['size'] > $maxSize) {
            throw new Exception("File too large (max: " . number_format($maxSize / 1024) . " KB)");
        }
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!empty($allowedTypes) && !in_array($mimeType, $allowedTypes)) {
            throw new Exception("Invalid file type. Allowed: " . implode(', ', $allowedTypes));
        }
        
        // Sanitize filename
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $file['name']);
        
        return [
            'name' => $filename,
            'tmp_name' => $file['tmp_name'],
            'size' => $file['size'],
            'mime_type' => $mimeType
        ];
    }
    
    public static function getClientIP() {
        $ipKeys = ['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'];
        
        foreach ($ipKeys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    public static function checkIPWhitelist($userIP, $allowedRanges = []) {
        if (empty($allowedRanges)) {
            return true; // No restrictions
        }
        
        foreach ($allowedRanges as $range) {
            if (strpos($range, '/') !== false) {
                // CIDR notation
                list($subnet, $mask) = explode('/', $range);
                if (self::ipInRange($userIP, $subnet, $mask)) {
                    return true;
                }
            } else {
                // Single IP
                if ($userIP === $range) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    private static function ipInRange($ip, $subnet, $mask) {
        $ipLong = ip2long($ip);
        $subnetLong = ip2long($subnet);
        $maskLong = -1 << (32 - $mask);
        
        return ($ipLong & $maskLong) === ($subnetLong & $maskLong);
    }
}