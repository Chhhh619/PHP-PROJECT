<?php
/**
author : Cheng Jun Yang
 */
require_once 'BaseModel.php';

class AuthLog extends BaseModel {
    protected $table = 'auth_logs';
    protected $primaryKey = 'log_id';
    protected $fillable = ['user_id', 'email', 'action', 'ip_address', 'user_agent'];
    
    public function setAttributes($attributes) {
        $this->attributes = $attributes;
        return $this;
    }
}