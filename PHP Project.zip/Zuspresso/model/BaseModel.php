<?php

abstract class BaseModel {

    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];
    protected $attributes = [];
    // NEW: Query builder properties
    protected $selectColumns = ['*'];
    protected $whereConditions = [];
    protected $joinClauses = [];
    protected $orderByClause = '';
    protected $limitClause = '';
    protected $groupByClause = '';
    protected $havingConditions = [];
    protected $queryParams = [];
    protected $currentTable = null;

    public function __construct() {
        $this->db = $this->getConnection();
        $this->resetQuery(); // NEW: Initialize query builder
    }

    private function getConnection() {
        $host = 'localhost';
        $dbname = 'zuspresso_db';
        $username = 'root';
        $password = '';

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        } catch (PDOException $e) {
            throw new Exception("Database connection failed: " . $e->getMessage());
        }
    }

    // EXISTING METHODS - UNCHANGED
    public function find($id) {
        $sql = "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch();
        if ($result) {
            $this->attributes = $result;
            return $this;
        }
        return null;
    }

    /**
     * Begin a database transaction
     * @return bool
     */
    public function beginTransaction() {
        return $this->db->beginTransaction();
    }

    /**
     * Commit the current transaction
     * @return bool
     */
    public function commit() {
        return $this->db->commit();
    }

    /**
     * Rollback the current transaction
     * @return bool
     */
    public function rollback() {
        return $this->db->rollback();
    }

    /**
     * Check if we're currently in a transaction
     * @return bool
     */
    public function inTransaction() {
        return $this->db->inTransaction();
    }

    public function transaction(callable $callback) {
        $this->beginTransaction();

        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (Exception $e) {
            $this->rollback();
            throw $e;
        }
    }

    public function getDb() {
        return $this->db;
    }

    public function findAll($conditions = [], $orderBy = null, $limit = null) {
        $sql = "SELECT * FROM {$this->table}";
        $params = [];

        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $key => $value) {
                $whereClause[] = "$key = :$key";
                $params[$key] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }

        if ($orderBy) {
            $sql .= " ORDER BY $orderBy";
        }

        if ($limit) {
            $sql .= " LIMIT $limit";
        }

        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function create($data) {
        $data = $this->sanitizeInput($data);
        $filteredData = $this->filterFillable($data);

        if (empty($filteredData)) {
            throw new Exception("No valid data provided for creation");
        }

        $columns = implode(', ', array_keys($filteredData));
        $placeholders = ':' . implode(', :', array_keys($filteredData));

        $sql = "INSERT INTO {$this->table} ($columns) VALUES ($placeholders)";
        $stmt = $this->db->prepare($sql);

        foreach ($filteredData as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }

        if ($stmt->execute()) {
            $this->attributes = array_merge($filteredData, [$this->primaryKey => $this->db->lastInsertId()]);
            return $this;
        }

        throw new Exception("Failed to create record");
    }

    public function update($data) {
        if (empty($this->attributes[$this->primaryKey])) {
            throw new Exception("Cannot update record without primary key");
        }

        $data = $this->sanitizeInput($data);
        $filteredData = $this->filterFillable($data);

        if (empty($filteredData)) {
            throw new Exception("No valid data provided for update");
        }

        $setParts = [];
        foreach ($filteredData as $key => $value) {
            $setParts[] = "$key = :$key";
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $setParts) . " WHERE {$this->primaryKey} = :id";
        $stmt = $this->db->prepare($sql);

        foreach ($filteredData as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindValue(':id', $this->attributes[$this->primaryKey]);

        if ($stmt->execute()) {
            $this->attributes = array_merge($this->attributes, $filteredData);
            return $this;
        }

        throw new Exception("Failed to update record");
    }

    public function updateById($id, $data) {
        $data = $this->sanitizeInput($data);
        $filteredData = $this->filterFillable($data);

        if (empty($filteredData)) {
            throw new Exception("No valid data provided for update");
        }

        $setParts = [];
        foreach ($filteredData as $key => $value) {
            $setParts[] = "$key = :$key";
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $setParts) . " WHERE {$this->primaryKey} = :id";
        $stmt = $this->db->prepare($sql);

        foreach ($filteredData as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindValue(':id', $id);

        return $stmt->execute();
    }

    public function getColumn($column, $conditions = []) {
        $sql = "SELECT $column FROM {$this->table}";
        $params = [];

        if (!empty($conditions)) {
            $whereClause = [];
            foreach ($conditions as $key => $value) {
                $whereClause[] = "$key = :$key";
                $params[$key] = $value;
            }
            $sql .= " WHERE " . implode(' AND ', $whereClause);
        }

        $sql .= " LIMIT 1";

        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->execute();

        return $stmt->fetchColumn();
    }

    public function delete() {
        if (empty($this->attributes[$this->primaryKey])) {
            throw new Exception("Cannot delete record without primary key");
        }

        $sql = "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':id', $this->attributes[$this->primaryKey]);

        return $stmt->execute();
    }

    public function query($sql, $params = []) {
        $stmt = $this->db->prepare($sql);

        foreach ($params as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }

        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function __get($key) {
        return $this->attributes[$key] ?? null;
    }

    public function __set($key, $value) {
        $this->attributes[$key] = $value;
    }

    public function toArray() {
        return $this->attributes;
    }

    protected function filterFillable($data) {
        if (empty($this->fillable)) {
            return $data;
        }

        return array_intersect_key($data, array_flip($this->fillable));
    }

    protected function sanitizeInput($data) {
        $sanitized = [];
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $sanitized[$key] = trim(htmlspecialchars($value, ENT_QUOTES, 'UTF-8'));
            } else {
                $sanitized[$key] = $value;
            }
        }
        return $sanitized;
    }

    // NEW ORM METHODS BELOW - ADDED FUNCTIONALITY
    // Reset query builder
    private function resetQuery() {
        $this->selectColumns = ['*'];
        $this->whereConditions = [];
        $this->joinClauses = [];
        $this->orderByClause = '';
        $this->limitClause = '';
        $this->groupByClause = '';
        $this->havingConditions = [];
        $this->queryParams = [];
        $this->currentTable = $this->table;
        return $this;
    }

    // Query Builder Methods
    public function select($columns = ['*']) {
        if (is_string($columns)) {
            $columns = [$columns];
        }
        $this->selectColumns = $columns;
        return $this;
    }

    public function from($table) {
        $this->currentTable = $table;
        return $this;
    }

    public function where($column, $operator = '=', $value = null) {
        if ($value === null && $operator !== 'IS NULL' && $operator !== 'IS NOT NULL') {
            $value = $operator;
            $operator = '=';
        }

        $paramKey = 'param_' . count($this->queryParams);
        $this->whereConditions[] = "$column $operator :$paramKey";

        if ($operator !== 'IS NULL' && $operator !== 'IS NOT NULL') {
            $this->queryParams[$paramKey] = $value;
        }

        return $this;
    }

    public function whereIn($column, $values) {
        $placeholders = [];
        foreach ($values as $i => $value) {
            $paramKey = 'param_' . count($this->queryParams);
            $placeholders[] = ":$paramKey";
            $this->queryParams[$paramKey] = $value;
        }

        $this->whereConditions[] = "$column IN (" . implode(', ', $placeholders) . ")";
        return $this;
    }

    public function whereLike($column, $value) {
        return $this->where($column, 'LIKE', $value);
    }

    public function whereBetween($column, $start, $end) {
        return $this->where($column, '>=', $start)->where($column, '<=', $end);
    }

    public function join($table, $firstColumn, $operator, $secondColumn, $type = 'INNER') {
        $this->joinClauses[] = "$type JOIN $table ON $firstColumn $operator $secondColumn";
        return $this;
    }

    public function leftJoin($table, $firstColumn, $operator, $secondColumn) {
        return $this->join($table, $firstColumn, $operator, $secondColumn, 'LEFT');
    }

    public function rightJoin($table, $firstColumn, $operator, $secondColumn) {
        return $this->join($table, $firstColumn, $operator, $secondColumn, 'RIGHT');
    }

    public function orderBy($column, $direction = 'ASC') {
        $this->orderByClause = "ORDER BY $column $direction";
        return $this;
    }

    public function limit($count, $offset = 0) {
        $this->limitClause = "LIMIT $count";
        if ($offset > 0) {
            $this->limitClause .= " OFFSET $offset";
        }
        return $this;
    }
    
    public function offset($offset) {
  
    if (!empty($this->limitClause)) {
        
        $this->limitClause = preg_replace('/\s+OFFSET\s+\d+/', '', $this->limitClause);
     
        if ($offset > 0) {
            $this->limitClause .= " OFFSET $offset";
        }
    } else {
      
        $this->limitClause = "LIMIT 18446744073709551615 OFFSET $offset";
    }
    return $this;
}

    public function groupBy($columns) {
        if (is_string($columns)) {
            $columns = [$columns];
        }
        $this->groupByClause = "GROUP BY " . implode(', ', $columns);
        return $this;
    }

    public function having($column, $operator, $value) {
        $paramKey = 'param_' . count($this->queryParams);
        $this->havingConditions[] = "$column $operator :$paramKey";
        $this->queryParams[$paramKey] = $value;
        return $this;
    }

    // Aggregation Methods
    public function count($column = '*') {
        return $this->aggregate('COUNT', $column);
    }

    public function sum($column) {
        return $this->aggregate('SUM', $column);
    }

    public function avg($column) {
        return $this->aggregate('AVG', $column);
    }

    public function max($column) {
        return $this->aggregate('MAX', $column);
    }

    public function min($column) {
        return $this->aggregate('MIN', $column);
    }

    private function aggregate($function, $column) {
        $this->selectColumns = ["$function($column) as result"];
        $sql = $this->buildSelectQuery();
        $stmt = $this->db->prepare($sql);
        $this->bindParams($stmt);
        $stmt->execute();

        $result = $stmt->fetch();
        $this->resetQuery();

        return $result ? $result['result'] : 0;
    }

    // Execute query and get results
    public function get() {
        $sql = $this->buildSelectQuery();
        $stmt = $this->db->prepare($sql);
        $this->bindParams($stmt);
        $stmt->execute();

        $results = $stmt->fetchAll();
        $this->resetQuery();

        return $results;
    }

    public function first() {
        $this->limit(1);
        $results = $this->get();
        return !empty($results) ? $results[0] : null;
    }

    // Pagination helper
    public function paginate($page = 1, $perPage = 10) {
        $offset = ($page - 1) * $perPage;
        $this->limit($perPage, $offset);
        return $this->get();
    }

    // Upsert method (INSERT ... ON DUPLICATE KEY UPDATE)
    public function upsert($data, $updateColumns = []) {
        $data = $this->sanitizeInput($data);
        $filteredData = $this->filterFillable($data);

        if (empty($filteredData)) {
            throw new Exception("No valid data provided for upsert");
        }

        $columns = implode(', ', array_keys($filteredData));
        $placeholders = ':' . implode(', :', array_keys($filteredData));

        $sql = "INSERT INTO {$this->table} ($columns) VALUES ($placeholders)";

        if (!empty($updateColumns)) {
            $updateParts = [];
            foreach ($updateColumns as $column) {
                if (isset($filteredData[$column])) {
                    $updateParts[] = "$column = VALUES($column)";
                }
            }
            if (!empty($updateParts)) {
                $sql .= " ON DUPLICATE KEY UPDATE " . implode(', ', $updateParts);
            }
        }

        $stmt = $this->db->prepare($sql);

        foreach ($filteredData as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }

        return $stmt->execute();
    }

    // Build SELECT query
    private function buildSelectQuery() {
        $tableToUse = $this->currentTable ?: $this->table;
        $sql = "SELECT " . implode(', ', $this->selectColumns) . " FROM {$tableToUse}";

        if (!empty($this->joinClauses)) {
            $sql .= " " . implode(' ', $this->joinClauses);
        }

        if (!empty($this->whereConditions)) {
            $sql .= " WHERE " . implode(' AND ', $this->whereConditions);
        }

        if (!empty($this->groupByClause)) {
            $sql .= " " . $this->groupByClause;
        }

        if (!empty($this->havingConditions)) {
            $sql .= " HAVING " . implode(' AND ', $this->havingConditions);
        }

        if (!empty($this->orderByClause)) {
            $sql .= " " . $this->orderByClause;
        }

        if (!empty($this->limitClause)) {
            $sql .= " " . $this->limitClause;
        }

        return $sql;
    }

    private function bindParams($stmt) {
        foreach ($this->queryParams as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
    }
    
    public function updateWhere($data) {
    $data = $this->sanitizeInput($data);
    $filteredData = $this->filterFillable($data);

    if (empty($filteredData)) {
        throw new Exception("No valid data provided for update");
    }

    if (empty($this->whereConditions)) {
        throw new Exception("Cannot update without WHERE conditions - use update() for primary key updates");
    }

    $setParts = [];
    $updateParams = [];
    
    foreach ($filteredData as $key => $value) {
        $paramKey = 'update_' . $key;
        $setParts[] = "$key = :$paramKey";
        $updateParams[$paramKey] = $value;
    }

    $sql = "UPDATE {$this->table} SET " . implode(', ', $setParts);
    
    if (!empty($this->whereConditions)) {
        $sql .= " WHERE " . implode(' AND ', $this->whereConditions);
    }

    $stmt = $this->db->prepare($sql);

  
    foreach ($updateParams as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    
  
    foreach ($this->queryParams as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }

    $result = $stmt->execute();
    
   
    $this->resetQuery();
    
    return $result;
}
}
