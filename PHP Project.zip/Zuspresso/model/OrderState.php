<?php
/**
 * Order State Design Pattern Implementation
 * @author Tang Wei Chiun
 * @module Order Management
 * @version 1.0
 */

require_once 'BaseModel.php';

// Abstract State Class
abstract class OrderState {
    protected $context;
    
    public function setContext(OrderContext $context) {
        $this->context = $context;
    }
    
    abstract public function handle();
    abstract public function canTransitionTo($state);
    abstract public function getStateName();
    abstract public function getNextPossibleStates();
    abstract public function canCancel();
    abstract public function canModify();
}

// Concrete State: Pending
class PendingState extends OrderState {
    public function handle() {
        return "Order is pending and waiting for confirmation";
    }
    
    public function canTransitionTo($state) {
        $allowed = ['preparing', 'canceled'];
        return in_array($state, $allowed);
    }
    
    public function getStateName() {
        return 'pending';
    }
    
    public function getNextPossibleStates() {
        return ['preparing', 'canceled'];
    }
    
    public function canCancel() {
        return true;
    }
    
    public function canModify() {
        return true;
    }
}

// Concrete State: Preparing
class PreparingState extends OrderState {
    public function handle() {
        return "Order is being prepared";
    }
    
    public function canTransitionTo($state) {
        $orderType = $this->context->getOrderType();
        
        if ($orderType === 'delivery') {
            $allowed = ['out for delivery', 'canceled'];
        } else { // pickup
            $allowed = ['ready to pickup', 'canceled'];
        }
        
        return in_array($state, $allowed);
    }
    
    public function getStateName() {
        return 'preparing';
    }
    
    public function getNextPossibleStates() {
        $orderType = $this->context->getOrderType();
        
        if ($orderType === 'delivery') {
            return ['out for delivery', 'canceled'];
        } else {
            return ['ready to pickup', 'canceled'];
        }
    }
    
    public function canCancel() {
        return true;
    }
    
    public function canModify() {
        return false;
    }
}

// Concrete State: Out for Delivery
class OutForDeliveryState extends OrderState {
    public function handle() {
        return "Order is out for delivery";
    }
    
    public function canTransitionTo($state) {
        $allowed = ['delivered'];
        return in_array($state, $allowed);
    }
    
    public function getStateName() {
        return 'out for delivery';
    }
    
    public function getNextPossibleStates() {
        return ['delivered'];
    }
    
    public function canCancel() {
        return false;
    }
    
    public function canModify() {
        return false;
    }
}

// Concrete State: Ready to Pickup
class ReadyToPickupState extends OrderState {
    public function handle() {
        return "Order is ready for pickup";
    }
    
    public function canTransitionTo($state) {
        $allowed = ['delivered'];
        return in_array($state, $allowed);
    }
    
    public function getStateName() {
        return 'ready to pickup';
    }
    
    public function getNextPossibleStates() {
        return ['delivered'];
    }
    
    public function canCancel() {
        return false;
    }
    
    public function canModify() {
        return false;
    }
}

// Concrete State: Delivered
class DeliveredState extends OrderState {
    public function handle() {
        return "Order has been delivered";
    }
    
    public function canTransitionTo($state) {
        return false; // Final state
    }
    
    public function getStateName() {
        return 'delivered';
    }
    
    public function getNextPossibleStates() {
        return [];
    }
    
    public function canCancel() {
        return false;
    }
    
    public function canModify() {
        return false;
    }
}

// Concrete State: Canceled
class CanceledState extends OrderState {
    public function handle() {
        return "Order has been canceled";
    }
    
    public function canTransitionTo($state) {
        return false; // Final state
    }
    
    public function getStateName() {
        return 'canceled';
    }
    
    public function getNextPossibleStates() {
        return [];
    }
    
    public function canCancel() {
        return false;
    }
    
    public function canModify() {
        return false;
    }
}

// Context Class
class OrderContext extends BaseModel {
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    
    private $state;
    private $orderId;
    private $orderType;
    private $orderData;
    
    public function __construct($orderId = null) {
        parent::__construct();
        
        if ($orderId) {
            $this->loadOrder($orderId);
        }
    }
    
    public function loadOrder($orderId) {
        $order = $this->find($orderId);
        if (!$order) {
            throw new Exception("Order not found");
        }
        
        $this->orderId = $orderId;
        $this->orderType = $order->order_type;
        $this->orderData = $order->toArray();
        
        // Set initial state based on current status
        $this->setState($this->createStateFromStatus($order->order_status));
        
        return $order;
    }
    
    private function createStateFromStatus($status) {
        switch ($status) {
            case 'pending':
                return new PendingState();
            case 'preparing':
                return new PreparingState();
            case 'out for delivery':
                return new OutForDeliveryState();
            case 'ready to pickup':
                return new ReadyToPickupState();
            case 'delivered':
                return new DeliveredState();
            case 'canceled':
                return new CanceledState();
            default:
                return new PendingState();
        }
    }
    
    public function setState(OrderState $state) {
        $this->state = $state;
        $this->state->setContext($this);
    }
    
    public function transitionTo($newStatus) {
        if (!$this->state->canTransitionTo($newStatus)) {
            throw new Exception("Cannot transition from {$this->state->getStateName()} to {$newStatus}");
        }
        
        // Update database
        $result = $this->updateStatus($newStatus);
        
        if ($result) {
            // Change state
            $this->setState($this->createStateFromStatus($newStatus));
            
            // Special handling for delivered status
            if ($newStatus === 'delivered') {
                $this->markAsDelivered();
            }
        }
        
        return $result;
    }
    
    private function updateStatus($newStatus) {
        $sql = "UPDATE orders SET order_status = ?, updated_at = NOW() WHERE order_id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$newStatus, $this->orderId]);
    }
    
    private function markAsDelivered() {
        $sql = "UPDATE orders SET is_received = 1, received_at = NOW() WHERE order_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$this->orderId]);
    }
    
    public function handle() {
        return $this->state->handle();
    }
    
    public function getOrderType() {
        return $this->orderType;
    }
    
    public function getCurrentState() {
        return $this->state->getStateName();
    }
    
    public function getNextPossibleStates() {
        return $this->state->getNextPossibleStates();
    }
    
    public function canCancel() {
        return $this->state->canCancel();
    }
    
    public function canModify() {
        return $this->state->canModify();
    }
    
    public function getOrderData() {
        return $this->orderData;
    }
}

// State Manager Helper Class for easier integration
class OrderStateManager {
    
    /**
     * Update order status using State Pattern
     */
    public static function updateOrderStatus($orderId, $newStatus) {
        try {
            $orderContext = new OrderContext($orderId);
            return $orderContext->transitionTo($newStatus);
        } catch (Exception $e) {
            error_log("State transition error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if order can transition to a specific state
     */
    public static function canTransitionTo($orderId, $targetStatus) {
        try {
            $orderContext = new OrderContext($orderId);
            $possibleStates = $orderContext->getNextPossibleStates();
            return in_array($targetStatus, $possibleStates);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Get current order state information
     */
    public static function getOrderStateInfo($orderId) {
        try {
            $orderContext = new OrderContext($orderId);
            return [
                'current_state' => $orderContext->getCurrentState(),
                'state_message' => $orderContext->handle(),
                'next_possible_states' => $orderContext->getNextPossibleStates(),
                'can_cancel' => $orderContext->canCancel(),
                'can_modify' => $orderContext->canModify()
            ];
        } catch (Exception $e) {
            return null;
        }
    }
}
?>