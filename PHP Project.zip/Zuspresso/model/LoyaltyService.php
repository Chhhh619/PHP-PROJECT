<?php

require_once __DIR__ . '/BaseModel.php';
require_once __DIR__ . '/Customer.php';
require_once __DIR__ . '/LoyaltyTransaction.php';
require_once __DIR__ . '/Reward.php';
require_once __DIR__ . '/RewardRedemption.php';
require_once __DIR__ . '/SecurityValidator.php';
require_once __DIR__ . '/TierManager.php';
require_once __DIR__ . '/strategies/PointCalculationStrategy.php';
require_once __DIR__ . '/strategies/VIPPointStrategy.php';
require_once __DIR__ . '/strategies/BronzePointStrategy.php';
require_once __DIR__ . '/strategies/SilverPointStrategy.php';
require_once __DIR__ . '/strategies/GoldPointStrategy.php';
require_once __DIR__ . '/strategies/PlatinumPointStrategy.php';
require_once __DIR__ . '/strategies/PromotionPointStrategy.php';

class LoyaltyService {

    private $pointStrategy;

    public function __construct(PointCalculationStrategy $strategy = null) {
        $this->pointStrategy = $strategy ?: new BronzePointStrategy();
    }

    public function setPointStrategy(PointCalculationStrategy $strategy) {
        $this->pointStrategy = $strategy;

        SecurityValidator::logAction('system', 'strategy_changed', [
            'new_strategy' => $strategy->getStrategyName(),
            'description' => $strategy->getDescription()
        ]);
    }

    public function getCurrentStrategy() {
        return [
            'name' => $this->pointStrategy->getStrategyName(),
            'description' => $this->pointStrategy->getDescription(),
            'is_promotional' => $this->isTuesdayPromotion()
        ];
    }

    private function isTuesdayPromotion() {
        return date('N') == 2;
    }

    public function getTuesdayPromotionStatus() {
        return [
            'is_tuesday' => date('N') == 2,
            'is_promotion_active' => $this->isTuesdayPromotion(),
            'current_multiplier' => $this->isTuesdayPromotion() ? 2.5 : 1.0,
            'current_day' => date('l'),
            'promotion_message' => $this->isTuesdayPromotion() ? 'Tuesday Bonus: 2.5x Points!' : 'Every Tuesday is ZUSDay!: 2.5x Points!'
        ];
    }

    public function setStrategyByCustomer($customer_id, $orderItems = null) {
        $tierInfo = $this->getTierInfo($customer_id);
        $tier = $tierInfo['current_tier'];

        error_log("DEBUG: setStrategyByCustomer - customer_id: $customer_id, tier: $tier, current_points: {$tierInfo['current_points']}");

        if ($this->isTuesdayPromotion()) {
            error_log("DEBUG: Tuesday promotion active - setting PromotionPointStrategy(2.5)");
            $this->setPointStrategy(new PromotionPointStrategy(2.5, "Tuesday Bonus"));
            return;
        }

        error_log("DEBUG: Not Tuesday, setting tier-specific strategy for: $tier");

        switch ($tier) {
            case 'Platinum':
                error_log("DEBUG: Setting PlatinumPointStrategy for Platinum");
                $this->setPointStrategy(new PlatinumPointStrategy());
                break;

            case 'Gold':
                error_log("DEBUG: Setting GoldPointStrategy for Gold");
                $this->setPointStrategy(new GoldPointStrategy());
                break;

            case 'Silver':
                error_log("DEBUG: Setting SilverPointStrategy for Silver");
                $this->setPointStrategy(new SilverPointStrategy());
                break;

            case 'Bronze':
            default:
                error_log("DEBUG: Setting BronzePointStrategy for Bronze/default");
                $this->setPointStrategy(new BronzePointStrategy());
                break;
        }

        $currentStrategy = $this->getCurrentStrategy();
        error_log("DEBUG: Strategy set to: " . json_encode($currentStrategy));
    }

    public function calculatePointsForOrder($orderAmount, $customerId = null, $orderItems = null) {
        if ($customerId) {
            $this->setStrategyByCustomer($customerId, $orderItems);
        } else {
            if ($this->isTuesdayPromotion()) {
                $this->setPointStrategy(new BonusPointStrategy(2.5));
            }
        }

        $points = $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems);

        SecurityValidator::logAction($customerId ?? 'guest', 'points_calculated', [
            'strategy' => $this->pointStrategy->getStrategyName(),
            'order_amount' => $orderAmount,
            'calculated_points' => $points,
            'items_count' => $orderItems ? count($orderItems) : 0,
            'is_tuesday_promotion' => $this->isTuesdayPromotion()
        ]);

        return $points;
    }

    public function awardOrderPoints($customer_id, $order_amount, $order_id, $orderItems = null) {
        error_log("DEBUG: awardOrderPoints called - customer_id: $customer_id, order_amount: $order_amount, order_id: $order_id");

        $tierInfo = $this->getTierInfo($customer_id);
        error_log("DEBUG: Customer tier info: " . json_encode($tierInfo));

        $dayOfWeek = date('N');
        $dayName = date('l');
        $isTuesday = ($dayOfWeek == 2);
        error_log("DEBUG: Current day - N=$dayOfWeek ($dayName), isTuesday=" . ($isTuesday ? 'true' : 'false'));

        if ($orderItems) {
            error_log("DEBUG: Order items: " . json_encode($orderItems));
        }

        error_log("=== DEBUG: Order Items Structure ===");
        error_log("Order Items: " . print_r($orderItems, true));
        $points = $this->calculatePointsForOrder($order_amount, $customer_id, $orderItems);

        $strategyInfo = $this->getCurrentStrategy();
        error_log("DEBUG: Final strategy used: " . json_encode($strategyInfo));
        error_log("DEBUG: Calculated points: $points");

        if ($points > 0) {
            $description = "Points earned from order #{$order_id} using {$strategyInfo['name']}";

            $result = $this->addPoints(
                    $customer_id,
                    $points,
                    $description,
                    $order_id
            );

            $result['strategy_used'] = $strategyInfo;
            $result['base_calculation'] = "RM{$order_amount} → {$points} points";

            return $result;
        }

        return [
            'success' => false,
            'message' => 'No points to award',
            'strategy_used' => $this->getCurrentStrategy()
        ];
    }

    public function getCustomerPoints($customer_id) {
        $customer = new Customer();
        $result = $customer->getColumn('loyalty_points', ['customer_id' => $customer_id]);
        return $result !== false ? (int) $result : 0;
    }

    private function getCustomerIdFromUserId($user_id) {
        $customer = new Customer();
        $result = $customer->getColumn('customer_id', ['user_id' => $user_id]);
        if ($result === false) {
            throw new Exception("Customer record not found for user_id: " . $user_id);
        }
        return (int) $result;
    }

    public function addPoints($customer_id, $points, $description = 'Points earned', $order_id = null) {
        if (!is_numeric($points) || $points < 0) {
            throw new InvalidArgumentException("Points must be a positive number");
        }

        if (!$this->customerExists($customer_id)) {
            throw new Exception("Customer not found");
        }

        $idempotencyKey = $order_id ? "points_award_{$customer_id}_{$order_id}" : "points_manual_{$customer_id}_" . time();

        if ($order_id && $this->isOperationProcessed($idempotencyKey)) {
            return $this->getProcessedOperation($idempotencyKey);
        }

        try {
            $customer = new Customer();

            if (property_exists($customer, 'db') && $customer->db) {
                $customer->db->beginTransaction();
            }

            $customerData = $customer->where('customer_id', '=', $customer_id)->first();

            if (!$customerData) {
                throw new Exception("Customer not found");
            }

            $user_id = $customerData['user_id'];
            $currentPoints = (int) $customerData['loyalty_points'];
            $newPoints = $currentPoints + $points;

            if (method_exists($customer, 'updateById')) {
                $updateResult = $customer->updateById($customer_id, [
                    'loyalty_points' => $newPoints
                ]);
                $rowsAffected = $updateResult ? 1 : 0;
            } else {
                throw new Exception("Unable to update customer points");
            }

            if ($rowsAffected === 0) {
                throw new Exception("Points update failed");
            }

            $transactionResult = LoyaltyTransaction::recordTransaction(
                    $user_id,
                    $points,
                    'earned',
                    $description,
                    $order_id
            );

            if (!$transactionResult) {
                throw new Exception("Failed to record loyalty transaction");
            }

            $result = [
                'success' => true,
                'points_added' => $points,
                'new_balance' => $newPoints
            ];

            if ($order_id) {
                $this->storeProcessedOperation($idempotencyKey, $result);
            }

            SecurityValidator::logAction($user_id, 'points_awarded', [
                'customer_id' => $customer_id,
                'points' => $points,
                'new_balance' => $newPoints,
                'order_id' => $order_id,
                'strategy_used' => $this->getCurrentStrategy()['name']
            ]);

            if (property_exists($customer, 'db') && $customer->db) {
                $customer->db->commit();
            }

            if ($result['success']) {
                // Add tier update after successful point addition
                $tierManager = new TierManager();
                $tierUpdate = $tierManager->updateCustomerTier($customer_id);

                if ($tierUpdate['updated']) {
                    $result['tier_upgraded'] = true;
                    $result['new_tier'] = $tierUpdate['new_tier'];
                    $result['upgrade_message'] = "Congratulations! You've been upgraded to {$tierUpdate['new_tier']} tier!";

                    SecurityValidator::logAction($user_id, 'tier_upgraded', [
                        'customer_id' => $customer_id,
                        'old_tier' => $tierUpdate['old_tier'],
                        'new_tier' => $tierUpdate['new_tier'],
                        'points' => $tierUpdate['points']
                    ]);
                }
            }

            return $result;
        } catch (Exception $e) {
            if (isset($customer) && property_exists($customer, 'db') && $customer->db) {
                $customer->db->rollback();
            }

            SecurityValidator::logAction($user_id ?? 'unknown', 'points_award_failed', [
                'customer_id' => $customer_id,
                'points' => $points,
                'error' => $e->getMessage()
            ]);

            throw $e;
        }
    }

    public function deductPoints($customer_id, $points, $description = 'Points redeemed') {
        if (!is_numeric($points) || $points < 0) {
            throw new InvalidArgumentException("Points must be a positive number");
        }

        if (!$this->customerExists($customer_id)) {
            throw new Exception("Customer not found");
        }

        $customer = new Customer();
        $db_connection = null;

        if (property_exists($customer, 'db') && $customer->db) {
            $db_connection = $customer->db;
        }

        try {
            if ($db_connection) {
                $db_connection->beginTransaction();
                error_log("Transaction started");
            }

            $customerData = $customer->where('customer_id', '=', $customer_id)->first();

            if (!$customerData) {
                throw new Exception("Customer not found in database");
            }

            $user_id = $customerData['user_id'];
            $currentPoints = (int) $customerData['loyalty_points'];
            error_log("Current points: $currentPoints");

            if ($currentPoints < $points) {
                throw new Exception("Insufficient loyalty points. Current balance: " . $currentPoints . ", Required: " . $points);
            }

            $newPoints = $currentPoints - $points;
            error_log("New points will be: $newPoints");

            if (method_exists($customer, 'updateById')) {
                $updateResult = $customer->updateById($customer_id, [
                    'loyalty_points' => $newPoints
                ]);
                $rowsAffected = $updateResult ? 1 : 0;
                error_log("BaseModel update result: " . ($updateResult ? 'true' : 'false'));
            } else {
                throw new Exception("Unable to update customer points - no update method available");
            }

            if ($rowsAffected === 0) {
                throw new Exception("Failed to update customer points - no rows affected");
            }

            $verifyData = $customer->where('customer_id', '=', $customer_id)->first();
            $actualNewPoints = (int) $verifyData['loyalty_points'];
            error_log("Verified points in database: $actualNewPoints");

            if ($actualNewPoints !== $newPoints) {
                throw new Exception("Points update verification failed. Expected: $newPoints, Got: $actualNewPoints");
            }

            $transactionResult = LoyaltyTransaction::recordTransaction(
                    $user_id,
                    -$points,
                    'redeemed',
                    $description
            );

            if (!$transactionResult) {
                throw new Exception("Failed to record loyalty transaction");
            }

            error_log("Transaction recorded successfully");

            SecurityValidator::logAction($user_id, 'points_deducted', [
                'customer_id' => $customer_id,
                'points' => $points,
                'new_balance' => $newPoints
            ]);

            if ($db_connection) {
                $db_connection->commit();
                error_log("Transaction committed");
            }

            return [
                'success' => true,
                'points_deducted' => $points,
                'new_balance' => $newPoints
            ];
        } catch (Exception $e) {
            if ($db_connection && $db_connection->inTransaction()) {
                $db_connection->rollback();
                error_log("Transaction rolled back due to error: " . $e->getMessage());
            }
            throw $e;
        }
    }

    public function redeemRewardWithSecurity($user_id, $reward_id, $idempotency_key) {
        if (!is_numeric($user_id) || !is_numeric($reward_id)) {
            throw new InvalidArgumentException("Invalid user or reward ID");
        }

        error_log("Starting redemption for user_id: $user_id, reward_id: $reward_id");

        $customer_id = $this->getCustomerIdFromUserId($user_id);
        error_log("Found customer_id: $customer_id for user_id: $user_id");

        $reward = Reward::getById($reward_id);
        if (!$reward || !$reward['is_active']) {
            throw new Exception("Reward not available or inactive");
        }

        if (isset($reward['stock_quantity']) && $reward['stock_quantity'] !== null && $reward['stock_quantity'] <= 0) {
            throw new Exception("Reward is out of stock");
        }

        if ($this->hasRecentSameRewardRedemption($customer_id, $reward_id, 86400)) {
            $hoursRemaining = $this->getRedemptionTimeRemaining($customer_id, $reward_id);
            $timeMessage = $hoursRemaining > 1 ? "{$hoursRemaining} hours" : "a few minutes";
            throw new Exception("You have already redeemed this reward recently. Please wait {$timeMessage} before redeeming the same reward again.");
        }

        if ($this->hasVeryRecentRedemption($customer_id, $reward_id, 2)) {
            throw new Exception("Please wait a moment before redeeming this reward again");
        }

        try {
            error_log("Checking customer points...");

            $currentPoints = $this->getCustomerPoints($customer_id);
            error_log("Customer current points: $currentPoints");
            error_log("Points required: {$reward['points_required']}");

            if ($currentPoints < $reward['points_required']) {
                throw new Exception("Insufficient loyalty points. Required: " . $reward['points_required'] . ", Available: " . $currentPoints);
            }

            error_log("Deducting points...");
            $deductResult = $this->deductPoints($customer_id, $reward['points_required'], "Redeemed: " . $reward['name']);

            if (!$deductResult['success']) {
                throw new Exception("Failed to deduct points");
            }

            error_log("Points deducted successfully. New balance: {$deductResult['new_balance']}");

            error_log("Creating redemption record...");
            $redemption = RewardRedemption::createRedemption($user_id, $reward_id, $reward['points_required']);

            if (!$redemption) {
                error_log("Redemption creation failed, attempting to restore points...");
                try {
                    $this->addPoints($customer_id, $reward['points_required'], "Refund: Failed redemption");
                } catch (Exception $refundException) {
                    error_log("WARNING: Failed to refund points after redemption failure: " . $refundException->getMessage());
                }
                throw new Exception("Failed to create redemption record");
            }

            error_log("Redemption record created: " . json_encode($redemption));

            if (isset($reward['stock_quantity']) && $reward['stock_quantity'] !== null) {
                $rewardModel = new Reward();
                if (method_exists($rewardModel, 'updateById')) {
                    $stockResult = $rewardModel->updateById($reward_id, [
                        'stock_quantity' => $reward['stock_quantity'] - 1
                    ]);
                    error_log("Stock updated: " . ($stockResult ? 'success' : 'failed'));
                }
            }

            $result = [
                'success' => true,
                'redemption_id' => $redemption['redemption_id'],
                'redemption_code' => $redemption['redemption_code'],
                'reward_name' => $reward['name'],
                'points_used' => $reward['points_required'],
                'remaining_points' => $deductResult['new_balance']
            ];

            $this->storeProcessedOperation($idempotency_key, $result);

            SecurityValidator::logAction($user_id, 'reward_redeemed', [
                'customer_id' => $customer_id,
                'reward_id' => $reward_id,
                'points_used' => $reward['points_required'],
                'redemption_code' => $redemption['redemption_code']
            ]);

            error_log("Redemption completed successfully");
            return $result;
        } catch (Exception $e) {
            SecurityValidator::logAction($user_id ?? 'unknown', 'failed_redemption', [
                'customer_id' => $customer_id,
                'reward_id' => $reward_id,
                'error' => $e->getMessage(),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ]);

            error_log("Redemption failed: " . $e->getMessage());
            throw $e;
        }
    }

    private function hasRecentSameRewardRedemption($customer_id, $reward_id, $timeWindow = 30) {
        try {
            error_log("DEBUG: Checking recent redemption - customer_id: $customer_id, reward_id: $reward_id");

            $redemptionModel = new RewardRedemption();
            $user_id = $this->getUserIdFromCustomerId($customer_id);

            error_log("DEBUG: Found user_id: $user_id from customer_id: $customer_id");

            $recentRedemptions = $redemptionModel->findAll([
                'customer_id' => $user_id,
                'reward_id' => $reward_id
            ]);

            error_log("DEBUG: Found " . count($recentRedemptions) . " total redemptions for this reward");

            $cutoffTime = date('Y-m-d H:i:s', time() - $timeWindow);
            error_log("DEBUG: Cutoff time: $cutoffTime");

            foreach ($recentRedemptions as $redemption) {
                error_log("DEBUG: Redemption - Date: {$redemption['redeemed_at']}, Status: {$redemption['status']}");

                if ($redemption['redeemed_at'] > $cutoffTime &&
                        $redemption['status'] !== 'cancelled') {

                    error_log("DEBUG: Found recent same reward redemption within {$timeWindow} seconds");
                    return true;
                }
            }

            error_log("DEBUG: No recent same reward redemption found");
            return false;
        } catch (Exception $e) {
            error_log("ERROR in hasRecentSameRewardRedemption: " . $e->getMessage());
            return true;
        }
    }

    private function getRedemptionTimeRemaining($customer_id, $reward_id) {
        try {
            $redemptionModel = new RewardRedemption();
            $user_id = $this->getUserIdFromCustomerId($customer_id);

            $recentRedemptions = $redemptionModel->findAll([
                'customer_id' => $user_id,
                'reward_id' => $reward_id
            ]);

            $mostRecentTime = null;
            foreach ($recentRedemptions as $redemption) {
                if ($redemption['status'] !== 'cancelled') {
                    $redemptionTime = strtotime($redemption['redeemed_at']);
                    if (!$mostRecentTime || $redemptionTime > $mostRecentTime) {
                        $mostRecentTime = $redemptionTime;
                    }
                }
            }

            if ($mostRecentTime) {
                $timeRemaining = 86400 - (time() - $mostRecentTime);
                if ($timeRemaining > 0) {
                    $hoursRemaining = ceil($timeRemaining/3600);
                    return $hoursRemaining;
                }
            }

            return 0;
        } catch (Exception $e) {
            error_log("Error getting redemption time remaining: " . $e->getMessage());
            return 0;
        }
    }

    private function hasVeryRecentRedemption($customer_id, $reward_id, $timeWindow = 2) {
        try {
            $redemptionModel = new RewardRedemption();
            $user_id = $this->getUserIdFromCustomerId($customer_id);

            $recentRedemptions = $redemptionModel->findAll([
                'customer_id' => $user_id,
                'reward_id' => $reward_id,
                'status' => 'active'
            ]);

            $cutoffTime = date('Y-m-d H:i:s', time() - $timeWindow);

            foreach ($recentRedemptions as $redemption) {
                if ($redemption['redeemed_at'] > $cutoffTime) {
                    return true;
                }
            }

            return false;
        } catch (Exception $e) {
            error_log("Error checking very recent redemption: " . $e->getMessage());
            return false;
        }
    }

    public function redeemReward($customer_id, $reward_id) {
        $user_id = $this->getUserIdFromCustomerId($customer_id);
        $idempotency_key = 'legacy_redemption_' . $customer_id . '_' . $reward_id . '_' . date('Y-m-d-H-i-s');
        return $this->redeemRewardWithSecurity($user_id, $reward_id, $idempotency_key);
    }

    public function getLoyaltyTier($customer_id) {
        $points = $this->getCustomerPoints($customer_id);

        $tier = 'Bronze'; // default
        if ($points >= 5000)
            $tier = 'Platinum';
        else if ($points >= 2000)
            $tier = 'Gold';
        else if ($points >= 500)
            $tier = 'Silver';

        error_log("DEBUG: getLoyaltyTier - customer_id: $customer_id, points: $points, tier: $tier");

        return $tier;
    }

    private function getUserIdFromCustomerId($customer_id) {
        $customer = new Customer();
        $result = $customer->getColumn('user_id', ['customer_id' => $customer_id]);
        if ($result === false) {
            throw new Exception("Customer not found");
        }
        return (int) $result;
    }

    private function customerExists($customer_id) {
        $customer = new Customer();
        $result = $customer->getColumn('customer_id', ['customer_id' => $customer_id]);
        return $result !== false;
    }

    public function getTierInfo($customer_id) {
        $points = $this->getCustomerPoints($customer_id);
        $tier = $this->getLoyaltyTier($customer_id);

        $tierInfo = [
            'Bronze' => ['min_points' => 0, 'next_tier' => 'Silver', 'next_points' => 500, 'multiplier' => 1.0],
            'Silver' => ['min_points' => 500, 'next_tier' => 'Gold', 'next_points' => 2000, 'multiplier' => 1.2],
            'Gold' => ['min_points' => 2000, 'next_tier' => 'Platinum', 'next_points' => 5000, 'multiplier' => 1.5],
            'Platinum' => ['min_points' => 5000, 'next_tier' => null, 'next_points' => null, 'multiplier' => 2.0]
        ];

        $current = $tierInfo[$tier];
        $current['current_tier'] = $tier;
        $current['current_points'] = $points;

        if ($current['next_points']) {
            $current['points_to_next'] = $current['next_points'] - $points;
        }

        return $current;
    }

    private function isOperationProcessed($idempotency_key) {
        $cacheFile = sys_get_temp_dir() . '/loyalty_operations_' . md5($idempotency_key) . '.json';
        return file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 3600;
    }

    private function getProcessedOperation($idempotency_key) {
        $cacheFile = sys_get_temp_dir() . '/loyalty_operations_' . md5($idempotency_key) . '.json';
        if (file_exists($cacheFile)) {
            $content = file_get_contents($cacheFile);
            return json_decode($content, true);
        }
        return null;
    }

    private function storeProcessedOperation($idempotency_key, $result) {
        $cacheFile = sys_get_temp_dir() . '/loyalty_operations_' . md5($idempotency_key) . '.json';
        file_put_contents($cacheFile, json_encode($result));
    }

    public function getCustomerLoyaltySummary($customer_id) {
        if (!$this->customerExists($customer_id)) {
            throw new Exception("Customer not found");
        }

        $points = $this->getCustomerPoints($customer_id);
        $tierInfo = $this->getTierInfo($customer_id);

        $user_id = $this->getUserIdFromCustomerId($customer_id);
        $recentTransactions = LoyaltyTransaction::getCustomerTransactions($user_id, 5);
        $activeRedemptions = $this->getActiveRedemptions($customer_id);

        return [
            'customer_id' => $customer_id,
            'loyalty_points' => $points,
            'tier' => $tierInfo['current_tier'],
            'tier_info' => $tierInfo,
            'recent_transactions' => $recentTransactions,
            'active_redemptions' => $activeRedemptions,
            'stats' => $this->getCustomerStats($customer_id),
            'current_strategy' => $this->getCurrentStrategy()
        ];
    }

    public function getCustomerStats($customer_id) {
        try {
            $user_id = $this->getUserIdFromCustomerId($customer_id);

            $transactionModel = new LoyaltyTransaction();
            $allTransactions = $transactionModel->findAll(['customer_id' => $user_id]);

            $totalEarned = 0;
            $totalRedeemed = 0;

            foreach ($allTransactions as $transaction) {
                if ($transaction['points'] > 0) {
                    $totalEarned += $transaction['points'];
                } else {
                    $totalRedeemed += abs($transaction['points']);
                }
            }

            $redemptionModel = new RewardRedemption();
            $redemptions = $redemptionModel->findAll(['customer_id' => $user_id]);
            $redemptionCount = count($redemptions);

            return [
                'total_earned' => (int) $totalEarned,
                'total_redeemed' => (int) $totalRedeemed,
                'redemption_count' => (int) $redemptionCount,
                'net_points' => (int) ($totalEarned - $totalRedeemed)
            ];
        } catch (Exception $e) {
            error_log("Error getting customer stats: " . $e->getMessage());
            return [
                'total_earned' => 0,
                'total_redeemed' => 0,
                'redemption_count' => 0,
                'net_points' => 0
            ];
        }
    }

    private function getActiveRedemptions($customer_id) {
        $redemptionModel = new RewardRedemption();
        $user_id = $this->getUserIdFromCustomerId($customer_id);
        return $redemptionModel->findAll([
                    'customer_id' => $user_id,
                    'status' => 'active'
                        ], 'created_at DESC');
    }

    public function getAvailableRewards($customer_id) {
        $customerPoints = $this->getCustomerPoints($customer_id);
        $allRewards = Reward::getActive();

        foreach ($allRewards as &$reward) {
            $reward['affordable'] = $customerPoints >= $reward['points_required'];
            $reward['points_short'] = max(0, $reward['points_required'] - $customerPoints);
        }

        usort($allRewards, function ($a, $b) {
            if ($a['affordable'] !== $b['affordable']) {
                return $b['affordable'] <=> $a['affordable'];
            }
            return $a['points_required'] <=> $b['points_required'];
        });

        return $allRewards;
    }

    public function validateRedemptionCode($redemption_code) {
        try {
            $redemptionModel = new RewardRedemption();
            $rewardModel = new Reward();

            $redemptions = $redemptionModel->findAll([
                'redemption_code' => $redemption_code,
                'status' => 'active'
            ]);

            if (empty($redemptions)) {
                return false;
            }

            $redemption = $redemptions[0];

            if ($redemption['expires_at'] && $redemption['expires_at'] <= date('Y-m-d H:i:s')) {
                return false;
            }

            $reward = $rewardModel->find($redemption['reward_id']);
            if ($reward) {
                $redemption['reward_name'] = $reward->name;
                $redemption['reward_description'] = $reward->description;
            }

            return $redemption;
        } catch (Exception $e) {
            error_log("Error validating redemption code: " . $e->getMessage());
            return false;
        }
    }

    public function useRedemptionCode($redemption_code) {
        try {
            $redemption = $this->validateRedemptionCode($redemption_code);
            if (!$redemption) {
                throw new Exception("Invalid or expired redemption code");
            }

            $rewardRedemption = new RewardRedemption();
            $result = $rewardRedemption->updateById($redemption['redemption_id'], [
                'status' => 'used',
                'used_at' => date('Y-m-d H:i:s')
            ]);

            if (!$result) {
                throw new Exception("Failed to update redemption status");
            }

            return [
                'success' => true,
                'redemption' => $redemption,
                'message' => 'Redemption code used successfully'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    public function getTierProgress($customer_id) {
        $tierInfo = $this->getTierInfo($customer_id);

        $progress = [
            'current_tier' => $tierInfo['current_tier'],
            'current_points' => $tierInfo['current_points'],
            'progress_percentage' => 0
        ];

        if ($tierInfo['next_points']) {
            $currentTierMin = $tierInfo['min_points'];
            $nextTierPoints = $tierInfo['next_points'];
            $pointsInCurrentTier = $tierInfo['current_points'] - $currentTierMin;
            $pointsNeededForTier = $nextTierPoints - $currentTierMin;

            $progress['progress_percentage'] = min(100, ($pointsInCurrentTier / $pointsNeededForTier) * 100);
            $progress['next_tier'] = $tierInfo['next_tier'];
            $progress['points_to_next'] = $tierInfo['points_to_next'];
        } else {
            $progress['progress_percentage'] = 100;
            $progress['next_tier'] = null;
            $progress['points_to_next'] = 0;
        }

        return $progress;
    }

    public function bulkUpdatePoints($operations) {
        $results = [];
        $customer = new Customer();

        try {
            $customer->db->beginTransaction();

            foreach ($operations as $operation) {
                $customer_id = $operation['customer_id'];
                $points = $operation['points'];
                $description = $operation['description'] ?? 'Bulk update';

                try {
                    if ($points > 0) {
                        $result = $this->addPoints($customer_id, $points, $description);
                    } else {
                        $result = $this->deductPoints($customer_id, abs($points), $description);
                    }

                    $results[] = [
                        'customer_id' => $customer_id,
                        'success' => $result['success'],
                        'points' => $points,
                        'new_balance' => $result['new_balance'] ?? null
                    ];
                } catch (Exception $e) {
                    $results[] = [
                        'customer_id' => $customer_id,
                        'success' => false,
                        'error' => $e->getMessage(),
                        'points' => $points
                    ];
                }
            }

            $customer->db->commit();
            return $results;
        } catch (Exception $e) {
            $customer->db->rollback();
            throw $e;
        }
    }

    public function getAvailableStrategies() {
        return [
            'bronze' => [
                'name' => 'Bronze Points',
                'class' => 'BronzePointStrategy',
                'description' => 'Bronze tier: 1 point per RM spent',
                'suitable_for' => ['Bronze customers', 'New members']
            ],
            'silver' => [
                'name' => 'Silver Points',
                'class' => 'SilverPointStrategy',
                'description' => 'Silver tier: 1.5x points + coffee bonuses',
                'suitable_for' => ['Silver customers', 'Regular members']
            ],
            'gold' => [
                'name' => 'Gold Points',
                'class' => 'GoldPointStrategy',
                'description' => 'Gold tier: 1.8x points + coffee bonuses',
                'suitable_for' => ['Gold customers', 'Frequent members']
            ],
            'platinum' => [
                'name' => 'Platinum Points',
                'class' => 'PlatinumPointStrategy',
                'description' => 'Platinum tier: 2x points + enhanced coffee bonuses',
                'suitable_for' => ['Platinum customers', 'VIP members']
            ],
            'promotion' => [
                'name' => 'Special Promotion',
                'class' => 'PromotionPointStrategy',
                'description' => 'Special promotional multipliers',
                'suitable_for' => ['Special events', 'Tuesday promotions', 'Marketing campaigns']
            ]
        ];
    }

    public function createStrategy($strategyName, $options = []) {
        switch (strtolower($strategyName)) {
            case 'bronze':
                return new BronzePointStrategy();

            case 'silver':
                return new SilverPointStrategy();

            case 'gold':
                return new GoldPointStrategy();

            case 'platinum':
                return new PlatinumPointStrategy();

            case 'promotion':
                $multiplier = $options['multiplier'] ?? 2.5;
                $promotionName = $options['promotion_name'] ?? 'Special Promotion';
                return new PromotionPointStrategy($multiplier, $promotionName);

            // Keep legacy strategies for backward compatibility
            case 'basic':
                $pointsPerRinggit = $options['points_per_ringgit'] ?? 1;
                return new BasicPointStrategy($pointsPerRinggit);

            case 'bonus':
                $multiplier = $options['multiplier'] ?? 2.0;
                $baseStrategy = $options['base_strategy'] ?? new BasicPointStrategy();
                return new BonusPointStrategy($multiplier, $baseStrategy);

            case 'vip':
                $multiplier = $options['multiplier'] ?? 1.5;
                return new VIPPointStrategy($multiplier);

            default:
                throw new Exception("Unknown strategy: {$strategyName}");
        }
    }

    public function setStrategyByName($strategyName, $options = []) {
        $strategy = $this->createStrategy($strategyName, $options);
        $this->setPointStrategy($strategy);
    }

    public function testAllStrategies($orderAmount, $customerId = null, $orderItems = null) {
        $results = [];
        $originalStrategy = $this->pointStrategy;

        try {
            $this->setPointStrategy(new BronzePointStrategy());
            $results['bronze'] = [
                'strategy' => $this->getCurrentStrategy(),
                'points' => $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems)
            ];

            $this->setPointStrategy(new SilverPointStrategy());
            $results['silver'] = [
                'strategy' => $this->getCurrentStrategy(),
                'points' => $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems)
            ];

            $this->setPointStrategy(new GoldPointStrategy());
            $results['gold'] = [
                'strategy' => $this->getCurrentStrategy(),
                'points' => $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems)
            ];

            $this->setPointStrategy(new PlatinumPointStrategy());
            $results['platinum'] = [
                'strategy' => $this->getCurrentStrategy(),
                'points' => $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems)
            ];

            $this->setPointStrategy(new PromotionPointStrategy(2.5, "Test Promotion"));
            $results['promotion'] = [
                'strategy' => $this->getCurrentStrategy(),
                'points' => $this->pointStrategy->calculatePoints($orderAmount, $customerId, $orderItems)
            ];
        } finally {
            $this->setPointStrategy($originalStrategy);
        }

        return $results;
    }
}

?>