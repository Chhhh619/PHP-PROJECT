<?php
/**
 * Output Security for Encoding User Data
 * @module Security Functions
 * @version 2.0
 */

class OutputSecurity {
    
    /**
     * HTML encode for general HTML output
     */
    public static function html($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    /**
     * HTML encode for HTML attributes
     */
    public static function attr($string) {
        return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    
    /**
     * Encode for JavaScript context
     */
    public static function js($data) {
        return json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    }
    
    /**
     * Encode URL parameters
     */
    public static function url($string) {
        return urlencode($string ?? '');
    }
    
    /**
     * Sanitize integer
     */
    public static function int($value) {
        return (int) ($value ?? 0);
    }
    
    /**
     * Sanitize float
     */
    public static function float($value) {
        return (float) ($value ?? 0);
    }
}
?>