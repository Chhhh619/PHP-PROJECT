<?php


require_once 'BaseModel.php';

class OrderManagementModel extends BaseModel {
    
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    protected $fillable = [
        'customer_id', 'total_amount', 'subtotal', 'tax_amount',
        'delivery_address', 'phone', 'notes', 'payment_method',
        'order_type', 'payment_details', 'order_status'
    ];

    
    private static $flexibleStatusWorkflows = [
        'pickup' => [
            'pending' => ['preparing', 'canceled', 'ready to pickup'],
            'preparing' => ['ready to pickup', 'canceled'],
            'canceled' => [],
            'ready to pickup' => [],
            '' => ['preparing', 'canceled', 'ready to pickup']
        ],
        'delivery' => [
            'pending' => ['preparing', 'canceled', 'out for delivery'],
            'preparing' => ['out for delivery', 'canceled', 'delivered'],
            'out for delivery' => ['delivered', 'canceled'],
            'canceled' => [],
            'delivered' => [],
            '' => ['preparing', 'canceled', 'out for delivery']
        ]
    ];

    private static $strictStatusWorkflows = [
        'pickup' => [
            'pending' => ['preparing', 'canceled'],
            'preparing' => ['ready to pickup', 'canceled'],
            'canceled' => [],
            'ready to pickup' => [],
            '' => ['preparing', 'canceled']
        ],
        'delivery' => [
            'pending' => ['preparing', 'canceled'],
            'preparing' => ['out for delivery', 'canceled'],
            'out for delivery' => ['delivered', 'canceled'],
            'canceled' => [],
            'delivered' => [],
            '' => ['preparing', 'canceled']
        ]
    ];

    private static $openStatusWorkflows = [
        'pickup' => [
            'pending' => ['preparing', 'canceled', 'ready to pickup'],
            'preparing' => ['pending', 'canceled', 'ready to pickup'],
            'canceled' => ['pending', 'preparing', 'ready to pickup'],
            'ready to pickup' => ['pending', 'preparing', 'canceled'],
            '' => ['preparing', 'canceled', 'ready to pickup']
        ],
        'delivery' => [
            'pending' => ['preparing', 'canceled', 'out for delivery', 'delivered'],
            'preparing' => ['pending', 'canceled', 'out for delivery', 'delivered'],
            'out for delivery' => ['pending', 'preparing', 'canceled', 'delivered'],
            'canceled' => ['pending', 'preparing', 'out for delivery', 'delivered'],
            'delivered' => ['pending', 'preparing', 'canceled', 'out for delivery'],
            '' => ['preparing', 'canceled', 'out for delivery', 'delivered']
        ]
    ];

    private static $activeWorkflow = 'flexible';
    private static $adminManageableStatuses = [
        'pending', 'preparing', 'canceled', 'out for delivery', 'ready to pickup', 'delivered', ''
    ];

 
    private static function getActiveWorkflow() {
        switch (self::$activeWorkflow) {
            case 'strict': return self::$strictStatusWorkflows;
            case 'flexible': return self::$flexibleStatusWorkflows;
            case 'open': return self::$openStatusWorkflows;
            default: return self::$flexibleStatusWorkflows;
        }
    }

    public static function setWorkflowMode($mode) {
        if (in_array($mode, ['strict', 'flexible', 'open'])) {
            self::$activeWorkflow = $mode;
            error_log("Order workflow mode changed to: {$mode}");
        }
    }

    public static function getWorkflowMode() {
        return self::$activeWorkflow;
    }

    public function getAllForAdmin($filters = [], $page = 1, $limit = 20) {
        try {
            error_log("getAllForAdmin called with filters: " . json_encode($filters));
            
            $limit = max(1, min(100, intval($limit)));
            $page = max(1, intval($page));
            $offset = ($page - 1) * $limit;
            
            
            $query = $this->select('o.*, c.first_name, c.last_name, c.phone as customer_phone, u.email as customer_email')
                         ->from('orders o')
                         ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                         ->leftJoin('users u', 'o.customer_id', '=', 'u.user_id');
            
            
            if (!empty($filters['status']) && $filters['status'] !== 'all') {
                $query->where('o.order_status', $filters['status']);
            }
            
            if (!empty($filters['search'])) {
                $searchTerm = '%' . $filters['search'] . '%';
                
                $tempModel = new self();
                $searchResults = $tempModel->select('o.order_id')
                                          ->from('orders o')
                                          ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                                          ->leftJoin('users u', 'o.customer_id', '=', 'u.user_id')
                                          ->where('o.order_id', 'LIKE', $searchTerm)
                                          ->get();
                
                $customerSearchResults = $tempModel->select('o.order_id')
                                                  ->from('orders o')
                                                  ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                                                  ->where('c.first_name', 'LIKE', $searchTerm)
                                                  ->get();
                
                $lastNameSearchResults = $tempModel->select('o.order_id')
                                                   ->from('orders o')
                                                   ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                                                   ->where('c.last_name', 'LIKE', $searchTerm)
                                                   ->get();
                
                $emailSearchResults = $tempModel->select('o.order_id')
                                                ->from('orders o')
                                                ->leftJoin('users u', 'o.customer_id', '=', 'u.user_id')
                                                ->where('u.email', 'LIKE', $searchTerm)
                                                ->get();
                

                $allSearchIds = [];
                foreach (array_merge($searchResults, $customerSearchResults, $lastNameSearchResults, $emailSearchResults) as $result) {
                    $allSearchIds[] = $result['order_id'];
                }
                
                if (!empty($allSearchIds)) {
                    $query->whereIn('o.order_id', array_unique($allSearchIds));
                } else {

                    return [
                        'orders' => [],
                        'total_count' => 0,
                        'total_pages' => 0,
                        'current_page' => $page,
                        'per_page' => $limit
                    ];
                }
            }
            

            $countQuery = clone $query;
            $countQuery->select('COUNT(DISTINCT o.order_id) as total');
            $countResult = $countQuery->first();
            $totalCount = $countResult ? $countResult['total'] : 0;
            

            $orders = $query->orderBy('o.created_at', 'DESC')
                           ->limit($limit, $offset)
                           ->get();
            

            $orderObjects = [];
            foreach ($orders as $orderData) {
                $order = new self();
                $order->attributes = $orderData;
                
                $firstName = $orderData['first_name'] ?? '';
                $lastName = $orderData['last_name'] ?? '';
                $order->customer_name = trim($firstName . ' ' . $lastName);
                if (empty($order->customer_name)) {
                    $order->customer_name = 'Unknown Customer';
                }
                
                $order->customer_email = $orderData['customer_email'] ?? 'unknown@email.com';
                $order->customer_phone = $orderData['customer_phone'] ?? '';
                
 
                $order->item_count = $this->getOrderItemCount($orderData['order_id']);
                
                $orderObjects[] = $order;
            }
            
            return [
                'orders' => $orderObjects,
                'total_count' => $totalCount,
                'total_pages' => ceil($totalCount / $limit),
                'current_page' => $page,
                'per_page' => $limit
            ];
            
        } catch (Exception $e) {
            error_log("getAllForAdmin error: " . $e->getMessage());
            throw new Exception("Unable to load orders: " . $e->getMessage());
        }
    }

    private function getOrderItemCount($orderId) {
        try {
            return $this->from('order_items')
                       ->where('order_id', $orderId)
                       ->count();
        } catch (Exception $e) {
            error_log("getOrderItemCount error: " . $e->getMessage());
            return 0;
        }
    }
    
 
    public function getOrderDetails() {
        if (!$this->order_id) {
            throw new Exception("Order ID is required to get details");
        }
        
        try {

            $orderData = $this->select('o.*, c.first_name, c.last_name, c.phone as customer_phone, u.email as customer_email')
                             ->from('orders o')
                             ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                             ->leftJoin('users u', 'o.customer_id', '=', 'u.user_id')
                             ->where('o.order_id', $this->order_id)
                             ->first();
            
            if (!$orderData) {
                return null;
            }
            
            $firstName = $orderData['first_name'] ?? '';
            $lastName = $orderData['last_name'] ?? '';
            $customerName = trim($firstName . ' ' . $lastName);
            if (empty($customerName)) {
                $customerName = 'Unknown Customer';
            }
            

            $items = $this->getOrderItems($this->order_id);
            
            return [
                'order_id' => $this->order_id,
                'customer_name' => $customerName,
                'customer_email' => $orderData['customer_email'] ?? 'unknown@email.com',
                'customer_phone' => $orderData['customer_phone'] ?? '',
                'total_amount' => $this->total_amount,
                'subtotal' => $this->subtotal,
                'tax_amount' => $this->tax_amount,
                'delivery_address' => $this->delivery_address,
                'phone' => $this->phone,
                'notes' => $this->notes,
                'payment_method' => $this->payment_method,
                'order_type' => $this->order_type ?? 'delivery',
                'order_status' => $this->order_status ?? 'pending',
                'created_at' => $this->created_at,
                'formatted_date' => $this->getFormattedDate(),
                'status_formatted' => $this->getStatusFormatted(),
                'status_class' => $this->getStatusClass(),
                'order_type_formatted' => $this->getOrderTypeFormatted(),
                'valid_next_statuses' => $this->getValidNextStatuses(),
                'workflow_mode' => self::getWorkflowMode(),
                'items' => $items
            ];
            
        } catch (Exception $e) {
            error_log("getOrderDetails error: " . $e->getMessage());
            throw new Exception("Unable to load order details: " . $e->getMessage());
        }
    }


    private function getOrderItems($orderId) {
        try {
            $items = $this->select('oi.*, COALESCE(mi.name, oi.item_name) as menu_item_name, (oi.item_price * oi.quantity) as subtotal')
                         ->from('order_items oi')
                         ->leftJoin('menu_items mi', 'oi.item_id', '=', 'mi.item_id')
                         ->where('oi.order_id', $orderId)
                         ->get();
            
            return $items;
        } catch (Exception $e) {
            error_log("getOrderItems error: " . $e->getMessage());
            return [];
        }
    }


    public function updateStatus($newStatus, $adminId) {
        if (!$this->canAdminManageOrder()) {
            throw new Exception("This order cannot be managed (current status: {$this->getStatusFormatted()})");
        }
        
        if (!$this->isValidStatusTransition($newStatus)) {
            $validStatuses = implode(', ', $this->getValidNextStatuses());
            $orderType = $this->getOrderTypeFormatted();
            $currentStatus = $this->getStatusFormatted();
            throw new Exception("Cannot change {$orderType} order from '{$currentStatus}' to '{$newStatus}'. Valid options: {$validStatuses}");
        }
        
        try {
            $result = $this->update([
                'order_status' => $newStatus,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            
            if ($result) {
                $this->order_status = $newStatus;
                error_log("Order #{$this->order_id} ({$this->order_type}) status updated to '{$newStatus}' by admin {$adminId} [Mode: " . self::getWorkflowMode() . "]");
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("updateStatus error: " . $e->getMessage());
            throw new Exception("Failed to update order status: " . $e->getMessage());
        }
    }
    

    public static function bulkUpdateStatus($orderIds, $newStatus, $adminId) {
        if (empty($orderIds) || !is_array($orderIds)) {
            throw new Exception("Invalid order IDs provided for bulk update");
        }
        
        try {
            $model = new self();
            

            $orders = $model->select('order_id, order_status, order_type')
                           ->whereIn('order_id', $orderIds)
                           ->get();
            
            $validOrders = [];
            $invalidCount = 0;
            $invalidReasons = [];
            

            foreach ($orders as $orderData) {
                $tempOrder = new self();
                $tempOrder->attributes = $orderData;
                
                if ($tempOrder->isValidStatusTransition($newStatus)) {
                    $validOrders[] = $orderData['order_id'];
                } else {
                    $invalidCount++;
                    $orderType = $tempOrder->getOrderTypeFormatted();
                    $currentStatus = $tempOrder->getStatusFormatted();
                    $invalidReasons[] = "Order #{$orderData['order_id']} ({$orderType}): Cannot change from '{$currentStatus}' to '{$newStatus}'";
                }
            }
            
            if (empty($validOrders)) {
                $reasonsText = implode('; ', array_slice($invalidReasons, 0, 3));
                throw new Exception("None of the selected orders can be updated to '{$newStatus}'. Reasons: {$reasonsText}");
            }
            

            $updateResult = $model->whereIn('order_id', $validOrders)
                                 ->updateWhere([
                                     'order_status' => $newStatus,
                                     'updated_at' => date('Y-m-d H:i:s')
                                 ]);
            
            if (!$updateResult) {
                throw new Exception("Bulk update operation failed");
            }
            
            error_log("Bulk update: " . count($validOrders) . " orders updated to {$newStatus} by admin {$adminId} [Mode: " . self::getWorkflowMode() . "]");
            
            return [
                'updated_count' => count($validOrders),
                'invalid_count' => $invalidCount,
                'total_requested' => count($orderIds),
                'invalid_reasons' => $invalidReasons
            ];
            
        } catch (Exception $e) {
            error_log("bulkUpdateStatus error: " . $e->getMessage());
            throw new Exception("Bulk update failed: " . $e->getMessage());
        }
    }

 
    public function getOrdersByStatus($status, $limit = 50) {
        return $this->where('order_status', $status)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }

  
    public function getRecentOrders($limit = 20) {
        return $this->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }

    public function getOrdersByCustomer($customerId, $limit = 20) {
        return $this->where('customer_id', $customerId)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getOrdersByType($orderType, $limit = 50) {
        return $this->where('order_type', $orderType)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function countOrdersByStatus($status) {
        return $this->where('order_status', $status)->count();
    }


    public function getPendingOrders() {
        return $this->where('order_status', 'pending')
                   ->orderBy('created_at', 'ASC')
                   ->get();
    }


    public function getTotalRevenue($startDate = null, $endDate = null) {
        $query = $this->whereIn('order_status', ['delivered', 'preparing', 'ready to pickup']);
        
        if ($startDate) {
            $query->where('created_at', '>=', $startDate);
        }
        
        if ($endDate) {
            $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }
        
        return $query->sum('total_amount') ?: 0;
    }


    public function getOrdersWithCustomers($limit = 50) {
        return $this->select('o.*, c.first_name, c.last_name, c.phone, u.email')
                   ->from('orders o')
                   ->leftJoin('customers c', 'o.customer_id', '=', 'c.user_id')
                   ->leftJoin('users u', 'o.customer_id', '=', 'u.user_id')
                   ->orderBy('o.created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getOrdersByDateRange($startDate, $endDate) {
        return $this->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                   ->orderBy('created_at', 'DESC')
                   ->get();
    }


    public function getHighValueOrders($minAmount = 100, $limit = 50) {
        return $this->where('total_amount', '>=', $minAmount)
                   ->orderBy('total_amount', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getAverageOrderValue($startDate = null, $endDate = null) {
        $query = $this->whereIn('order_status', ['delivered', 'preparing', 'ready to pickup']);
        
        if ($startDate) {
            $query->where('created_at', '>=', $startDate);
        }
        
        if ($endDate) {
            $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }
        
        return $query->avg('total_amount') ?: 0;
    }


    public function countOrdersByType($orderType) {
        return $this->where('order_type', $orderType)->count();
    }


    public function getOrdersByPaymentMethod($paymentMethod, $limit = 50) {
        return $this->where('payment_method', $paymentMethod)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    
    public function canAdminManageOrder() {
        $currentStatus = $this->order_status ?? '';
        return in_array($currentStatus, self::$adminManageableStatuses);
    }
    
    public function isValidStatusTransition($newStatus) {
        $currentStatus = $this->order_status ?? '';
        $orderType = $this->order_type ?? 'delivery';
        $workflows = self::getActiveWorkflow();
        
        if (!isset($workflows[$orderType])) {
            error_log("Invalid order type: {$orderType}");
            return false;
        }
        
        $allowedTransitions = $workflows[$orderType][$currentStatus] ?? [];
        $isValid = in_array($newStatus, $allowedTransitions);
        
        error_log("Status transition check [{$orderType}]: '{$currentStatus}' → '{$newStatus}' = " . ($isValid ? 'VALID' : 'INVALID') . " [Mode: " . self::getWorkflowMode() . "]");
        error_log("Allowed transitions: " . implode(', ', $allowedTransitions));
        
        return $isValid;
    }
    
    public function getValidNextStatuses() {
        $currentStatus = $this->order_status ?? '';
        $orderType = $this->order_type ?? 'delivery';
        $workflows = self::getActiveWorkflow();
        
        if (!isset($workflows[$orderType])) {
            return [];
        }
        
        return $workflows[$orderType][$currentStatus] ?? [];
    }
    
    public function getAdminStatusesForOrderType($orderType = null) {
        $orderType = $orderType ?? $this->order_type ?? 'delivery';
        
        if ($orderType === 'pickup') {
            return ['pending', 'preparing', 'canceled', 'ready to pickup'];
        } else {
            return ['pending', 'preparing', 'canceled', 'out for delivery', 'delivered'];
        }
    }
    

    
    public function getStatusFormatted() {
        $statusLabels = [
            'pending' => 'Pending',
            'preparing' => 'Preparing',
            'canceled' => 'Canceled',
            'out for delivery' => 'Out for Delivery',
            'ready to pickup' => 'Ready to Pickup',
            'delivered' => 'Delivered',
            '' => 'Pending'
        ];
        
        $status = $this->order_status ?? '';
        return $statusLabels[$status] ?? 'Unknown Status';
    }
    
    public function getStatusClass() {
        $statusClasses = [
            'pending' => 'status-pending',
            'preparing' => 'status-preparing',
            'canceled' => 'status-canceled',
            'out for delivery' => 'status-out-of-delivery',
            'ready to pickup' => 'status-ready-to-pickup',
            'delivered' => 'status-delivered',
            '' => 'status-pending'
        ];
        
        $status = $this->order_status ?? '';
        return $statusClasses[$status] ?? 'status-unknown';
    }
    
    public function getFormattedDate() {
        $date = $this->created_at ?? date('Y-m-d H:i:s');
        return date('M d, Y H:i', strtotime($date));
    }
    
    public function getOrderTypeFormatted() {
        $orderType = $this->order_type ?? 'delivery';
        return $orderType === 'pickup' ? 'Pickup' : 'Delivery';
    }
    
    public function toArray() {
        $baseArray = parent::toArray();
        
        return array_merge($baseArray, [
            'formatted_date' => $this->getFormattedDate(),
            'status_formatted' => $this->getStatusFormatted(),
            'status_class' => $this->getStatusClass(),
            'order_type_formatted' => $this->getOrderTypeFormatted(),
            'valid_next_statuses' => $this->getValidNextStatuses(),
            'can_admin_manage' => $this->canAdminManageOrder(),
            'customer_name' => $this->customer_name ?? 'Unknown Customer',
            'customer_email' => $this->customer_email ?? 'unknown@email.com',
            'item_count' => $this->item_count ?? 0,
            'workflow_mode' => self::getWorkflowMode()
        ]);
    }
    
    public function create($data) {

        if (empty($data['customer_id']) || $data['customer_id'] <= 0) {
            throw new Exception("Valid customer ID is required");
        }
        
        if (empty($data['total_amount']) || $data['total_amount'] <= 0) {
            throw new Exception("Valid total amount is required");
        }
        

        $data['order_type'] = in_array($data['order_type'] ?? '', ['pickup', 'delivery']) 
            ? $data['order_type'] : 'delivery';
        $data['order_status'] = $data['order_status'] ?? 'pending';
        $data['created_at'] = date('Y-m-d H:i:s');
        
        return parent::create($data);
    }
}
?>