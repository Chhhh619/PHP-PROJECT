<?php
/**
author : Cheng Jun Yang
 */

require_once 'BaseModel.php';

abstract class User extends BaseModel {
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['email', 'password_hash', 'role', 'is_active'];
    
   
    protected $user_id;
    protected $email;
    protected $password_hash;
    protected $role;
    protected $created_at;
    protected $updated_at;
    protected $is_active;
    
    public function __construct($database_connection = null) {
    
        if ($database_connection) {
            $this->db = $database_connection;
        } else {
            parent::__construct();
        }
    }
    
   
    public function setUserData($data) {
        $this->setUserProperties($data);
    }
    
  
    public function loadUser($user_id) {
        try {
            if (!is_numeric($user_id) || $user_id <= 0) {
                return false;
            }
            
        
            $user = $this->find($user_id);
            if ($user) {
                $this->setUserProperties($user->toArray());
                $this->loadSpecificData();
                return true;
            }
            return false;
        } catch (Exception $e) {
            error_log("User load failed: " . $e->getMessage());
            return false;
        }
    }
    
 
    protected function setUserProperties($data) {
        $this->user_id = $data['user_id'] ?? null;
        $this->email = $data['email'] ?? null;
        $this->password_hash = $data['password_hash'] ?? null;
        $this->role = $data['role'] ?? null;
        $this->created_at = $data['created_at'] ?? null;
        $this->updated_at = $data['updated_at'] ?? null;
        $this->is_active = $data['is_active'] ?? true;
        
        
        $this->attributes = $data;
    }
    
   
    public function toArray() {
        return [
            'user_id' => $this->user_id,
            'email' => $this->email,
            'password_hash' => $this->password_hash,
            'role' => $this->role,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
            'is_active' => $this->is_active
        ];
    }
    
  
    abstract public function loadSpecificData();
    abstract public function getDisplayName();
    abstract public function getPermissions();
    abstract public function getDashboardUrl();
    
    
    public function getUserId() { return $this->user_id; }
    public function getEmail() { return $this->email; }
    public function getRole() { return $this->role; }
    public function isActive() { return $this->is_active; }
    public function getCreatedAt() { return $this->created_at; }
    public function getPasswordHash() { return $this->password_hash; }
    
  
    public function verifyPassword($password) {
        if (empty($password) || empty($this->password_hash)) {
            return false;
        }
        return password_verify($password, $this->password_hash);
    }
    
  
    public function updatePassword($new_password) {
        if (!$this->isPasswordSecure($new_password)) {
            throw new InvalidArgumentException("Password does not meet security requirements");
        }
        
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $result = $this->update(['password_hash' => $hashed]);
        
        if ($result) {
            $this->password_hash = $hashed;
        }
        
        return $result;
    }
    
   
    public function updateEmail($new_email) {
        if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidArgumentException("Invalid email format");
        }
        
        $result = $this->update(['email' => $new_email]);
        
        if ($result) {
            $this->email = $new_email;
        }
        
        return $result;
    }
    
    
    public function updateStatus($is_active) {
        $result = $this->update(['is_active' => $is_active ? 1 : 0]);
        
        if ($result) {
            $this->is_active = $is_active;
        }
        
        return $result;
    }
    
   
    public static function findByEmail($email, $db_connection = null) {
        try {
            $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return null;
            }
            
           
            $userModel = new class($db_connection) extends BaseModel {
                protected $table = 'users';
                protected $primaryKey = 'user_id';
                
                public function __construct($db_connection = null) {
                    if ($db_connection) {
                        $this->db = $db_connection;
                    } else {
                        parent::__construct();
                    }
                }
            };
            
            return $userModel->where('email', '=', $email)
                           ->where('is_active', '=', 1)
                           ->first();
            
        } catch (Exception $e) {
            error_log("User findByEmail error: " . $e->getMessage());
            return null;
        }
    }
    
    
    public static function getAllUsers($conditions = [], $orderBy = null, $limit = null) {
        try {
           
            $userModel = new class extends BaseModel {
                protected $table = 'users';
                protected $primaryKey = 'user_id';
            };
            
            $query = $userModel->select(['*']);
            
        
            foreach ($conditions as $column => $value) {
                $query->where($column, '=', $value);
            }
            
        
            if ($orderBy) {
                if (strpos($orderBy, ' ') !== false) {
                    $parts = explode(' ', $orderBy, 2);
                    $query->orderBy($parts[0], $parts[1]);
                } else {
                    $query->orderBy($orderBy);
                }
            }
            
         
            if ($limit) {
                $query->limit($limit);
            }
            
            return $query->get();
            
        } catch (Exception $e) {
            error_log("Get all users error: " . $e->getMessage());
            return [];
        }
    }
    
    
    public function getColumnValue($column, $conditions = []) {
        try {
            $query = $this->select([$column]);
            
            foreach ($conditions as $key => $value) {
                $query->where($key, '=', $value);
            }
            
            $result = $query->first();
            return $result ? $result[$column] : null;
            
        } catch (Exception $e) {
            error_log("Get column value error: " . $e->getMessage());
            return null;
        }
    }
   
    public static function emailExists($email, $exclude_user_id = null) {
        try {
         
            $userModel = new class extends BaseModel {
                protected $table = 'users';
                protected $primaryKey = 'user_id';
            };
            
            $query = $userModel->where('email', '=', $email);
            
            if ($exclude_user_id) {
                $query->where('user_id', '!=', $exclude_user_id);
            }
            
            return $query->count() > 0;
            
        } catch (Exception $e) {
            error_log("Email exists check error: " . $e->getMessage());
            return true; 
        }
    }
    
  
    public static function getUserCount($conditions = []) {
        try {
        
            $userModel = new class extends BaseModel {
                protected $table = 'users';
                protected $primaryKey = 'user_id';
            };
            
            $query = $userModel->select(['*']);
            
            foreach ($conditions as $column => $value) {
                $query->where($column, '=', $value);
            }
            
            return $query->count();
            
        } catch (Exception $e) {
            error_log("Get user count error: " . $e->getMessage());
            return 0;
        }
    }
    
  
    protected function isPasswordSecure($password) {
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
    }
    
    protected function sanitizeString($input) {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }
    
    protected function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    protected function isValidName($name) {
        return preg_match('/^[a-zA-Z\s\'-]{2,50}$/', $name);
    }
}