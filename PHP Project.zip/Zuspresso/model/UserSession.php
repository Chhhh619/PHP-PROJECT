<?php

/**
author : Cheng Jun Yang
 */

class UserSession extends BaseModel {
    protected $table = 'user_sessions';
    protected $primaryKey = 'session_id';
    protected $fillable = ['session_id', 'user_id', 'ip_address', 'user_agent', 'expires_at'];
    
    public function setAttributes($attributes) {
        $this->attributes = $attributes;
        return $this;
    }
}
?>