<?php

class JWTHelper {
    
    private static $secret = 'zuspresso_loyalty_secret_key_2024'; // In production, use environment variable
    private static $algorithm = 'HS256';
    
    public static function generateToken($payload, $expiry = 3600) {
        $header = [
            'typ' => 'JWT',
            'alg' => self::$algorithm
        ];
        
        $payload['iat'] = time(); // Issued at
        $payload['exp'] = time() + $expiry; // Expiry
        $payload['iss'] = 'zuspresso-loyalty'; // Issuer
        
        $headerEncoded = self::base64UrlEncode(json_encode($header));
        $payloadEncoded = self::base64UrlEncode(json_encode($payload));
        
        $signature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, self::$secret, true);
        $signatureEncoded = self::base64UrlEncode($signature);
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signatureEncoded;
    }
    
    /**
     * Validate and decode JWT token
     * 
     * @param string $token JWT token
     * @return array|false Decoded payload or false if invalid
     */
    public static function validateToken($token) {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }
            
            list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
            
            // Verify signature
            $expectedSignature = hash_hmac('sha256', $headerEncoded . '.' . $payloadEncoded, self::$secret, true);
            $providedSignature = self::base64UrlDecode($signatureEncoded);
            
            if (!hash_equals($expectedSignature, $providedSignature)) {
                return false;
            }
            
            // Decode payload
            $payload = json_decode(self::base64UrlDecode($payloadEncoded), true);
            if (!$payload) {
                return false;
            }
            
            // Check expiry
            if (isset($payload['exp']) && time() > $payload['exp']) {
                return false;
            }
            
            // Check issued at time (not too far in the future)
            if (isset($payload['iat']) && $payload['iat'] > (time() + 300)) {
                return false;
            }
            
            return $payload;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Generate token for loyalty API access
     * 
     * @param int $userId User ID
     * @param string $userRole User role
     * @return string JWT token
     */
    public static function generateLoyaltyToken($userId, $userRole = 'customer') {
        $payload = [
            'user_id' => $userId,
            'role' => $userRole,
            'scope' => 'loyalty_api'
        ];
        
        return self::generateToken($payload, 3600); // 1 hour expiry
    }
    
    /**
     * Base64 URL encode
     * 
     * @param string $data Data to encode
     * @return string Encoded data
     */
    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Base64 URL decode
     * 
     * @param string $data Data to decode
     * @return string Decoded data
     */
    private static function base64UrlDecode($data) {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
    
    /**
     * Extract user ID from token
     * 
     * @param string $token JWT token
     * @return int|false User ID or false if invalid
     */
    public static function getUserIdFromToken($token) {
        $payload = self::validateToken($token);
        return $payload ? ($payload['user_id'] ?? false) : false;
    }
    
    /**
     * Check if token has specific scope
     * 
     * @param string $token JWT token
     * @param string $requiredScope Required scope
     * @return bool True if token has scope
     */
    public static function hasScope($token, $requiredScope) {
        $payload = self::validateToken($token);
        if (!$payload) {
            return false;
        }
        
        $tokenScope = $payload['scope'] ?? '';
        return $tokenScope === $requiredScope;
    }
}