<?php

/**
author : Cheng Jun Yang
 */

require_once 'User.php';
require_once 'Customer.php';
require_once 'Admin.php';

class UserFactory {

    private $db;

    public function __construct($database_connection) {
        $this->db = $database_connection;
    }

   
    public function createUser($role) {
        switch (strtolower($role)) {
            case 'customer':
                return new Customer($this->db);

            case 'admin':
                return new Admin($this->db);

            default:
                throw new InvalidArgumentException("Invalid user role: $role. Expected 'customer' or 'admin'.");
        }
    }

    public function createUserByEmail($email) {
        try {

            $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return null;
            }


            $userModel = new class($this->db) extends BaseModel {

                protected $table = 'users';
                protected $primaryKey = 'user_id';

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $user_data = $userModel->select([
                        'u.*',
                        'c.customer_id', 'c.first_name', 'c.last_name', 'c.phone', 'c.date_of_birth', 'c.loyalty_points',
                        'a.admin_id', 'a.admin_name', 'a.permissions', 'a.last_login'
                    ])
                    ->from('users u')
                    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                    ->where('u.email', '=', $email)
                    ->where('u.is_active', '=', 1)
                    ->first();

            if ($user_data) {

                $user = $this->createUser($user_data['role']);

                $user->setUserData($user_data);

                $this->setRoleSpecificData($user, $user_data);

                return $user;
            }

            return null;
        } catch (Exception $e) {
            error_log("UserFactory::createUserByEmail failed: " . $e->getMessage());
            return null;
        }
    }

    public function createUserById($user_id) {
        try {
            if (!is_numeric($user_id) || $user_id <= 0) {
                return null;
            }


            $userModel = new class($this->db) extends BaseModel {

                protected $table = 'users';
                protected $primaryKey = 'user_id';

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $user_data = $userModel->select([
                        'u.*',
                        'c.customer_id', 'c.first_name', 'c.last_name', 'c.phone', 'c.date_of_birth', 'c.loyalty_points',
                        'a.admin_id', 'a.admin_name', 'a.permissions', 'a.last_login'
                    ])
                    ->from('users u')
                    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                    ->where('u.user_id', '=', $user_id)
                    ->where('u.is_active', '=', 1)
                    ->first();

            if ($user_data) {

                $user = $this->createUser($user_data['role']);

                $user->setUserData($user_data);

                $this->setRoleSpecificData($user, $user_data);

                return $user;
            }

            return null;
        } catch (Exception $e) {
            error_log("UserFactory::createUserById failed: " . $e->getMessage());
            return null;
        }
    }

    private function setRoleSpecificData($user, $data) {
        if ($user instanceof Customer) {

            $reflection = new ReflectionClass($user);

            $this->setPrivateProperty($reflection, $user, 'customer_id', $data['customer_id']);
            $this->setPrivateProperty($reflection, $user, 'first_name', $data['first_name']);
            $this->setPrivateProperty($reflection, $user, 'last_name', $data['last_name']);
            $this->setPrivateProperty($reflection, $user, 'phone', $data['phone']);
            $this->setPrivateProperty($reflection, $user, 'date_of_birth', $data['date_of_birth']);
            $this->setPrivateProperty($reflection, $user, 'loyalty_points', $data['loyalty_points']);
        } elseif ($user instanceof Admin) {

            $reflection = new ReflectionClass($user);

            $this->setPrivateProperty($reflection, $user, 'admin_id', $data['admin_id']);
            $this->setPrivateProperty($reflection, $user, 'admin_name', $data['admin_name']);
            $this->setPrivateProperty($reflection, $user, 'permissions', $data['permissions']);
            $this->setPrivateProperty($reflection, $user, 'last_login', $data['last_login']);
        }
    }

    private function setPrivateProperty($reflection, $object, $property_name, $value) {
        if ($reflection->hasProperty($property_name)) {
            $property = $reflection->getProperty($property_name);
            $property->setAccessible(true);
            $property->setValue($object, $value);
        }
    }

    public function registerCustomer($customer_data) {
        try {

            $required_fields = ['email', 'password', 'first_name', 'last_name'];
            $errors = $this->validateCustomerData($customer_data, $required_fields);

            if (!empty($errors)) {
                throw new InvalidArgumentException(implode(', ', $errors));
            }


            if ($this->isEmailTaken($customer_data['email'])) {
                throw new Exception("Email address is already registered");
            }


            $userModel = new class($this->db) extends BaseModel {

                protected $table = 'users';
                protected $primaryKey = 'user_id';
                protected $fillable = ['email', 'password_hash', 'role'];

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $userModel->beginTransaction();

            $password_hash = password_hash($customer_data['password'], PASSWORD_DEFAULT);
            $userRecord = $userModel->create([
                'email' => $customer_data['email'],
                'password_hash' => $password_hash,
                'role' => 'customer'
            ]);

            if (!$userRecord) {
                throw new Exception("Failed to create user record");
            }

            $user_id = $userRecord->user_id;

            $customerModel = new class($this->db) extends BaseModel {

                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
                protected $fillable = ['user_id', 'first_name', 'last_name', 'phone', 'date_of_birth'];

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $customerRecord = $customerModel->create([
                'user_id' => $user_id,
                'first_name' => $customer_data['first_name'],
                'last_name' => $customer_data['last_name'],
                'phone' => $customer_data['phone'] ?? null,
                'date_of_birth' => $customer_data['date_of_birth'] ?? null
            ]);

            if (!$customerRecord) {
                throw new Exception("Failed to create customer record");
            }


            $userModel->commit();

            return $this->createUserById($user_id);
        } catch (Exception $e) {

            if (isset($userModel) && $userModel->inTransaction()) {
                $userModel->rollback();
            }

            error_log("Customer registration failed: " . $e->getMessage());
            throw $e; 
        }
    }

    public function createAdmin($admin_data) {
        try {

            $required_fields = ['email', 'password', 'admin_name'];
            $errors = $this->validateAdminData($admin_data, $required_fields);

            if (!empty($errors)) {
                throw new InvalidArgumentException(implode(', ', $errors));
            }


            if ($this->isEmailTaken($admin_data['email'])) {
                throw new Exception("Email address is already registered");
            }


            $userModel = new class($this->db) extends BaseModel {

                protected $table = 'users';
                protected $primaryKey = 'user_id';
                protected $fillable = ['email', 'password_hash', 'role'];

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $userModel->beginTransaction();

            $password_hash = password_hash($admin_data['password'], PASSWORD_DEFAULT);
            $userRecord = $userModel->create([
                'email' => $admin_data['email'],
                'password_hash' => $password_hash,
                'role' => 'admin'
            ]);

            if (!$userRecord) {
                throw new Exception("Failed to create user record");
            }

            $user_id = $userRecord->user_id;

            $permissions = isset($admin_data['permissions']) ? json_encode($admin_data['permissions']) : json_encode([
                        'user_management' => true,
                        'menu_management' => true,
                        'order_management' => true,
                        'reports' => true
            ]);

            $adminModel = new class($this->db) extends BaseModel {

                protected $table = 'admins';
                protected $primaryKey = 'admin_id';
                protected $fillable = ['user_id', 'admin_name', 'permissions'];

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $adminRecord = $adminModel->create([
                'user_id' => $user_id,
                'admin_name' => $admin_data['admin_name'],
                'permissions' => $permissions
            ]);

            if (!$adminRecord) {
                throw new Exception("Failed to create admin record");
            }


            $userModel->commit();

            return $this->createUserById($user_id);
        } catch (Exception $e) {

            if (isset($userModel) && $userModel->inTransaction()) {
                $userModel->rollback();
            }

            error_log("Admin creation failed: " . $e->getMessage());
            throw $e; // Re-throw to let calling code handle it
        }
    }

    private function isEmailTaken($email) {
        try {
       
            $userModel = new class($this->db) extends BaseModel {

                protected $table = 'users';
                protected $primaryKey = 'user_id';

                public function __construct($db_connection) {
                    $this->db = $db_connection;
                }
            };

            $count = $userModel->where('email', '=', $email)->count();
            return $count > 0;
        } catch (Exception $e) {
            error_log("Email check failed: " . $e->getMessage());
            return true;
        }
    }

    private function validateCustomerData($data, $required_fields) {
        $errors = [];

        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = ucfirst(str_replace('_', ' ', $field)) . " is required";
            }
        }


        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }


        if (!empty($data['password']) && !$this->isPasswordSecure($data['password'])) {
            $errors[] = "Password must be at least 8 characters with uppercase, lowercase, number, and special character";
        }

        return $errors;
    }

    private function validateAdminData($data, $required_fields) {
        $errors = [];

        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                $errors[] = ucfirst(str_replace('_', ' ', $field)) . " is required";
            }
        }


        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }


        if (!empty($data['password']) && !$this->isPasswordSecure($data['password'])) {
            $errors[] = "Password must be at least 8 characters with uppercase, lowercase, number, and special character";
        }

        return $errors;
    }

    private function isPasswordSecure($password) {
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
    }
}
