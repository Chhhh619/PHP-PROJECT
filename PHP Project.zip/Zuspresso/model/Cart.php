<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Cart Model with ORM (Session-based) - Updated Version
 * @version 2.0
 */
require_once 'BaseModel.php';
require_once 'MenuItem.php';

class Cart extends BaseModel {
    
    protected $table = 'cart_items'; // For potential future database storage
    protected $primaryKey = 'cart_id';
    protected $fillable = [
        'session_id', 'customer_id', 'item_id', 'quantity', 
        'customizations', 'is_free_item', 'voucher_code', 'added_at'
    ];
    
    private $menuItem;
    private $useDatabase = false; 
    
    public function __construct() {
        parent::__construct();
        $this->menuItem = new MenuItem();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }
    
    /**
     * Add item to cart using ORM for validation
     */
    public function addToCart($itemId, $quantity = 1, $customizations = []) {
        // Get item details using ORM
        $item = $this->menuItem->find($itemId);
        
        if (!$item || !$item->is_available) {
            throw new Exception('Menu item not found or unavailable');
        }
        
        // Check stock using ORM features
        if ($item->stock_quantity !== null && $item->stock_quantity < $quantity) {
            throw new Exception('Insufficient stock available');
        }
        
        // Create cart item key
        $cartKey = $itemId . '_' . md5(serialize($customizations));
        
        // Add or update item in session cart
        if (isset($_SESSION['cart'][$cartKey])) {
            $_SESSION['cart'][$cartKey]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$cartKey] = [
                'item_id' => $item->item_id,
                'name' => $item->name,
                'price' => $item->price,
                'category' => $item->category,
                'quantity' => $quantity,
                'customizations' => $customizations,
                'added_at' => time()
            ];
        }
        
        // Optionally save to database if enabled
        if ($this->useDatabase && isset($_SESSION['user_id'])) {
            $this->syncCartToDatabase($_SESSION['user_id']);
        }
        
        return true;
    }
    
    /**
     * Get all cart items for a user (from session or database)
     */
    public function getCartItems($userId = null) {
        if ($this->useDatabase && $userId) {
            return $this->getCartFromDatabase($userId);
        }
        
        return $_SESSION['cart'] ?? [];
    }
    
    /**
     * Get cart items from database using ORM
     */
    private function getCartFromDatabase($userId) {
        $cartItems = $this->where('customer_id', '=', $userId)
                          ->where('session_id', '=', session_id())
                          ->get();
        
        $formatted = [];
        foreach ($cartItems as $item) {
            $menuItem = $this->menuItem->find($item['item_id']);
            if ($menuItem) {
                $key = $item['item_id'] . '_' . md5($item['customizations']);
                $formatted[$key] = [
                    'item_id' => $item['item_id'],
                    'name' => $menuItem->name,
                    'price' => $menuItem->price,
                    'category' => $menuItem->category,
                    'quantity' => $item['quantity'],
                    'customizations' => json_decode($item['customizations'], true),
                    'is_free_item' => $item['is_free_item'],
                    'voucher_code' => $item['voucher_code'],
                    'added_at' => strtotime($item['added_at'])
                ];
            }
        }
        
        return $formatted;
    }
    
    /**
     * Sync cart to database using ORM
     */
    private function syncCartToDatabase($userId) {
        if (!$this->useDatabase) return;
        
        // Clear existing cart items for this session using ORM
        $this->where('customer_id', '=', $userId)
              ->where('session_id', '=', session_id())
              ->delete();
        
        // Save current cart items using ORM
        foreach ($_SESSION['cart'] as $cartKey => $item) {
            $this->create([
                'session_id' => session_id(),
                'customer_id' => $userId,
                'item_id' => $item['item_id'],
                'quantity' => $item['quantity'],
                'customizations' => json_encode($item['customizations'] ?? []),
                'is_free_item' => isset($item['is_free_item']) ? 1 : 0,
                'voucher_code' => $item['voucher_code'] ?? null,
                'added_at' => date('Y-m-d H:i:s', $item['added_at'] ?? time())
            ]);
        }
    }
    
    /**
     * Update cart item quantity using ORM validation
     */
    public function updateCartItem($cartKey, $quantity) {
        if (!isset($_SESSION['cart'][$cartKey])) {
            throw new Exception('Cart item not found');
        }
        
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$cartKey]);
        } else {
            // Validate stock using ORM
            $itemId = $_SESSION['cart'][$cartKey]['item_id'];
            $item = $this->menuItem->find($itemId);
            
            if ($item && $item->stock_quantity !== null && $item->stock_quantity < $quantity) {
                throw new Exception('Requested quantity exceeds available stock');
            }
            
            $_SESSION['cart'][$cartKey]['quantity'] = $quantity;
        }
        
        if ($this->useDatabase && isset($_SESSION['user_id'])) {
            $this->syncCartToDatabase($_SESSION['user_id']);
        }
        
        return true;
    }
    
    /**
     * Remove item from cart
     */
    public function removeFromCart($cartKey) {
        if (isset($_SESSION['cart'][$cartKey])) {
            unset($_SESSION['cart'][$cartKey]);
            
            if ($this->useDatabase && isset($_SESSION['user_id'])) {
                $this->syncCartToDatabase($_SESSION['user_id']);
            }
            
            return true;
        }
        return false;
    }
    
    /**
     * Clear entire cart
     */
    public function clearCart() {
        $_SESSION['cart'] = [];
        
        if ($this->useDatabase && isset($_SESSION['user_id'])) {
            $this->where('customer_id', '=', $_SESSION['user_id'])
                  ->where('session_id', '=', session_id())
                  ->delete();
        }
        
        return true;
    }
    
    /**
     * Calculate cart totals
     */
    public function getCartTotals($userId = null) {
        $cart = $this->getCartItems($userId);
        $subtotal = 0;
        $itemCount = 0;
        
        foreach ($cart as $item) {
            $subtotal += $item['price'] * $item['quantity'];
            $itemCount += $item['quantity'];
        }
        
        $taxRate = 0.06; // 6% SST
        $tax = $subtotal * $taxRate;
        $total = $subtotal + $tax;
        
        return [
            'subtotal' => round($subtotal, 2),
            'tax' => round($tax, 2),
            'total' => round($total, 2),
            'item_count' => $itemCount
        ];
    }
    
    /**
     * Validate cart items are still available using ORM
     */
    public function validateCart() {
        $cart = $this->getCartItems();
        $hasChanges = false;
        
        foreach ($cart as $cartKey => $item) {
            // Use ORM to check item availability
            $menuItem = $this->menuItem->find($item['item_id']);
            
            if (!$menuItem || !$menuItem->is_available) {
                // Remove unavailable items
                unset($_SESSION['cart'][$cartKey]);
                $hasChanges = true;
            } elseif ($menuItem->price != $item['price']) {
                // Update price if changed
                $_SESSION['cart'][$cartKey]['price'] = $menuItem->price;
                $hasChanges = true;
            } elseif ($menuItem->stock_quantity !== null && $menuItem->stock_quantity < $item['quantity']) {
                // Adjust quantity if stock is limited
                if ($menuItem->stock_quantity == 0) {
                    unset($_SESSION['cart'][$cartKey]);
                } else {
                    $_SESSION['cart'][$cartKey]['quantity'] = $menuItem->stock_quantity;
                }
                $hasChanges = true;
            }
        }
        
        if ($hasChanges && $this->useDatabase && isset($_SESSION['user_id'])) {
            $this->syncCartToDatabase($_SESSION['user_id']);
        }
        
        return !$hasChanges;
    }
    
    /**
     * Get cart item count
     */
    public function getItemCount() {
        $cart = $this->getCartItems();
        $count = 0;
        foreach ($cart as $item) {
            $count += $item['quantity'];
        }
        return $count;
    }
    
    /**
     * Check if cart is empty
     */
    public function isEmpty() {
        return empty($_SESSION['cart']);
    }
    
    /**
     * Get cart summary for display
     */
    public function getCartSummary() {
        $cart = $this->getCartItems();
        $totals = $this->getCartTotals();
        
        return [
            'items' => $cart,
            'totals' => $totals,
            'is_empty' => $this->isEmpty()
        ];
    }
    
    /**
     * Get recommended items based on cart using ORM
     */
    public function getRecommendedItems($limit = 4) {
        $cart = $this->getCartItems();
        if (empty($cart)) {
            // Return popular items if cart is empty
            return $this->menuItem
                ->where('is_available', '=', 1)
                ->limit($limit)
                ->get();
        }
        
        // Get categories in cart
        $categories = array_unique(array_column($cart, 'category'));
        $cartItemIds = array_column($cart, 'item_id');
        
        // Get items from same categories not in cart using ORM
        $recommendations = $this->menuItem
            ->where('is_available', '=', 1)
            ->whereIn('category', $categories)
            ->limit($limit * 2)
            ->get();
        
        // Filter out items already in cart
        $filtered = [];
        foreach ($recommendations as $item) {
            if (!in_array($item['item_id'], $cartItemIds)) {
                $filtered[] = $item;
                if (count($filtered) >= $limit) break;
            }
        }
        
        return $filtered;
    }
    
    /**
     * Merge guest cart with user cart when logging in
     */
    public function mergeGuestCart($userId) {
        $guestCart = $_SESSION['cart'] ?? [];
        
        if ($this->useDatabase) {
            // Load user's saved cart from database using ORM
            $userCart = $this->getCartFromDatabase($userId);
            
            // Merge carts
            foreach ($guestCart as $key => $item) {
                if (!isset($userCart[$key])) {
                    $userCart[$key] = $item;
                } else {
                    // Combine quantities
                    $userCart[$key]['quantity'] += $item['quantity'];
                }
            }
            
            $_SESSION['cart'] = $userCart;
            $this->syncCartToDatabase($userId);
        }
        
        return true;
    }
}