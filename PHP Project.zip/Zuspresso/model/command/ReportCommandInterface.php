<?php


interface ReportCommandInterface {
    
    public function execute();
    

    public function getDescription();
    
    public function validate();
}


class GenerateDashboardCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $filters;
    
    public function __construct(ReportsModel $reportsModel, array $filters = []) {
        $this->reportsModel = $reportsModel;
        $this->filters = $filters;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid dashboard command parameters');
        }
        
        return $this->reportsModel->getDashboardSummary();
    }
    
    public function getDescription() {
        return 'Generate dashboard summary with key metrics';
    }
    
    public function validate() {
        return $this->reportsModel !== null;
    }
}
