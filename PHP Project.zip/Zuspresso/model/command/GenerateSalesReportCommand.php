<?php


class GenerateSalesReportCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $filters;
    
    public function __construct(ReportsModel $reportsModel, array $filters) {
        $this->reportsModel = $reportsModel;
        $this->filters = $filters;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid sales report parameters');
        }
        
        return [
            'salesReport' => $this->reportsModel->getSalesReport(
                $this->filters['start_date'] ?? null,
                $this->filters['end_date'] ?? null,
                $this->filters['group_by'] ?? 'day'
            )
        ];
    }
    
    public function getDescription() {
        $startDate = $this->filters['start_date'] ?? 'N/A';
        $endDate = $this->filters['end_date'] ?? 'N/A';
        return "Generate sales report from {$startDate} to {$endDate}";
    }
    
    public function validate() {
        if ($this->reportsModel === null) {
            return false;
        }
        
        
        if (isset($this->filters['start_date'], $this->filters['end_date'])) {
            $startDate = strtotime($this->filters['start_date']);
            $endDate = strtotime($this->filters['end_date']);
            
            return $startDate !== false && $endDate !== false && $startDate <= $endDate;
        }
        
        return true;
    }
}
