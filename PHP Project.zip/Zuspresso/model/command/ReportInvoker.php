<?php


class ReportInvoker {
    
    private $history = [];
    private $maxHistory = 100;
    
    
    public function execute(ReportCommandInterface $command) {
        $startTime = microtime(true);
        
        try {
            
            $result = $command->execute();
            
            
            $this->logExecution($command, $startTime, true);
            
            return $result;
            
        } catch (Exception $e) {

            $this->logExecution($command, $startTime, false, $e->getMessage());
            
            
            throw $e;
        }
    }
    
    public function executeBatch(array $commands) {
        $results = [];
        
        foreach ($commands as $index => $command) {
            try {
                $results[$index] = [
                    'success' => true,
                    'data' => $this->execute($command),
                    'command' => get_class($command)
                ];
            } catch (Exception $e) {
                $results[$index] = [
                    'success' => false,
                    'error' => $e->getMessage(),
                    'command' => get_class($command)
                ];
            }
        }
        
        return $results;
    }
    
    public function getHistory() {
        return $this->history;
    }
    

    public function clearHistory() {
        $this->history = [];
    }
    

    public function getStatistics() {
        if (empty($this->history)) {
            return [
                'total_executions' => 0,
                'successful_executions' => 0,
                'failed_executions' => 0,
                'success_rate' => 0,
                'average_execution_time' => 0
            ];
        }
        
        $total = count($this->history);
        $successful = count(array_filter($this->history, function($entry) {
            return $entry['success'];
        }));
        $failed = $total - $successful;
        
        $totalTime = array_sum(array_column($this->history, 'execution_time'));
        $averageTime = $totalTime / $total;
        
        return [
            'total_executions' => $total,
            'successful_executions' => $successful,
            'failed_executions' => $failed,
            'success_rate' => round(($successful / $total) * 100, 2),
            'average_execution_time' => round($averageTime, 4)
        ];
    }
    

    private function logExecution(ReportCommandInterface $command, $startTime, $success, $error = null) {
        $executionTime = microtime(true) - $startTime;
        
        $logEntry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'command_class' => get_class($command),
            'description' => $command->getDescription(),
            'execution_time' => $executionTime,
            'success' => $success,
            'error' => $error
        ];
        

        $this->history[] = $logEntry;
        

        if (count($this->history) > $this->maxHistory) {
            array_shift($this->history);
        }
        
      
        $logMessage = sprintf(
            "[%s] %s - %s (%.4fs) %s",
            $logEntry['timestamp'],
            $logEntry['command_class'],
            $logEntry['description'],
            $executionTime,
            $success ? 'SUCCESS' : 'FAILED: ' . $error
        );
        
        error_log("ReportInvoker: " . $logMessage);
    }
}