<?php


class GenerateTrendsReportCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $filters;
    
    public function __construct(ReportsModel $reportsModel, array $filters) {
        $this->reportsModel = $reportsModel;
        $this->filters = $filters;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid trends report parameters');
        }
        
        return [
            'orderTrends' => $this->reportsModel->getOrderTrends(
                $this->filters['start_date'] ?? null,
                $this->filters['end_date'] ?? null
            )
        ];
    }
    
    public function getDescription() {
        return 'Generate order trends and patterns analysis';
    }
    
    public function validate() {
        return $this->reportsModel !== null;
    }
}
