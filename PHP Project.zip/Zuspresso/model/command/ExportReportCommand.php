<?php


class ExportReportCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $reportType;
    private $format;
    private $filters;
    private $adminId;
    
    public function __construct(ReportsModel $reportsModel, $reportType, $format, array $filters, $adminId) {
        $this->reportsModel = $reportsModel;
        $this->reportType = $reportType;
        $this->format = $format;
        $this->filters = $filters;
        $this->adminId = $adminId;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid export parameters');
        }
        
      
        $reportCommand = $this->createReportCommand();
        $invoker = new ReportInvoker();
        $reportData = $invoker->execute($reportCommand);
        
      
        return $this->exportData($reportData);
    }
    
    private function createReportCommand() {
        switch ($this->reportType) {
            case 'sales':
                return new GenerateSalesReportCommand($this->reportsModel, $this->filters);
            case 'products':
                return new GenerateProductsReportCommand($this->reportsModel, $this->filters);
            case 'trends':
                return new GenerateTrendsReportCommand($this->reportsModel, $this->filters);
            case 'customers':
                return new GenerateCustomersReportCommand($this->reportsModel, $this->filters);
            default:
                throw new InvalidArgumentException("Unknown report type: {$this->reportType}");
        }
    }
    
    private function exportData($data) {
        $filename = $this->generateFilename();
        $filepath = $this->getExportPath($filename);
        
        switch (strtolower($this->format)) {
            case 'csv':
                return $this->exportToCsv($data, $filepath, $filename);
            case 'json':
                return $this->exportToJson($data, $filepath, $filename);
            default:
                throw new InvalidArgumentException("Unsupported export format: {$this->format}");
        }
    }
    
    private function exportToCsv($data, $filepath, $filename) {
        $file = fopen($filepath, 'w');
        
        if (!$file) {
            throw new Exception("Cannot create export file: {$filepath}");
        }
        

        $csvData = $this->extractCsvData($data);
        
        if (!empty($csvData)) {
            
            fputcsv($file, array_keys($csvData[0]));
            
            
            foreach ($csvData as $row) {
                fputcsv($file, $row);
            }
        }
        
        fclose($file);
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath),
            'mime_type' => 'text/csv',
            'cleanup' => true
        ];
    }
    
    private function exportToJson($data, $filepath, $filename) {
        $jsonData = json_encode($data, JSON_PRETTY_PRINT);
        
        if (file_put_contents($filepath, $jsonData) === false) {
            throw new Exception("Cannot write JSON file: {$filepath}");
        }
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => filesize($filepath),
            'mime_type' => 'application/json',
            'cleanup' => true
        ];
    }
    
    private function extractCsvData($data) {
        
        foreach ($data as $key => $value) {
            if (is_array($value) && !empty($value)) {
                return $value;
            }
        }
        return [];
    }
    
    private function generateFilename() {
        $timestamp = date('Y-m-d_H-i-s');
        $adminPrefix = 'admin_' . $this->adminId;
        return "{$this->reportType}_report_{$adminPrefix}_{$timestamp}.{$this->format}";
    }
    
    private function getExportPath($filename) {
        $exportDir = '../../exports/';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }
        return $exportDir . $filename;
    }
    
    public function getDescription() {
        return "Export {$this->reportType} report as {$this->format}";
    }
    
    public function validate() {
        $allowedFormats = ['csv', 'json'];
        $allowedReportTypes = ['sales', 'products', 'trends', 'customers'];
        
        return $this->reportsModel !== null &&
               in_array(strtolower($this->format), $allowedFormats) &&
               in_array($this->reportType, $allowedReportTypes) &&
               $this->adminId > 0;
    }
}
