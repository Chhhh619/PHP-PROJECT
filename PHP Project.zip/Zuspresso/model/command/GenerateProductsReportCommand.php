<?php



class GenerateProductsReportCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $filters;
    
    public function __construct(ReportsModel $reportsModel, array $filters) {
        $this->reportsModel = $reportsModel;
        $this->filters = $filters;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid products report parameters');
        }
        
        return [
            'bestSellingProducts' => $this->reportsModel->getBestSellingProducts(
                $this->filters['start_date'] ?? null,
                $this->filters['end_date'] ?? null,
                $this->filters['limit'] ?? 10
            ),
            'categoryPerformance' => $this->reportsModel->getCategoryPerformance(
                $this->filters['start_date'] ?? null,
                $this->filters['end_date'] ?? null
            )
        ];
    }
    
    public function getDescription() {
        $limit = $this->filters['limit'] ?? 10;
        return "Generate top {$limit} products performance report";
    }
    
    public function validate() {
        if ($this->reportsModel === null) {
            return false;
        }
        
        // Validate limit parameter
        if (isset($this->filters['limit'])) {
            $limit = (int)$this->filters['limit'];
            if ($limit < 1 || $limit > 100) {
                return false;
            }
        }
        
        return true;
    }
}
