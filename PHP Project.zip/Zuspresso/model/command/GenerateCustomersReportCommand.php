<?php


require_once 'ReportCommandInterface.php';

class GenerateCustomersReportCommand implements ReportCommandInterface {
    
    private $reportsModel;
    private $filters;
    
    public function __construct(ReportsModel $reportsModel, array $filters) {
        $this->reportsModel = $reportsModel;
        $this->filters = $filters;
    }
    
    public function execute() {
        if (!$this->validate()) {
            throw new InvalidArgumentException('Invalid customers report parameters');
        }
        
        return [
            'customerAnalytics' => $this->reportsModel->getCustomerAnalytics(
                $this->filters['start_date'] ?? null,
                $this->filters['end_date'] ?? null
            )
        ];
    }
    
    public function getDescription() {
        return 'Generate customer analytics and behavior report';
    }
    
    public function validate() {
        return $this->reportsModel !== null;
    }
}