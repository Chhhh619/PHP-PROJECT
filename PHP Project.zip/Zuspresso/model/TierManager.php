<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

class TierManager {
    
    private $customerModel;
    private $loyaltyService;
    
    // Tier thresholds - modify these as needed
    private const TIER_THRESHOLDS = [
        'Bronze' => 0,
        'Silver' => 500,
        'Gold' => 2000,
        'Platinum' => 5000
    ];
    
    public function __construct() {
        $this->customerModel = new Customer();
        $this->loyaltyService = new LoyaltyService();
    }
    
    public function updateCustomerTier($customer_id) {
        try {
            // Get current customer data
            $customer = $this->customerModel->find($customer_id);
            if (!$customer) {
                throw new Exception("Customer not found: $customer_id");
            }
            
            $currentTierInDb = $customer->tier;
            $currentPoints = $customer->loyalty_points;
            
            // Calculate what tier should be based on points
            $calculatedTier = $this->calculateTierFromPoints($currentPoints);
            
            // Check if update needed
            if ($currentTierInDb === $calculatedTier) {
                return [
                    'updated' => false,
                    'customer_id' => $customer_id,
                    'points' => $currentPoints,
                    'tier' => $calculatedTier,
                    'message' => 'Tier already correct'
                ];
            }
            
            // Update the database
            $updateResult = $this->customerModel->updateById($customer_id, [
                'tier' => $calculatedTier,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            
            if (!$updateResult) {
                throw new Exception("Failed to update customer tier in database");
            }
            
            // Log the tier change
            SecurityValidator::logAction($customer->user_id, 'tier_updated', [
                'customer_id' => $customer_id,
                'old_tier' => $currentTierInDb,
                'new_tier' => $calculatedTier,
                'points' => $currentPoints,
                'update_method' => 'automatic'
            ]);
            
            return [
                'updated' => true,
                'customer_id' => $customer_id,
                'points' => $currentPoints,
                'old_tier' => $currentTierInDb,
                'new_tier' => $calculatedTier,
                'message' => "Tier updated from $currentTierInDb to $calculatedTier"
            ];
            
        } catch (Exception $e) {
            error_log("Error updating customer tier for ID $customer_id: " . $e->getMessage());
            return [
                'updated' => false,
                'customer_id' => $customer_id,
                'error' => $e->getMessage()
            ];
        }
    }
    
    private function calculateTierFromPoints($points) {
        if ($points >= self::TIER_THRESHOLDS['Platinum']) {
            return 'Platinum';
        } elseif ($points >= self::TIER_THRESHOLDS['Gold']) {
            return 'Gold';
        } elseif ($points >= self::TIER_THRESHOLDS['Silver']) {
            return 'Silver';
        } else {
            return 'Bronze';
        }
    }

    public function updateAllCustomerTiers($limit = null) {
        $results = [
            'total_processed' => 0,
            'total_updated' => 0,
            'updates' => [],
            'errors' => []
        ];
        
        try {
            // Get all customers
            $customers = $this->customerModel->findAll([], 'customer_id ASC', $limit);
            
            foreach ($customers as $customerData) {
                $result = $this->updateCustomerTier($customerData['customer_id']);
                $results['total_processed']++;
                
                if (isset($result['error'])) {
                    $results['errors'][] = $result;
                } elseif ($result['updated']) {
                    $results['total_updated']++;
                    $results['updates'][] = $result;
                }
            }
            
            // Log batch operation
            SecurityValidator::logAction('system', 'batch_tier_update', [
                'total_processed' => $results['total_processed'],
                'total_updated' => $results['total_updated'],
                'errors_count' => count($results['errors'])
            ]);
            
        } catch (Exception $e) {
            error_log("Error in batch tier update: " . $e->getMessage());
            $results['batch_error'] = $e->getMessage();
        }
        
        return $results;
    }
    
    /**
     * Get tier benefits information
     * 
     * @param string $tier
     * @return array Tier benefits and thresholds
     */
    public function getTierInfo($tier) {
        $tierBenefits = [
            'Bronze' => [
                'multiplier' => 1.0,
                'coffee_bonus' => false,
                'next_tier' => 'Silver',
                'next_threshold' => self::TIER_THRESHOLDS['Silver'],
                'benefits' => ['Basic points earning', 'Access to standard rewards']
            ],
            'Silver' => [
                'multiplier' => 1.5,
                'coffee_bonus' => true,
                'next_tier' => 'Gold',
                'next_threshold' => self::TIER_THRESHOLDS['Gold'],
                'benefits' => ['1.5x points earning', '2+ points per coffee', 'Priority support']
            ],
            'Gold' => [
                'multiplier' => 1.8,
                'coffee_bonus' => true,
                'next_tier' => 'Platinum',
                'next_threshold' => self::TIER_THRESHOLDS['Platinum'],
                'benefits' => ['1.8x points earning', '2+ points per coffee', 'Exclusive rewards']
            ],
            'Platinum' => [
                'multiplier' => 2.0,
                'coffee_bonus' => true,
                'next_tier' => null,
                'next_threshold' => null,
                'benefits' => ['2.0x points earning', '2+ points per coffee', 'VIP events', 'Premium support']
            ]
        ];
        
        return $tierBenefits[$tier] ?? $tierBenefits['Bronze'];
    }
    
    public function checkTierUpgradeEligibility($customer_id) {
        $customer = $this->customerModel->find($customer_id);
        if (!$customer) {
            return null;
        }
        
        $currentTier = $customer->tier;
        $currentPoints = $customer->loyalty_points;
        $calculatedTier = $this->calculateTierFromPoints($currentPoints);
        
        if ($calculatedTier !== $currentTier) {
            $tierInfo = $this->getTierInfo($calculatedTier);
            
            return [
                'eligible' => true,
                'current_tier' => $currentTier,
                'new_tier' => $calculatedTier,
                'current_points' => $currentPoints,
                'benefits' => $tierInfo['benefits'],
                'multiplier' => $tierInfo['multiplier']
            ];
        }
        
        return ['eligible' => false];
    }
}
