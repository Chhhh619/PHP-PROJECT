<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

require_once 'BaseModel.php';

class RewardRedemption extends BaseModel {

    protected $table = 'reward_redemptions';
    protected $primaryKey = 'redemption_id';
    protected $fillable = [
        'customer_id', 'reward_id', 'points_used', 'redemption_code',
        'status', 'redeemed_at', 'used_at', 'expires_at', 'order_id'
    ];

    const STATUS_PENDING = 'pending';
    const STATUS_ACTIVE = 'active';
    const STATUS_USED = 'used';
    const STATUS_EXPIRED = 'expired';
    const STATUS_CANCELLED = 'cancelled';

    public static function generateCode() {
        return 'ZUS' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
    }

    public static function getCustomerRedemptions($user_id) {
        $instance = new self();
        $redemptions = $instance->findAll(['customer_id' => $user_id]);

        $rewardModel = new Reward();
        foreach ($redemptions as &$redemption) {
            $reward = $rewardModel->find($redemption['reward_id']);
            if ($reward) {
                $redemption['reward_name'] = $reward->name;
                $redemption['reward_type'] = $reward->reward_type;
                $redemption['reward_value'] = $reward->reward_value;
            } else {
                $redemption['reward_name'] = 'Unknown Reward';
                $redemption['reward_type'] = 'unknown';
                $redemption['reward_value'] = 0;
            }
        }

        usort($redemptions, function ($a, $b) {
            $statusPriority = [
                'active' => 1,
                'pending' => 2,
                'used' => 3,
                'expired' => 4,
                'cancelled' => 5
            ];

            $priorityA = $statusPriority[$a['status']] ?? 99;
            $priorityB = $statusPriority[$b['status']] ?? 99;

            if ($priorityA !== $priorityB) {
                return $priorityA - $priorityB;
            }

            return strcasecmp($a['reward_name'], $b['reward_name']);
        });

        return $redemptions;
    }

    public static function getActiveRedemptions($user_id) {
        $instance = new self();
        return $instance->findAll([
            'customer_id' => $user_id,
            'status' => self::STATUS_ACTIVE
        ], 'redeemed_at DESC');
    }

    public static function createRedemption($user_id, $reward_id, $points_used) {
        $redemption_code = 'ZUS' . strtoupper(bin2hex(random_bytes(4)));

        $instance = new self();
        $redemption = $instance->create([
            'customer_id' => $user_id,
            'reward_id' => $reward_id,
            'points_used' => $points_used,
            'redemption_code' => $redemption_code,
            'status' => self::STATUS_ACTIVE,
            'redeemed_at' => date('Y-m-d H:i:s'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+30 days'))
        ]);

        return [
            'redemption_id' => $redemption->{$instance->primaryKey},
            'redemption_code' => $redemption_code
        ];
    }

    public function markAsUsed($orderId = null) {
        $updateData = [
            'status' => self::STATUS_USED,
            'used_at' => date('Y-m-d H:i:s')
        ];

        if ($orderId) {
            $updateData['order_id'] = $orderId;
        }

        return $this->update($updateData);
    }

    public function isExpired() {
        return isset($this->attributes['expires_at']) &&
                $this->attributes['expires_at'] &&
                strtotime($this->attributes['expires_at']) < time();
    }

    public static function findByCode($redemption_code) {
        $instance = new self();
        $redemptions = $instance->findAll(['redemption_code' => $redemption_code]);

        if (!empty($redemptions)) {
            $redemption = new self();
            $redemption->attributes = $redemptions[0];
            return $redemption;
        }

        return null;
    }

    public static function getById($redemption_id) {
        $instance = new self();
        $result = $instance->find($redemption_id);
        return $result ? $result->toArray() : null;
    }
}