<?php
/**
 * Zuspresso Online Ordering System
 * 
 * @author Tang Wei Chiun
 * @module Cart Management Function
 * @version 2.0
 */
require_once 'BaseModel.php';
require_once 'MenuItem.php';

class CartModel extends BaseModel {
    
   
    protected $table = 'cart_items'; 
    protected $primaryKey = 'cart_id';
    
    private $menuItem;
    
    public function __construct() {
        parent::__construct();
        $this->menuItem = new MenuItem();
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }
    
    /**
     * Add item to cart (session-based storage) using ORM for item validation
     */
    public function addToCart($item_id, $quantity = 1, $customizations = []) {
        // Get item details using ORM
        $item = $this->menuItem->find($item_id);
        
        if (!$item || !$item->is_available) {
            throw new Exception('Menu item not found or unavailable');
        }
        
        // Create cart item key
        $cart_key = $item_id . '_' . md5(serialize($customizations));
        
        // Add or update item in cart
        if (isset($_SESSION['cart'][$cart_key])) {
            $_SESSION['cart'][$cart_key]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$cart_key] = [
                'item_id' => $item->item_id,
                'name' => $item->name,
                'price' => $item->price,
                'category' => $item->category,
                'quantity' => $quantity,
                'customizations' => $customizations,
                'added_at' => time()
            ];
        }
        
        return true;
    }
    
    /**
     * Get all cart items from session
     */
    public function getCartItems() {
        return $_SESSION['cart'] ?? [];
    }
    
    /**
     * Update cart item quantity
     */
    public function updateCartItem($cart_key, $quantity) {
        if (!isset($_SESSION['cart'][$cart_key])) {
            throw new Exception('Cart item not found');
        }
        
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$cart_key]);
        } else {
            $_SESSION['cart'][$cart_key]['quantity'] = $quantity;
        }
        
        return true;
    }
    
    /**
     * Remove item from cart
     */
    public function removeFromCart($cart_key) {
        if (isset($_SESSION['cart'][$cart_key])) {
            unset($_SESSION['cart'][$cart_key]);
            return true;
        }
        
        return false;
    }
    
    /**
     * Clear entire cart
     */
    public function clearCart() {
        $_SESSION['cart'] = [];
        return true;
    }
    
    /**
     * Calculate cart totals
     */
    public function getCartTotals() {
        $cart = $this->getCartItems();
        $subtotal = 0;
        $item_count = 0;
        
        foreach ($cart as $item) {
            $subtotal += $item['price'] * $item['quantity'];
            $item_count += $item['quantity'];
        }
        
        $tax_rate = 0.06; // 6% SST
        $tax = $subtotal * $tax_rate;
        $total = $subtotal + $tax;
        
        return [
            'subtotal' => round($subtotal, 2),
            'tax' => round($tax, 2),
            'total' => round($total, 2),
            'item_count' => $item_count
        ];
    }
    
    /**
     * Get menu item details using ORM
     */
    public function getMenuItem($item_id) {
        $item = $this->menuItem->find($item_id);
        return $item ? $item->toArray() : null;
    }
    
    /**
     * Get all menu items with categories using ORM
     */
    public function getMenuItems($category = null) {
        // Build query using ORM
        $query = $this->menuItem->where('is_available', '=', 1);
        
        if ($category) {
            $query->where('category', '=', $category);
        }
        
        return $query->orderBy('category')
                    ->orderBy('name')
                    ->get();
    }
    
    /**
     * Get menu categories using ORM
     */
    public function getMenuCategories() {
        // Use ORM to get distinct categories
        $results = $this->menuItem
            ->select(['category'])
            ->where('is_available', '=', 1)
            ->groupBy('category')
            ->orderBy('category')
            ->get();
            
        return array_column($results, 'category');
    }
    
    /**
     * Search menu items using ORM
     */
    public function searchMenuItems($searchTerm) {
        return $this->menuItem
            ->where('is_available', '=', 1)
            ->whereLike('name', '%' . $searchTerm . '%')
            ->orderBy('name')
            ->get();
    }
    
    /**
     * Get featured items using ORM
     */
    public function getFeaturedItems($limit = 6) {
        // Example: Get popular items (you could add a 'is_featured' column)
        return $this->menuItem
            ->where('is_available', '=', 1)
            ->orderBy('name')
            ->limit($limit)
            ->get();
    }
    
    /**
     * Validate cart before checkout using ORM
     */
    public function validateCart() {
        $cart = $this->getCartItems();
        $hasChanges = false;
        
        if (empty($cart)) {
            throw new Exception('Cart is empty');
        }
        
        foreach ($cart as $cart_key => $item) {
            // Check item availability using ORM
            $menu_item = $this->menuItem->find($item['item_id']);
            
            if (!$menu_item || !$menu_item->is_available) {
                // Remove unavailable items
                unset($_SESSION['cart'][$cart_key]);
                $hasChanges = true;
                throw new Exception('Item "' . $item['name'] . '" is no longer available');
            }
            
            // Update price if changed
            if ($menu_item->price != $item['price']) {
                $_SESSION['cart'][$cart_key]['price'] = $menu_item->price;
                $hasChanges = true;
            }
            
            // Check stock if applicable
            if ($menu_item->stock_quantity !== null && $menu_item->stock_quantity < $item['quantity']) {
                $_SESSION['cart'][$cart_key]['quantity'] = $menu_item->stock_quantity;
                $hasChanges = true;
                
                if ($menu_item->stock_quantity == 0) {
                    unset($_SESSION['cart'][$cart_key]);
                    throw new Exception('Item "' . $item['name'] . '" is out of stock');
                }
            }
        }
        
        return !$hasChanges;
    }
    
    /**
     * Get cart item count
     */
    public function getItemCount() {
        $cart = $this->getCartItems();
        $count = 0;
        
        foreach ($cart as $item) {
            $count += $item['quantity'];
        }
        
        return $count;
    }
    
    /**
     * Check if cart is empty
     */
    public function isEmpty() {
        return empty($_SESSION['cart']);
    }
    
    /**
     * Get cart summary for display
     */
    public function getCartSummary() {
        $cart = $this->getCartItems();
        $totals = $this->getCartTotals();
        
        return [
            'items' => $cart,
            'totals' => $totals,
            'is_empty' => $this->isEmpty(),
            'item_count' => $this->getItemCount()
        ];
    }
    
    /**
     * Add free item to cart (for rewards)
     */
    public function addFreeItemToCart($item_id, $voucher_code) {
        // Get item details using ORM
        $item = $this->menuItem->find($item_id);
        
        if (!$item || !$item->is_available) {
            throw new Exception('Free item not found or unavailable');
        }
        
        // Create unique cart key for free item
        $cart_key = 'free_' . $item_id . '_' . time();
        
        $_SESSION['cart'][$cart_key] = [
            'item_id' => $item->item_id,
            'name' => $item->name . ' (FREE)',
            'price' => 0.00,
            'original_price' => $item->price,
            'category' => $item->category,
            'quantity' => 1,
            'customizations' => [],
            'is_free_item' => true,
            'voucher_code' => $voucher_code,
            'added_at' => time()
        ];
        
        return true;
    }
    
    /**
     * Remove free items from cart
     */
    public function removeFreeItems() {
        $cart = $this->getCartItems();
        $removed = 0;
        
        foreach ($cart as $cart_key => $item) {
            if (isset($item['is_free_item']) && $item['is_free_item']) {
                unset($_SESSION['cart'][$cart_key]);
                $removed++;
            }
        }
        
        return $removed;
    }
    
    /**
     * Get items by category using ORM
     */
    public function getItemsByCategory($category) {
        return $this->menuItem
            ->where('category', '=', $category)
            ->where('is_available', '=', 1)
            ->orderBy('name')
            ->get();
    }
    
    /**
     * Get low stock items using ORM (for admin notification)
     */
    public function getLowStockItems() {
        // Use ORM to find items where stock is below threshold
        $results = $this->menuItem
            ->where('is_available', '=', 1)
            ->get();
            
        $lowStockItems = [];
        foreach ($results as $item) {
            if ($item['stock_quantity'] !== null && 
                $item['low_stock_threshold'] !== null &&
                $item['stock_quantity'] <= $item['low_stock_threshold']) {
                $lowStockItems[] = $item;
            }
        }
        
        return $lowStockItems;
    }
    
    /**
     * Check if item is in cart
     */
    public function isItemInCart($item_id) {
        $cart = $this->getCartItems();
        
        foreach ($cart as $item) {
            if ($item['item_id'] == $item_id) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get cart item by ID
     */
    public function getCartItemById($item_id) {
        $cart = $this->getCartItems();
        
        foreach ($cart as $cart_key => $item) {
            if ($item['item_id'] == $item_id) {
                return [
                    'cart_key' => $cart_key,
                    'item' => $item
                ];
            }
        }
        
        return null;
    }
}