<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

interface PointCalculationStrategy {
    public function calculatePoints($orderAmount, $customerId = null, $orderItems = null);
    public function getStrategyName();
    public function getDescription();
}