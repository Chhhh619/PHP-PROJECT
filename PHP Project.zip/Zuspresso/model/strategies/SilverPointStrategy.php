<?php

/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */
class SilverPointStrategy implements PointCalculationStrategy {

    public function calculatePoints($orderAmount, $customerId = null, $orderItems = null, $orderId = null) {
        $roundedAmount = floor($orderAmount);  
        $basePoints = floor($roundedAmount * 1.5);  
        $coffeeBonus = $this->calculateCoffeeBonus($orderItems, $orderId);

        error_log("Silver Strategy: floor($orderAmount) = $roundedAmount * 1.5 = $basePoints + $coffeeBonus coffee bonus = " . ($basePoints + $coffeeBonus));

        return $basePoints + $coffeeBonus;
    }

    public function getStrategyName() {
        return 'Silver Points';
    }

    public function getDescription() {
        return "Silver tier: 1.5x points + coffee bonuses";
    }

    private function calculateCoffeeBonus($orderItems, $orderId = null) {
        $coffeeBonus = 0;

        if (!empty($orderItems)) {
            foreach ($orderItems as &$item) {
                if (!isset($item['category']) && isset($item['item_id'])) {
                    $item['category'] = $this->getItemCategoryFromWebService($item['item_id'], $orderId);
                }

                if (isset($item['category']) && strtolower($item['category']) === 'coffee') {
                    $itemBonus = (int) $item['quantity'] * 2;
                    $coffeeBonus += $itemBonus;
                    error_log("Silver Strategy: Coffee bonus - item {$item['item_id']} qty {$item['quantity']} = +$itemBonus points");
                }
            }
        }

        return $coffeeBonus;
    }

    private function getItemCategoryFromWebService($itemId, $orderId = null) {
        try {
            if ($orderId) {
                $orderItems = $this->getOrderItemsFromWebService($orderId);
                if ($orderItems) {
                    foreach ($orderItems as $orderItem) {
                        if ($orderItem['item_id'] == $itemId && isset($orderItem['category'])) {
                            return $orderItem['category'];
                        }
                    }
                }
            }

            return $this->fallbackGetItemCategory($itemId);

        } catch (Exception $e) {
            error_log("Silver Strategy: Error getting category for item $itemId: " . $e->getMessage());
            return $this->fallbackGetItemCategory($itemId);
        }
    }

    private function getOrderItemsFromWebService($orderId) {
        try {
            $url = "http://localhost/service/OrderService.php?action=get_order_items&order_id=" . intval($orderId);

            // Create context for the request
            $context = stream_context_create([
                'http' => [
                    'timeout' => 5,
                    'method' => 'GET',
                    'header' => "Accept: application/json\r\n"
                ]
            ]);

            $response = @file_get_contents($url, false, $context);

            if ($response === false) {
                throw new Exception("Failed to fetch order items from web service");
            }

            $data = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Invalid JSON response");
            }

            if (isset($data['success']) && $data['success'] && isset($data['data']['items'])) {
                return $data['data']['items'];
            }

            return null;

        } catch (Exception $e) {
            error_log("Silver Strategy: Web service error: " . $e->getMessage());
            return null;
        }
    }

    private function fallbackGetItemCategory($itemId) {
        try {
            $menuItem = new MenuItem();
            $itemData = $menuItem->find($itemId);
            if ($itemData) {
                error_log("Silver Strategy: Using fallback database query for item $itemId category: {$itemData->category}");
                return $itemData->category;
            }
            return null;
        } catch (Exception $e) {
            error_log("Silver Strategy: Fallback error: " . $e->getMessage());
            return null;
        }
    }
}
