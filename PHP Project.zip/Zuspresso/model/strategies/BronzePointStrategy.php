<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

class BronzePointStrategy implements PointCalculationStrategy {
    
    public function calculatePoints($orderAmount, $customerId = null, $orderItems = null) {
        return floor($orderAmount);
    }

    public function getStrategyName() {
        return 'Bronze Points';
    }

    public function getDescription() {
        return "Bronze tier: 1 point per RM spent";
    }
}