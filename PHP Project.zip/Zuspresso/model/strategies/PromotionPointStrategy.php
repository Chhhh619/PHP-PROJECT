<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 * Special Promotion Strategy - For Tuesday promotions or special events
 */

require_once 'PointCalculationStrategy.php';

class PromotionPointStrategy implements PointCalculationStrategy {
    private $multiplier;
    private $promotionName;
    
    public function __construct($multiplier = 2.5, $promotionName = "Special Promotion") {
        $this->multiplier = $multiplier;
        $this->promotionName = $promotionName;
    }
    
    public function calculatePoints($orderAmount, $customerId = null, $orderItems = null) {
        $roundedAmount = floor($orderAmount);
        $points = floor($roundedAmount * $this->multiplier);
        
        error_log("{$this->promotionName}: floor($orderAmount) = $roundedAmount * {$this->multiplier} = $points points");
        
        return $points;
    }

    public function getStrategyName() {
        return $this->promotionName;
    }

    public function getDescription() {
        return "{$this->promotionName}: {$this->multiplier}x points";
    }
}