<?php
/**
 * Author: Tan Cheng Hong
 * Module: Rewards Module
 */

require_once 'PointCalculationStrategy.php';
require_once __DIR__ . '/../MenuItem.php';

class VIPPointStrategy implements PointCalculationStrategy {

    private $multiplier;

    public function __construct($multiplier = 1.5) {
        $this->multiplier = $multiplier;
    }

    public function calculatePoints($orderAmount, $customerId = null, $orderItems = null) {
        $roundedAmount = floor($orderAmount);
        $points = floor($roundedAmount * $this->multiplier);

        error_log("=== VIP STRATEGY DEBUG ===");
        error_log("Order Amount: $orderAmount");
        error_log("Base Points: $points");
        error_log("Order Items: " . json_encode($orderItems));

        $coffeeBonus = 0;

        if (!empty($orderItems)) {
            foreach ($orderItems as $index => &$item) {
                error_log("Processing item $index: " . json_encode($item));

                if (!isset($item['category']) && isset($item['item_id'])) {
                    $menuItem = new MenuItem();
                    $itemData = $menuItem->find($item['item_id']);

                    if ($itemData) {
                        $item['category'] = $itemData->category;
                        error_log("Found category for item {$item['item_id']}: {$itemData->category}");
                    } else {
                        error_log("NO category found for item {$item['item_id']}");
                    }
                }

                if (isset($item['category']) && strtolower($item['category']) === 'coffee') {
                    $itemBonus = (int) $item['quantity'] * 2;
                    $coffeeBonus += $itemBonus;
                    error_log("COFFEE BONUS: Item {$item['item_id']} qty {$item['quantity']} = +$itemBonus points");
                }
            }
        }

        $totalPoints = $points + $coffeeBonus;
        error_log("Final: $points base + $coffeeBonus coffee bonus = $totalPoints total");

        return $totalPoints;
    }

    public function getStrategyName() {
        return 'VIP Points';
    }

    public function getDescription() {
        return "VIP Customer ({$this->multiplier}x points + coffee bonus)";
    }
}
