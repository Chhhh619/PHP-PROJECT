<?php

require_once 'BaseModel.php';

class UserManagement extends BaseModel {
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = ['email', 'password_hash', 'role', 'is_active'];


    public function getAllUsersWithProfiles() {
        try {
            
            return $this->select('u.user_id, u.email, u.role, u.created_at, u.is_active, 
                                 CASE 
                                     WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                     WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                     ELSE u.email
                                 END as display_name,
                                 CASE 
                                     WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                     WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                     ELSE u.email
                                 END as full_name,
                                 c.phone, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                       ->from('users u')
                       ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                       ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                       ->orderBy('u.created_at', 'DESC')
                       ->get();
            
        } catch (Exception $e) {
            error_log("Error getting users: " . $e->getMessage());
            return [];
        }
    }


    public function searchUsers($searchTerm) {
        try {
            $searchTerm = '%' . trim($searchTerm) . '%';
            
           
            $emailMatches = $this->select('u.user_id')
                                ->from('users u')
                                ->where('u.email', 'LIKE', $searchTerm)
                                ->get();
            
            
            $firstNameMatches = $this->select('u.user_id')
                                    ->from('users u')
                                    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                                    ->where('c.first_name', 'LIKE', $searchTerm)
                                    ->get();
            
            
            $lastNameMatches = $this->select('u.user_id')
                                   ->from('users u')
                                   ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                                   ->where('c.last_name', 'LIKE', $searchTerm)
                                   ->get();
            
            
            $adminNameMatches = $this->select('u.user_id')
                                    ->from('users u')
                                    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                                    ->where('a.admin_name', 'LIKE', $searchTerm)
                                    ->get();
            
            
            $allUserIds = [];
            foreach (array_merge($emailMatches, $firstNameMatches, $lastNameMatches, $adminNameMatches) as $match) {
                $allUserIds[] = $match['user_id'];
            }
            
            if (empty($allUserIds)) {
                return [];
            }
            
            
            return $this->select('u.user_id, u.email, u.role, u.created_at, u.is_active,
                                 CASE 
                                     WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                     WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                     ELSE u.email
                                 END as display_name,
                                 CASE 
                                     WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                     WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                     ELSE u.email
                                 END as full_name,
                                 c.phone, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                       ->from('users u')
                       ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                       ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                       ->whereIn('u.user_id', array_unique($allUserIds))
                       ->orderBy('u.created_at', 'DESC')
                       ->get();
            
        } catch (Exception $e) {
            error_log("Search error: " . $e->getMessage());
            return [];
        }
    }


    public function getUsersByRole($role) {
        return $this->select('u.user_id, u.email, u.role, u.created_at, u.is_active,
                            CASE 
                                WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                ELSE u.email
                            END as display_name,
                            c.phone, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                    ->from('users u')
                    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                    ->where('u.role', $role)
                    ->orderBy('u.created_at', 'DESC')
                    ->get();
    }


    public function getUsersByStatus($isActive) {
        return $this->select('u.user_id, u.email, u.role, u.created_at, u.is_active,
                            CASE 
                                WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                ELSE u.email
                            END as display_name,
                            c.phone, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                    ->from('users u')
                    ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                    ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                    ->where('u.is_active', (int)$isActive)
                    ->orderBy('u.created_at', 'DESC')
                    ->get();
    }


    public function getUserWithProfile($userId) {
        try {
            return $this->select('u.*, c.first_name, c.last_name, c.phone, c.date_of_birth, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                       ->from('users u')
                       ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                       ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id')
                       ->where('u.user_id', (int)$userId)
                       ->first();
            
        } catch (Exception $e) {
            error_log("getUserWithProfile error: " . $e->getMessage());
            return null;
        }
    }


    public function getPaginatedUsers($page = 1, $perPage = 20, $filters = []) {
        try {
            $offset = ($page - 1) * $perPage;
            
            $query = $this->select('u.user_id, u.email, u.role, u.created_at, u.is_active,
                                  CASE 
                                      WHEN u.role = "customer" THEN COALESCE(CONCAT(c.first_name, " ", c.last_name), c.first_name, "Customer")
                                      WHEN u.role = "admin" THEN COALESCE(a.admin_name, "Admin")
                                      ELSE u.email
                                  END as display_name,
                                  c.phone, c.loyalty_points, a.admin_name, a.permissions, a.last_login')
                         ->from('users u')
                         ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                         ->leftJoin('admins a', 'u.user_id', '=', 'a.user_id');
            
            if (!empty($filters['role'])) {
                $query->where('u.role', $filters['role']);
            }
            
            if (isset($filters['is_active']) && $filters['is_active'] !== '') {
                $query->where('u.is_active', (int)$filters['is_active']);
            }
            
            return $query->orderBy('u.created_at', 'DESC')
                         ->limit($perPage, $offset)
                         ->get();
            
        } catch (Exception $e) {
            error_log("getPaginatedUsers error: " . $e->getMessage());
            return [];
        }
    }


    public function getUserCount($filters = []) {
        try {
            $query = $this->select('COUNT(*) as total')->from('users u');
            
            if (!empty($filters['role'])) {
                $query->where('u.role', $filters['role']);
            }
            
            if (isset($filters['is_active']) && $filters['is_active'] !== '') {
                $query->where('u.is_active', (int)$filters['is_active']);
            }
            
            $result = $query->first();
            return $result ? (int)$result['total'] : 0;
            
        } catch (Exception $e) {
            error_log("getUserCount error: " . $e->getMessage());
            return 0;
        }
    }


    public function toggleUserStatus($userId) {
        try {
            $user = $this->find($userId);
            if (!$user) {
                throw new Exception("User not found");
            }

            $newStatus = $user->is_active ? 0 : 1;
            return $this->updateById($userId, ['is_active' => $newStatus]);
            
        } catch (Exception $e) {
            error_log("Toggle status error: " . $e->getMessage());
            throw $e;
        }
    }

 
    public function getUserStats() {
        try {
            $stats = [];
            
            $stats['total_users'] = $this->count();
            $stats['active_users'] = $this->where('is_active', 1)->count();
            $stats['customers'] = $this->where('role', 'customer')->count();
            $stats['admins'] = $this->where('role', 'admin')->count();
            
            $thirtyDaysAgo = date('Y-m-d H:i:s', strtotime('-30 days'));
            $stats['recent_registrations'] = $this->where('created_at', '>=', $thirtyDaysAgo)->count();
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("Stats error: " . $e->getMessage());
            return [
                'total_users' => 0,
                'active_users' => 0,
                'customers' => 0,
                'admins' => 0,
                'recent_registrations' => 0
            ];
        }
    }


    public function softDelete($userId) {
        try {
            return $this->updateById($userId, ['is_active' => 0]);
        } catch (Exception $e) {
            error_log("Soft delete error: " . $e->getMessage());
            throw new Exception("Failed to deactivate user");
        }
    }


    public function emailExists($email, $excludeUserId = null) {
        try {
            $query = $this->where('email', $email);
            
            if ($excludeUserId) {
                $query->where('user_id', '!=', $excludeUserId);
            }
            
            return $query->count() > 0;
            
        } catch (Exception $e) {
            error_log("Email check error: " . $e->getMessage());
            return false;
        }
    }


    public function updateUserDetails($userId, $data) {
        try {
            $allowedFields = ['email', 'is_active'];
            $updateData = [];
            
            foreach ($data as $key => $value) {
                if (in_array($key, $allowedFields)) {
                    if ($key === 'email') {
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            throw new Exception("Invalid email format");
                        }
                        if ($this->emailExists($value, $userId)) {
                            throw new Exception("Email already exists");
                        }
                    }
                    $updateData[$key] = $value;
                }
            }
            
            if (empty($updateData)) {
                throw new Exception("No valid fields to update");
            }
            
            return $this->updateById($userId, $updateData);
            
        } catch (Exception $e) {
            error_log("Update error: " . $e->getMessage());
            throw $e;
        }
    }


    public function getActiveCustomers($limit = 50) {
        return $this->where('role', 'customer')
                   ->where('is_active', 1)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getRecentRegistrations($days = 7, $limit = 20) {
        $dateThreshold = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        return $this->where('created_at', '>=', $dateThreshold)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getInactiveUsers($limit = 50) {
        return $this->where('is_active', 0)
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function searchByEmail($email) {
        return $this->whereLike('email', "%{$email}%")
                   ->orderBy('created_at', 'DESC')
                   ->get();
    }


    public function getUsersByDateRange($startDate, $endDate) {
        return $this->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                   ->orderBy('created_at', 'DESC')
                   ->get();
    }


    public function countUsersByRole($role) {
        return $this->where('role', $role)->count();
    }


    public function countActiveUsers() {
        return $this->where('is_active', 1)->count();
    }

 
    public function bulkUpdateStatus($userIds, $isActive) {
        try {
            if (empty($userIds) || !is_array($userIds)) {
                throw new Exception("Invalid user IDs provided");
            }

            return $this->whereIn('user_id', $userIds)
                       ->updateWhere(['is_active' => (int)$isActive]);
            
        } catch (Exception $e) {
            error_log("Bulk update status error: " . $e->getMessage());
            throw new Exception("Failed to bulk update user status");
        }
    }


    public function getCustomersWithLoyaltyPoints($minPoints = 0, $limit = 50) {
        return $this->select('u.*, c.first_name, c.last_name, c.loyalty_points')
                   ->from('users u')
                   ->leftJoin('customers c', 'u.user_id', '=', 'c.user_id')
                   ->where('u.role', 'customer')
                   ->where('c.loyalty_points', '>=', $minPoints)
                   ->orderBy('c.loyalty_points', 'DESC')
                   ->limit($limit)
                   ->get();
    }


    public function getUsersByRegistrationMonth($year, $month) {
        $startDate = "{$year}-{$month}-01";
        $endDate = date('Y-m-t', strtotime($startDate));
        
        return $this->whereBetween('created_at', $startDate, $endDate . ' 23:59:59')
                   ->orderBy('created_at', 'DESC')
                   ->get();
    }


    public function updateAdminPermissions($userId, $adminName, $permissionsJson) {
        try {
            $this->beginTransaction();
            
            
            $user = $this->find($userId);
            if (!$user || $user->role !== 'admin') {
                throw new Exception("User not found or is not an admin");
            }
            
            // Admin table update still needs raw SQL due to specific table
            $sql = "UPDATE admins SET admin_name = :admin_name, permissions = :permissions WHERE user_id = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':admin_name', $adminName);
            $stmt->bindParam(':permissions', $permissionsJson);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            
            $success = $stmt->execute();
            
            if ($success && $stmt->rowCount() > 0) {
                $this->commit();
                error_log("Admin permissions updated for user {$userId}: {$adminName}");
                return true;
            } else {
                $this->rollback();
                throw new Exception("No admin record found to update");
            }
            
        } catch (Exception $e) {
            $this->rollback();
            error_log("Update admin permissions error: " . $e->getMessage());
            throw $e;
        }
    }


    public function getAdminPermissions($userId) {
        try {
            $result = $this->select('permissions')
                          ->from('admins')
                          ->where('user_id', (int)$userId)
                          ->first();
            
            if ($result) {
                $permissions = json_decode($result['permissions'], true);
                return $permissions ?: [];
            }
            
            return [];
            
        } catch (Exception $e) {
            error_log("Get admin permissions error: " . $e->getMessage());
            return [];
        }
    }

    public function adminHasPermission($userId, $permission) {
        try {
            $permissions = $this->getAdminPermissions($userId);
            return isset($permissions[$permission]) && $permissions[$permission] === true;
        } catch (Exception $e) {
            error_log("Check admin permission error: " . $e->getMessage());
            return false;
        }
    }

    public function getAvailablePermissions() {
        return [
            'user_management' => [
                'name' => 'User Management',
                'description' => 'Manage customers and admin accounts',
                'icon' => 'fas fa-users',
                'color' => 'primary'
            ],
            'menu_management' => [
                'name' => 'Menu Management', 
                'description' => 'Add, edit, and manage menu items',
                'icon' => 'fas fa-utensils',
                'color' => 'success'
            ],
            'order_management' => [
                'name' => 'Order Management',
                'description' => 'View and manage customer orders',
                'icon' => 'fas fa-shopping-cart',
                'color' => 'warning'
            ],
            'review_management' => [
                'name' => 'Review Management',
                'description' => 'Manage customer reviews and ratings',
                'icon' => 'fas fa-star',
                'color' => 'dark'
            ],
            'reports' => [
                'name' => 'Reports & Analytics',
                'description' => 'Access sales reports and analytics',
                'icon' => 'fas fa-chart-bar',
                'color' => 'info'
            ],
            'system_settings' => [
                'name' => 'System Settings',
                'description' => 'Modify system configurations',
                'icon' => 'fas fa-cogs',
                'color' => 'danger'
            ]
        ];
    }


    public function getAllAdminsWithPermissions() {
        try {
            $admins = $this->select('u.user_id, u.email, u.created_at, u.is_active, a.admin_name, a.permissions, a.last_login')
                          ->from('users u')
                          ->join('admins a', 'u.user_id', '=', 'a.user_id', 'INNER')
                          ->where('u.role', 'admin')
                          ->orderBy('a.admin_name', 'ASC')
                          ->get();
            
           
            foreach ($admins as &$admin) {
                $admin['parsed_permissions'] = json_decode($admin['permissions'], true) ?: [];
                $admin['permission_count'] = count(array_filter($admin['parsed_permissions']));
            }
            
            return $admins;
            
        } catch (Exception $e) {
            error_log("Get all admins error: " . $e->getMessage());
            return [];
        }
    }


    public function validatePermissions($permissions) {
        $availablePermissions = array_keys($this->getAvailablePermissions());
        $validPermissions = [];
        
        foreach ($permissions as $permission) {
            if (in_array($permission, $availablePermissions)) {
                $validPermissions[] = $permission;
            }
        }
        
        return $validPermissions;
    }


    public function getAllUsers() {
        return $this->orderBy('created_at', 'DESC')->get();
    }
    
    public function getActiveUsers() {
        return $this->where('is_active', 1)->orderBy('created_at', 'DESC')->get();
    }
    
    public function getCustomers() {
        return $this->where('role', 'customer')->orderBy('created_at', 'DESC')->get();
    }
    
    public function getAdmins() {
        return $this->where('role', 'admin')->orderBy('created_at', 'DESC')->get();
    }
}