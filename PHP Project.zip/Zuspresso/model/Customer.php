<?php
/**
author : Cheng Jun Yang
 */

require_once 'User.php';
require_once 'LoyaltyService.php';

class Customer extends User {
    protected $table = 'customers';
    protected $primaryKey = 'customer_id';
    protected $fillable = ['user_id', 'first_name', 'last_name', 'phone', 'date_of_birth', 'loyalty_points', 'tier', 'points_version'];
    
    protected $customer_id;
    protected $first_name;
    protected $last_name;
    protected $phone;
    protected $date_of_birth;
    protected $loyalty_points;
    protected $tier;
    
    
    
    
  
    public function loadSpecificData() {
        if (!$this->user_id) return false;
        
        try {
           
            $customerModel = new class extends BaseModel {
                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
                protected $fillable = ['user_id', 'first_name', 'last_name', 'phone', 'date_of_birth', 'loyalty_points', 'tier'];
            };
            
            $customer = $customerModel->where('user_id', '=', $this->user_id)->first();
            
            if ($customer) {
                $this->setCustomerProperties($customer);
                return true;
            }
            return false;
            
        } catch (Exception $e) {
            error_log("Customer data loading failed: " . $e->getMessage());
            return false;
        }
    }
    
    protected function setCustomerProperties($data) {
        $this->customer_id = $data['customer_id'] ?? null;
        $this->first_name = $data['first_name'] ?? null;
        $this->last_name = $data['last_name'] ?? null;
        $this->phone = $data['phone'] ?? null;
        $this->date_of_birth = $data['date_of_birth'] ?? null;
        $this->loyalty_points = $data['loyalty_points'] ?? 0;
        $this->tier = $data['tier'] ?? 'Bronze';
    }
    
    public function setAttributes($attributes) {
        $this->attributes = $attributes;
        $this->setCustomerProperties($attributes);
        return $this;
    }
    
    
    public function getDisplayName() {
        return trim($this->first_name . ' ' . $this->last_name) ?: ($this->email ?? 'Guest');
    }
   
    public function getPermissions() {
        return [
            'place_order' => true,
            'view_menu' => true,
            'manage_profile' => true,
            'view_order_history' => true,
            'redeem_rewards' => true,
            'rate_products' => true,
            'view_loyalty_points' => true
        ];
    }
    
   
    public function getDashboardUrl() {
        return '/view/customer/dashboard.php';
    }
    
    public function getLoyaltyPoints() {
        $loyaltyService = new LoyaltyService();
        return $loyaltyService->getCustomerPoints($this->customer_id);
    }
    
    public function getLoyaltyTier() {
        $loyaltyService = new LoyaltyService();
        return $loyaltyService->getLoyaltyTier($this->customer_id);
    }
    
    public function getTierInfo() {
        $loyaltyService = new LoyaltyService();
        return $loyaltyService->getTierInfo($this->customer_id);
    }
    
    public function getLoyaltySummary() {
        $loyaltyService = new LoyaltyService();
        return $loyaltyService->getCustomerLoyaltySummary($this->customer_id);
    }
    
   
public function updateProfile($first_name, $last_name, $phone = null, $date_of_birth = null) {
    if (!$this->isValidName($first_name) || !$this->isValidName($last_name)) {
        throw new InvalidArgumentException("Invalid name format");
    }
    
    if ($phone && !$this->isValidPhone($phone)) {
        throw new InvalidArgumentException("Invalid phone format");
    }
    
    try {
        
        $customerModel = new CustomerModel($this->db);
        
        $data = [
            'first_name' => $this->sanitizeString($first_name),
            'last_name' => $this->sanitizeString($last_name),
            'phone' => $phone ? $this->sanitizeString($phone) : null,
            'date_of_birth' => $date_of_birth
        ];
        
      
        $result = $customerModel->where('user_id', '=', $this->user_id)->updateWhere($data);
        
        if ($result) {
         
            $this->first_name = $first_name;
            $this->last_name = $last_name;
            $this->phone = $phone;
            $this->date_of_birth = $date_of_birth;
        }
        
        return $result;
        
    } catch (Exception $e) {
        error_log("Customer profile update failed: " . $e->getMessage());
        throw $e; 
    }
}
    
    
    public function getRecentOrders($limit = 5) {
        try {
            require_once 'Order.php';
            
            
            $orderModel = new class extends BaseModel {
                protected $table = 'orders';
                protected $primaryKey = 'order_id';
            };
            
            return $orderModel->where('customer_id', '=', $this->customer_id)
                            ->orderBy('created_at', 'DESC')
                            ->limit($limit)
                            ->get();
                            
        } catch (Exception $e) {
            error_log("Get recent orders failed: " . $e->getMessage());
            return [];
        }
    }
  
    public function getOrderStats() {
        try {
           
            $orderModel = new class extends BaseModel {
                protected $table = 'orders';
                protected $primaryKey = 'order_id';
            };
            
            $orders = $orderModel->where('customer_id', '=', $this->customer_id)->get();
            
            $totalOrders = count($orders);
            $totalSpent = 0;
            $lastOrderDate = null;
            
            foreach ($orders as $order) {
                if ($order['order_status'] !== 'cancelled') {
                    $totalSpent += $order['total_amount'];
                    if (!$lastOrderDate || $order['created_at'] > $lastOrderDate) {
                        $lastOrderDate = $order['created_at'];
                    }
                }
            }
            
            return [
                'total_orders' => $totalOrders,
                'total_spent' => $totalSpent,
                'average_order_value' => $totalOrders > 0 ? $totalSpent / $totalOrders : 0,
                'last_order_date' => $lastOrderDate
            ];
            
        } catch (Exception $e) {
            error_log("Get order stats failed: " . $e->getMessage());
            return [
                'total_orders' => 0,
                'total_spent' => 0,
                'average_order_value' => 0,
                'last_order_date' => null
            ];
        }
    }
    
  
    public static function exists($customer_id) {
        try {
           
            $customerModel = new class extends BaseModel {
                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
            };
            
            $count = $customerModel->where('customer_id', '=', $customer_id)->count();
            return $count > 0;
            
        } catch (Exception $e) {
            error_log("Customer exists check failed: " . $e->getMessage());
            return false;
        }
    }
    
    
    public static function createCustomer($user_id, $first_name, $last_name, $phone = null, $date_of_birth = null) {
        try {
            $instance = new self();
            
            if (!$instance->isValidName($first_name) || !$instance->isValidName($last_name)) {
                throw new InvalidArgumentException("Invalid name format");
            }
            
            if ($phone && !$instance->isValidPhone($phone)) {
                throw new InvalidArgumentException("Invalid phone format");
            }
            
          
            $customerModel = new class extends BaseModel {
                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
                protected $fillable = ['user_id', 'first_name', 'last_name', 'phone', 'date_of_birth', 'loyalty_points', 'tier'];
            };
            
            $result = $customerModel->create([
                'user_id' => $user_id,
                'first_name' => $instance->sanitizeString($first_name),
                'last_name' => $instance->sanitizeString($last_name),
                'phone' => $phone ? $instance->sanitizeString($phone) : null,
                'date_of_birth' => $date_of_birth,
                'loyalty_points' => 0,
                'tier' => 'Bronze'
            ]);
            
            if ($result) {
                $instance->setCustomerProperties($result->toArray());
                return $instance;
            }
            
            return null;
            
        } catch (Exception $e) {
            error_log("Create customer failed: " . $e->getMessage());
            return null;
        }
    }
   

    public static function getByUserId($user_id) {
        try {
          
            $customerModel = new class extends BaseModel {
                protected $table = 'customers';
                protected $primaryKey = 'customer_id';
            };
            
            $customerData = $customerModel->where('user_id', '=', $user_id)->first();
            
            if ($customerData) {
                $customer = new self();
                $customer->setCustomerProperties($customerData);
                $customer->user_id = $user_id;
                return $customer;
            }
            
            return null;
            
        } catch (Exception $e) {
            error_log("Get customer by user ID failed: " . $e->getMessage());
            return null;
        }
    }
    
   
    public function getProfileData() {
        return [
            'user_id' => $this->user_id,
            'email' => $this->email,
            'role' => $this->role,
            'customer_id' => $this->customer_id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'phone' => $this->phone,
            'date_of_birth' => $this->date_of_birth,
            'loyalty_points' => $this->loyalty_points,
            'tier' => $this->tier,
            'display_name' => $this->getDisplayName(),
            'created_at' => $this->created_at,
            'is_active' => $this->is_active
        ];
    }
    
   
    protected function isValidName($name) {
        return !empty($name) && strlen(trim($name)) >= 2 && preg_match('/^[a-zA-Z\s\'-]+$/', $name);
    }
    
    protected function isValidPhone($phone) {
        $digits = preg_replace('/\D/', '', $phone);
        return strlen($digits) >= 10 && strlen($digits) <= 15;
    }
    
    protected function sanitizeString($string) {
        return trim(htmlspecialchars($string, ENT_QUOTES, 'UTF-8'));
    }
    
    public function __get($property) {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
        return parent::__get($property);
    }
    
   
    public function getCustomerId() { return $this->customer_id; }
    public function getFirstName() { return $this->first_name; }
    public function getLastName() { return $this->last_name; }
    public function getPhone() { return $this->phone; }
    public function getDateOfBirth() { return $this->date_of_birth; }
    public function getTier() { return $this->tier; }
}

class CustomerModel extends BaseModel {
    protected $table = 'customers';
    protected $primaryKey = 'customer_id';
    protected $fillable = ['user_id', 'first_name', 'last_name', 'phone', 'date_of_birth', 'loyalty_points', 'tier'];
    
    public function __construct($database_connection = null) {
        if ($database_connection) {
            $this->db = $database_connection;
        } else {
            parent::__construct();
        }
    }
    
    public function updateByUserId($user_id, $data) {
        $data = $this->sanitizeInput($data);
        $filteredData = $this->filterFillable($data);

        if (empty($filteredData)) {
            throw new Exception("No valid data provided for update");
        }

        $setParts = [];
        foreach ($filteredData as $key => $value) {
            $setParts[] = "$key = :$key";
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $setParts) . " WHERE user_id = :user_id";
        $stmt = $this->db->prepare($sql);

        foreach ($filteredData as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindValue(':user_id', $user_id);

        return $stmt->execute();
    }
}